"""Keep the original challenge result and each selected physical card together on the browser save."""
from crisisfire.game import pve, pve_progress, pve_rewards

KEY = "webPveCards"
FLIP, BUY, COLLECT = 1245268, 1245270, 1245279

def remember(world, session, fields, mode, detail):
    role = world.role(session.roleid)
    outcome = next(m["fields"] for m in session.messages if m["id"] == pve.SC_RESULT)
    state = dict(matchId=fields["matchId"], ruleId=mode["id"], won=bool(outcome["win"]),
                 wave=outcome["round"], playerScores=outcome["scores"], detail=detail,
                 grade=pve_rewards.grade_for(mode, detail["sumscore"]),
                 monthly=pve_progress.month_active(role), rolls={}, closed=False,
                 remaining=pve_rewards.daily_state(role)["left"])
    world.merge_role_data(role.roleid, **{KEY: state})

async def dispatch(world, session, request):
    cmd = request.get("id")
    if cmd not in (FLIP, BUY, COLLECT):
        return False
    role = world.role(session.roleid)
    saved = role.data.get(KEY)
    fields = request.get("fields", {})
    if not saved or saved.get("closed") or saved["matchId"] != fields.get("matchId"):
        return True
    state = dict(saved)
    if cmd == FLIP:
        slot = fields.get("slot")
        if type(slot) is not int or not 0 <= slot <= 4 or str(slot) in state["rolls"]:
            return True
        await pve_rewards.flip(session, {"boxtype": 3 if slot == 4 else 1})
        reply = next(m["fields"]["res"] for m in reversed(session.messages) if m["id"] == pve_rewards.SC_CARD)
        if reply > 0:
            state["rolls"] = {**state["rolls"], str(slot): reply}
    elif cmd == BUY:
        await pve_rewards.buy_times(session, {})
    else:
        await pve_rewards.collect(session, {})
        state["closed"] = True
    state["remaining"] = pve_rewards.daily_state(world.role(role.roleid))["left"]
    world.merge_role_data(role.roleid, **{KEY: state})
    return True
