"""全民枪战 (com.crisisfire.android.putao) private-server implementation."""

__version__ = "0.1.0"
