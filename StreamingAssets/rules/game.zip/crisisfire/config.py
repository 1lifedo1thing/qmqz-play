"""Server-side configuration.

Everything the client needs to reach us lives here: the bootstrap HTTP base
URL that replaces ``AndroidDelegate.ResourceSite`` and the GS/Room TCP ports.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _env(name: str, default: str) -> str:
    v = os.environ.get(name)
    return v if v else default


# 手机 APK 里改不了环境变量（ServerService 只传命令行参数），
# 所以额外支持一个"开关文件"——在手机上用任何文件管理器建一个就行：
#   /sdcard/qc-aim.txt   （或 /sdcard/Download/qc-aim.txt）
# 内容（任选其一）：
#   2                       → 锁头
#   mode=2 / fov=0 / ids=100004,100003
def _aim_file() -> dict:
    for path in ("/sdcard/qc-aim.txt", "/sdcard/Download/qc-aim.txt"):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
        except OSError:
            continue
        out = {}
        for line in text.replace(";", "\n").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                out[k.strip().lower()] = v.strip()
            elif line.isdigit():
                out.setdefault("mode", line)
        return out
    return {}


_AIM = _aim_file()

@dataclass
class Config:
    # ---- listener -------------------------------------------------------
    # 0.0.0.0 so an Android device/emulator on the LAN can reach us.
    host: str = field(default_factory=lambda: _env("CF_HOST", "0.0.0.0"))

    # Game server (GS / lobby).  The client connects here after bootstrap.
    gs_port: int = field(default_factory=lambda: int(_env("CF_GS_PORT", "10000")))

    # Room server (own TCP connection, 10s keepalive on the client side).
    room_port: int = field(default_factory=lambda: int(_env("CF_ROOM_PORT", "10001")))

    # HTTP bootstrap: /forceup/..., /versionInfo, /serverlist
    http_port: int = field(default_factory=lambda: int(_env("CF_HTTP_PORT", "8080")))

    # Web GM panel (browser-based admin console).
    # Bound to loopback by default: nothing outside this machine can reach it,
    # so no password is needed.  Only when you deliberately expose it
    # (--gm-host 0.0.0.0) does a password become mandatory.
    gm_host: str = field(default_factory=lambda: _env("CF_GM_HOST", "127.0.0.1"))
    gm_port: int = field(default_factory=lambda: int(_env("CF_GM_PORT", "8090")))
    gm_password: str = field(default_factory=lambda: _env("CF_GM_PASSWORD", ""))

    # Address advertised to the client in the serverlist.  Must be reachable
    # from the device: use the LAN IP of this machine, or 10.0.2.2 for the
    # stock Android emulator.
    public_host: str = field(default_factory=lambda: _env("CF_PUBLIC_HOST", "127.0.0.1"))

    # 宣告给客户端的地址从哪来：
    #   fixed = 永远用 public_host（老行为，模拟器/端口映射场景靠手动填）
    #   auto  = 用「这个客户端连进来的那个本机地址」——局域网客户端收到
    #           192.168.x.x，皎月连/ZeroTier 客户端收到 10.x 虚拟 IP，
    #           同机 127.0.0.1 客户端收到 127.0.0.1。多网卡同时玩不用配 IP。
    advertise_mode: str = field(
        default_factory=lambda: _env("CF_ADVERTISE", "fixed").strip().lower())

    # ---- client bootstrap ----------------------------------------------
    # On-disk localVersion of the APK is "4"; report localversion so the
    # updater short-circuits (see Updater.StartUpdate).
    local_version: int = field(default_factory=lambda: int(_env("CF_LOCAL_VERSION", "4")))

    # Halt the client with Application.Quit() when ForceUpdate reports a
    # higher code -- always advertise 0.
    force_update_code: int = 0

    # The path segment the APK patched ResourceSite to.  AndroidDelegate
    # overrode ResourceSite with ".../tv4", so keep that shape.
    resource_site_path: str = field(default_factory=lambda: _env("CF_SITE_PATH", "tv4"))

    # ---- gameplay tuning ------------------------------------------------
    server_name: str = field(default_factory=lambda: _env("CF_SERVER_NAME", "本地私服"))
    # 黑暗模式（GameMode 9）的「黑」全部在客户端做：
    #     CurrentRoom.isBlackMode => roomInfo.gamemode == 9
    # 然后 ShaderFilter 压暗、场景材质换暗色。服务端只能通过 gamemode 这一个
    # 字段控制它。想**保留黑暗模式的规则**（id=999：50 杀、10 秒复活、上限 8）
    # 但用**正常光照**，就把 roominfo.gamemode 发成 1（规则仍按 levelid=999 走）。
    #   CF_BLACK_MODE_DARK=1  -> 要回真正的黑夜
    black_mode_dark: bool = field(
        default_factory=lambda: _env("CF_BLACK_MODE_DARK", "0").strip() in ("1", "true", "yes"))
    server_identifier: str = field(default_factory=lambda: _env("CF_SERVER_ID", "local-1"))
    unlock_equipment: bool = field(
        default_factory=lambda: _env("CF_UNLOCK_EQUIPMENT", "0").strip().lower() in ("1", "true", "yes"))
    # 皮肤武器兜底：把非基础款（tex != 0）换成基础款，防止**旧客户端**因为
    # 「第一人称模型名不一致」在出生后静默退出战斗（见 battle.sanitize_equipmap）。
    # 装了带 SkinQuit 补丁的客户端后，把 CF_SKIN_SANITIZE 设成 0 就能让枪皮回来。
    # ------------------------------------------------------------------
    # 服务端「自瞄 / 锁头」（只在本机私服用，别开在公共服）
    #   CF_AIM_ASSIST=0  关闭（默认）
    #   CF_AIM_ASSIST=1  锁最近敌人（每一枪强制命中）
    #   CF_AIM_ASSIST=2  锁最近敌人 + 必中头部
    # CF_AIM_ASSIST_FOV：只锁瞄具锥角内的目标（度；0 = 360° 全向锁）
    # ------------------------------------------------------------------
    # PvP 房间里自动加入的人机数量（服务端侧假玩家，站桩靶子）。
    #   CF_BOTS=0 关闭（默认，保持原有行为）
    #   CF_BOTS=2 每局加 2 个机器人（一边一个）
    # 单回合计时（秒）。客户端 HUD 的倒计时读的就是这个值；
    # CF_ROUND_TIME 设很大（如 999999）就等于「没有倒计时」。
    round_time: int = field(default_factory=lambda: int(_env("CF_ROUND_TIME", "900") or 900))
    bots_per_room: int = field(default_factory=lambda: int(_env("CF_BOTS", "0") or 0))
    # 人机怎么"活"起来 —— 两条互斥的路，只能选一条（原因见下）：
    #
    # ① CF_BOTS_DRIVE=1（默认）：**服务端驱动**。服务端每 tick 改机器人的
    #    syncpos 并用 `ScRoleStatusSync(1441895)` 推给客户端，攻击由服务端裁决后
    #    用 `ScShoot` 下发。客户端把机器人当成"另一个远程真人"来渲染。
    # ② CF_BOTS_AI=1：下发 `ScManageAI(1441905)`，让**客户端**跑它自带的
    #    `Robot : StateMachine`（会寻路、会找掩体、会换弹）。
    #
    # 两条不能同时开：`ClientManager.RoleStatusSync` 对 `DataPool.IsRelated(key)`
    # 的角色直接跳过，而 `IsRelated = IsHero || IsRobot`、`IsRobot` 正是
    # ManageAI 写进 `robots` 字典的那个键。一旦走了 ②，服务端推的位置全部作废。
    # ②在真机上还没跑起来（`Robot` 的心跳只有 `AArsenal` 的 TPS 上枪分支这一个
    # 入口，服务端侧无法触发，见 HANDOFF 第九轮），所以默认用 ①。
    bots_drive: bool = field(default_factory=lambda: _env("CF_BOTS_DRIVE", "1") != "0")
    bots_ai: bool = field(default_factory=lambda: _env("CF_BOTS_AI", "0") != "0")
    bots_ai_level: int = field(
        default_factory=lambda: int(_env("CF_BOTS_AI_LEVEL", "2") or 2))
    # 挑战模式（PVE，gameMode 12）刷怪。默认开（CF_PVE=0 可关）。
    # 之前默认 0，结果选挑战模式进图后一只怪都没有。
    pve_enabled: int = field(default_factory=lambda: int(_env("CF_PVE", "1") or 0))
    aim_assist: int = field(default_factory=lambda: int(_env("CF_AIM_ASSIST", str(_AIM.get("mode", "0")))))
    aim_assist_fov: float = field(
        default_factory=lambda: float(_env("CF_AIM_ASSIST_FOV", str(_AIM.get("fov", "0")))))
    # 只对指定 roleid 生效（逗号分隔）。留空 = 房间里所有开枪的人都锁。
    # 例：CF_AIM_ASSIST_IDS=100004  -> 只有 100004 这个号有锁头。
    aim_assist_ids: str = field(
        default_factory=lambda: _env("CF_AIM_ASSIST_IDS", str(_AIM.get("ids", ""))))
    # 【v63-2】真人命中宽容锥（服务端命中兜底的"瞄偏/坐标脱节"救援）。
    # 只在主射线判定没命中时才触发，把瞄准锥内最近的非队友补判为命中——
    # 专门救黑暗模式那种"看不清->瞄不准、小图贴脸坐标脱节"导致的打空。
    # 0 = 关闭（纯原始细射线）；>0 当作锥角缩放倍率（默认 1.0）。
    # 锥角随距离收紧：<=4m 用 40 度 x 倍率，之后线性收到 5 度；硬上限 16m。
    player_hit_assist: float = field(
        default_factory=lambda: float(_env("CF_PLAYER_HIT_ASSIST", "1.0") or "1.0"))


    skin_sanitize: bool = field(
        default_factory=lambda: _env("CF_SKIN_SANITIZE", "0").strip() not in ("0", "false", "no"))
    server_group: int = field(default_factory=lambda: int(_env("CF_SERVER_GROUP", "0")))
    server_status: int = 1          # 1 = up (0 shows the maintenance string)

    # Value handed to the client in ServerIDResponse; the client does
    # int.Parse(ASCII(serverid)) so it MUST be digits.
    server_id: int = field(default_factory=lambda: int(_env("CF_SERVER_ID_NUM", "1")))

    # ---- VIP / recharge ---------------------------------------------------
    # `UserManager.VipStatus` is `RechargeData.vipLevelCurrent`, written only by
    # ScVipCashSync.  Its default of -1 blocks a lot of content:
    #
    #     VIP >= 1   PackPanel 卖英雄级武器礼包, 免费聊天板
    #     VIP >= 3   神秘转盘 (RoulettePanel), 世界聊天
    #     VIP >= 5   赠送功能
    #     VIP >= 12  超级军备 (GachaWindow VIP_BIG_GACHA)
    #
    # `cash_all` is the cumulative recharge the VIP tier is derived from
    # (Vip table: VIP1=600, VIP3=10000, VIP12=500000), and it also gates the
    # 幸运转盘 via `RechargeManager.CanPlayRoulette => accumulateValue > 0`.
    # Default 500000 => VIP 12, which opens everything above.
    default_cash_all: int = field(
        default_factory=lambda: int(_env("CF_DEFAULT_CASH", "500000")))

    # 登录时一次性补发的传奇改装卡张数（0 = 不发）。
    # 见 equip.grant_login_test_cards，marker 保证每个账号只补一次。
    # v59 曾默认 500 张做测试，2.0.0 起恢复为 0（不发）；需要时用
    # CF_TEST_LEGEND_CARDS=500 启动即可。
    test_legend_cards: int = field(
        default_factory=lambda: int(_env("CF_TEST_LEGEND_CARDS", "0")))

    # 【v50】狂龙芯片 addTime 每一点的出生无敌加成系数。
    # 官方文案按 20%/点显示（addTime * 20），实际系数却是 0.01（=1%/点），
    # 用户要求「改成 20 倍」→ 对齐文案用 0.20。改回 0.01 可恢复 v49 行为。
    chip_time_scale: float = field(
        default_factory=lambda: float(_env("CF_CHIP_TIME_SCALE", "0.20")))

    # Keepalive: the client's CheckAlive() drops us after 50s idle (GS) and
    # 10s idle (room).  Ping well inside those windows.
    gs_idle_timeout: float = 50.0
    room_idle_timeout: float = 10.0

    # 【v49】新建房间默认带上「自动瞄准」标志位（RoomInfo.flags bit 3 = 8）。
    # 客户端本来就有完整实现（DataPool.AutoAiming → DetectAssistor 球形检测
    # → TouchRotator 把视角吸附到目标），只是私服建房 flags 恒 0，于是联机
    # 全都没有这个功能；离线机器人关卡走 OfflineData.IsAutoAim（默认 true）。
    # 0 = 关回 v48 行为（房主仍可在建房界面手动打开）。
    room_auto_aim: int = field(
        default_factory=lambda: int(_env("CF_ROOM_AUTOAIM", "1")))

    max_players: int = field(default_factory=lambda: int(_env("CF_MAX_PLAYERS", "200")))

    # 生化模式的人数门槛。
    #
    # 官方 `GameRule.roomMinTeamer = 8`，但**客户端代码里根本没有这个字段** ——
    # 真正卡住开始的是 RoomWindow：
    #
    #     if (enabled && flag && IsDialogFormEmpty && CurrentRoom.instance.IsFull)
    #         StartCoroutine(ReadCountdown(125));
    #     // CurrentRoom
    #     public bool IsFull => playerLimits == getUserSize();
    #
    # `IsFull` 是「满员」而不是「够人」，而 playerLimits 就是服务端发的
    # roominfo.playerlimits。生化规则里 maxTeamer = 0，原来算出来是 8，
    # 于是**客户端一直等 8 个人满员才肯倒计时**。
    #
    # 所以把生化房的 playerlimits 直接设成想要的人数即可。
    # 上限仍然夹在官方 roomMinTeamer 之内，不会比原版更宽松。
    biochem_min_players: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_MIN_PLAYERS", "2")))

    # 仅用于**本地调试的确定性开关**：指定某 roleid 固定当母体（ScBioBoss）。
    # 默认 0 = 保持 `random.choice`，发布形态行为与原版一致、不受本项影响。
    # 存在的理由：母体随机到 12 人里的某一个，想验「僵尸砍人类→服务端判感染→
    # ScBioInfected」这条链，靠多跑回合太贵（一回合 180 秒）。
    biochem_matrix_role: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_MATRIX_ROLE", "0") or 0))

    # 生化模式「人类英雄」出现时机：回合剩余多少秒时把还活着的人类升成
    # 英雄（ScBioHero 1441970）。0 = 关闭。
    #
    # 客户端 `ClientManager.Response(ScBioHero)` 收到名单后自己完成全部表现：
    #     IsHunter = true
    #     hpmax *= 50（不足 5000 时），hp = hpmax
    #     actorid = 1999
    #     equips = {50: 8001}        // 英雄战刀
    #     Born(playerData, online: true)
    # 所以服务端只要把「谁变英雄」和对应的 hp 对齐（否则服务端按 100 血判死、
    # 客户端按 5000 血显示），其余不用再发 ScBorn。
    # 剩余多少秒时把幸存的 ≤2 个人类升成英雄（33s -> 45s -> 52s）
    biochem_hero_time: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_HERO_TIME", "52")))
    biochem_hero_hp: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_HERO_HP", "5000")))

    # ------------------------------------------------------------------
    # 生化伤害 / 成长
    #
    # 士气（人类等级，GameRule.humanAtkPerLv=20 / humanMaxLv=10）：
    #   官方是**加固定点数**：伤害 += humanAtkPerLv × level
    #   LV.10 = 基础伤害 +200 点（不是 ×3.0）。
    #   低伤高射速枪收益最大（格洛克18 12→212），狙击最吃亏（SVD 115→315）。
    #   20 对应 GameRule.humanAtkPerLv；改这个值就是改官方的每级加伤。
    # ------------------------------------------------------------------
    biochem_morale_per_point: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_MORALE_PER_PT", "20")))

    # 旧版「每级 +20%」的乘算系数。官方是加点数，这个字段已停用，
    # 只保留给 `damage.morale_multiplier()`（调试/兼容）用。
    biochem_morale_per_level: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_MORALE_PER_LV", "0.2")))

    # 被感染的幽灵血量：基础值 + 每多一人加成（默认 1200 固定，与母体分开算）。
    # 母体仍走 BioProperty.mumHpBase + hpPerCapita*(人数-1)。
    biochem_infected_hp_base: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_INFECTED_HP", "1200")))
    biochem_infected_hp_per_capita: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_INFECTED_HP_PER", "0")))

    # 有人类被感染时，其余存活人类各涨几级士气（0 = 关闭）。
    # 【狂暴版】1 → 2 级。
    biochem_infect_morale_levels: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_INFECT_MORALE", "2")))

    # 强化天赋（ResearchTalent）每级的伤害加成倍率。
    # 配置表 perLevel=1 表示「每级 +1%」，太小；这里按倍数放大。
    research_talent_scale: float = field(
        default_factory=lambda: float(_env("CF_RESEARCH_SCALE", "1")))

    # 防弹衣（Armor）是否参与伤害裁决。0 = 关闭（保持旧行为，ac 恒 0）。
    armor_enabled: bool = field(
        default_factory=lambda: _env("CF_ARMOR", "1").strip() not in ("0", "false", "no"))

    # ------------------------------------------------------------------
    # 人类基础血量
    #
    # 原来 `battle.born` 里写死 100。但枪械 basicDamage 是按 100 血设计的
    # （AK 26 / 沙鹰 38 / 巴雷特 160），生化伤害再翻几倍之后 100 血就是
    # 「谁先看到谁赢」。原版靠「血量增强天赋 + 芯片 + 重甲」拉开生存空间。
    #
    # 实际血量 = 这个值 + Talent.type=1(血量增强) + 已购礼包芯片 Gift.addHp
    # 想把整体血量拉高就改这里（150 / 200），天赋和芯片会自动叠加。
    # ------------------------------------------------------------------
    human_base_hp: float = field(
        default_factory=lambda: float(_env("CF_HUMAN_HP", "100")))

    # ------------------------------------------------------------------
    # 枪械强化（Part.json / Fusion.json）
    #
    # 强化点（studyPoint）在原版只从转盘和月卡来，本地私服没有稳定来源，
    # 强化界面会一直显示 0。登录时不足这个数就补到该值（只补不扣）。
    # 设 0 = 关闭补点，完全靠转盘/月卡。
    # ------------------------------------------------------------------
    research_start_points: int = field(
        default_factory=lambda: int(_env("CF_RESEARCH_POINTS", "20000")))

    # 卖碎片：每片换多少钻石（蓝宝石，即 account 的 gold 字段）。
    # 客户端出售弹窗读 Fusion 表的 gem 字段显示收益，默认 200 钻石/片。
    # 注意：role.diamond 字段在这个游戏里存的是「荣誉(bloodGem)」，真正的
    # 钻石是 role.gold（UserManager.CanBuy 用的蓝宝石）。
    # 【v46】用户口径：出售收益改成 **20 钻石/片**（原来是 200，太值钱）。
    # 另外服务端强制「至少留 1 片」：手里只有 1 片时不允许出售。
    parts_diamond_per_piece: int = field(
        default_factory=lambda: int(_env("CF_PARTS_DIAMOND", "20")))

    # 【v46】幸运转盘（GemLottery）。
    # 单抽实际扣 20 钻 / 十连 200 钻，是**客户端本地扣的**（Price id 9），
    # 服务端不再扣费；下面两个值只决定「奖池累积」和「幸运积分」。
    #   每抽往奖池累 200 钻（十连 2000）—— 奖池大奖按 50% 派发。
    #   每抽给 20 幸运积分（十连 200）。
    roulette_pool_gain: int = field(
        default_factory=lambda: int(_env("CF_ROULETTE_POOL_GAIN", "200")))
    roulette_points_per_spin: int = field(
        default_factory=lambda: int(_env("CF_ROULETTE_POINTS", "20")))

    # 【v47】手雷「生化打击」的整体倍率：生化房里伤害 = Grenade.bioDamage × 该值。
    # 用户口径「bioDamage 全部乘 10 倍」，所以默认 10；设 1.0 就回到表里的原值。
    grenade_bio_scale: float = field(
        default_factory=lambda: float(_env("CF_GRENADE_BIO_SCALE", "10")))

    # 强化点回收：一次消耗多少点、换多少荣誉（客户端「强化点回收」按钮）。
    study_point_sale_block: int = field(
        default_factory=lambda: int(_env("CF_POINT_SALE_BLOCK", "1000")))
    study_point_sale_honor: int = field(
        default_factory=lambda: int(_env("CF_POINT_SALE_HONOR", "10")))

    # ------------------------------------------------------------------
    # 生化僵尸（bot）爪击节奏
    #
    # 伤害数值不动（BioProperty.damage 620~800，防化服挡 1 下 + 抓中 2 下
    # 感染是统一机制）。问题在频率：`atkRate+atkSpeed` 算出来是 0.6 秒一下，
    # 三下只要 1.2 秒，玩家几乎没有拉开距离的窗口。
    #
    #   bot_claw_interval 两爪之间的最小间隔（秒）。0 = 用表里的原值
    #   bot_claw_windup   贴身后第一爪前的蓄力时间（秒）。给一次反应机会
    # ------------------------------------------------------------------
    bot_claw_interval: float = field(
        default_factory=lambda: float(_env("CF_BOT_CLAW_INTERVAL", "1.05")))
    bot_claw_windup: float = field(
        default_factory=lambda: float(_env("CF_BOT_CLAW_WINDUP", "0.35")))

    # ------------------------------------------------------------------
    # 生化：人类 BOT 的伤害系数与防化服
    #
    # 人类 BOT 和真人共用同一条 `settle_shoot`，原来没有任何 bot 系数，
    # 于是 bot 拿 AK 和玩家一样疼。0.8 = 生化模式里人类 bot 伤害只减 20%
    # （用户要求从原来的减 50% 放宽到减 20%）。
    # ------------------------------------------------------------------
    # 【v9】恢复为 1.0：不再对 BOT 伤害打折（用户要求「被削弱的伤害全部恢复」）。
    biochem_bot_dmg_scale: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_BOT_DMG", "1.0")))

    # 僵尸 BOT 被击中的击退力系数。1.0 = 与真人完全一致（v9 恢复；
    # 之前 0.6 → 0.4 → 0.24 是历史削弱）。
    # 只作用于服务端驱动的僵尸 BOT（bot_recoil），真人当僵尸时的击退是
    # 客户端本地 Warrior.RecedeTask 结算，不受这里影响。
    bot_recoil_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_RECOIL", "1.0")))

    # 【v48】击退是否**接管**僵尸 BOT 的移动。
    #
    # 客户端 `Warrior.Speed`（isUser）在 `recedeTime > 0` 时直接
    # `return -recedeSpeed`：玩家前进输入被整体忽略，被连射时是「锁住只后退」。
    # 服务端 BOT 是「照常跑 7m/s + 减去击退位移」—— 这是 BOT 的原生机制。
    #   0（默认）= 保留 BOT 原机制（边推边冲），只靠下面的推力倍率做平衡
    #   1        = 与真人一致：击退期间不推进，只被推（被 4~5 人集火时推不进来）
    bot_recoil_lock_move: float = field(
        default_factory=lambda: float(_env("CF_BOT_RECOIL_LOCK", "0")))

    # 【v48】击退**推力倍率**（只作用在击退速度上，不改持续时间）。
    #
    # 标定口径（用户定的靶）：僵尸 BOT 被 M4A1 系（Gun.bioHit 0.10s /
    # bioHitSpeed 5）**10 发/秒**连续命中时，1 秒内被推的累计距离 =
    #   0.10 × 5 × 2/3 × 10 = 3.333m  ×  倍率
    # 要 6.5m => 倍率 = 6.5 / 3.333 = 1.95。
    # ★ 位移与倍率是**线性**的（速度乘倍率），不是平方关系。
    bot_recoil_push: float = field(
        default_factory=lambda: float(_env("CF_BOT_RECOIL_PUSH", "1.95")))

    # 【v48】霰弹叠加上限：一枪 N 颗弹丸命中时，按 min(N, 本值) 倍**延长**
    # 击退时长（总位移 = 单颗 × 倍数，速度不变，避免一帧瞬移）。
    # 1 = 不叠加（旧行为：8 颗只算一次）；8 = 全叠（KSG 一枪推 40m，会飞）。
    bot_recoil_stack_max: int = field(
        default_factory=lambda: int(_env("CF_BOT_RECOIL_STACK", "2")))

    # 【v49】击退的**净位移下限**（米/秒，负值）。任何武器、任何叠加倍率，
    # 僵尸在连续被打时的稳态净位移都不会低于这个值 —— 即「不许被打飞」。
    # 每 tick 的击退位移上限 = (推进速度 − 本值) × dt；实测把霰弹从
    # KSG -6.98 / AA-12 -17.15 一并拉回到 -0.50，步枪（原本 +0.50）不触发。
    # 设一个很负的值（如 -99）等于关掉这个限制。
    bot_recoil_net_min: float = field(
        default_factory=lambda: float(_env("CF_BOT_RECOIL_NET_MIN", "-0.5")))

    # 幽灵 BOT 血量系数。普通幽灵 hpBase 只有 800~1400（母体才按人数加厚），
    # 加上人类 bot 伤害减半，很容易被玩家秒掉 —— 用户反馈「幽灵 bot 好脆」。
    # 等级成长加血（level×hpPlus）对 bot 是生效的，这里只是把基础血抬一截。
    biochem_bot_hp_scale: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_BOT_HP", "1.5")))

    # 幽灵脱战回血：服务端等待时间相对 BioProperty.healWait 的校准系数。
    # 客户端状态栏倒计时条 SkillSlider.Setup(0, healWait) 走 healWait 秒
    # 满条归零；服务端时间基准已统一为 time.time()，与动画一致，所以这里
    # 应严格 = 1.0（回血起点 = 动画走完那一下）。上一版误设 1.8 导致
    # 「动画早走完了、还要再等十几秒才回血」。
    biochem_heal_wait_scale: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_HEAL_WAIT_SCALE", "1.0")))

    # 【狂暴版】脱战回血等待秒数**绝对覆盖**。> 0 时直接顶掉 BioProperty.healWait
    # （官方 15s），不再乘 scale。0 = 关闭覆盖、回到 healWait×scale 的旧行为。
    biochem_heal_wait_seconds: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_HEAL_WAIT_SEC", "5")))


    # 开局给人类发防化服（ScBioProtectLayer）的概率。1.0 = 以前的行为
    # （人人 3 层），0.5 = 一半人没有。
    biochem_protect_chance: float = field(
        default_factory=lambda: float(_env("CF_BIOCHEM_PROTECT_CHANCE", "0.5")))

    # 【v15】「重创」图标（ScBioAccDamage / PrivateKillNotice.Type.Blow）的
    # 触发门槛：某个**人类**对幽灵累计造成这么多伤害，才给他本人发一次。
    # 客户端只在 `DataPool.IsHero(roleid)` 时显示，所以 roleid 必须是攻击者。
    # 0 = 关闭。破防化服走的是 ScBioProtectLayer 自带的 Shield 图标，与它无关。
    biochem_acc_damage_step: int = field(
        default_factory=lambda: int(_env("CF_BIO_ACC_DMG_STEP", "1000")))

    # 【v49】「重创」图标的全局冷却（秒）。客户端 PrivateNoticeBoard 每条要
    # 0.3s 弹入 + 1.5s 停留 ≈ 1.8s，而 note_zombie_damage 每次结算都会判定，
    # 一梭子就连播。用户口径：「等图标显示完才做下次判定」——
    # 冷却期内打出的伤害**直接丢弃**（不累计），不是延后补发。
    # 0 = 关掉冷却（回到 v15 行为）。
    biochem_acc_damage_cooldown: float = field(
        default_factory=lambda: float(_env("CF_BIO_ACC_DMG_CD", "2.0")))

    # 【v16】全图 8 复活点：僵尸复活时按「这个点周围多少活人」降权。
    # 判定半径（米）。8 个点铺满全图，半径太小就永远数不到人。
    biochem_spawn_crowd_range: float = field(
        default_factory=lambda: float(_env("CF_BIO_SPAWN_CROWD_RANGE", "10")))

    # 最低权重（相对满权重 1.0 的倍数）。用户要求：4 个人就触底，
    # 但仍保留触发机会，不能低到 100 次都不刷。阶梯
    # 1.0 / 0.7 / 0.45 / 0.25 / 0.1 对应 0/1/2/3/4+ 人。
    biochem_spawn_min_weight: float = field(
        default_factory=lambda: float(_env("CF_BIO_SPAWN_MIN_W", "0.1")))

    # 每个复活点的**绝对概率下限**。用户原话「4 个人就到最低权重，但是还有
    # 10% 的概率会在这里复活」：8 个点各保底 10%，剩下 20% 才按上面的
    # 相对权重分。这样再挤的点也一定会被抽到，不会 100 次都不触发。
    # 设 0 = 回到纯相对权重（那时 4 人点约 1.6%）。
    biochem_spawn_min_prob: float = field(
        default_factory=lambda: float(_env("CF_BIO_SPAWN_MIN_PROB", "0.1")))

    # 【v17】大厅「购买与装备教程」（新手教官卡罗琳那一串）由客户端
    # `UserManager.OnSyncFreshStatus(ScFreshmanProgress.progress)` 驱动：
    #   bit0..7   = greenHandProgress（14 = 教程走完，int.MaxValue = 跳过）
    #   bit9  0x200 = 0 表示「装备教程已完成」(isGreenEquipCleared)
    #   bit10 0x400 = 0 表示「购买教程已完成」(isGreenBuyCleared)
    #   bit11 0x800 = 1 表示「训练关已完成」(isGreenFightFinished)
    # 服务端原来从不下发 1114123，客户端 isGreenEquipCleared 一直是 false，
    # 于是每次登录抽一次补给箱，GachaPrizeDialog 结束就 CheckTriggerEquip()
    # -> GreenHandWizzard.Trigger(18)，整串引导重放。登录时推 14（官方
    # 「教程走完」值，且 0x200/0x400 位为 0 = 购买/装备教程已完成）即可：
    # GreenHandWizzard.Awake 与 BattleWindow.ShowThis 都以 >=14 为「不再弹」，
    # CheckTriggerEquip 也因 isGreenEquipCleared=true 直接返回。
    # **不要**置 0x800（isGreenFightFinished）：那会连训练关按钮一起隐藏，
    # 也会影响 AGreenGuider。设 0 = 不下发（回到原行为）。
    lobby_guide_done_progress: int = field(
        default_factory=lambda: int(_env("CF_LOBBY_GUIDE_DONE", "14")))

    # 【v17】生化补给箱统一口径：数量上限 / 刷新间隔覆盖 GameRule 表
    # （bioBoxNum、ammoBoxNum、BoxIntervalTime、supplyTime）。0 = 沿用配置表。
    biochem_box_limit: int = field(
        default_factory=lambda: int(_env("CF_BIO_BOX_LIMIT", "6")))
    biochem_box_interval: float = field(
        default_factory=lambda: float(_env("CF_BIO_BOX_INTERVAL", "10")))
    # 箱子候选点：跟复活点同一套「寻路网格 4×2 分区」，每区抽这么多点，
    # 每局重新随机。8 区 × 4 = 32 个全图候选点。
    biochem_box_points_per_zone: int = field(
        default_factory=lambda: int(_env("CF_BIO_BOX_POINTS_PER_ZONE", "4")))
    # BOT 主动去捡补给箱的最大距离（米）；0 = 只在路过时被动拾取。
    bot_box_seek_range: float = field(
        default_factory=lambda: float(_env("CF_BOT_BOX_SEEK_RANGE", "18")))

    # 生化经验（整数点，1 级 = GameRule.humanExpNeed = 4 点）
    #   生化补给箱（僵尸专用）：8 点 = 直接升 2 级（zombieExpNeed=4）
    #   弹药补给箱（人类专用）：8 点 = +2 级士气
    #   僵尸死亡：普通 +4 点（+1 级）、母体 +8 点（+2 级），且**不扣经验**
    #   （原来的 zombieDieDeductExp=4 会让死一次掉一整级）
    biochem_bio_box_exp: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_BIO_BOX_EXP", "8")))
    biochem_ammo_box_exp: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_AMMO_BOX_EXP", "8")))
    # 【v20】弹药补给箱回血量：上一轮规划的「+1500 血」，硬 clamp 到 hp_max。
    # 0 = 不回血；设成 -1 可回到 v18 的「直接补满」（不建议，会盖过血上限）。
    biochem_ammo_box_heal: int = field(
        default_factory=lambda: int(_env("CF_BIO_AMMO_BOX_HEAL", "1500")))
    biochem_zombie_death_exp: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_ZOMBIE_DEATH_EXP", "4")))
    biochem_matrix_death_exp: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_MATRIX_DEATH_EXP", "8")))

    # 【狂暴版】终极生化结算：倒计时到点时，按「对方阵营存活数」给己方补等级。
    # 人类加成等级是**非线性表**（按存活僵尸数取值，用户给定）：
    #     1 只 +5 / 2 只 +12 / 3 只 +20 / 4 只 +30 / 5 只 +42 / 6 只 +55 / 7 只 +80
    # 超过 7 只按每多 1 只 +25 级线性外推。
    # 0 = 关闭（保持旧的「只变英雄、不补等级」行为）。
    biochem_ultimate_enabled: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_ULTIMATE", "1")))

    # 人类终极加成等级表（逗号分隔，索引 0 = 对面 1 只）。见上。
    biochem_ultimate_human_levels: str = field(
        default_factory=lambda: _env("CF_BIO_ULT_HLV", "5,12,20,30,42,55,80"))

    # 母体终极加伤表（按存活人类数，索引 0 = 1 个人类）：累计点数。
    # 【v12】1v7 档 4600 → **5000**（用户要求）：800 爪伤 + 5000 = 5800，
    # 乘腿系数 0.9 也有 5220 > 英雄 5000 血，任何部位一爪必倒。
    biochem_ultimate_matrix_dmg: str = field(
        default_factory=lambda: _env("CF_BIO_ULT_MDMG",
                                     "300,400,500,700,1100,2100,5000"))

    # 普通僵尸终极加伤：每个存活人类 +30 点爪击伤害（线性累加）。
    biochem_ultimate_zombie_dmg_per_human: float = field(
        default_factory=lambda: float(_env("CF_BIO_ULT_ZDMG_FLAT", "100")))

    # 刚体 / 恶魔刚体 期间的移速变化（米/秒，负数 = 变慢）。
    # 只对服务端驱动的 BOT 生效：真人玩家由客户端 Warrior.SteelSkillTask
    # 结算（客户端只改 skillRecedeRate＝击退系数，不改跑速）。
    # 【v50】刚体对 BOT 的额外减速。用户口径：移除此项（0 = 不减）。
    # 真人侧本来就只改推力（客户端 SteelSkillTask 不动 skillSpeedPlus）。
    biochem_steel_speed_minus: float = field(
        default_factory=lambda: float(_env("CF_BIO_STEEL_SPEED", "0.0")))

    # 【狂暴版】僵尸爪击伤害的**等级成长系数**（每级）。0 = 关闭（官方行为：
    # 僵尸升级只加血、不加攻）。例如 0.05 → 10 级时爪击伤害 ×1.5。
    biochem_zombie_dmg_growth: float = field(
        default_factory=lambda: float(_env("CF_BIO_ZOMBIE_DMG_GROWTH", "0")))

    # 【狂暴版】查不到僵尸角色 BioProperty 时，升级加血用的兜底 hpPlus。
    biochem_default_hp_plus: int = field(
        default_factory=lambda: int(_env("CF_BIO_DEFAULT_HP_PLUS", "120")))

    # 【狂暴版】人类士气伤害的等级上限。**0 = 不封顶**（默认）。
    # 原来 damage.resolve_shoot 写死 min(level, humanMaxLv=10)，
    # 等级涨到 10 级后伤害就不动了 —— 这就是「等级加成没生效」的元凶。
    biochem_morale_cap: int = field(
        default_factory=lambda: int(_env("CF_BIOCHEM_MORALE_CAP", "0")))

    # 【狂暴版】人类近战（拿刀）相对基础跑速的加成（米/秒）。
    # 注意：真人玩家的移动是**客户端**执行的（Antiknock.VelocityRun 写死 7f），
    # 这里只影响服务端驱动的 BOT 寻路速度。
    human_melee_speed_bonus: float = field(
        default_factory=lambda: float(_env("CF_HUMAN_MELEE_SPEED_BONUS", "2.0")))

    # 【狂暴版】手枪不计入「持枪降速」（true = 手枪跑到基础满速）。
    human_pistol_no_slow: int = field(
        default_factory=lambda: int(_env("CF_HUMAN_PISTOL_NO_SLOW", "1")))

    # 【狂暴版】签到领取时额外赠送的一把武器（0 = 不送）。
    # 507020 = 暴烈骑士改·38。grant_items 对 maxPile==1 的装备自带去重，
    # 所以重复领签到也不会重复入库。
    grant_weapon_id: int = field(
        default_factory=lambda: int(_env("CF_GRANT_WEAPON", "507020")))

    # ------------------------------------------------------------------
    # BOT 开火模型：反应时间 + 瞄准滞后
    #
    # 原来的 BOT 是「瞬时瞄准 + 瞬时开火」：`_tick_human_bot` 每次 tick 读目标
    # 当前坐标、立刻扣扳机，等于自带透视 + 零延迟自瞄。表现就是玩家一露头
    # 血条瞬间见底，狙击 BOT 盲狙必中，身法完全无效。
    #
    #   bot_react_base  = 官方 Lv4「军官」的首发反应基准（0.384s），
    #                    实际 = base × clamp(距离/15, 0.3, 1)：
    #                    3m→0.115s、10m→0.256s、20m 以上→0.384s。
    #                    官方按距离缩放（RobotConsts.Adjusttime(adjust, dis)），
    #                    越近抬枪越快，不再按枪种分档。
    #   bot_aim_lag_*  已退役：官方 AI 不打「历史位置」，而是用枪械散布。
    #                  保留字段只为兼容老的 env，不再被读取。
    # ------------------------------------------------------------------
    bot_react_base: float = field(
        default_factory=lambda: float(_env("CF_BOT_REACT_BASE", "0.384")))

    bot_aim_lag_base: float = field(
        default_factory=lambda: float(_env("CF_BOT_AIM_LAG_BASE", "0")))
    bot_aim_lag_sniper: float = field(
        default_factory=lambda: float(_env("CF_BOT_AIM_LAG_SNIPER", "0")))
    bot_aim_lag_mg: float = field(
        default_factory=lambda: float(_env("CF_BOT_AIM_LAG_MG", "0")))
    bot_aim_lag_smg: float = field(
        default_factory=lambda: float(_env("CF_BOT_AIM_LAG_SMG", "0")))
    # 兼容字段：散布模型接管之后不再扣命中数
    bot_sniper_hit_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_SNIPER_HIT", "1.0")))

    # ------------------------------------------------------------------
    # 官方 Lv4「军官」的其余交战参数
    # ------------------------------------------------------------------
    # 交战锁定：目标死亡/丢失视线超过这个宽限才停火（秒）。
    # 官方 Robot 的 Ranging 每帧重算射程，视线掉了立即进 Orient；
    # 这里给 0.35s 只为了让「躲进掩体」有个可感知的收尾，不是无限跟枪。
    bot_los_grace: float = field(
        default_factory=lambda: float(_env("CF_BOT_LOS_GRACE", "0.35")))

    # 开火门限：枪口必须对到 target 的这个角度以内（度）。
    # 官方 = clamp(0.5 + 15/距离, 0.5, 30)：10m≈2.0°、30m≈1.0°、3m≈30°。
    bot_aim_deg_base: float = field(
        default_factory=lambda: float(_env("CF_BOT_AIM_DEG", "0.5")))
    bot_aim_deg_dist: float = field(
        default_factory=lambda: float(_env("CF_BOT_AIM_DIST", "15")))

    # 跟枪距离超过「交战距离 × 这个倍数」就放弃（防止追到地图另一头）。
    bot_engage_range_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_ENGAGE_SCALE", "1.2")))

    # 散布缩放：公式本身是官方的（Gun.min/maxDistribution × 0.33 + 精度惩罚），
    # 这个系数只做「官方公式 → 我们的圆柱体命中判定」的标定。
    #   1.0 = 完全按官方算（我们判定下过散：AK 10m 只有 ~27%）
    #   0.4 = 默认，Lv4 军官落在「10m 必中 / 20m 四成 / 30m 两成」
    bot_spread_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_SPREAD_SCALE", "0.4")))

    # 【v9】竞技/团队/爆破等非生化房间的散布缩放。
    # 圆柱命中 ∝ 1/R²，锥角 ×1/√目标命中率：
    #   v9 = 80% -> 0.4 × 1/√0.8 = 0.4472
    #   v10 = 90% -> 0.4 × 1/√0.9 = 0.4216（用户反映 BOT 太弱，提回来）
    # 生化房仍用 `bot_spread_scale`（0.4）不变；狙击不受这条影响。
    bot_spread_scale_arena: float = field(
        default_factory=lambda: float(_env("CF_BOT_SPREAD_ARENA", "0.4216")))

    # 【v11 加的「对英雄一击必杀」——v13 默认关闭】。
    # 当初是为了 1v7 打不完才加，但它不区分场景：3 个鬼围 5 个英雄时同样一爪
    # 一个，手感就是「秒杀」。现在改用**纯数值**：
    #   1v7 → 800 + 5000(终极) = 5800 > 英雄 5000 血，一爪倒（用户要的效果）；
    #   3v5 → 800 + 1100 = 1900，需要 3 爪，不再是秒杀。
    # 再叠加 v13 的「幽灵打英雄部位系数固定 1.0」，数字就是真的。
    # 仍可用 CF_BIO_HERO_ONESHOT=1 恢复「一爪必杀」的作弊档。
    biochem_zombie_hero_oneshot: int = field(
        default_factory=lambda: int(_env("CF_BIO_HERO_ONESHOT", "0")))

    # 【v9】生化房里狙击回到旧口径（0.4° 锥 + 不额外加反应）。
    # 竞技房里狙击保持 1.0° + 反应 ×2（用户说「狙击没问题」）。
    bot_sniper_spread_bio: float = field(
        default_factory=lambda: float(_env("CF_BOT_SNIPER_BIO", "0.4")))

    # 每发额外附加的「客户端帧开销」（秒）。
    # 真人开火是逐帧驱动：`if (IsIdle()) Attack()`，一发要占掉
    # 「OneShot 一帧 + 输入循环一帧」，所以实际射速 ≈ Gun.shootSpeed + 2/fps。
    # 30fps 模拟器下 AK 实测 5~6 发/秒（表值 8.3），RPD 一梭 10 多秒。
    # BOT 直接按表值打会比真人快 30~50%，这里补回同样的开销（0.06 ≈ 2 帧@33fps）。
    # 【v8】用户要求：BOT 不再补这 0.06 秒，直接按枪械表值开火。
    bot_fire_overhead: float = field(
        default_factory=lambda: float(_env("CF_BOT_FIRE_OVERHEAD", "0")))

    # BOT 房间的结算频率。10Hz 下 0.12s 的枪会变成 0.1/0.2 交替（听感是两连点），
    # 20Hz 量化到 0.05s，连发基本顺滑。0 = 沿用全局 10Hz。
    bot_tick_hz: float = field(
        default_factory=lambda: float(_env("CF_BOT_TICK_HZ", "20")))

    # 【v23】仅 BOT：拿狙击（Gun.actType==6）时开火间隔再乘这个倍率。
    # 【v35】★ 已被下面四模式分档表取代（本字段仅为旧 env 兼容，不再被读取）。
    bot_sniper_period_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_SNIPER_SCALE", "2")))

    # ------------------------------------------------------------------
    # 【v36 / v39 已停用】四模式「锁定延迟」
    # ------------------------------------------------------------------
    # v39 按用户要求整体撤销，开火许可回到 `bot_react_base`（按距离缩放的反应
    # 时间，只在进入交战时算一次）。下面这几个字段**没有任何代码读取**，只保留
    # 字段占位以免旧 env / 旧配置文件解析报错。
    bot_lock_bio: float = field(
        default_factory=lambda: float(_env("CF_BOT_LOCK_BIO", "0.5")))
    bot_lock_league: float = field(
        default_factory=lambda: float(_env("CF_BOT_LOCK_LEAGUE", "0.5")))
    bot_lock_qualifying: float = field(
        default_factory=lambda: float(_env("CF_BOT_LOCK_QUAL", "0.5")))
    bot_lock_normal: float = field(
        default_factory=lambda: float(_env("CF_BOT_LOCK_NORMAL", "0.5")))
    bot_lock_sniper_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_LOCK_SNIPER", "2.0")))
    # 【v39 已停用】锁定清零宽限 / 目标粘滞：随「连续可见 N 秒」一起撤销，
    # 现在只有 `bot_los_grace`(0.35s) 决定是否退出交战。字段保留不读取。
    bot_reacquire: float = field(
        default_factory=lambda: float(_env("CF_BOT_REACQUIRE", "0.25")))
    bot_target_slack: float = field(
        default_factory=lambda: float(_env("CF_BOT_TARGET_SLACK", "5.0")))

    # ------------------------------------------------------------------
    # 【v39】三连发枪（Gun.firePerShoot>1）的**一次扣扳机**间隔，单位秒。
    # ------------------------------------------------------------------
    # 之前用面板 period（M93R 0.35s）当触发间隔，一梭 3 发只花 3×0.055s，
    # 实际 3 发/0.35s ≈ 8.6 发/秒，听感变成「三连发的射速打全自动」。
    # 现在固定 0.6s 一次三连发；面板更慢的枪仍按面板，不会被加快。
    bot_burst_period: float = field(
        default_factory=lambda: float(_env("CF_BOT_BURST_PERIOD", "0.6")))

    # ------------------------------------------------------------------
    # 【v36】视野锥：总张角（度），实际半角 = 该值 / 2
    # ------------------------------------------------------------------
    # ★ 180° = 半角 90°，正侧面是边界、**不会背身**；只有 >180° 才看到背后。
    # 原来排位/联赛都是 280°（半角 140°）= 背后 40° 盲区被抹掉，这才是「背身开枪」。
    # 【v46】联赛 / 生化按用户口径改成 225°（半角 112.5°，背后只剩 45° 盲区）：
    # 贴脸绕圈时目标更容易留在视野锥内，但**仍然看不到正背后**。
    bot_fov_bio: float = field(
        default_factory=lambda: float(_env("CF_BOT_FOV_BIO", "225")))
    bot_fov_league: float = field(
        default_factory=lambda: float(_env("CF_BOT_FOV_LEAGUE", "225")))
    bot_fov_qualifying: float = field(
        default_factory=lambda: float(_env("CF_BOT_FOV_QUAL", "225")))
    bot_fov_normal: float = field(
        default_factory=lambda: float(_env("CF_BOT_FOV_NORMAL", "135")))

    # ------------------------------------------------------------------
    # 【v36】听觉半径（米）：听到枪声后转向声源。生化 40 / 联赛 15 / 排位 8 / 普通 5。
    # ------------------------------------------------------------------
    bot_hear_bio: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR_BIO", "40")))
    bot_hear_league: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR_LEAGUE", "15")))
    bot_hear_qualifying: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR_QUAL", "15")))
    bot_hear_normal: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR_NORMAL", "5")))

    # 【v37】枪声记忆时长（秒）：只认这段时间内响过的枪。
    # 生化 10s（僵尸 BOT 追人不放弃），联赛/排位/普通 1.5s（用 bot_hear_memory）。
    bot_hear_mem_bio: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR_MEM_BIO", "10")))

    # ------------------------------------------------------------------
    # 【v39】穿透方案 A：服务端 `sd` 下限校验
    # ------------------------------------------------------------------
    # 客户端的 sd = 射线命中距离 + 穿墙等效距离（APenetrator.Distance 累加），
    # 所以正常射击恒有 `sd >= 直线距离`。比直线距离还小只可能是数据异常，
    # 或者被改造过客户端故意报 0 来拿「贴身满伤」。
    #   clamp（默认）：钳到 `直线距离 - 容差`，不影响正常玩家
    #   drop        ：直接丢弃这一发
    # 只做下限，不改变穿墙判定本身（那在客户端 AGun.CaptureHit 里）。
    bullet_sd_floor_tolerance: float = field(
        default_factory=lambda: float(_env("CF_SD_FLOOR_TOL", "0.5")))
    bullet_sd_floor_mode: str = field(
        default_factory=lambda: _env("CF_SD_FLOOR_MODE", "clamp").strip().lower())

    # 交战闪避（横摆）是否只在高难房（排位 / 联赛）启用。True = 只在排位/联赛。
    bot_dodge_rank_only: bool = field(
        default_factory=lambda: _env("CF_BOT_DODGE_RANK_ONLY", "1") != "0")

    # 【v35】狙击间隔的四模式分档（★ 联赛 = 原始值 = 最高难度基准）。
    #   联赛 LEAGUE      = 1.0  （原始间隔：M200 1.90s、AWP 1.60s、SVD 0.90s）
    #   排位 QUALIFYING  = 2.0  （×2：M200 3.80s）
    #   普通（团队/爆破/SOLO 等）= 3.0（×3：M200 5.70s）
    #   生化 BIOCHEM    = 2.0  （用户未指定 -> 保持 v30 以来的 2 倍不变）
    # 只影响 BOT 手里的狙击，真人面板不变。
    bot_sniper_scale_league: float = field(
        default_factory=lambda: float(_env("CF_SNIPER_SCALE_LEAGUE", "1.0")))
    bot_sniper_scale_qualifying: float = field(
        default_factory=lambda: float(_env("CF_SNIPER_SCALE_QUAL", "1.5")))
    bot_sniper_scale_normal: float = field(
        default_factory=lambda: float(_env("CF_SNIPER_SCALE_NORMAL", "3.0")))
    # 【v47】生化房**人类 BOT** 与联赛对齐：狙击间隔 = 原始值 1.0x
    # （原来 2.0）。僵尸不受影响（它们不用枪）。
    bot_sniper_scale_bio: float = field(
        default_factory=lambda: float(_env("CF_SNIPER_SCALE_BIO", "1.0")))

    # 【v61】生化 / 生化英雄房给 **BOT** 额外几个弹匣的备弹。
    # `Gun.ammo` 是「总弹数」，备弹 = ammo - clip，机枪常常只有 1~2 个备用
    # 弹匣，一局 8 人 + 十几只僵尸根本不够（用户要求「加多两个弹匣」）。
    # 只影响 BOT 的服务端弹药模型；真人玩家的弹药由客户端自己维护。
    # CF_BIO_BOT_MAGS=0 可关闭。
    bio_bot_extra_mags: int = field(
        default_factory=lambda: int(_env("CF_BIO_BOT_MAGS", "2")))

    # 【v24 临时测试】联赛 BOT 主武器只发 冲锋枪/机枪。测完设 CF_LEAGUE_SMG_MG_ONLY=0。
    # 【v29 临时测试】联赛 BOT 主武器强制枪种：
    #   ""    = 正常随机（恢复用）
    #   rifle = 全步枪 / smg = 全冲锋枪 / mg = 全机枪
    # 用环境变量 CF_LEAGUE_FORCE_CAT="" 即可恢复。
    bot_league_force_category: str = field(
        default_factory=lambda: _env("CF_LEAGUE_FORCE_CAT", "").strip().lower())

    # 视野锥：BOT 只有在这个张角内才「看得见」人（水平方向，度）。
    # 原来 `_visible()` 只做线段遮挡检测、不看朝向 —— BOT 背后长眼睛，
    # 你从侧后接近他立刻转火，这也是「像提前枪」的一部分来源。
    # 【v8】官方 Lv4 军官 viewAngle = 280°（Robot.Synch 里 ×0.5 当半角）。
    # 【v19】用户口径：280° 只给高难房（排位 / 英雄联赛），外面所有非高难
    # 房回到 135°。房间级覆盖在 rank_profiles.bot_fov()，这里只是全局默认值，
    # 不要把高难的值写回全局 —— 否则普通房会串味。
    bot_fov_deg: float = field(
        default_factory=lambda: float(_env("CF_BOT_FOV", "135")))

    # 【v28】BOT 机枪/冲锋枪的散布倍率（乘在 official_spread_deg 的结果上）。
    # 联赛 = 最高难度基准 = 1.1；其它模式在此基础上按难度系数继续缩放。
    bot_smg_mg_spread_scale: float = field(
        default_factory=lambda: float(_env("CF_SMG_MG_SPREAD", "1.1")))

    # 【v30】BOT 复活/出生后多少秒内禁止开火（仍可移动、可瞄准）。
    # 给玩家一个刚复活的喘息窗口，避免「一出生就被预瞄打死」。
    bot_spawn_fire_lock: float = field(
        default_factory=lambda: float(_env("CF_BOT_SPAWN_LOCK", "1.0")))

    # BOT tick 耗时统计（每 30s 一条 log）。默认关；调 20Hz/30Hz 时用来量 CPU。
    bot_tick_stats: bool = field(
        default_factory=lambda: _env("CF_BOT_TICK_STATS", "0") != "0")

    # 【v31】高射速手枪（格洛克18 系列）单独压命中率。
    # 射速 >= 1/bot_fast_pistol_period 的手枪，散布按「命中率 = hit_rate」
    # 的面积关系放大：spread *= 1/sqrt(hit_rate)。0.50 -> ×1.414。
    # 50% 作为联赛（最高难度）基准，其它模式在此基础上继续下调。
    bot_fast_pistol_hit_rate: float = field(
        default_factory=lambda: float(_env("CF_FAST_PISTOL_HIT", "0.50")))
    bot_fast_pistol_period: float = field(
        default_factory=lambda: float(_env("CF_FAST_PISTOL_PERIOD", "0.15")))

    # 【v28】BOT 命中率倍率。1.0 = 联赛基准（最高难度）。
    # 其他模式削弱难度就往下降：0.8 = 命中率降到 80%，0.7 = 70%。
    # 注意它作用在**命中率**上，代码里按面积折算成散布（spread / sqrt(hit)）。
    # ★ 只对机枪/冲锋枪生效（历史遗留），全局分模式请看下面 v34 那张表。
    bot_hit_rate_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_HIT_SCALE", "1.0")))

    # ------------------------------------------------------------------
    # 【v34】四模式 BOT 命中率（★ 以「联赛」为最高难度基准 = 1.0）
    # ------------------------------------------------------------------
    # 用户口径：球棍属性统一，只按模式削弱命中率；联赛是最高难度 = 原始强度。
    #   联赛 LEAGUE      = 1.00  （基准，不动）
    #   排位 QUALIFYING  = 0.75  （命中率降到 75%）
    #   普通（团队/爆破/SOLO/生化以外的全部）= 0.50（命中率降到 50%）
    #   生化 BIOCHEM    = 1.00  （不变）
    # 命中率 h 与散布 σ 是面积关系（二维正态 P ∝ 1/σ²），所以
    #   散布倍率 = 1 / sqrt(h)： h=0.75 -> ×1.155，h=0.50 -> ×1.414。
    # 它作用在**所有枪械**（步枪/机枪/冲锋枪/狙击/手枪/霰弹枪）上，
    # 与 mg/smg 的 1.1、格洛克18 的 1.414 是**相乘**关系。
    bot_hit_league: float = field(
        default_factory=lambda: float(_env("CF_BOT_HIT_LEAGUE", "1.00")))
    bot_hit_qualifying: float = field(
        default_factory=lambda: float(_env("CF_BOT_HIT_QUAL", "0.75")))
    bot_hit_normal: float = field(
        default_factory=lambda: float(_env("CF_BOT_HIT_NORMAL", "0.50")))
    bot_hit_bio: float = field(
        default_factory=lambda: float(_env("CF_BOT_HIT_BIO", "1.00")))

    # 【v28】两段式转身（用户要求：不要自瞄吸附，但要能被偷袭时转身）。
    #   大角度（偏差 > bot_turn_snap_deg）：用 bot_turn_speed 快转，避免像木头。
    #   小角度跟踪（偏差 <= 阈值）：用 bot_turn_speed_track 慢跟，让玩家横移能甩开。
    # 45 的来历：10m 处 7m/s 横向移动，目标角速度 = v/d = 40.1°/s；取 45 只高 12%，
    # 所以「刚好咬得住但不吸附」——5° 误差约 1.0~2.0s 才能收敛。
    bot_turn_speed: float = field(
        default_factory=lambda: float(_env("CF_BOT_TURN", "120")))
    bot_turn_speed_track: float = field(
        default_factory=lambda: float(_env("CF_BOT_TURN_TRACK", "45")))
    bot_turn_snap_deg: float = field(
        default_factory=lambda: float(_env("CF_BOT_TURN_SNAP", "120")))

    # 【v40】跟踪速度的距离自适应：`跟踪率 = bot_turn_speed_track × 基准距离/实际距离`
    # ------------------------------------------------------------------
    # 45°/s 是按「10m 处 7m/s 横移」标定的（目标角速度 v/d = 40°/s），但角速度
    # 跟距离成反比：5m 处同样横移就要 80°/s，固定 45 会落后半个身位，枪口偏
    # 30~100° 时连射的子弹全打墙上 —— 贴脸冲锋枪/机枪「打不中人」。
    # 现在按距离等比提速，**10m 以外完全不变**（守住原来的标定手感），
    # 上限 bot_turn_track_max 保证不会变成瞬间吸附（3m 内绕圈仍追不上）。
    # 想退回固定 45°/s：`CF_BOT_TURN_TRACK_RANGE=0`。
    bot_turn_track_range: float = field(
        default_factory=lambda: float(_env("CF_BOT_TURN_TRACK_RANGE", "10")))
    bot_turn_track_max: float = field(
        default_factory=lambda: float(_env("CF_BOT_TURN_TRACK_MAX", "120")))

    # 【v49】跳跃失败黑名单（秒）：BOT 跳上高台发现是死路又跳下来时，把那个
    # 起跳点记 N 秒坏点，期间不在它附近起跳。0 = 关闭（回到 v48 行为）。
    # 解决「生化沙漠反复跳箱顶、上下上下不动」。
    bot_jump_bad_sec: float = field(
        default_factory=lambda: float(_env("CF_BOT_JUMP_BAD_SEC", "20")))

    # 【v54】BOT 能直接迈上去的一级台阶高度（米）。地铁站台那级台阶实测
    # 0.44~0.57 m，原来 `nav.ground()` 只会吸回原地高度 → 上不去也不跳，
    # 表现为「人类 BOT 不会跳上台阶」。设为 0 退回旧行为（只能走下坡）。
    bot_step_up: float = field(
        default_factory=lambda: float(_env("CF_BOT_STEP_UP", "0.60")))

    # 【v44】霰弹枪弹丸锥角的整体倍率（1.0 = 直接用手册里的
    # minDistributionStand/Walk/Run，2~4°）。嫌霰弹太强就调大（如 1.2），
    # 太弱就调小。只影响 BOT 的弹道生成，真人霰弹完全不受影响。
    bot_shotgun_spread_scale: float = field(
        default_factory=lambda: float(_env("CF_SHOTGUN_SPREAD", "1.0")))

    # ------------------------------------------------------------------
    # 【v8】官方 Lv4 军官的其余四项（用户要求实装）
    # ------------------------------------------------------------------
    # 听觉：有人开枪后，这个半径内的 BOT 会「听到」并转向/进入交战，
    # 即使射线被掩体挡住（官方 hearRange = 20m）。
    bot_hear_range: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR", "20")))
    # 听到的枪声在多少秒内仍然有效（官方没有明说，给 1.5s 覆盖一轮交火）。
    bot_hear_memory: float = field(
        default_factory=lambda: float(_env("CF_BOT_HEAR_MEM", "1.5")))

    # 追击记忆：目标消失后继续往「最后看到的位置」追多久（官方 pursueTime=20s）。
    bot_pursue_seconds: float = field(
        default_factory=lambda: float(_env("CF_BOT_PURSUE", "20")))

    # 主动换弹：弹匣剩这个比例以下、且当前看不见敌人时先换弹
    # （官方 reloadActive = 30%）。
    bot_reload_active: float = field(
        default_factory=lambda: float(_env("CF_BOT_RELOAD_ACTIVE", "0.30")))

    # 交战闪避：每 bot_dodge_freq 秒做一次横摆，持续 bot_dodge_time 秒
    # （官方 Lv4 dodgeFreq=2s / dodgeTime=1.25s）。
    bot_dodge_freq: float = field(
        default_factory=lambda: float(_env("CF_BOT_DODGE_FREQ", "2.0")))
    bot_dodge_time: float = field(
        default_factory=lambda: float(_env("CF_BOT_DODGE_TIME", "1.25")))

    # 狙击的额外反应倍率：0.384 × 2 = 0.77s（举枪慢），
    # 配合散布锥 1.0°，不再强制脱靶。
    bot_react_sniper_scale: float = field(
        default_factory=lambda: float(_env("CF_BOT_REACT_SNIPER", "2.0")))

    # BOT 武器池：允许出现的最高星级。5★ 以上全是皮肤（Item.tex != 0），
    # 客户端没有第一把模型，会让旧客户端出生即退图。
    bot_pool_max_star: int = field(
        default_factory=lambda: int(_env("CF_BOT_POOL_STAR", "4")))

    # 出生点向上抬多少米。
    #
    # 场景里的出生点是精确坐标（例如血战回廊 police[0] 的 y=0.566），客户端
    # OnRoleCreated 里就是 	rans.position = data.position 直接落位。如果角色
    # 碰撞体比这个点大，脚底会卡进地面碰撞体，物理引擎再把人挤进旁边的墙 ——
    # 表现就是「一人在墙里」。
    #
    # 抬一点点通常能解决，而且不影响正常情况（人会在下一帧落到地面）。
    # 实测有效就留着，无效就设回 0。
    spawn_y_offset: float = field(
        default_factory=lambda: float(_env("CF_SPAWN_Y_OFFSET", "0.0")))

    # 【v15】BOT 抄近路（next_waypoint / path 的 string pulling）时，
    # 长距离直连要求「到最近障碍 > 身体半径 + 这个余量」。
    # 服务端碰撞模型用 3 条平行射线近似圆柱，凸角处会漏（圆柱端部圆弧），
    # 于是 BOT 选了贴角直连、被卡在转角。0 = 不加严（回到 v14 行为）。
    bot_corner_clearance: float = field(
        default_factory=lambda: float(_env("CF_BOT_CORNER_CLEARANCE", "0.20")))

    # 出生时是否用**场景里的朝向**（spawnpoints.json 的 *_quat）。
    #
    # 加它的理由：人机模式 ornData.Transform(trans) 位置和朝向都取自场景，
    # 而联机时服务端只发位置的话，客户端
    #     player.rotation = Euler(0, born.quat.eulerAngles.y + Random(-45,45), 0)
    # 会得到随机朝向，怀疑是「面朝墙卡进去」的原因。
    #
    # **但实测加上之后出现新症状「人物出生时都是蹲姿」** ——
    # 说明客户端对 initQuat 的用法和我理解的不一样（OnRoleCreated 里
    # trans.GetChild(0).localRotation = data.initQuat，模型子节点会被这个值直接旋转）。
    # 所以默认关掉，需要时用 CF_SPAWN_QUAT=1 打开做对照。
    spawn_use_scene_quat: bool = field(
        default_factory=lambda: _env("CF_SPAWN_QUAT", "0")
        not in ("0", "", "false", "False"))

    # 【v46】SOLO 战（个人竞技，mode4）复活朝向。
    #
    # 上面那个开关是「照抄场景 spawnpoints.json 里的 police/terrist_quat」；
    # SOLO 用的是 v20 动态铺满全图的 8 个预设点，场景里没有对应朝向，所以
    # 单独走这一条：每个点由 `battle.solo_spawn_facings()` 在 BOT 寻路网格上
    # 算一个固定 yaw —— 优先「±45° 扇形都能走」（客户端会给 yaw 随机 ±45°），
    # 同分时朝地图中心（交火区）。8 点各不同，整局/整个进程只有一套。
    # 真机若出现「出生蹲姿 / 模型歪掉」（那是客户端把 initQuat 用到子节点的
    # 老症状），把 CF_SOLO_FACING 设 0 即可关掉。
    spawn_solo_facing: bool = field(
        default_factory=lambda: _env("CF_SOLO_FACING", "1")
        not in ("0", "", "false", "False"))

    debug: bool = field(default_factory=lambda: _env("CF_DEBUG", "0") == "1")

    @property
    def site_base(self) -> str:
        """The URL the patched client uses as ResourceSite."""
        return f"http://{self.public_host}:{self.http_port}/{self.resource_site_path}"

    @property
    def gm_url(self) -> str:
        """Where the operator opens the GM panel."""
        host = "127.0.0.1" if self.gm_host in ("0.0.0.0", "", "::") else self.gm_host
        return f"http://{host}:{self.gm_port}/"

    @property
    def gm_needs_password(self) -> bool:
        return bool(self.gm_password)

    @property
    def gm_is_loopback(self) -> bool:
        return self.gm_host in ("127.0.0.1", "localhost", "::1")

    def advertised_host(self, local_addr: str = "") -> str:
        """这个客户端应该被告知去连哪个地址。

        ``local_addr`` 是服务端在这条连接上的本机地址（TCP 的 sockname）。
        只有 IPv4 才采信：客户端把 ip 和端口拼成 "ip:port"，IPv6 会拼坏。
        """
        if self.advertise_mode == "auto":
            addr = (local_addr or "").strip()
            if addr and addr != "0.0.0.0" and ":" not in addr:
                return addr
        return self.public_host

    def serverlist_text(self, host: str | None = None) -> str:
        """`port+addr+name+identifier+status+group` lines (see ParseServer)."""
        line = "+".join([
            str(self.gs_port),
            host or self.public_host,
            self.server_name,
            self.server_identifier,
            str(self.server_status),
            str(self.server_group),
        ])
        return line + "\n"


CONFIG = Config()
