"""Game logic: world state, persistence and protocol handlers."""

from .world import Account, Role, World  # noqa: F401
