"""Battle driver for the room server.

The client has NO local battle logic in online mode -- `ClientManager.InitFight`
returns right after `RoomServer.Instance.CreateConnection(10)` and never adds a
FightServer.  Everything below therefore has to come from here:

    gclient.ScLoginRet(0)          client is connected, sitting in the map
    gclient.ScBornPrepare(t)    -> ClientManager.Prepare(t)      equip screen + countdown
    gclient.CsChooseEquip       <- the player pressed 确定
    gclient.ScBorn(...)         -> ClientManager.Born()          the player actually spawns
    gclient.ScRoundStart(t)     -> ClientManager.RoundStart(t)   round timer, weapons live

Until ScBornPrepare arrives the player stares at the equip screen and clicking
确定 does nothing, because `Commander.ChooseEquipGroup` only *sends*
CsChooseEquip when `Status.online` and never starts anything locally.

Positions are `com.gwebtop.gclient.Vec3` = short of world*100, and `Vec4`
quaternions are component*20000 (see BeanConverter).  Spawn coordinates come
from the map scenes (tools/extract_spawnpoints.py) because the client trusts
the server's position outright:

    trans.position = data.position;      // ClientManager.Born
"""
from __future__ import annotations

import json
import logging
import math
import os
import random
import time
from collections import deque
from typing import Any, Dict, List, Optional, Tuple

from .. import gamedata
from ..net.server import ROUTER, Session
from . import rooms as R
from . import bomb
from .damage import same_team

log = logging.getLogger("crisisfire.battle")

_SPAWN_CACHE: Optional[Dict[str, Any]] = None

# prepare window before the round starts (seconds), and the round length
PREPARE_TIME = 45   # 重建实现：20s 对真机选装备太紧（run6 实测超时强生导致客户端错过 ScBorn 卡装备页）
# 战斗主循环间隔（秒）。
# 原来 0.25s(4Hz) 还是「tick 跑完再排下一次」，实际间隔 0.3s+：
# BOT 位置每 0.3 秒才推一次 -> 移动一卡一卡；玩家切枪/CsWeaponChange 的
# 回包也被主循环拖慢；更糟的是一次 tick 里 take_shots 会补发 2~3 发、
# 每发独立 settle_shoot，高伤英雄武器一个 tick 就能把 1300 血打空。
# 改成 10Hz 固定相位（补偿执行耗时，落后太多不追赶），单 tick 补发自然降到
# 1 发左右。想更流畅可继续调小，但注意 CPU 开销。
TICK_INTERVAL = 0.1
ROUND_TIME = 900
REBORN_INVINCIBLE = 5
# 死亡后等待可复活的秒数（ScWaitRelive.waittime）
WAIT_RELIVE = 5
# 生化模式两回合之间留给结算面板的秒数
BIO_INTERMISSION = 5
# 普通多回合模式（爆破/歼灭等）两回合之间留给结算面板的秒数。
# 原生离线镜像 VirtualServer.CalcResult -> RoundEnd 后，未结束则 Connect(3f)，
# 再走 Prepare(15) + RoundPrepare(15) -> BornAll -> RoundStart。
ROUND_INTERMISSION = 3
# 普通模式「续回合」准备窗口。15s 来自本包离线镜像 FightServer.Connection
# 的 Prepare(15)/RoundPrepare(15)，是**重建流程的校准值**，不是官方服务端值；
# 首局仍用 PREPARE_TIME=45（真机选装备余量），生化现有值不变。
NEXT_ROUND_PREPARE_TIME = 15


def _spawnpoints() -> Dict[str, Any]:
    global _SPAWN_CACHE
    if _SPAWN_CACHE is None:
        path = os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "gamedata", "spawnpoints.json")
        try:
            with open(path, encoding="utf-8") as fh:
                _SPAWN_CACHE = json.load(fh)
        except Exception:
            log.exception("could not load spawnpoints.json")
            _SPAWN_CACHE = {}
    return _SPAWN_CACHE


# ---------------------------------------------------------------------------
# 【v1.1.1】团队(1)/歼灭(3)复活点覆盖
# ---------------------------------------------------------------------------
# 用户口径：
#   1. 团队/歼灭复活不要一落地就面壁。原则是「按 x/z 轴取正东南西北」——
#      敌方复活点在北偏东 30°，就朝正北（把 yaw 吸附到最近的 90° 倍数）。
#   2. 仓库A 的复活点太挤：两个阵营各自改成 4 个预设点，每次复活随机取一个。
#   3. 仓库B 复活点只挤在房间一角，要均匀铺到整个复活房。
# 表里 points 存在时按点随机；只有 yaw 时保留原表位置、只改朝向。
# 只对 gamemode 1/3 生效 —— 爆破(2)、SOLO(4)、生化(8/10) 一律不受影响。
_SPAWN_OV_CACHE: Optional[Dict[str, Any]] = None


def _spawn_override() -> Dict[str, Any]:
    global _SPAWN_OV_CACHE
    if _SPAWN_OV_CACHE is None:
        path = os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "gamedata", "spawn_override.json")
        try:
            with open(path, encoding="utf-8") as fh:
                _SPAWN_OV_CACHE = json.load(fh)
        except Exception:
            log.exception("could not load spawn_override.json")
            _SPAWN_OV_CACHE = {}
    return _SPAWN_OV_CACHE


def _team_spawn_rule(scene: str, key: str, gamemode: int) -> Optional[Dict[str, Any]]:
    """(scene, police|terrist) 的覆盖规则；不生效时返回 None。"""
    if int(gamemode or 0) not in (1, 3):
        return None
    if key not in ("police", "terrist"):
        return None
    try:
        return (_spawn_override().get(scene) or {}).get(key) or None
    except Exception:
        return None



def _vec3(x: float, y: float, z: float) -> Dict[str, int]:
    """World position -> com.gwebtop.gclient.Vec3 (short, *100)."""
    def q(v: float) -> int:
        return max(-32768, min(32767, int(round(v * 100.0))))
    return {"x": q(x), "y": q(y), "z": q(z)}


def _fighter_pos(f) -> Optional[Tuple[float, float, float]]:
    """战机当前坐标（米）。

    `syncpos` 由 UDP 位置上报或 `born()` 写入，服务端 bot 也有。
    `_bio_spawn_index()` 需要它来避开「此刻真的站着人」的复活点；
    不要引用 bots._pos —— 本模块没有任何地方导入它，写了就是 NameError，
    而且那个异常会一路冒出 `born()`，把 ScBorn 吞掉（母体只倒地不出现）。
    """
    p = getattr(f, "syncpos", None)
    if not p:
        return None
    try:
        return (float(p[0]), float(p[1]), float(p[2]))
    except (TypeError, ValueError, IndexError):
        return None


def grid_zone_points(scene: str, per_zone: int = 1, rng=None):
    """【v17】从 BOT 寻路网格按地图 AABB 切 4×2 八区，每区随机抽
    ``per_zone`` 个「站得下、能寻路」的地面层节点。

    复活点（per_zone=1 → 8 点）和补给箱候选点（per_zone=4 → 32 点）共用
    这一套机制：全图铺开、每次调用都重新随机、取出来的点天然能被 BOT
    寻路。返回米坐标 list；任何一步失败返回 []，由调用方回退到旧表。

    【v20】``rng`` 可传入固定种子的 ``random.Random``，用于生成**确定性
    预设**（SOLO 复活点要「整个游戏每张图只有一套」，不能每局变）。
    """
    _rng = rng if rng is not None else random
    try:
        from . import geometry as _geo
        nav = _geo.grid_for_scene(scene)
        phys = _geo.for_scene(scene)
        if nav is None or phys is None:
            return []
        keys = [k for k in nav._links if nav.neighbours(k)]
        if len(keys) < 8:
            return []
        # 只取最大连通分量：取出来的点互相可达，BOT 一出生就能寻路。
        comps: Dict[int, int] = {}
        for k in keys:
            c = nav.component[k]
            comps[c] = comps.get(c, 0) + 1
        main = max(comps, key=comps.get)
        xyz = [nav.point(k) for k in keys if nav.component[k] == main]
        xs = [p[0] for p in xyz]
        zs = [p[2] for p in xyz]
        xmin, xmax, zmin, zmax = min(xs), max(xs), min(zs), max(zs)
        if xmax - xmin < 8 or zmax - zmin < 8:
            return []
        cells: Dict[Tuple[int, int], list] = {}
        for p in xyz:
            i = min(3, int((p[0] - xmin) / (xmax - xmin + 1e-6) * 4))
            j = min(1, int((p[2] - zmin) / (zmax - zmin + 1e-6) * 2))
            cells.setdefault((i, j), []).append(p)
        out = []
        for j in range(2):
            for i in range(4):
                pool = cells.get((i, j)) or []
                if not pool:
                    return []
                # 【v18】按每个点**自身 (x,z) 的最低可站地面**筛，排除屋顶 /
                # 箱顶 / 高台。原来用「每格 y 中位数」时，实测欧洲小镇 38.8%、
                # 神庙 25% 的取点高出地面 >0.8m（最大 7.21m），角色和箱子会
                # 被刷到半空；客户端看起来就是浮空。
                ground = []
                for p in pool:
                    try:
                        floors = phys.floors(p[0], p[2])
                        if not floors:
                            continue
                        rise = p[1] - min(floors)
                        if rise > 0.5:
                            # 多层图里 min(floors) 常常是**不可站**的装饰面 /
                            # 天花板（欧洲小镇实测 floors=[-1.76,0.74]，
                            # -1.76 的 stand_clear=False）。找真正可站的最低层；
                            # 只有它就等于 p[1] 时，这个点才算地面点。
                            base = None
                            for h in sorted(floors):
                                if phys.stand_clear((p[0], round(h, 2), p[2])):
                                    base = h
                                    break
                            if base is None or p[1] - base > 0.5:
                                continue
                        ground.append(p)
                    except Exception:
                        continue
                if not ground:
                    # 整格都在高台时取该格**最低的一批**点，别回退到全池
                    # （那样又会把人刷到屋顶）。
                    ground = sorted(pool, key=lambda p: p[1])[:max(20, per_zone * 5)]
                _rng.shuffle(ground)
                picked = 0
                for p in ground[:max(60, per_zone * 20)]:
                    q = tuple(round(v * 100) / 100 for v in p)
                    if phys.stand_clear(q) and nav.locate(q) is not None:
                        out.append(p)
                        picked += 1
                        if picked >= per_zone:
                            break
                if picked < per_zone:
                    return []
        return out
    except Exception:
        log.exception("grid_zone_points 生成失败 scene=%s", scene)
        return []


# 【v20】SOLO 复活点预设：scene -> 固定 8 点。模块级缓存 = 整个服务端进程
# 每张 SOLO 图只有一套；生成用固定种子，进程重启后也是同一套（不随对局、
# 回合、房间变化）。用户：「不是每局随机，是固定一个预设」。
_SOLO_SPAWN_CACHE: Dict[str, List[Tuple[float, float, float]]] = {}


def solo_spawn_points(scene: str) -> List[Tuple[float, float, float]]:
    """SOLO 战全图 8 个复活点的确定性预设；失败返回 [] 由调用方回退旧表。"""
    if not scene:
        return []
    cached = _SOLO_SPAWN_CACHE.get(scene)
    if cached is not None:
        return cached
    try:
        import zlib
        from . import rank_profiles as _rp
        base = int(_rp.SOLO_SPAWN_SEED) ^ (zlib.crc32(scene.encode("utf-8")) & 0xFFFFFFFF)
        # 从 8 组确定性种子里挑「8 点两两最小间距最大」的一套，避免两个人
        # 刷在同一点附近（实测单种子在江南小镇只能做到 2.8m）。种子全部由
        # scene 名派生，所以每次启动、每局、每回合都还是同一套。
        best, best_min = [], -1.0
        for k in range(8):
            cand = grid_zone_points(scene, 1, rng=random.Random(base + k * 7919))
            if len(cand) != 8:
                continue
            dmin = min(
                math.hypot(a[0] - b[0], a[2] - b[2])
                for i, a in enumerate(cand) for b in cand[i + 1:])
            if dmin > best_min:
                best, best_min = cand, dmin
        if len(best) != 8:
            log.warning("SOLO-SPAWN 预设生成失败 scene=%s，回退出生点表", scene)
            best = []
        else:
            (log.info("SOLO-SPAWN 固定预设 scene=%s 最小间距 %.1fm 8 点=%s",
                     scene, best_min,
                     [(round(p[0], 1), round(p[1], 1), round(p[2], 1)) for p in best]) if log.isEnabledFor(20) else None)
        _SOLO_SPAWN_CACHE[scene] = best
        return best
    except Exception:
        log.exception("SOLO-SPAWN 预设异常 scene=%s", scene)
        _SOLO_SPAWN_CACHE[scene] = []
        return []


# ---------------------------------------------------------------------------
# 【v46】SOLO 复活朝向：每个复活点一个**固定**朝向，正对开阔地/交火区
# ---------------------------------------------------------------------------
# 用户口径（穿越火线「个人竞技·胜利广场」）：每个复活点都有自己的固定朝向，
# 而且面向道路/交火方向 —— 一出生不用先原地转 180° 才敢走。
# 现在 `spawn_pos()` 默认返回 `quat=None`，客户端拿到单位四元数后执行
#     player.rotation = Euler(0, quat.eulerAngles.y + Random(-45,45), 0)
# 也就是**永远朝 +Z、再随机偏 ±45°**：在墙边复活就必然面朝墙。
#
# 这里给 8 个 SOLO 复活点各算一个 yaw：在 BOT 寻路网格上，沿该方向连续
# 可走（`nav.locate` 打点）越远越好；并且要求**左右 ±45° 这个扇形也都通**，
# 因为客户端会随机偏 ±45°。同分时优先「朝向地图中心（交火区）」。
# 纯几何计算 + 模块级缓存：同一张图整个进程只有一套，进程重启后也一样。
_SOLO_FACING_CACHE: Dict[str, List[float]] = {}


def _yaw_quat(yaw: float) -> Dict[str, int]:
    """绕 Y 轴的 yaw（弧度）-> Vec4。与 bots._step 的写线口径一致。"""
    half = float(yaw) * 0.5
    return _vec4(0.0, math.sin(half), 0.0, math.cos(half))


def _nav_center(nav):
    """寻路网格的中心点（交火区的粗略代理）。"""
    try:
        pts = getattr(nav, "centers", None)
        if pts:
            n = max(1, len(pts))
            sx = sum(p[0] for p in pts.values())
            sz = sum(p[2] for p in pts.values())
            return (sx / n, 0.0, sz / n)
    except Exception:
        pass
    return None


def _nav_reach(nav, p, yaw: float, steps) -> float:
    """从 p 沿 yaw 方向，在寻路网格上连续能走多远（米）。"""
    x, y, z = p
    dx, dz = math.sin(yaw), math.cos(yaw)
    reach = 0.0
    for d in steps:
        if nav.locate((x + dx * d, y, z + dz * d)) is None:
            break
        reach = d
    return reach


def _solo_facing_for(nav, p, center) -> float:
    """给一个复活点挑朝向。

    打分（客户端会给 yaw 随机 ±45°，所以两侧也要留余量）：
        score = 2×正前方可走距离 + 1×min(±22°) + 0.5×min(±45°)
                + 2×朝向地图中心的对齐度
    正前方权重最大 —— 要的是「一复活就能往前走」，其次是「朝着交火区」。
    """
    steps = (2.0, 4.0, 6.0, 8.0, 11.0, 15.0, 20.0)
    best_score, best_yaw = None, 0.0
    for i in range(24):
        yaw = i * (math.pi / 12.0)                # 15° 一档
        r0 = _nav_reach(nav, p, yaw, steps)
        r22 = min(_nav_reach(nav, p, yaw - 0.384, steps),
                  _nav_reach(nav, p, yaw + 0.384, steps))
        r45 = min(_nav_reach(nav, p, yaw - 0.785, steps),
                  _nav_reach(nav, p, yaw + 0.785, steps))
        align = 0.0
        if center is not None:
            to_c = math.atan2(center[0] - p[0], center[2] - p[2])
            align = math.cos(yaw - to_c)          # 1 = 正对中心
        score = 2.0 * r0 + 1.0 * r22 + 0.5 * r45 + 2.0 * align
        if best_score is None or score > best_score + 1e-9:
            best_score, best_yaw = score, yaw
    return float(best_yaw)


def solo_spawn_facings(scene: str) -> List[float]:
    """SOLO 8 个复活点的固定朝向（弧度，与 `solo_spawn_points` 同序）。"""
    if not scene:
        return []
    pts = solo_spawn_points(scene)
    if not pts:
        return []
    hit = _SOLO_FACING_CACHE.get(scene)
    if hit is not None and len(hit) == len(pts):
        return hit
    try:
        from . import geometry as _geo
        nav = _geo.grid_for_scene(scene)
        if nav is None:
            _SOLO_FACING_CACHE[scene] = []
            return []
        center = _nav_center(nav)
        out = [_solo_facing_for(nav, p, center) for p in pts]
        _SOLO_FACING_CACHE[scene] = out
        (log.info("SOLO-SPAWN 固定朝向 scene=%s 度数=%s", scene,
                 [round(math.degrees(a), 1) for a in out]) if log.isEnabledFor(20) else None)
        return out
    except Exception:
        log.exception("SOLO-SPAWN 朝向计算失败 scene=%s", scene)
        _SOLO_FACING_CACHE[scene] = []
        return []


def _vec4(x: float, y: float, z: float, w: float) -> Dict[str, int]:
    """Quaternion -> com.gwebtop.gclient.Vec4 (short, *20000)."""
    def q(v: float) -> int:
        return max(-32768, min(32767, int(round(v * 20000.0))))
    return {"w": q(w), "x": q(x), "y": q(y), "z": q(z)}


IDENTITY_QUAT = _vec4(0.0, 0.0, 0.0, 1.0)


class ID:
    # room login / lifecycle
    ROOM_SC_LOGIN_RET = 1441894
    SC_ROLE_STATUS_SYNC = 1441895
    CS_ROLE_STATUS_REPORT = 1441896
    CS_SHOOT = 1441897
    SC_SHOOT = 1441898
    CS_MULTI_SHOOT = 1441899
    SC_MULTI_SHOOT = 1441900
    ROLE_QUIT = 1441901
    # 双向：客户端切枪时发，服务端也要转发给同房间的人看到换枪动作
    WEAPON_CHANGE = 1441906
    SC_GUN_CHANGE = 1441933
    SC_SPAWN_AI = 1441902
    KEEP_ALIVE = 1441911
    SC_BORN_PREPARE = 1441912
    CS_CHOOSE_EQUIP = 1441913
    SC_CHOOSE_EQUIP_RES = 1441914
    SC_BORN = 1441915
    SC_KILL = 1441916
    SC_SCORE = 1441917
    SC_ROUND_END = 1441918
    SC_ROUND_START = 1441919
    SC_WAIT_RELIVE = 1441920
    SC_MY_KILL = 1441921
    CS_RELIVE = 1441923
    SC_AVOID_DAMAGE = 1441924
    # ScAddHp：客户端 `ScAddHp.process() -> ClientManager.AddHP(roleid, addhp)`
    # 是**唯一**能让客户端血条往上涨的入口。芯片击杀回血原来只改了服务端
    # 的 hp，没发这条，所以「炎龙芯片击杀回血」在客户端完全看不到。
    SC_ADD_HP = 1441952
    CS_GRENADE_THROW = 1441907
    SC_GRENADE_THROW = 1441908
    CS_GRENADE_EXPLODE = 1441909
    SC_GRENADE_EXPLODE = 1441910
    CS_ACTION = 1441936
    SC_ACTION = 1441937
    SC_ROUND_PREPARE = 1441939
    SC_WIN_ROUND = 1441940
    SC_ROUND_KILL = 1441941
    SC_MY_MONEY = 1441942
    SC_MY_DIAMOND = 1441943
    CS_FILL_BULLET = 1441934
    SC_FILL_BULLET = 1441935
    SC_FILL_BULLET_STOP = 1441946
    CS_JUMP = 1441948
    SC_JUMP = 1441949
    SC_FIGHT_END = 1441951
    CS_TICK = 1441959
    # 队友复活（PVE 花钻石救队友）：客户端只发目标 roleid
    CS_RELIVE_OTHERS = 1441979
    SC_RELIVE_OTHERS = 1441980
    # 补弹（按住按钮 -> oper 0 开始 / 2 取消，服务端回 result 1 = 补满）
    CS_FILL_AMMO = 1442004
    SC_FILL_AMMO = 1442005
    # PVE 道具增益（拾取后客户端上报，广播给队友看光环）
    CS_ADD_BUFF = 1245272
    SC_ADD_BUFF = 1245273
    CS_REMOVE_BUFF = 1245274
    SC_REMOVE_BUFF = 1245275
    SC_BUFF_LIST = 1245276
    # 最终结算走大厅服（com.gwebtop.fight），因为 ScFightEnd 已经把房间服连接关了：
    #     ScFightEnd.process()   -> RoomServer.willClosed = true; RoomServer.Close();
    #     ScFightResult.process()-> CurrentRoom.OnBattleClose(this) -> "Battle_Close"
    SC_FIGHT_RESULT = 1245214
    # 结算面板的「自己这一局拿了多少」—— **没有它结算界面是空白的**：
    #     RewardDialog.OnEnable: detail == null -> 订阅 onSelfFightDetail 等消息；
    #     BattleRewardPanel.Render: 读 detail.exp / money / bloodgem 填数字。
    # 服务端原来从来不发这条，所以打完一局只有胜/负图标，经验金币全是空的。
    SC_SELF_FIGHT_DETAIL = 1245215
    CS_DOUBLE_REWARD = 1245218
    SC_DOUBLE_REWARD_RET = 1245219
    SC_ACOUNT_SYNC = 983043


class Fighter:
    """One player inside a running battle."""

    __slots__ = ("roleid", "name", "side", "actorid", "equipindex", "equipmap",
                 "born", "kills", "deaths", "score", "hp", "bornidx", "dead_at",
                 "weaponpos", "paid_ammo_slots", "syncpos", "born_at", "fullac",
                 # 防弹衣：ac 是剩余护甲值，ac_max 是出生时算的上限。
                 # 客户端 `Commander.DamagerTarget` 只在 `ac > 0` 时套护甲系数。
                 "ac", "ac_max",
                 # 强化天赋（ResearchTalent）按 type 聚合的等级：{type: 级数}
                 "research",
                 # 这一条命的血量上限（基础 HP + 天赋 + 芯片）。
                 # 补发 ScBorn 给新加入的玩家时必须用它，不能拿当前 hp——
                 # 受伤的人会被显示成「满血」。
                 "hp_max",
                 # 这一次出生跳过「出生保护」——母体被系统选中时用
                 "no_inv_once",
                 # 芯片 addDmg（魔龙礼包）的伤害加成，百分比
                 "chip_adddmg",
                 # 血龙 pistolrange（手枪射程）/ 屠龙 meleerange（近战范围），
                 # 单位都是百分比，按拥有个数累加。
                 "chip_pistolrange", "chip_meleerange",
                 # 生化模式：这一局里「作为人类」的 actorid / 装备。
                 # 变僵尸 / 变英雄时会被换掉，下一回合重置回人类时要用它们
                 # 恢复，否则会以僵尸模型、或只有一把英雄战刀出生。
                 "human_actorid", "human_equipmap",
                 # BOT 自己的朝向（弧度）。`syncpos` 只发位置，转身限速需要
                 # 一个独立保存的 yaw，否则每帧都能瞬间面向目标 = 背后长眼。
                 # **必须在 `__slots__` 里**：Fighter 没有 `__dict__`，
                 # 漏掉这一项会让 `_step()` 每次抛 AttributeError，
                 # 整条 bot 主循环直接中断（表现就是所有 bot 卡在原地不动）。
                 "_bot_yaw")

    def __init__(self, roleid: int, name: str, side: int):
        self.roleid = roleid
        self.name = name
        self.side = side
        self.actorid = 0
        self.equipindex = 0
        self.equipmap: Dict[int, int] = {}
        # 当前武器槽（WeaponChange 追踪）。CsShoot 不带 weaponid，伤害裁决靠它反查。
        self.weaponpos = 0
        self.paid_ammo_slots = set()
        self.born = False
        self.kills = 0
        self.deaths = 0
        self.score = 0
        self.hp = 100.0
        self.hp_max = 100.0
        self.no_inv_once = False
        self.chip_adddmg = 0
        self.ac = 0.0
        self.ac_max = 0.0
        self.research: Dict[int, int] = {}
        self.fullac = 0
        self.bornidx = 0
        self.dead_at = 0.0
        # 最近一次 UDP 位置同步上报的坐标（世界单位，已 /100）。
        # 服务端自己算命中要用它 —— 原来位置只是转发，服务端手里没有任何坐标。
        self.syncpos = None
        # 上一次出生时刻（排查「出生几秒后客户端自己退出」用）
        self.born_at = 0.0
        # 作为人类时的 actorid / 装备（生化模式换僵尸角色/英雄后，下一回合恢复用）
        self.human_actorid = 0
        self.human_equipmap: Dict[int, int] = {}
        # BOT 朝向（弧度）。None = 还没转过身，第一帧直接对齐。
        self._bot_yaw = None


# --------------------------------------------------------------------------
# 护甲 / 强化天赋：出生时结算一次，伤害裁决时直接查
#
# 这两块原来服务端完全没有：ScBorn 里写死 `ac=0, fullac=0`，
# 客户端 `Commander.DamagerTarget` 的护甲分支要求 `targetData.ac > 0`，
# 所以防弹衣从来没生效过；强化天赋（ResearchTalent）也只停留在面板加点上。
# --------------------------------------------------------------------------
ARMOR_SLOTS = (31, 32, 33, 34)


def _role_obj(roleid: int):
    """取角色存档（拿天赋等级用）。没 world / 没这个号时返回 None。"""
    try:
        from . import handlers as _h
        world = getattr(_h, "world", None)
        return world.role(roleid) if world is not None else None
    except Exception:
        return None


def _armor_ac(equipmap: Dict[int, int]) -> int:
    """客户端 Numeric.ArmorAC：槽 31~34 里 maxAc 最大的那一件。"""
    rows = {int(r.get("id") or 0): r for r in gamedata.table("Armor")}
    best = 0
    for slot in ARMOR_SLOTS:
        row = rows.get(int((equipmap or {}).get(slot) or 0))
        if row is not None:
            best = max(best, int(row.get("maxAc") or 0))
    return best


def _talent_levels(role) -> Dict[int, int]:
    try:
        from . import talent as _tal
        return _tal.talents(role) if role is not None else {}
    except Exception:
        return {}


def _talent_ac(role) -> int:
    """护甲增强（Talent.type=3）：每级 +perLevel 点护甲（客户端 TalentManager.ACAcc）。"""
    levels = _talent_levels(role)
    if not levels:
        return 0
    total = 0
    for row in gamedata.table("Talent"):
        if int(row.get("type") or 0) != 3:
            continue
        lv = int(levels.get(int(row.get("id") or 0), 0))
        if lv:
            total += lv * int(row.get("perLevel") or 0)
    return total


def _talent_hp(role) -> int:
    """血量增强（Talent.type=1）：每级 +perLevel 点血量（客户端 TalentManager.HPAcc）。"""
    levels = _talent_levels(role)
    if not levels:
        return 0
    total = 0
    for row in gamedata.table("Talent"):
        if int(row.get("type") or 0) != 1:
            continue
        lv = int(levels.get(int(row.get("id") or 0), 0))
        if lv:
            total += lv * int(row.get("perLevel") or 0)
    return total


_gift_rows: Optional[Dict[int, Dict[str, Any]]] = None

# Gift.json 里能加成的字段。客户端 `GiftBuff.Sync` 只汇总前四个
# （AddHp / AddTime / AddDmg / LifeDrain），射程两个字段客户端没用，
# 服务端也一并读进来备用。
# 【v58】怒龙芯片（Gift.giftLevel=11）的效果从「移动速度 +5%」改成
# 「每击杀 1 名敌人补满当前弹匣」。客户端靠 gift id 判断拥有与否。
ANGRY_DRAGON_GIFT = 11

CHIP_FIELDS = ("addHp", "addDmg", "addTime", "lifeDrain",
               "meleerange", "pistolrange")


def _gift_table() -> Dict[int, Dict[str, Any]]:
    """Gift 表按 **giftLevel** 索引 —— 这张表**没有 id 字段**。

    之前按 `row["id"]` 建索引，10 行全部 KeyError 被 except 吞掉，
    索引恒为空 → 芯片加血永远算 0（用户实测「天赋 3 + 芯片 5 = 103 血」，
    正好等于 100+3+0）。shop.gift_row() 也是按 giftLevel 查的。
    """
    global _gift_rows
    if _gift_rows is None:
        _gift_rows = {}
        for row in gamedata.table("Gift"):
            try:
                key = int(row.get("giftLevel") or 0)
            except (TypeError, ValueError):
                continue
            if key:
                _gift_rows[key] = row
    return _gift_rows


def chip_bonus(role) -> Dict[str, int]:
    """已购礼包芯片的合计加成（与客户端 `GiftBuff.Sync` 一致：**累加**）。"""
    out = {k: 0 for k in CHIP_FIELDS}
    if role is None:
        return out
    try:
        from . import shop as _shop
        owned = _shop.owned_gifts(role)
    except Exception:
        return out
    if not owned:
        return out
    rows = _gift_table()
    for gid in owned:
        row = rows.get(int(gid)) or {}
        for k in CHIP_FIELDS:
            try:
                out[k] += int(row.get(k) or 0)
            except (TypeError, ValueError):
                continue
    return out


def _chip_hp(role) -> int:
    """已购礼包芯片的血量加成（Gift.addHp 合计，客户端 GiftBuff.AddHp）。

    购买验证由 shop.on_buy_gift 完成并把 giftid 记进 `role.data["gifts"]`，
    客户端收到 ScGiftSync 后 GiftBuff.Sync 会把它算进本地血量预测：
        OfflineAssist: bornData.hp = 100 + HPAcc + ChipHPAcc
    但**服务端出生血量原来是写死的 100**，所以芯片加血只在客户端显示、
    一进服务端裁决就没了。这里把它补上。
    """
    return chip_bonus(role).get("addHp", 0)


_ROLE_HP_CACHE: Dict[int, int] = {}


def actor_hp_bonus(actorid: int) -> int:
    """角色卡（Role.addHp）给的永久生命加成。

    角色界面上写着「属性 生命+5 / +6」，客户端 `OfflineAssist` 里也是
    `bornData.hp += roleById.addHp` —— 但**服务端出生血量从来没加过**，
    所以买了角色只是换了个模型，血量一点没涨（用户实测）。
    这里按 `Fighter.actorid`（= 本局选/被分配的角色）查 Role 表补上。
    """
    key = int(actorid or 0)
    if key <= 0:
        return 0
    if key in _ROLE_HP_CACHE:
        return _ROLE_HP_CACHE[key]
    val = 0
    try:
        for row in gamedata.table("Role"):
            if int(row.get("id") or 0) == key:
                val = int(row.get("addHp") or 0)
                break
    except (TypeError, ValueError):
        val = 0
    _ROLE_HP_CACHE[key] = val
    return val


def _research_levels(role) -> Dict[int, int]:
    """强化天赋按 type 聚合：{1: 步枪总级数, 4: 防弹涂层总级数, ...}"""
    try:
        from . import talent as _tal
        levels = _tal.research_talents(role) if role is not None else {}
    except Exception:
        return {}
    if not levels:
        return {}
    out: Dict[int, int] = {}
    for row in gamedata.table("ResearchTalent"):
        lv = int(levels.get(int(row.get("id") or 0), 0))
        if lv:
            t = int(row.get("type") or 0)
            out[t] = out.get(t, 0) + lv
    return out


MAIN_WEAPON_SLOT = 11       # 装备槽：11 主武器 / 12 副武器 / 50 近战
SECOND_WEAPON_SLOT = 12
MELEE_SLOT = 50


def _main_weapon_of(fighter) -> int:
    """凶手当前拿的武器 id —— 击杀播报的图标要靠它。

    客户端的击杀播报是这么取图标的：

        Item item = GameData.instance.getItem(killNotice.weaponid);
        weapon = item.sketchSprite;

    传 0 或无效 id 时 `getItem` 查不到武器，图标就落到默认那张 ——
    实测症状「击杀人是一个骷髅头标志，不是正常的击杀图标」。

    优先用客户端上报的当前槽位（`BulletChange.weaponpos`），
    拿不到就退回主武器。
    """
    eq = getattr(fighter, "equipmap", None) or {}
    pos = int(getattr(fighter, "weaponpos", 0) or 0)
    for slot in (pos, MAIN_WEAPON_SLOT, SECOND_WEAPON_SLOT, MELEE_SLOT):
        wid = int(eq.get(slot) or 0)
        if wid > 0:
            return wid
    return 0


def _is_melee(weaponid: int) -> bool:
    """近战武器判定 —— Item.equipPos == 50（对齐 VirtualServer.GetAttackProperty）。"""
    if not weaponid:
        return False
    from .. import gamedata
    for row in gamedata.table("Item"):
        if int(row.get("id") or 0) == int(weaponid):
            return int(row.get("equipPos") or 0) == 50
    return False


# ---------------------------------------------------------------------------
# 玩家装备校验：只处理客户端确实没有资源的武器，不再按 tex != 0 一刀切
# ---------------------------------------------------------------------------
# 旧实现把 `Item.tex != 0` 一律当成「客户端没有第一人称模型」，例如：
#
#     weapon_base_id(403085) = 403061   // 炎龙改·38 AK47_L_YL02 tex=99
#     weapon_base_id(606132) = 606041   // 生化骑士-龙 AWP_L_G tex=99
#
# 于是玩家存档里的 403085/606132 在服务端被静默换成基础 AK/AWP。新一版
# `weapon_catalog` 已按本包资源审计（equipment_audit/summary.json）逐 id 证明
# 这些 `resource + tex` 组合真实存在，必须原样保留 ID。
#
# 校验规则（仅 11/12/50 这三个会加载第一人称模型的槽位）：
#   1. 审计已验证的 resource/tex -> 原 ID 保留（含合法皮肤）。
#   2. 英雄 8001 与内部装备（711001/711011 等真实客户端路径）-> 保留。
#   3. 行存在但资源/纹理未验证 -> 若同型号基础款也通过审计，才降级；
#      否则从本次 ScBorn 的 equipmap 单独移除并记录字段与原因。
#   4. Item 表查不到的 id -> 单独移除，不猜测同类型替代。
# 其它槽位（护甲/手雷等）不动；玩家存档 loadouts 永远只读，不在此重写。
_WEAPON_BASE_CACHE: Dict[int, int] = {}


def _items_by_id() -> Dict[int, Dict[str, Any]]:
    from .. import gamedata
    out: Dict[int, Dict[str, Any]] = {}
    for row in gamedata.table("Item"):
        try:
            out[int(row.get("id") or 0)] = row
        except (TypeError, ValueError):
            continue
    return out


def weapon_base_id(itemid: int) -> int:
    """非基础款武器 -> 对应的基础款 id；基础款/查不到返回 -1。"""
    iid = int(itemid or 0)
    if not iid:
        return -1
    if iid in _WEAPON_BASE_CACHE:
        return _WEAPON_BASE_CACHE[iid]
    rows = _items_by_id()
    s = rows.get(iid) or {}
    result = -1
    try:
        pos = int(s.get("equipPos") or 0)
        tex = int(s.get("tex") or 0)
    except (TypeError, ValueError):
        pos, tex = 0, 0
    # 只处理枪 / 副武器 / 近战（只有它们会加载第一人称模型）
    if pos in (11, 12, 50) and tex != 0:
        res = str(s.get("resource") or "").strip()
        prefix = res.split("_L_")[0]
        # 皮肤款常把基础名再加个后缀：Dagger_3 / Dagger_3Up、AK47_L_YL02。
        # 先按整个前缀找，找不到再退回「第一段」（Dagger / AK47）——
        # 否则 870211 屠龙尼泊尔会掉到「同 subType 最小 id」的兜底里，
        # 换成 8001 英雄战刀（1.9 数据下实测）。
        base = prefix.split("_")[0]
        cands = [r for r in rows.values()
                 if int(r.get("tex") or 0) == 0
                 and int(r.get("equipPos") or 0) == pos]

        def _closest(rows_in):
            rows_in = list(rows_in)
            rows_in.sort(key=lambda r: (abs(int(r.get("id") or 0) - iid),
                                        int(r.get("id") or 0)))
            return rows_in

        exact = [r for r in cands if str(r.get("resource") or "") == prefix]
        if not exact:
            pref = [r for r in cands
                    if str(r.get("resource") or "").startswith(prefix)]
            exact = _closest(pref)
        if not exact and base and base != prefix:
            pref = [r for r in cands
                    if str(r.get("resource") or "") == base
                    or str(r.get("resource") or "").startswith(base + "_")]
            exact = _closest(pref)
        if not exact:
            same = [r for r in cands
                    if int(r.get("subType") or 0) == int(s.get("subType") or 0)]
            exact = _closest(same)
        if exact:
            result = int(exact[0].get("id") or 0)
    _WEAPON_BASE_CACHE[iid] = result
    return result


def _player_weapon_decision(itemid: int,
                            rows: Optional[Dict[int, Dict[str, Any]]] = None
                            ) -> Tuple[Optional[int], str, Dict[str, Any]]:
    """Return `(kept_id_or_None, reason, fields)` for one 11/12/50 slot.

    This is deliberately narrower than the BOT catalogue selection: it never
    changes a slot to a *different* weapon type and never guesses an id when the
    Item row is missing.  Only text/model evidence verified by
    `weapon_catalog` is trusted.
    """
    from . import weapon_catalog as wc
    iid = int(itemid or 0)
    if rows is None:
        rows = _items_by_id()
    row = rows.get(iid)
    fields: Dict[str, Any] = {"itemid": iid}
    if row is None:
        return None, "missing_item_row", fields
    try:
        pos = int(row.get("equipPos") or 0)
        tex = int(row.get("tex") or 0)
    except (TypeError, ValueError):
        return None, "invalid_item_row", fields
    res = str(row.get("resource") or "").strip()
    fields.update({"resource": res, "tex": tex, "equipPos": pos})
    if pos not in (MAIN_WEAPON_SLOT, SECOND_WEAPON_SLOT, MELEE_SLOT):
        # Not a first-person weapon slot; leave armour/grenades to the caller.
        return iid, "non_weapon_slot", fields

    special = wc.SPECIAL_REASONS.get(iid)
    if special is not None:
        reason = special[0]
        fields["evidence"] = special[1]
        if reason == "hero_melee" or reason.startswith("internal_"):
            return iid, reason, fields
        # Reserved/orphan rows are not ordinary player weapons.  They may only
        # survive through a verified same-model base below.
        if wc.texture_verified(res, tex):
            return iid, reason + "_verified", fields
    elif wc.texture_verified(res, tex):
        return iid, "verified_resource_texture", fields

    base = _same_resource_verified_base(iid, row, rows)
    if base > 0 and base != iid:
        base_row = rows.get(int(base)) or {}
        fields.update({"fallback": int(base),
                       "fallback_resource": str(base_row.get("resource") or ""),
                       "fallback_tex": int(base_row.get("tex") or 0)})
        return int(base), "fallback_same_model_verified_base", fields
    return None, "unverified_no_verified_base", fields


def _same_resource_verified_base(itemid: int, row: Dict[str, Any],
                                 rows: Dict[int, Dict[str, Any]]) -> int:
    """Closest verified tex=0 row with the SAME `resource` and slot, or -1.

    Deliberately does NOT fall back to the same subType: the old
    `weapon_base_id` did that and could replace e.g. a knife with an unrelated
    `subType` neighbour.  If the same model has no verified plain variant, the
    caller rejects the slot instead of guessing.
    """
    from . import weapon_catalog as wc
    try:
        pos = int(row.get("equipPos") or 0)
        tex = int(row.get("tex") or 0)
    except (TypeError, ValueError):
        return -1
    if pos not in (MAIN_WEAPON_SLOT, SECOND_WEAPON_SLOT, MELEE_SLOT):
        return -1
    res = str(row.get("resource") or "").strip()
    if not res:
        return -1
    peers = []
    for rid, cand in rows.items():
        try:
            if (int(cand.get("equipPos") or 0) != pos
                    or int(cand.get("tex") or 0) != 0
                    or str(cand.get("resource") or "").strip() != res):
                continue
        except (TypeError, ValueError):
            continue
        if int(rid) == int(itemid):
            continue
        if wc.texture_verified(res, 0):
            peers.append(int(rid))
    if not peers:
        return -1
    peers.sort(key=lambda j: (abs(j - int(itemid)), j))
    return peers[0]


def sanitize_equipmap(equipmap: Dict[int, int]) -> Dict[int, int]:
    """Validate player weapon slots against the audited resource catalogue.

    Verified `resource + tex` pairs keep their original id (403085/606132 stay
    untouched).  Unverified skins may fall back to their same-model base; an
    unknown id or a skin with no verified base is removed from this ScBorn map.
    The saved loadout is never written.
    """
    out: Dict[int, int] = {}
    rows = _items_by_id()
    for slot, raw in (equipmap or {}).items():
        try:
            iid = int(raw)
            slot_i = int(slot)
        except (TypeError, ValueError):
            continue
        kept, reason, fields = _player_weapon_decision(iid, rows)
        if kept is None:
            log.warning("PLAYER-EQUIP reject slot=%s reason=%s fields=%s",
                        slot_i, reason, fields)
            continue
        if kept != iid:
            log.warning("PLAYER-EQUIP fallback slot=%s id=%s -> %s reason=%s "
                        "fields=%s", slot_i, iid, kept, reason, fields)
        elif reason not in ("non_weapon_slot", "verified_resource_texture"):
            (log.info("PLAYER-EQUIP keep slot=%s id=%s reason=%s fields=%s",
                     slot_i, iid, reason, fields) if log.isEnabledFor(20) else None)
        out[slot_i] = int(kept)
    return out


def _drop_unowned_secondary(roleid: int, rows: Dict[int, int]) -> Dict[int, int]:
    """【v47】副武器（槽 12）如果**不在玩家背包里**，本局就不装备它。

    客户端「快速切枪」是按 `PlayerData.EquipWeapons` 循环的，
    而那份列表只要 `equips.ContainsKey(12)` 就把 12 加进去：

        // client.data/PlayerData.cs
        if (equips.ContainsKey(12)) list.Add(12);
        if (equips.ContainsKey(50)) list.Add(50);

    新号的 `starter_loadouts()` 里塞了一把格洛克（`COMMON[12]`），装备方案
    一旦没保存过就每局都回落到它 —— 玩家把仓库里的手枪卖掉/从没拥有，
    按切枪键仍会切到 12 槽那把「自己没有的枪」，客户端拿不到模型，
    表现就是「按了没反应」。这里直接把 12 槽去掉，列表就变成
    [主武器, 刀]，切枪自然落到刀上。
    """
    if not rows:
        return rows
    from . import handlers
    world = handlers.world
    if world is None:
        return rows
    try:
        role = world.role(int(roleid))
    except Exception:
        return rows
    if role is None:
        return rows
    try:
        owned = {int(i) for i in (role.data or {}).get("pkg_items", [])}
    except (TypeError, ValueError):
        return rows
    if not owned:
        # 老存档没有背包记录，别乱删（宁可保持原样）
        return rows
    side = int(rows.get(SECOND_WEAPON_SLOT) or 0)
    if side and side not in owned:
        (log.info("PLAYER-EQUIP role=%s 副武器 %s 不在背包里 -> 本局不装备"
                 "（快速切枪会走刀）", roleid, side) if log.isEnabledFor(20) else None)
        out = dict(rows)
        out.pop(SECOND_WEAPON_SLOT, None)
        return out
    return rows


class Battle:
    """Drives one room's match."""

    def __init__(self, room: R.Room):
        self.room = room
        self.fighters: Dict[int, Fighter] = {}
        self.round = 0
        self.grenade_projectiles = {}
        self.grenade_serial = 0
        self.started = False
        self.begun = False
        self.biochem = None
        self.challenge = None
        # 爆破模式（gameMode 2）的安包/拆包状态机，证据说明见 bomb.py
        self.bomb = bomb.Bomb(self)
        # 生化模式的 1 秒 tick（掉箱子 / 感染倒计时 / 回合时间到）
        self._bio_handle = None
        self.round_started_at = 0.0
        self.prepare_until = 0.0
        self._timer = None
        # 回合结算状态
        self.round_over = False
        self.fight_over = False
        self.police_wins = 0
        self.terrist_wins = 0
        # 出生点轮换序号（见 born()）
        # 每个阵营的下一个出生点序号（**必须自增**，见 _take_spawn_seq）
        self._spawn_seq: Dict[int, int] = {}
        # 可复活模式（rebornRule != 0）：没有团灭概念，胜负看 winKillCount。
        # 团战 rebornRule=2、winKillCount=40、round=1；爆破等 rebornRule=0。
        _rule = gamedata.rule(room.levelid) or {}
        try:
            self.has_relive = int(_rule.get("rebornRule") or 0) != 0
        except (TypeError, ValueError):
            self.has_relive = False
        from . import special_modes
        self.win_kill_count = special_modes.kill_target(
            _rule, getattr(room, "equiplimitid", 0), getattr(room, "playerlimits", 8) or 8)
        # **复活必须由服务端驱动。** 客户端自己不会在倒计时结束后发 CsRelive ——
        # 对照离线端 `FightServer.DelayPrepare`（它镜像官方服务端行为）：
        #     WaitForSeconds(rebornTime) -> ClientManager.Prepare(15) -> BornPlayer()
        # 也就是：等 rebornTime 秒 -> 发 ScBornPrepare（客户端 Prepare：清
        # WaitingRelive + 开选装备界面）-> 再发 ScBorn 真正复活。
        # 少了后面两步，玩家就会「倒计时归零后一直躺在原地」。
        self.reborn_item = bool(_rule.get("rebornItem"))
        try:
            self.reborn_time = int(_rule.get("rebornTime") or 0)
        except (TypeError, ValueError):
            self.reborn_time = 0
        if self.reborn_time <= 0:
            self.reborn_time = WAIT_RELIVE
        # 出生保护时长改为**读表**（GameRule.rebornInvincibleTime）：
        # 原来死写 5 秒，团队竞技要改成 1 秒根本改不动。
        # ★ v59：必须用 float —— 用户口径是 1.5 秒，int() 会截成 1。
        try:
            self.reborn_invincible = float(_rule.get("rebornInvincibleTime") or 0)
        except (TypeError, ValueError):
            self.reborn_invincible = 0.0
        if self.reborn_invincible <= 0:
            # 生化模式（GameMode 8/10）表里写 0 就是**不无敌**，不再回退 5 秒；
            # 其它没有配置的模式仍保留原来的兜底，避免团队竞技等行为变化。
            try:
                _gm = int(getattr(self.room, "gamemode", 0) or 0)
            except (TypeError, ValueError):
                _gm = 0
            if _gm not in (8, 10):
                self.reborn_invincible = REBORN_INVINCIBLE
        # 【v20】高难房复活无敌按房间级覆盖：排位歼灭(mode3) 规则表写 5 秒、
        # 联赛 SOLO(mode4) 写 3 秒，用户嫌太长，统一 1.5 秒。外面自建房、
        # 其它模式一律沿用规则表原值。只改这里，不动共享的 GameRule 行。
        try:
            from . import rank_profiles as _rp
            _rank_inv = _rp.spawn_invincible(
                room, int(getattr(room, "gamemode", 0) or 0))
            if _rank_inv is not None:
                self.reborn_invincible = float(_rank_inv)
        except Exception:
            (log.debug("高难房无敌覆盖失败", exc_info=True) if log.isEnabledFor(10) else None)
        self._relive_timers: Dict[int, Any] = {}
        # 每个 role 的复活回调代次。取消/重新安排时递增；旧定时器即使已经
        # 进入事件队列，回调也会因代次不匹配而被丢弃（不能跨回合复生）。
        self._relive_seq: Dict[int, int] = {}
        self._inv_timers: Dict[int, Any] = {}
        # 普通多回合模式的回合间隔定时器（结算面板 -> 重新准备下一回合）
        self._intermission_timer = None
        # 普通模式重新准备的阶段/序号：旧回调必须能识别自己已经过期。
        # phase: idle -> intermission -> prepare -> round / fight
        self._round_phase = "idle"
        self._intermission_seq = 0
        self.total_rounds = max(1, int((gamedata.rule(room.levelid) or {})
                                       .get("round") or 1))
        # 穿甲弹改为真实扣仓库（stackable.take_item 写库 + 推 ScPackageSync），
        # 退出对局不再恢复，所以这里不再需要局内计数。
        # 连杀计数（竞技/非生化模式）：roleid -> 当前连杀数。死亡清零。
        self.combo: Dict[int, int] = {}

    # -- roster ----------------------------------------------------------
    def _ammobags_for(self, roleid: int) -> Tuple[int, ...]:
        """这个角色拥有的弹匣道具 id（910001~910007）。对局内缓存一次。"""
        cache = getattr(self, "_ammobags_cache", None)
        if cache is None:
            cache = self._ammobags_cache = {}
        hit = cache.get(int(roleid))
        if hit is not None:
            return hit
        out: Tuple[int, ...] = ()
        try:
            from . import equip as _eq
            role = _role_obj(roleid)
            out = tuple(sorted({i for i in (_eq.owned_ids(role) if role is not None else ())
                                if 910001 <= int(i) <= 910007}))
        except Exception:
            (log.debug("读取弹匣道具失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        cache[int(roleid)] = out
        return out

    def add(self, member: R.Member) -> Fighter:
        f = self.fighters.get(member.roleid)
        if f is None:
            f = Fighter(member.roleid, member.name, member.side)
            # The timeout path receives no CsChooseEquip. Start from the same
            # saved active group/actor sent in ScEquipGroup at login.
            from . import equip, handlers
            role = handlers.world.role(member.roleid) if handlers.world else None
            if role is not None:
                f.equipindex = equip.active_index(role)
                f.actorid = equip.chosen_actors(role).get(int(member.side), 0)
            self.fighters[member.roleid] = f
        else:
            f.side = member.side
        return f

    def alive(self) -> List[Fighter]:
        return [f for f in self.fighters.values() if f.born]

    # -- spawn position --------------------------------------------------
    def _take_spawn_seq(self, side: int) -> int:
        """取这个阵营的下一个出生点序号（每个阵营独立轮换）。

        **原来 `_spawn_seq` 只赋了一次 0，从来没自增** —— 同一边的两个人
        永远拿到 `idx=0`，也就是同一个出生点（实测「两个联盟军叠在同一个点上」，
        日志里两条 BORNDBG 的 pos 完全一样、bornidx 都是 0）。
        """
        key = int(side)
        seq = int(self._spawn_seq.get(key, 0))
        self._spawn_seq[key] = seq + 1
        return seq

    # 【v16】僵尸复活权重：下标 = 复活点周围 crowd_range 内的活人数。
    # 4 人及以上触底（默认 0.1 = 满权重的 10%），但**永不排除**，
    # 所以幽灵仍可能直接刷在人堆旁边（用户要的「刺激」）。
    _BIO_SPAWN_W = (1.0, 0.7, 0.45, 0.25, 0.1)

    def _bio_spawn_points(self) -> List[Tuple[float, float, float]]:
        """【v16】本回合的全图 8 个复活点，**每局重新随机**。

        不再用「原出生点区里挑 8 个站位」（那 8 点只跨 5~17m）。改成从
        BOT 真正用来寻路的烘焙网格 `geometry.grid_for_scene()` 里，按地图
        AABB 切成 4×2 八个区域，每区随机抽一个「站得下、能寻路」的地面层
        节点 —— 8 点铺满整张图（间距中位约 40~50m），幽灵可能就在人类身边
        复活，也可能在地图另一头。

        点挂在 `self.biochem.spawn_points` 上：Biochem 每回合新建，所以
        「每局随机」是自动的，人类开局和本回合所有僵尸复活共用同一组点。
        任何一步失败返回 []，调用方退回 v13 的 `spawnpoints.json` bio 表。
        """
        bio = getattr(self, "biochem", None)
        if bio is None:
            return []
        cached = getattr(bio, "spawn_points", None)
        if cached and len(cached) == 8:
            return cached
        try:
            from .. import gamedata as _gd
            scene = (_gd.map_row(self.room.mapid) or {}).get("scene") or ""
            # 【v17】算法抽到模块级 grid_zone_points()，补给箱候选点共用同一套。
            out = grid_zone_points(scene, 1)
            if len(out) != 8:
                return []
            bio.spawn_points = out
            (log.info("BIO-SPAWN-POINTS scene=%s 本局 8 点=%s", scene,
                     [(round(p[0], 1), round(p[1], 1), round(p[2], 1)) for p in out]) if log.isEnabledFor(20) else None)
            return out
        except Exception:
            log.exception("生成全图复活点失败，退回出生点表")
            return []

    def _bio_weighted_index(self, pts, n: int) -> int:
        """僵尸复活：按「点周围有多少活人」降权的加权随机，不硬排除。"""
        from ..config import CONFIG as _C
        try:
            rng = max(1.0, float(getattr(
                _C, "biochem_spawn_crowd_range", 10.0) or 10.0))
            floor = max(0.01, float(getattr(
                _C, "biochem_spawn_min_weight", 0.10) or 0.10))
        except (TypeError, ValueError):
            rng, floor = 10.0, 0.10
        weights = [1.0] * n
        if pts:
            counts = [0] * n
            for g in self.fighters.values():
                try:
                    if not g.born or float(getattr(g, "hp", 0) or 0) <= 0:
                        continue
                    if self.biochem.is_zombie(g.roleid):
                        continue
                    gp = _fighter_pos(g)
                    if gp is None:
                        continue
                    for i, p in enumerate(pts):
                        if math.hypot(gp[0] - p[0], gp[2] - p[2]) <= rng:
                            counts[i] += 1
                except Exception:
                    continue
            last = len(self._BIO_SPAWN_W) - 1
            weights = [max(floor, self._BIO_SPAWN_W[min(c, last)])
                       for c in counts]
            if any(counts):
                (log.info("BIO-SPAWN-W crowds=%s weights=%s", counts,
                         [round(w, 2) for w in weights]) if log.isEnabledFor(20) else None)
        # 绝对概率保底：8 个点各先分到 min_prob（默认 10%），剩下
        # 1 - n*min_prob 才按上面的相对权重分。只按相对权重算的话，
        # 「1 个点挤 4 人 + 其余 7 点全空」时它只有 1.6%，用户说的
        # 「还有 10% 概率会在这里复活」就落空了。
        try:
            prob = float(getattr(_C, "biochem_spawn_min_prob", 0.10) or 0.0)
        except (TypeError, ValueError):
            prob = 0.10
        prob = min(max(0.0, prob), 1.0 / max(1, n))
        rest = 1.0 - n * prob
        total = sum(weights) or 1.0
        probs = [prob + rest * w / total for w in weights]
        r = random.random()
        for i, p in enumerate(probs):
            r -= p
            if r <= 0:
                return i
        return n - 1

    def _bio_spawn_index(self, f: "Fighter", side: int) -> int:
        """生化模式的复活点下标（【v16】全图 8 点，每局随机）。

        · 人类开局：0..7 打乱后按顺序发，8 人各占一点、绝不重样；
        · 僵尸复活：在这 8 点里按「周围活人数」加权随机，人越多概率越小，
          但 4 人触底后仍留 10% 相对权重 —— 不硬排除，可能贴脸刷。
        · 非生化房 / 网格不可用：退回原来的阵营自增 + v13 出生点表。
        """
        bio = getattr(self, "biochem", None)
        # 【v20】SOLO 战：全图固定 8 点预设。开局 8 人按洗牌顺序各占一点
        # （绝不重样）；阵亡复活时在 8 点里随机取一点。点本身整个游戏不变，
        # 变的只是「谁站哪个点」。
        if int(getattr(self.room, "gamemode", 0) or 0) == 4:
            try:
                from .. import gamedata as _solo_gd
                _solo_scene = (_solo_gd.map_row(self.room.mapid) or {}).get("scene") or ""
                _solo_pts = solo_spawn_points(_solo_scene)
            except Exception:
                _solo_pts = []
            if len(_solo_pts) == 8:
                _already = int(getattr(f, "deaths", 0) or 0) > 0
                if _already:
                    return int(random.randrange(8))
                order = getattr(self, "_solo_order", None)
                if not order or len(order) != 8:
                    order = list(range(8))
                    random.shuffle(order)
                    self._solo_order = order
                    self._solo_seq = 0
                seq = int(getattr(self, "_solo_seq", 0) or 0)
                self._solo_seq = seq + 1
                return int(order[seq % 8])
        if bio is None:
            return self._take_spawn_seq(side)
        pts = self._bio_spawn_points()
        n = len(pts) if pts else 0
        if n <= 0:
            try:
                from .. import gamedata as _gd
                scene = (_gd.map_row(self.room.mapid) or {}).get("scene") or ""
                n = len((_spawnpoints().get(scene) or {}).get("bio") or []) or 8
            except Exception:
                n = 8
        try:
            zombie = bool(bio.is_zombie(f.roleid))
        except Exception:
            zombie = False
        if zombie:
            if not pts:
                # 退回 v13：3m 内有活人的点直接排除
                busy = set()
                try:
                    from .. import gamedata as _gd2
                    scene2 = (_gd2.map_row(self.room.mapid) or {}).get("scene") or ""
                    pts2 = (_spawnpoints().get(scene2) or {}).get("bio") or []
                    for g in self.fighters.values():
                        if not g.born or float(getattr(g, "hp", 0) or 0) <= 0:
                            continue
                        if bio.is_zombie(g.roleid):
                            continue
                        gp = _fighter_pos(g)
                        if gp is None:
                            continue
                        for i, p3 in enumerate(pts2):
                            if math.hypot(gp[0] - p3[0], gp[2] - p3[2]) < 3.0:
                                busy.add(i)
                except Exception:
                    pass
                free = [i for i in range(n) if i not in busy]
                return int(random.choice(free or list(range(n))))
            return self._bio_weighted_index(pts, n)
        order = getattr(self, "_bio_order", None)
        if not order or len(order) != n:
            order = list(range(n))
            random.shuffle(order)
            self._bio_order = order
            self._bio_seq = 0
        seq = int(getattr(self, "_bio_seq", 0) or 0)
        self._bio_seq = seq + 1
        return int(order[seq % n])

    def spawn_pos(self, side: int, index: int, exact: bool = False
                  ) -> Tuple[Dict[str, int], int, Optional[Dict[str, int]]]:
        """A real spawn point for this room's map, as a Vec3.

        返回 **三元组** `(pos, bornidx, quat|None)` —— `born()` 是按三个值解包的，
        这里任何一条 return 少了 quat 都会让 `born()` 抛
        `ValueError: not enough values to unpack (expected 3, got 2)`
        （实测：mapid=25 场景 S_Glass 还没进 spawnpoints.json 时，
        CsChooseEquip 直接 500、玩家永远停在选装备界面）。
        """
        from .. import gamedata
        row = gamedata.map_row(self.room.mapid) or {}
        scene = row.get("scene") or ""
        table = _spawnpoints().get(scene) or {}
        # 【v13】生化模式（mode 8/10）用专门的 `bio` 表：8 个点，人类出生和
        # 僵尸复活共用。原来生化专用图的 police 只有 1 个点（实测
        # `s_dust2_01_Biochemical` police=1 / terrist=1、`S_gongdian_Biochemical`
        # police=1），8 个人类全叠在同一个坐标上 —— 就是用户说的「两个固定复活点」。
        # 这些生化场景和普通版是同一张地图（坐标完全一致，已核对 gongdian 的
        # police[0] 两边一模一样），所以 8 个点直接从普通版的 police 区借。
        _bio_table = table.get("bio")
        # 【v16】生化房优先用本局动态生成的全图 8 点；网格不可用时
        # 才退回 v13 写在 spawnpoints.json 里的固定 bio 表。
        _dyn = (self._bio_spawn_points()
                if getattr(self, "biochem", None) is not None else [])
        # 【v20】SOLO 战（mode4）用全图固定 8 点预设。网格不可用时才回退
        # 原出生点表，逻辑和生化房一致。
        _solo = (solo_spawn_points(scene)
                 if int(getattr(self.room, "gamemode", 0) or 0) == 4 else [])
        if len(_solo) == 8:
            key = "solo"
            pts = _solo
        elif getattr(self, "biochem", None) is not None and len(_dyn) == 8:
            key = "bio"
            pts = _dyn
        elif getattr(self, "biochem", None) is not None and _bio_table:
            key = "bio"
            pts = _bio_table
        else:
            key = "police" if side == 1 else "terrist"
            pts = table.get(key) or table.get("police") or []
        # 【v1.1.1】团队/歼灭覆盖（仓库A/B 四选一）。只换 police/terrist 的
        # 坐标来源，数组长度、bornidx 语义、以及其它模式一律不动。
        _ov = _team_spawn_rule(
            scene, key, int(getattr(self.room, "gamemode", 0) or 0))
        _ov_points = (_ov or {}).get("points") or []
        if _ov_points:
            pts = [tuple(p) for p in _ov_points]
        if not pts:
            log.warning("no spawn points for scene %r (mapid=%s); using origin",
                        scene, self.room.mapid)
            return _vec3(0.0, 1.0, 0.0), 0, None
        # 有些地图的 SpawnPoints 是**残缺的** —— 实测：
        #     SpaceLab_W（超空间实验室） police=1 terrist=1，两队同一个点 [1.85,0,9.0]
        #     subway（封锁地铁）         police=1 terrist=1，两队高度差 6.14 米
        # 正常图每边 10~15 个点。客户端 `Born(PlayerData,bool,int)` 里就是
        # `trans.position = data.position` —— 服务端发什么它就站哪，所以坐标不好
        # 就会掉出地图 / 穿模。这里只能报警（数据是资源包里写死的），
        # 排查用 tools/check_spawnpoints.py。
        if len(pts) < 3:
            log.warning(
                "场景 %r 的 %s 出生点只有 %d 个（正常 10~15）—— "
                "这张图的 SpawnPoints 是残缺的，进图可能掉出地图/穿模",
                scene, key, len(pts))
        # **绝对不要过滤/重排这张数组**：`bornidx` 是客户端
        # `Level.GetSpawnPoint(side, bornidx)` 的**数组下标**，不是「第几个好点」。
        # 旧代码按 y 中位数筛掉异常点后 `index % len(clean)`，服务端算出的 idx
        # 指向 clean 列表、客户端却拿它索引完整列表 —— 两边不是同一个点
        # （出生点表一错位就会把人放进地图下面）。
        # 1.8.1 scene extraction now matches the exact client child order.
        # Authored high/low spawns are valid; a median-Y filter corrupts bornidx.
        if _ov_points:
            # 【v1.1.1】四个预设点：正常出生随机取一个；
            # `exact=True`（给别人补发 ScBorn）按他自己的 bornidx 取同一点，
            # 否则同一个人的模型会在别人屏幕上出现在别的位置。
            idx = (int(index) % len(pts)) if exact else random.randrange(len(pts))
        else:
            idx = index % len(pts)
        x, y, z = pts[idx]
        # Some authored points and baked polygons sit on native HackLayer
        # geometry. Keep its native quit check intact and choose legal ground.
        from . import geometry
        physical=geometry.for_scene(scene)
        safe=geometry.spawn_ground(scene,(x,y,z)) if physical is not None else None
        if safe is not None:
            x,y,z=safe
        else:
            log.error('SPAWN-NO-SAFE-GROUND scene=%s side=%s index=%s',scene,key,idx)
        # 抬一点高度，避免碰撞体卡进地面/墙面（见 config.spawn_y_offset 的说明）
        try:
            from ..config import CONFIG as _C
            y = y + float(getattr(_C, "spawn_y_offset", 0.0) or 0.0)
        except Exception:
            pass
        # **朝向也要用场景里的**（对齐人机模式的 bornData.Transform(trans)）。
        # 客户端 PlayerData.Apply 里：
        #     player.rotation = Quaternion.Euler(0f, born.quat.eulerAngles.y + Random(-45,45), 0f);
        # 发单位四元数的话 eulerAngles.y = 0，角色朝向随机 —— 面朝墙时一动就卡进几何体。
        quat = None
        try:
            from ..config import CONFIG as _C2
            _use_q = bool(getattr(_C2, "spawn_use_scene_quat", False))
        except Exception:
            _use_q = False
        if _use_q or self.challenge is not None:
            q = (table.get(key + "_quat") or [])
            if 0 <= idx < len(q):
                qx, qy, qz, qw = q[idx]
                quat = _vec4(qx, qy, qz, qw)
        # 【v46】SOLO（mode4）复活朝向：8 个预设点各自固定朝开阔地。
        # `spawn_use_scene_quat` 是给「场景自带 police/terrist_quat」用的开关，
        # 和这里无关 —— SOLO 的点是 v20 动态铺满全图的，场景里没有对应朝向。
        if quat is None and key == "solo":
            try:
                from ..config import CONFIG as _C3
                _facing_on = bool(getattr(_C3, "spawn_solo_facing", True))
            except Exception:
                _facing_on = True
            if _facing_on:
                _fy = solo_spawn_facings(scene)
                if 0 <= idx < len(_fy):
                    quat = _yaw_quat(_fy[idx])
        # 【v1.1.1】团队/歼灭：统一朝正东南西北（yaw 已吸附到 90° 倍数）。
        # 客户端会在此基础上再随机 ±45°，所以按轴向发就不会出现「一落地
        # 就对着墙」；这条优先级最高，覆盖上面的场景 quat。
        if _ov is not None and _ov.get("yaw") is not None:
            try:
                quat = _yaw_quat(math.radians(float(_ov["yaw"])))
            except (TypeError, ValueError):
                log.warning("SPAWN-OVERRIDE bad yaw scene=%s key=%s", scene, key)
        return _vec3(x, y, z), idx, quat

    # -- outgoing --------------------------------------------------------
    def send_all(self, type_id: int, **fields) -> None:
        from . import room_handlers
        for s in room_handlers._sessions_of(self.room,
                                            room_handlers._kind_for(type_id)):
            s.send(type_id, **fields)

    def broadcast_positions(self, entries: Dict[int, dict]) -> None:
        """把若干角色的位置推给全场（`ScRoleStatusSync`，和 UDP 那条同构）。

        `entries[roleid]` 是已经按线上缩放好的
        `{"pos": {x,y,z}, "quat": {w,x,y,z}, "speed": {x,y,z}}`（Vec3=short×100、
        Vec4=short×20000）。

        客户端 `ClientManager.RoleStatusSync` 的三条硬门（都要满足才会动）：
            if (!Status.Rounding || servertime < lastSyncServerTime) return;
            if (!DataPool.IsRelated(key) && players.TryGetValue(key, ...))
        ⇒ ① 必须在回合中；② `servertime` 要用**墙上毫秒**且单调不减，否则整包被丢；
        ③ 这个角色不能被标成机器人 —— 一旦发过 `ScManageAI`，`IsRelated` 为真，
        服务端推的位置全部作废（所以 bots 的两条驱动路线互斥，见 config.py）。
        位移超过 8 米（sqrMagnitude>64）时客户端直接 teleport，否则插值跟随。
        """
        if not entries:
            return
        self.send_all(ID.SC_ROLE_STATUS_SYNC,
                      rolestatuses=entries,
                      servertime=int(time.time() * 1000))

    def send_others(self, except_roleid: int, type_id: int, **fields) -> None:
        """发给房间里除 `except_roleid` 之外的所有人。

        **第一个参数不能叫 `roleid`**：很多协议自己就有 `roleid` 字段，
        调用时写 `send_others(rid, TID, roleid=rid, ...)` 会撞成
        `TypeError: got multiple values for argument 'roleid'`。
        """
        from . import room_handlers
        for s in room_handlers._sessions_of(self.room,
                                            room_handlers._kind_for(type_id)):
            if s.roleid != except_roleid:
                s.send(type_id, **fields)

    # -- flow ------------------------------------------------------------
    def send_to_role(self, target_roleid: int, type_id: int, **fields) -> None:
        """只发给某个角色（走房间服那条连接，退回到它唯一的一条）。

        生化模式的「选僵尸」必须**单人**发 ScBornPrepare：广播的话人类也会
        重新弹选装备界面。

        **第一个参数不能叫 `roleid`**：很多协议自己就有 `roleid` 字段，
        `send_to_role(rid, TID, roleid=rid, ...)` 会撞成
        `TypeError: got multiple values for argument 'roleid'`
        （ScBorn 补发就踩过这个）。
        """
        from . import handlers as _h
        if _h.world is None:
            return
        s = (_h.world.session_of_role(target_roleid, "room")
             or _h.world.session_of_role(target_roleid))
        if s is not None and not s.closed:
            s.send(type_id, **fields)
    def begin(self, only: Optional[Session] = None) -> None:
        """Open the equip screen.

        Called on every room-server login.  The first caller arms the prepare
        window; later joiners just get their own ScBornPrepare instead of
        re-broadcasting to everyone already waiting.
        """
        # PvP 房间里塞几个人机（服务端侧假玩家，进成员表 + fighters，
        # 所以客户端当真人渲染，也能被打）。
        try:
            from . import bots as _bots
            from . import pve as _pve
            if _pve.is_pve(self.room.gamemode):
                _bots.install(self, 0)  # Same-side members were allocated in the lobby.
            else:
                from ..config import CONFIG
                n = int(getattr(CONFIG, "bots_per_room", 0) or 0)
                if n > 0:
                    _bots.install(self, n)
        except Exception:
            (log.debug("install bots failed", exc_info=True) if log.isEnabledFor(10) else None)

        for m in self.room.members.values():
            # 【v47】单个成员装备/角色数据异常不能让整场起不来：以前这里
            # 抛一次，下面的 ScBornPrepare 就发不出去 —— 客户端表现就是
            # 「加载界面卡在 90%、BGM 还在响」，而且只有那一局这样。
            try:
                self.add(m)
            except Exception:
                log.exception("ROOM-LOGIN add member failed room=%s role=%s",
                              self.room.roomid, getattr(m, "roleid", "?"))

        if self.begun or self.started:
            if only is not None:
                only.send(ID.SC_BORN_PREPARE,
                          remaintime=max(1, int(self.prepare_until - time.time())))
            return

        self.begun = True
        self.prepare_until = time.time() + PREPARE_TIME
        # **生化模式要在「出生之前」就把 Biochem 建好**：`born()` 判断出生点
        # 要用它（人类一律 police 点、僵尸 terrist 点 —— 和客户端
        # `VirtualServer.Born` 按 actor camp 推 side 的规则对齐）。
        # 等到 start_round 才建的话，第一轮出生用的还是 roster 的随机 side，
        # 会出现「人类被分到 side=2 → 出生在地图另一头/半空中」。
        from . import biochem as _bio
        if self.biochem is None and _bio.is_biochem(self.room.gamemode):
            try:
                self.biochem = _bio.Biochem(self)
            except Exception:
                # 生化对象建不起来也要先把准备界面发出去（否则客户端卡加载），
                # 后面 born() 有 biochem is None 的兜底分支。
                log.exception("ROOM-LOGIN biochem init failed room=%s",
                              self.room.roomid)
                self.biochem = None

        # 挑战模式（PVE，gameMode 12）：按 ChallengeMode/ChallengeRound/MonsterGroup
        # 刷怪。怪物 AI 在客户端（TPSMonsterBehaviour），服务端只发 ScMonsterBorn
        # 并收 CsMonsterAttack / CsMonsterHide。
        from . import pve as _pve
        from ..config import CONFIG as _CONFIG
        if (getattr(self, "challenge", None) is None
                and _pve.is_pve(self.room.gamemode)
                and int(getattr(_CONFIG, "pve_enabled", 0) or 0)):
            self.challenge = _pve.Challenge(self)
            (log.info("battle for room %s: PVE challenge modeid=%s rounds=%s",
                     self.room.roomid, self.challenge.mode.get("id"), self.challenge.rounds) if log.isEnabledFor(20) else None)
        (log.info("battle for room %s: ScBornPrepare(%ds), %d player(s)",
                 self.room.roomid, PREPARE_TIME, len(self.fighters)) if log.isEnabledFor(20) else None)
        if self.biochem is not None:
            # Clear the previous round's TPS objects BEFORE new Born messages.
            self.send_all(ID.SC_ROUND_PREPARE, remaintime=PREPARE_TIME)
        self.send_all(ID.SC_BORN_PREPARE, remaintime=PREPARE_TIME)
        if self.biochem is not None:
            try:
                self._spawn_prepared_bots()
            except Exception:
                log.exception("ROOM-LOGIN spawn prepared bots failed room=%s",
                              self.room.roomid)
        elif not _pve.is_pve(self.room.gamemode):
            # **普通 PvP 首局也要在准备期把已 ready 的服务端 BOT 出生。**
            # 原来只有生化分支调用 _spawn_prepared_bots，普通模式 BOT 在
            # 准备期始终 born=False；即使真人确认，on_choose_equip 也会因为
            # len(alive) < len(fighters) 不 start_round，只能等满 45 秒
            # _prepare_expired 强制出生 BOT。这里不新增成员，只准备
            # bots.install/room_fill 已经放进房间且 ready 的 BOT。
            try:
                self._spawn_prepared_bots(ready_only=True)
            except Exception:
                log.exception("ROOM-LOGIN spawn prepared bots failed room=%s",
                              self.room.roomid)

        # 挑战模式的怪不能在这里刷：这时玩家还在选装备（GameLoading/装备界面），
        # ScMonsterBorn 会在战斗场景就绪前到达并被丢。改到第一个玩家 born()
        # 之后（见文件末尾 born()）。

        # If somebody never presses 确定 the round would never start, so force
        # it when the prepare window runs out.
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            self._timer = loop.call_later(PREPARE_TIME, self._prepare_expired)
        except Exception:
            (log.debug("could not arm the prepare timer", exc_info=True) if log.isEnabledFor(10) else None)

    def _spawn_prepared_bots(self, ready_only: bool = False) -> None:
        from . import bots
        for f in list(self.fighters.values()):
            if not bots.is_bot(f.roleid) or f.born:
                continue
            if ready_only:
                member = self.room.members.get(f.roleid)
                if member is None or not member.ready:
                    continue
            self.born(f)

    def _prepare_expired(self) -> None:
        self._timer = None
        if self.started or self.round_over or self.fight_over:
            return
        pending = [f for f in self.fighters.values() if not f.born]
        if pending:
            (log.info("prepare window expired: force-spawning %d player(s)",
                     len(pending)) if log.isEnabledFor(20) else None)
            for f in pending:
                if not f.born:
                    self.born(f)
        self.start_round()

    def _normalise_equip_index(self, roleid: int, requested: Any) -> int:
        """Resolve a loadout tab index against the role's saved rows.

        The client sends `OperationAgent.equipindex` (0-based, the tab the
        player actually confirmed).  A missing/-1 value means "keep the saved
        active tab"; an out-of-range tab is clamped to 0 and logged instead of
        silently reading the wrong saved group.
        """
        from . import equip, handlers
        role = handlers.world.role(roleid) if handlers.world is not None else None
        rows = equip.loadouts_of(role) if role is not None else []
        try:
            idx = int(requested)
        except (TypeError, ValueError):
            idx = -1
        if idx < 0:
            idx = equip.active_index(role) if role is not None else 0
        if rows and not (0 <= idx < len(rows)):
            log.warning("PLAYER-EQUIP role=%s group=%s out of range (%d rows); "
                        "using group 0", roleid, idx, len(rows))
            idx = 0
        return max(0, int(idx))

    def _sanitize_player_equipmap(self, equipmap: Dict[int, int],
                                  roleid: int = 0) -> Dict[int, int]:
        from ..config import CONFIG as _cfg
        out = (sanitize_equipmap(equipmap)
               if getattr(_cfg, "skin_sanitize", True) else dict(equipmap))
        return _drop_unowned_secondary(roleid, out)

    def _loadout_map(self, roleid: int, index: int) -> Dict[int, int]:
        """The weapons for one of the player's saved 装备方案.

        The client NEVER fills `equipmap` -- `Commander.ChooseEquipGroup` sends
        a dictionary it constructs empty at the call site:

            RoomServer.Instance.Send(new CsChooseEquip(
                group, actorid, new Dictionary<int, int>()));

        and `Converter.toBornData` passes it straight through to the player:

            bornData.equipmap = bean.equipmap;

        so taking the message at face value spawns everyone with no weapon at
        all.  The server has to look the loadout up itself.
        """
        from . import equip, handlers
        world = handlers.world
        if world is None:
            return {}
        role = world.role(roleid)
        if role is None:
            return {}
        rows = equip.loadouts_of(role)
        if not rows:
            return {}
        idx = int(index)
        if not (0 <= idx < len(rows)):
            log.warning("PLAYER-EQUIP role=%s group=%s out of range (%d rows); "
                        "using group 0", roleid, idx, len(rows))
            idx = 0
        return {int(k): int(v) for k, v in rows[idx]["equipmap"].items()}

    def _apply_player_equipment(self, f: Fighter, requested: Any,
                                explicit: Any, source: str,
                                prefer_saved: bool = False) -> None:
        """Resolve + validate one player's equipmap without touching the save.

        All entrances (choose, relive, timeout/torch snapshot) go through here so
        a verified skin id is preserved and an unknown id is handled once.
        """
        f.equipindex = self._normalise_equip_index(f.roleid, requested)
        rows: Dict[int, int] = {}
        if isinstance(explicit, dict) and explicit:
            for k, v in explicit.items():
                try:
                    rows[int(k)] = int(v)
                except (TypeError, ValueError):
                    continue
            source = "client"
        elif f.equipmap and not prefer_saved:
            rows = {int(k): int(v) for k, v in f.equipmap.items()}
            source = "current"
        else:
            rows = self._loadout_map(f.roleid, f.equipindex)
            source = "saved"
        before = dict(rows)
        f.equipmap = self._sanitize_player_equipmap(rows, f.roleid)
        if f.equipmap:
            f.human_equipmap = dict(f.equipmap)
        (log.info("PLAYER-EQUIP role=%s group=%s source=%s raw=%s final=%s",
                 f.roleid, f.equipindex, source, sorted(before.items()),
                 sorted(f.equipmap.items())) if log.isEnabledFor(20) else None)

    def bio_eliminated(self, roleid):
        return (roleid in getattr(self.biochem, "eliminated", ()) or
                roleid in getattr(self.biochem, "no_relive", ()))

    def on_choose_equip(self, session: Session, msg: dict) -> None:
        if self.bio_eliminated(session.roleid):
            return
        # 回合结算/结束期间客户端可能还在发「选僵尸」的 CsChooseEquip
        # （感染那一刻弹的窗口）。这时绝不能出生 —— 否则会带着僵尸 actor
        # 进入下一回合（实测「下一局两只幽灵、0 个人类」）。
        if self.round_over or self.fight_over:
            (log.info("role %s 在回合结算期发 CsChooseEquip，忽略", session.roleid) if log.isEnabledFor(20) else None)
            return
        f = self.fighters.get(session.roleid)
        if f is None:
            member = self.room.members.get(session.roleid)
            if member is None:
                log.warning("CsChooseEquip from roleid=%s who is not in room %s",
                            session.roleid, self.room.roomid)
                return
            f = self.add(member)

        if f.born and f.hp > 0 and not (
                self.biochem is not None and f.roleid in self.biochem.pending):
            # Do not change server equipment behind an already spawned client.
            (log.info("role %s 已经活着，忽略重复的 CsChooseEquip", f.roleid) if log.isEnabledFor(20) else None)
            return

        # `equipindex` is the tab the player actually confirmed (0-based).  Do
        # not use `or 0`: a real 0 must stay 0, and a missing/-1 value must fall
        # back to the saved active tab instead of silently selecting group 0.
        _bio = self.biochem
        picking = bool(_bio is not None and f.roleid in _bio.pending)
        # 感染选角 = 原地变僵尸（用死亡/感染时的坐标）；
        # 被击杀后复活选角 = 回出生点，**不能**用 f.syncpos 原地复活。
        _at_spawn = bool(picking and int(f.roleid) in
                         (getattr(_bio, "relive_picks", None) or set()))
        if picking:
            try:
                _bio.relive_picks.discard(int(f.roleid))
            except Exception:
                pass
            # 生化模式「选僵尸角色」：客户端 ZombieSelectWindow -> onEnter ->
            # Commander.ChooseEquip(0, actorid, {})，**equipmap 是空字典**。
            # 这里只换 actorid（僵尸角色，Role.camp == 3），人类装备保持不动。
            _bio.pending.discard(f.roleid)
            t = _bio._pick_timers.pop(f.roleid, None)
            if t is not None:
                try:
                    t.cancel()
                except Exception:
                    pass
            from .bio_rules import zombie_choices
            chosen = int(msg.get("actorid") or 0)
            available = zombie_choices()
            if chosen in available:
                f.actorid = chosen
            elif f.actorid not in available:
                f.actorid = _bio.default_actor()
            # 【v17】选幽灵界面默认框选「上一次选的幽灵」。
            # 客户端 ZombieItemList.RenderTask() 是按 EquipManager.defaultBiochemactor
            # 框选的，而这个值只由 ScSetDefaultActor / ScEquipGroup 的 curbioactor
            # 写入。选幽灵窗口走的是 CsChooseEquip(onActor)，**不会**发
            # CsSetDefaultActor，于是服务端存档里永远是第一个幽灵 —— 每次
            # 复活都重置回第一个。这里把本次选中的写回存档并回推两条协议，
            # 下次复活打开窗口就会自动框选它。纯服务端，不动 DLL。
            try:
                from . import equip as _eq
                from . import handlers as _h
                from .equipment import ID as _EID
                _role = _role_obj(f.roleid)
                if _role is not None and f.actorid:
                    _world = getattr(_h, "world", None)
                    if _eq.set_default_actor(_role, int(f.actorid), _world) == 3:
                        # world.merge_role_data 正常会同步 role.data；这里再显式
                        # 写一次，保证回推的 curbioactor 一定是本次选的幽灵，
                        # 不依赖 world 实现细节 —— 否则后发的 ScEquipGroup 会
                        # 用旧值把 ScSetDefaultActor 刚设好的默认值覆盖回去。
                        _data = dict(_role.data or {})
                        _picks = dict(_eq.chosen_actors(_role))
                        _picks[3] = int(f.actorid)
                        _data["chosen_actor"] = {str(k): v for k, v in _picks.items()}
                        _role.data = _data
                        _payload = _eq.equip_group_payload(_role)
                        session.send(_EID.SC_SET_DEFAULT_ACTOR,
                                     policeid=_payload["curpoliceactor"],
                                     terristid=_payload["curterristactor"],
                                     bioid=_payload["curbioactor"])
                        session.send(_EID.SC_EQUIP_GROUP, equipgroup=_payload)
                        (log.info("BIO-DEFAULT-ZOMBIE role=%s -> %s",
                                 f.roleid, _payload["curbioactor"]) if log.isEnabledFor(20) else None)
            except Exception:
                log.exception("BIO-DEFAULT-ZOMBIE 写回失败 role=%s", f.roleid)
            # 僵尸角色定下来了 -> 按真僵尸的 BioProperty 补算血量
            _bio.refresh_hp(f.roleid)
            (log.info("role %s (%s) 选了僵尸角色 %s（生化选僵尸）",
                     f.roleid, f.name, f.actorid) if log.isEnabledFor(20) else None)
        else:
            f.equipindex = self._normalise_equip_index(f.roleid, msg.get("equipindex"))
            chosen = int(msg.get("actorid") or 0)
            # 生化模式人类手模：客户端 `OperationAgent.Operation` 在
            # `DataPool.IsHeroZombie` 为真时把 actorid 填成
            # `EquipManager.defaultBiochemactor`（camp=3 的生化幽灵），
            # 这是该模式的**正常发包**，不是「上一回合僵尸残留」。
            # 老代码一律替换成 `f.human_actorid or 101`，于是玩家在大厅
            # 选的女角色每次都变回 101 联盟上尉（男手模）—— 这就是
            # 「别的模式选角色能变，生化模式永远默认手模」的根因。
            # 改法：发来的不是合法人类角色时，用大厅已选的人类角色。
            if _bio is not None and (not chosen or _bio.is_zombie_actor(chosen)):
                chosen = self._saved_human_actor(f)
                (log.info("BIO-HUMAN-ACTOR role=%s 生化人类手模改用大厅所选 %s",
                         f.roleid, chosen) if log.isEnabledFor(20) else None)
            f.actorid = chosen
            # 记下人类形态的 actorid —— 生化模式变僵尸后会被换成僵尸角色，
            # 下一回合重置时要用它恢复（见 _next_bio_round）。
            if f.actorid:
                f.human_actorid = f.actorid
            # A real player's saved group is authoritative when the client sends
            # the normal empty equipmap.  Verified skins keep their original id;
            # only genuinely unrenderable/unknown ids are rejected/fallback.
            self._apply_player_equipment(
                f, msg.get("equipindex", f.equipindex),
                msg.get("equipmap"), "choose", prefer_saved=True)
            (log.info("role %s (%s) chose equip=%s actor=%s side=%s -> %d 件武器 %s",
                     f.roleid, f.name, f.equipindex, f.actorid, f.side,
                     len(f.equipmap), sorted(f.equipmap.items())) if log.isEnabledFor(20) else None)

        # the client ignores ScChooseEquipRes (its process() is empty), so the
        # only thing that gets the player off the equip screen is ScBorn
        #
        # **已经活着就不要再 born 一遍。** 客户端会**重复**发 CsChooseEquip
        # （实测一秒内 3~4 次），而每 born 一次就给全场广播一次 ScBorn；
        # 对面的客户端收到 ScBorn 会 `Remove(roleid)` + 重新实例化模型，
        # 一秒里被拆建好几次之后对面就看不见这个人了 ——
        # 实测症状「只有联盟军能看到反叛军，反叛军看不到联盟军」。
        if f.born and f.hp > 0 and not picking:
            (log.info("role %s 已经活着，忽略重复的 CsChooseEquip", f.roleid) if log.isEnabledFor(20) else None)
        else:
            if picking:
                # 必须重新 ScBorn 一次：客户端收到 ScBioInfected/ScBioBoss 时
                # 对**别人**是 Remove(roleid) 把模型删了，只有新的 ScBorn 才会
                # 以僵尸形象重新出现。
                f.born = False
            # 感染选角：原地变僵尸（f.syncpos）。
            # 被击杀后复活选角：**回出生点**（position=None），不能原地站起来。
            if _at_spawn:
                f.syncpos = None
                self.born(f, position=None)
            else:
                self.born(f, position=f.syncpos if picking else None)

        if not self.started and len(self.alive()) >= len(self.fighters):
            self.start_round()

    def force_born_zombie(self, roleid: int, actorid: int = 0) -> None:
        """选僵尸窗口超时：用默认僵尸角色把他重新出生（别让他卡在窗口里）。"""
        if self.round_over or self.fight_over:
            return
        f = self.fighters.get(roleid)
        if f is None:
            return
        if actorid:
            f.actorid = int(actorid)
        elif not self.biochem or not self.biochem.is_zombie_actor(
                int(getattr(f, "actorid", 0) or 0)):
            f.actorid = self.biochem.default_actor() if self.biochem else f.actorid
        if self.biochem is not None:
            self.biochem.refresh_hp(roleid)
        # 【v14】母体/被感染的 bot 全靠这一次 ScBorn 重新出现。
        # 客户端在收到 ScBioBoss / ScBioInfected 时已经把人类模型 Remove 掉了；
        # 只要 born() 里抛一次异常，这个人就永远躺在地上、母体不生成。
        _at = getattr(f, "syncpos", None)
        (log.info("BIO-FORCE-BORN role=%s actor=%s matrix=%s at=%s",
                 roleid, f.actorid,
                 (self.biochem.matrix if self.biochem else 0), _at) if log.isEnabledFor(20) else None)
        f.born = False
        try:
            self.born(f, position=_at)
        except Exception:
            log.exception("BIO-FORCE-BORN 原地出生失败 role=%s，再试出生点", roleid)
            f.born = False
            try:
                self.born(f, position=None)
            except Exception:
                log.exception("BIO-FORCE-BORN 出生点重试也失败 role=%s", roleid)
        if not f.born:
            log.error("BIO-FORCE-BORN 最终失败 role=%s 仍处于未出生状态", roleid)

    def _saved_human_actor(self, f) -> int:
        """玩家在大厅装备界面选的人类角色 id（生化模式人类手模用）。"""
        from . import equip as _eq
        role = _role_obj(f.roleid)
        side = int(getattr(f, "side", 1) or 1)
        if role is not None:
            picks = _eq.chosen_actors(role)
            for _s in (side, 1, 2):
                aid = int(picks.get(_s, 0) or 0)
                if not aid:
                    continue
                try:
                    if self.biochem is not None and self.biochem.is_zombie_actor(aid):
                        continue
                except Exception:
                    pass
                return aid
        return int(getattr(f, "human_actorid", 0) or 0) or 101

    def _valid_actor(self, f) -> int:
        """actorid 兜底：不在 Role 表里就换成同阵营的真实角色 id。"""
        from . import bots as _bots
        aid = int(getattr(f, "actorid", 0) or 0)
        bio = getattr(self, "biochem", None)
        zombie = bool(bio is not None and bio.is_zombie(f.roleid))
        camp = 3 if zombie else (2 if f.side == 2 else 1)
        ids = _bots.actors_of_camp(camp)
        if aid in ids:
            return aid
        # 生化房不分边（IsSingle），人类的 side 可能跟大厅选的角色阵营
        # 不一致。只要 actorid 是合法的人类角色就保留，否则玩家选的女角色
        # 会被同阵营检查兜底回 101 男手模。
        if not zombie:
            for _c in (1, 2):
                if aid in _bots.actors_of_camp(_c):
                    return aid
        fixed = ids[0] if ids else aid
        if fixed != aid:
            (log.info("born role %s actorid=%s 不在 Role 表(camp=%s)，兜底成 %s",
                     f.roleid, aid, camp, fixed) if log.isEnabledFor(20) else None)
        return fixed

    def _apply_combat_stats(self, f: Fighter) -> None:
        """结算出生时的护甲值与强化天赋等级（服务端侧数据，客户端只负责显示）。

        * `ac`  = Numeric.ArmorAC(equipmap) + 护甲增强天赋（Talent.type=3）
                  —— 客户端 `Commander.DamagerTarget` 只有在 `ac > 0` 时才算护甲
        * `research` = {type: 总级数}，伤害公式里按枪械类别查（精通/防弹涂层/防爆护盾）
        僵尸 / 英雄不穿甲（英雄只有一把战刀，装备表里没有 31~34）。
        """
        f.ac = 0.0
        f.ac_max = 0.0
        role = _role_obj(f.roleid)
        f.research = _research_levels(role) if role is not None else {}
        zombie = self.biochem is not None and self.biochem.is_zombie(f.roleid)
        if zombie:
            return
        ac = float(_armor_ac(f.equipmap) + (_talent_ac(role) if role else 0))
        f.ac = ac
        f.ac_max = ac
        if ac > 0:
            (log.info("ARMORDBG role=%s ac=%.0f equip31~34=%s", f.roleid, ac,
                     [f.equipmap.get(s) for s in ARMOR_SLOTS]) if log.isEnabledFor(20) else None)

    def born(self, f: Fighter, position=None) -> None:
        if self.round_over or self.fight_over or self.bio_eliminated(f.roleid):
            return
        if f.roleid in getattr(self.room, 'kicked_bot_ids', ()):
            (log.info('BOT-REJOIN-BLOCK room=%s role=%s', self.room.roomid, f.roleid) if log.isEnabledFor(20) else None)
            return
        # Any explicit/scheduled spawn makes a pending death timer obsolete.
        # Cancelling also bumps the callback generation, so a queue-delayed old
        # relive can never spawn this role a second time.
        self._cancel_relive(f.roleid)
        # All first-spawn/timeout/relive entrances converge here. A missing
        # choice must load the saved group, just like on_choose_equip; it must
        # not silently send an empty ScBorn.equipmap. Existing equipment and
        # zombie/hero forms remain authoritative.
        special_form = self.biochem is not None and (
            self.biochem.is_zombie(f.roleid) or f.roleid in self.biochem.heroes)
        # Human BOT spawn: put the biochem machine-gun loadout into equipmap
        # before ScBorn and return finite reserve counts.  Real players and
        # special forms get (-1, -1) and follow the existing path untouched.
        mainbullet, minorbullet = -1, -1
        if not special_form:
            try:
                from . import bots as _spawn_bots
                mainbullet, minorbullet = _spawn_bots.prepare_born(self, f)
            except Exception:
                (log.debug("bot born loadout hook failed", exc_info=True) if log.isEnabledFor(10) else None)
        # 弹匣道具：客户端 `BuffCounter.GainAmmoAddition` 从来没被调用过，
        # 买了枪种/生化弹匣备弹也不会变。真人玩家原先走 -1 让客户端自己
        # FillAmmoAll，这里改成由服务端算好加成后的备弹数下发。
        if not special_form and mainbullet == -1 and minorbullet == -1:
            try:
                _bags = self._ammobags_for(f.roleid)
                if _bags:
                    from . import human as _human
                    _st = _human.AmmoState.from_loadout(f.equipmap,
                                                        ammobags=_bags)
                    mainbullet, minorbullet = _st.born_reserve()
                    (log.info("AMMOBAG role=%s bags=%s reserve=%s/%s",
                             f.roleid, _bags, mainbullet, minorbullet) if log.isEnabledFor(20) else None)
            except Exception:
                (log.debug("弹匣备弹计算失败", exc_info=True) if log.isEnabledFor(10) else None)
        if not special_form:
            try:
                from . import bots as _spawn_bots
                _is_bot = _spawn_bots.is_bot(f.roleid)
            except Exception:
                _is_bot = False
            if _is_bot:
                if not f.equipmap:
                    f.equipmap = _spawn_bots._bot_equipmap(self, f.roleid)
            elif f.equipmap:
                # The fighter may have been staged by an earlier path; re-apply
                # the same verifier before ScBorn.  Verified skins (403085 /
                # 606132) remain byte-for-byte the same ids.
                f.equipmap = self._sanitize_player_equipmap(
                    f.equipmap, f.roleid)
                if f.equipmap:
                    f.human_equipmap = dict(f.equipmap)
            else:
                self._apply_player_equipment(
                    f, f.equipindex, None, "spawn", prefer_saved=True)
            from . import special_modes
            limit = getattr(self.room, "equiplimitid", 0)
            if limit:
                f.equipmap = special_modes.equipmap(f.equipmap, limit)
            if not _is_bot:
                # 【v61】近战槽兜底：客户端「快速切换」的循环列表是
                #     if (equips.ContainsKey(12)) list.Add(12);
                #     if (equips.ContainsKey(50)) list.Add(50);
                # 而 `ApplyWeapon` 还有一道 `data.GetEquipID(weaponpos) != -1`。
                # 也就是说 **equipmap 里没有 50 就永远切不出刀**。
                # 玩家的保存方案里如果没带刀（或者刀被上面两步洗掉），
                # 狙击/霰弹这类「主武器限定」模式就会变成切不出刀 ——
                # 手枪战因为副武器在、循环只有两项，反而显得正常。
                # 这里按基础匕首补上，不影响其它槽位。
                from . import equip as _equip
                if 50 not in f.equipmap:
                    _knife = int(_equip.COMMON.get(50) or 0)
                    if _knife > 0 and _knife in _items_by_id():
                        f.equipmap[50] = _knife
                        (log.info("PLAYER-EQUIP role=%s 补上近战槽 50 -> %s",
                                 f.roleid, _knife) if log.isEnabledFor(20) else None)
                # 【v61】出生=满弹：清掉旧的弹药记账，下次切枪按 Gun 表重建。
                # 同一回合内复活也走这里（客户端 ScBorn 后本来就是满的）。
                try:
                    from . import player_ammo as _pammo
                    _pammo.reset(self, f.roleid)
                except Exception:
                    pass
            # 【v62】出生就把当前槽位定下来。
            #
            # 客户端开局持枪时**不发 `WeaponChange`**（`FPSOnlineBehaviour.
            # ChangeWeapon` 只在玩家主动换枪时调用），所以服务端 `weaponpos`
            # 会一直停在 `begin_round` 清出来的 0。后果有两个：
            #   1. 本局第一次切枪之前的每一枪，弹药记账拿不到槽位 -> 全部
            #      漏扣，账本一直到第一次切枪才用满弹建起来 -> 客户端算
            #      `reserve = (clip+reserve) - clip` 正好是满的，表现就是
            #      「每局第一次切枪回满备弹」；
            #   2. 伤害裁决要靠 `damage.active_weapon` 现推，多绕一圈。
            # `held_slot` 和客户端 `PlayerData.weaponid` 的出生优先级一致
            # （11 主武器 > 12 副武器 > 41/42 投掷 > 50 近战）。
            if f.equipmap:
                try:
                    from . import special_modes as _spm
                    f.weaponpos = _spm.held_slot(f.equipmap)
                except Exception:
                    (log.debug("spawn held_slot failed role=%s", f.roleid,
                              exc_info=True) if log.isEnabledFor(10) else None)
            f.weaponpos = special_modes.held_slot(f.equipmap)
            if f.equipmap:
                (log.info("SPAWN-LOADOUT role=%s group=%s items=%s source=%s",
                         f.roleid, f.equipindex, len(f.equipmap),
                         "bot" if _is_bot else "player") if log.isEnabledFor(20) else None)
            else:
                log.warning("SPAWN-LOADOUT role=%s group=%s source=missing",
                            f.roleid, f.equipindex)
        # 护甲与强化天赋：equipmap 已定稿、ScBorn 还没发，正好在这里结算。
        self._apply_combat_stats(f)
        # **先给本人重推一次房间成员表，再发 ScBorn。**
        #
        # 客户端的 ScBorn 处理链是：
        #     VirtualServer.Born -> CurrentRoom.getUserInfo(born.roleid)
        #     if (userInfo != null && userInfo.playerInfo != null) ->
        #             ClientManager.Born(...)          // 只有这里才真正出生
        #     else if (UserManager.isOwner(roleid)) -> Commander.Quit()
        #
        # 也就是说：**客户端房间成员表里查不到这个人时，ScBorn 会被静默丢掉**，
        # 人永远回不来、装备界面也不关；同一个条件还会让 isObserver 变 true
        # （退出战斗时提示「确定退出观战吗」）。实测症状就是复活卡在选装备界面。
        # 这里每次出生前给**全场**重推一次 players 表：不只是本人需要 ——
        # **每个客户端**都要有完整的成员表才能处理别人的 ScBorn。少了这个，
        # 没死的那一方会静默忽略对方复活的消息（实测「反叛军杀了联盟军一回，
        # 就再也看不到复活后的联盟军」，然后自己死时也回不来）。
        try:
            from . import room_handlers as _rh
            _rh._sync_room(self.room)
        except Exception:
            (log.debug("born 前重推房间成员表失败", exc_info=True) if log.isEnabledFor(10) else None)

        # 轮换出生点。默认所有 Fighter 的 bornidx 都是 0，两个人会叠在同一个点上。
        # 用服务端的序号推进，保证 pos 和 bornidx 始终指向同一点。
        # **生化模式的出生点要按 actor 的 camp 推 side，不能用 roster 的 side。**
        # 客户端 `VirtualServer.Born`：
        #     if (IsBiochemMode) bornData.side = (Role.camp != 3) ? 1 : 2;
        # 然后 `Level.GetSpawnPoint(side, bornidx)` 取 trans；而 `player.position`
        # 取的是我们发的 `born.pos`。两边 side 不一致时（生化里 roster side 是
        # 随机平衡分配的，人类也可能被分到 2），trans 和 pos 会差大半张图 ——
        # 实测地铁图：人类 police 点 (-23.5, 0.25, -56.5) vs terrist 点
        # (-6.18, 6.39, 19.8)，玩家反馈「出生点不对」。
        # 玩家存档（拿天赋/芯片加成用）。服务端 bot 没有真实存档，_role_obj
        # 返回 None —— 所以芯片 buff（加血/加伤/狂龙无敌时间等）天然只对真人
        # 玩家生效，bot 一律取不到。这里在函数头统一取一次，避免僵尸/英雄分支
        # 里 _role 未定义（原来只在人类 else 分支赋值，其余分支引用会 NameError）。
        _role = _role_obj(f.roleid)
        _side = f.side
        if self.biochem is not None:
            _side = 2 if self.biochem.is_zombie(f.roleid) else 1
        # **actorid 必须是 Role 表里真实存在的角色**，否则客户端整条 ScBorn 会
        # 抛空引用：`PlayerData.Init()` 是
        #     Role roleById = CsRoleMgr.instance.GetRoleById(actorid);
        #     IsZombie = roleById.camp == 3;      // 查不到 -> null -> NRE
        # 而 `GetRoleById` 未命中直接回 null。真机抓到的两条同类异常就是它：
        # 机器人写死 actorid=1（v11 修掉），以及玩家没走装备界面时 actorid=0
        # （16:35:08 的 `PlayerData.Init <- PlayerData.Apply <- DataPool.AddPlayer
        # <- ClientManager.Born <- ScBorn.process`）。真人也要兜。
        f.actorid = self._valid_actor(f)
        if not special_form:
            f.human_actorid = f.actorid
        # 【v14】出生点计算绝不能把 ScBorn 吞掉。
        # 客户端收到 ScBioBoss / ScBioInfected 时已经 Remove(roleid) 删掉了
        # 人类模型，只有随后的 ScBorn 才会以僵尸形象重新出现。只要这里抛一次
        # 异常（v13 的 `_pos` NameError 就是），人永远躺在地上、母体不出现。
        try:
            pos, idx, quat = self.spawn_pos(_side, self._bio_spawn_index(f, _side))
            pos = lift_spawn(pos)
        except Exception:
            log.exception("BORN-SPAWN 计算失败 role=%s side=%s，退回 0 号点",
                          f.roleid, _side)
            idx, quat = 0, None
            try:
                pos, idx, quat = self.spawn_pos(_side, 0)
                pos = lift_spawn(pos)
            except Exception:
                log.exception("BORN-SPAWN 0 号点仍失败 role=%s，用原点", f.roleid)
                pos, idx, quat = _vec3(0.0, 1.0, 0.0), 0, None
        carry_air_state = None
        if position is not None:
            # 1.8.1 ClientManager.OnRoleCreated uses data.position directly.
            # Infection replaces the model at its current location.
            from . import bot_airlife
            position,carry_air_state=bot_airlife.prepare(self,f,position)
            pos = _vec3(*position)
        f.bornidx = idx
        f.born = True
        f.hp = 100.0
        # 服务端假人（bots）不会走 UDP 位置上报，syncpos 永远是 None，
        # 会被 aim_lock / 命中裁决跳过 —— 站桩假人的位置就是出生点，直接记上。
        f.syncpos = (pos["x"] / 100.0, pos["y"] / 100.0, pos["z"] / 100.0)
        # 人类血量**不再写死 100**。
        #
        # 枪械 basicDamage 是按 100 血设计的（AK 26 / 沙鹰 38 / 巴雷特 160），
        # 一旦生化伤害翻几倍、护甲又吸收一部分，100 血就变成「谁先看到谁赢」。
        # 原版靠「血量增强天赋 + 芯片 + 重甲」拉开生存空间，这里把三样都算进去：
        #
        #     HP = CF_HUMAN_HP(默认 100) + Talent.type=1 + Gift.addHp
        #
        # 僵尸 / 英雄各自有独立血量分支，不走这里。
        _hp_max = 100.0
        if self.biochem is not None and self.biochem.is_zombie(f.roleid):
            from . import biochem as _bio
            _hp_max = float(_bio.zombie_hp(f.actorid, len(self.fighters),
                                           self.biochem.is_matrix(f.roleid)))
            # 幽灵 BOT 血量系数（普通幽灵 hpBase 只有 800~1400，太脆）
            try:
                from . import bots as _bots
                if _bots.is_bot(f.roleid):
                    from ..config import CONFIG as _cfg
                    _hp_max *= max(0.1, float(getattr(
                        _cfg, "biochem_bot_hp_scale", 1.0) or 1.0))
            except Exception:
                pass
            # 死亡重生保留等级血量：hpBase + level×hpPlus（和 refresh_hp 一致）。
            # 客户端 BioLevelBar 显示「LV.X 生命值+{X*hpPlus}」，服务端必须同口径，
            # 否则僵尸升级后一死，血量就掉回基础值。
            try:
                _prop = _bio.bio_property_of(int(getattr(f, "actorid", 0) or 0))
                _hp_plus = int(_prop.get("hpPlus") or 0)
                _lv = int(self.biochem.level_of(f.roleid) or 0)
                if _hp_plus > 0 and _lv > 0:
                    _hp_max += _hp_plus * _lv
            except Exception:
                pass
            f.hp = _hp_max
        elif self.biochem is not None and f.roleid in self.biochem.heroes:
            # 人类英雄：客户端收到 ScBioHero 后把 hpmax 抬到 5000；
            # 之后再出生（重复 CsChooseEquip / 下一回合）必须还是 5000，
            # 否则服务端 100 血判死、客户端显示 5000。
            from ..config import CONFIG as _CFG
            _hp_max = float(getattr(_CFG, "biochem_hero_hp", 5000.0) or 5000.0)
            f.hp = _hp_max
        else:
            from ..config import CONFIG as _CFG
            _base_hp = float(getattr(_CFG, "human_base_hp", 100.0) or 100.0)
            _actor_hp = actor_hp_bonus(int(getattr(f, "actorid", 0) or 0))
            _hp_max = max(1.0, _base_hp + _talent_hp(_role) + _chip_hp(_role)
                          + _actor_hp)
            f.hp = _hp_max
            if _hp_max != 100.0:
                (log.info("BORNDBG role=%s hp=%.0f (基础%.0f + 天赋%s + 芯片%s + 角色%s)",
                         f.roleid, _hp_max, _base_hp, _talent_hp(_role),
                         _chip_hp(_role), _actor_hp) if log.isEnabledFor(20) else None)
        f.hp_max = float(_hp_max)
        # 5 个龙芯片的合计值存到 Fighter 上给 damage 读（damage.py 不能
        # 反向 import battle）。`chip_bonus` 按 `owned_gifts` 逐个累加，
        # 所以拥有 n 个同款芯片就是 n 倍。
        try:
            _cb = chip_bonus(_role) if _role is not None else {}
        except Exception:
            _cb = {}
        f.chip_adddmg = int(_cb.get("addDmg", 0) or 0)
        f.chip_pistolrange = int(_cb.get("pistolrange", 0) or 0)
        f.chip_meleerange = int(_cb.get("meleerange", 0) or 0)
        f.born_at = time.time()
        # A new model must not inherit a previous life's route/foot offset.
        getattr(self, '_bot_motion', {}).pop(int(f.roleid), None)
        # 【v63】复活/换回合是合法的位置跳变，但**出生点本身必须作为下一帧
        # 位置连续性的基准**：否则 bots.tick 第一帧没有 prev，会放行一次
        # 2~3m 的寻路落点跳变，玩家看到的就是「BOT 在复活点复活，然后
        # 瞬移出去」。写基准而不是清空，出生后第一步就受 BOT-STEP-CLAMP
        # 约束，必须从复活点正常走出来。
        try:
            _bp = tuple(getattr(f, 'syncpos', None) or ())
            if len(_bp) == 3:
                if not hasattr(self, '_bot_last_sent'):
                    self._bot_last_sent = {}
                self._bot_last_sent[int(f.roleid)] = _bp
            else:
                getattr(self, '_bot_last_sent', {}).pop(int(f.roleid), None)
        except Exception:
            getattr(self, '_bot_last_sent', {}).pop(int(f.roleid), None)
        if carry_air_state is not None:
            if not hasattr(self,'_bot_motion'):self._bot_motion={}
            self._bot_motion[int(f.roleid)]=carry_air_state
        getattr(self, '_bot_shot_at', {}).pop(int(f.roleid), None)
        # **`bornidx` 必须和 `pos` 是同一个点。**
        #
        #     // ClientManager
        #     trans = (posid != -1) ? Level.Instance.GetSpawnPoint(bornData.side, posid)
        #                           : Level.Instance.RandomSpawnPoint(bornData.side);
        #     // PlayerData
        #     player.position = born.pos;          // <- 实际位置取的是 born.pos
        #
        # `trans` 和 `player.position` 是两个来源。发 -1 时客户端**随机**挑一个点做
        # trans，而位置仍用服务端发的那个坐标 —— 两者错位，人会掉出地图
        # （实测：生化沙漠发 -1 直接掉下去，发 0 只是「站在墙里」）。
        #
        # 所以这里发**具体索引**，由服务端保证 pos 与索引一致；轮换索引是为了
        # 别让两个人叠在同一个点。
        # 出生点诊断（排查「掉出地图」用）。
        # 客户端侧位置有**两个来源**，必须让它们指向同一点：
        #     trans          = Level.GetSpawnPoint(bornData.side, bornidx)   <- 用索引
        #     player.position = born.pos                                      <- 用坐标
        # 而且 `bornData.side` 在客户端会变成 4（= 随机取一方）
        # 当 `!CurrentRoom.IsBothSides` 时：
        #     bornData.side = (!IsBothSides) ? 4 : userInfo.playerInfo.side;
        # side=4 时 GetSpawnPoint 随机选警察或匪徒的点 —— 和 pos 必然错位。
        from .. import gamedata as _gd
        _row = _gd.map_row(self.room.mapid) or {}
        _scene = _row.get("scene") or ""
        _tbl = _spawnpoints().get(_scene) or {}
        # 用**实际出生用的 _side**（生化里僵尸 side=2，而不是 roster 的 f.side）
        _key = "police" if _side == 1 else "terrist"
        _pts = _tbl.get(_key) or []
        # 【v16】生化房实际用的是本局动态全图 8 点，日志别再显示旧出生点表。
        if getattr(self, "biochem", None) is not None:
            _dyn_pts = getattr(self.biochem, "spawn_points", None)
            if _dyn_pts and len(_dyn_pts) == 8:
                _key = "bio(动态)"
                _pts = _dyn_pts
        (log.info(
            "BORNDBG role=%s side=%s mapid=%s scene=%r rule=%s mode=%s "
            "bornidx=%s pos=(%.3f,%.3f,%.3f) 该方共%d点 "
            "配置里第%s点=%s 全部点=%s",
            f.roleid, f.side, self.room.mapid, _scene, self.room.levelid,
            self.room.gamemode, idx,
            pos["x"] / 100.0, pos["y"] / 100.0, pos["z"] / 100.0,
            len(_pts), idx,
            (_pts[idx] if 0 <= idx < len(_pts) else "越界!"),
            _pts if len(_pts) <= 3 else f"{_pts[:3]}...(共{len(_pts)})") if log.isEnabledFor(20) else None)
        # 人机：**出生消息之前**把 AI 交给客户端（顺序是硬要求，证据链见
        # bots.manage_ai —— 晚于 ScBorn 的话枪械加载协程那一刻 IsRobot 还是
        # false，Robot.EquipWeapon/Startup 永不被调，机器人继续立正）。
        # 真人不受影响。
        try:
            from . import bots as _bots
            _bots.manage_ai(self, f)
        except Exception:
            (log.debug("manage_ai failed", exc_info=True) if log.isEnabledFor(10) else None)
        ch = self.challenge
        if ch is not None:
            ch.support.activate(f.roleid)
            ch.spawn_armor(f)
            _hp_max = f.hp = ch.support.full_hp(f.roleid)
            mainbullet = ch.support.reserve(f, 11, mainbullet)
            minorbullet = ch.support.reserve(f, 12, minorbullet)
        from . import room_ai
        quat = room_ai.spawn_facing(self, f, _side, idx, quat)
        self.send_all(
            ID.SC_BORN,
            roleid=f.roleid, pos=pos,
            quat=quat or dict(IDENTITY_QUAT),
            actorid=f.actorid, hp=f.hp, ac=int(round(f.ac or 0)),
            sapihp=0, starscore=0,
            equipmap=dict(f.equipmap), bornidx=idx,
            mainbullet=mainbullet, minorbullet=minorbullet,
            fullhp=_hp_max, fullac=int(round(f.fullac if ch is not None else f.ac_max or 0)),
        )
        # FillAmmoAll(all:true) always sets clip = Gun.clip on every ScBorn,
        # so the finite server magazine must be re-sent right after it.
        try:
            from . import bots as _born_bots
            _born_bots.after_born(self, f)
        except Exception:
            (log.debug("bot born ammo sync failed", exc_info=True) if log.isEnabledFor(10) else None)
        # 这个客户端已经就绪：把场上已有的人再补一份 ScBorn 给它。
        # 否则在它加载地图期间先到的别人的 ScBorn 会被丢掉 —— 表现就是
        # 「母体看不到人类」（人类先出生、母体后出生，母体客户端没收到人类的）。
        try:
            self._snapshot_born_to(f.roleid, f.roleid)
        except Exception:
            (log.debug("补发场上已出生玩家失败 role=%s", f.roleid, exc_info=True) if log.isEnabledFor(10) else None)
        # 出生保护。字段名是 remaintime 不是 duration —— ScAvoidDamage 的真实定义
        # 只有 roleid + remaintime，发错名字等于没发。
        #
        # **母体例外**：被系统选中当母体时不该有那 5 秒无敌，否则人类打上去
        # 全是免伤，而僵尸又能反过来抓人。`no_inv_once` 由 _make_zombie 置位，
        # 这里消费一次就清掉，之后它复活照常享受出生保护。
        _skip_inv = bool(getattr(f, "no_inv_once", False))
        # 幽灵**任何时候**都不给出生保护：母体、被感染变身、以及复活。
        # `no_inv_once` 是一次性标记（born 消费完就清），复活时已经没了，
        # 所以这里必须再按「是不是僵尸」强制一次。
        try:
            if self.biochem is not None and self.biochem.is_zombie(f.roleid):
                _skip_inv = True
        except Exception:
            pass
        if _skip_inv:
            try:
                f.no_inv_once = False
            except Exception:
                pass
        # 芯片 addTime（狂龙礼包）延长出生保护。
        # 【v50】用户「改成 20 倍」：官方文案把 1 点 addTime 显示成 +20%
        #   （SetGiftDetail 的 `gift.addTime * 20`、ChipAddition 的
        #    `addMaxim * 20`），但两端实际系数只有 0.01 → 每点 +1%，
        #   差 20 倍。这里把**实际效果**对齐文案：每点 +20%，
        #   满级 15 个 = +300%（1.5s → 6s）。面板不用改，天然显示 300%。
        _inv_secs = (ch.support.spawn_invincible(f.roleid) if ch is not None else
                     float(getattr(self, 'reborn_invincible', REBORN_INVINCIBLE)))
        if not _skip_inv:
            try:
                from ..config import CONFIG as _cfg
                _scale = float(getattr(_cfg, "chip_time_scale", 0.20))
            except (TypeError, ValueError):
                _scale = 0.20
            try:
                _add_t = chip_bonus(_role).get("addTime", 0) if _role is not None else 0
                if _add_t:
                    _inv_secs *= 1.0 + float(_add_t) * _scale
            except Exception:
                pass
            self.send_all(ID.SC_AVOID_DAMAGE, roleid=f.roleid,
                          remaintime=int(round(_inv_secs)))
        # **出生保护到期必须再有一条 remaintime=0**。
        # 客户端 `ClientManager.AvoidDamage` 是这么写的：
        #     playerData.invincible = remaintime > 0;
        #     Shield(player.trans, playerData.invincible);   // false 才 RemoveShield
        # 没有这条收尾消息的话，那层护盾/光环特效会**永远挂在人身上**
        # （实测症状「人物身上永远带着刚出生时的光环」）。
        # 跳无敌时也要发一条 remaintime=0，把上一局残留的护盾光效清掉。
        if _skip_inv:
            self.send_all(ID.SC_AVOID_DAMAGE, roleid=f.roleid, remaintime=0)
        else:
            self._arm_invincible(f.roleid, _inv_secs)
        (log.info("born role %s (%s) side=%s hint=%s idx=%s equip=%d 件", 
                 f.roleid, f.name, f.side, (pos["x"] / 100.0, pos["y"] / 100.0,
                                            pos["z"] / 100.0), idx, len(f.equipmap)) if log.isEnabledFor(20) else None)

        # 第一个玩家真正出生后再刷挑战模式的怪（场景已经加载完，消息不会丢）。
        if ch is not None:
            ch.player_born(f)
        if ch is not None and ch.started:
            ch.retarget()
        if ch is not None and not ch.started:
            ch.begin()
            self._spawn_prepared_bots(ready_only=True)
            (log.info("PVE 已开始刷怪：mode=%s 回合数=%s 场上怪物=%s",
                     ch.mode.get("id"), len(ch.rounds), len(ch.monsters)) if log.isEnabledFor(20) else None)

    # -- 出生保护光环的收尾 ------------------------------------------------
    def _send_born_to(self, viewerid: int, f: Fighter, pos, idx: int,
                      quat=None) -> None:
        """把某个 Fighter 的 ScBorn 单独补发给一个客户端（不改服务端状态）。

        用途：客户端加载地图较慢时，先到的别人的 ScBorn 会被静默丢掉
        （`VirtualServer.Born` 里 `CurrentRoom.getUserInfo` 还没准备好）。
        表现就是「母体看不到人类」：人类先出生，母体的 ScBorn 晚，能看见；
        但母体客户端没收到人类的 ScBorn。
        """
        _snap_main, _snap_minor = -1, -1
        try:
            from . import bots as _snap_bots
            _snap_main, _snap_minor = _snap_bots.current_born_reserve(self, f)
        except Exception:
            pass
        self.send_to_role(
            viewerid, ID.SC_BORN,
            roleid=f.roleid, pos=pos,
            quat=quat or dict(IDENTITY_QUAT),
            actorid=f.actorid, hp=f.hp, ac=int(round(f.ac or 0)),
            sapihp=0, starscore=0,
            equipmap=dict(f.equipmap), bornidx=idx,
            mainbullet=_snap_main, minorbullet=_snap_minor,
            fullhp=(self.challenge.support.full_hp(f.roleid) if self.challenge else
                    float(getattr(f, "hp_max", None) or max(100.0, float(f.hp or 0.0)))),
            fullac=int(round(f.fullac if self.challenge else f.ac_max or 0)))
        # Same auto-full-clip correction, but only for this viewer.
        try:
            from . import bots as _snap_bots
            _snap_bots.after_born(self, f, viewerid=int(viewerid))
        except Exception:
            pass

    def _snapshot_born_to(self, viewerid: int, exclude: int) -> None:
        """给刚出生的客户端补一份「场上已有的人」的 ScBorn。"""
        for other in self.fighters.values():
            if other.roleid == exclude or not other.born:
                continue
            o_side = 1
            if self.biochem is not None and self.biochem.is_zombie(other.roleid):
                o_side = 2
            if other.syncpos is not None:
                ox, oy, oz = other.syncpos
                opos = _vec3(float(ox), float(oy), float(oz))
                oidx = int(other.bornidx)
            else:
                opos, oidx, _q = self.spawn_pos(
                    o_side, int(other.bornidx), exact=True)
                opos = lift_spawn(opos)
            self._send_born_to(viewerid, other, opos, oidx, None)

    def _arm_invincible(self, roleid: int, duration=None) -> None:
        """安排出生保护到期。`duration` 可被芯片 addTime 拉长。"""
        import asyncio
        try:
            _d = (float(duration) if duration is not None
                  else float(getattr(self, 'reborn_invincible', REBORN_INVINCIBLE)))
        except (TypeError, ValueError):
            _d = float(getattr(self, 'reborn_invincible', REBORN_INVINCIBLE))
        t = self._inv_timers.pop(roleid, None)
        if t is not None:
            try:
                t.cancel()
            except Exception:
                pass
        if _d <= 0:
            return
        try:
            self._inv_timers[roleid] = asyncio.get_event_loop().call_later(
                _d, self._invincible_expired, roleid)
        except Exception:
            (log.debug("安排出生保护收尾失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)

    def _invincible_expired(self, roleid: int) -> None:
        self._inv_timers.pop(roleid, None)
        if self.fight_over or self.round_over:
            return
        if roleid not in self.fighters:
            return
        # remaintime=0 -> 客户端 playerData.invincible=false -> RemoveShield
        self.send_all(ID.SC_AVOID_DAMAGE, roleid=roleid, remaintime=0)

    def is_invincible(self, roleid: int) -> bool:
        """是否还在出生保护期（对齐客户端 `VirtualServer.AvoidDamaged(roleid)`）。

        手雷 AoE 用它跳过刚复活的人：`_inv_timers` 里还有条目 = 护盾还在。
        """
        try:
            return int(roleid) in self._inv_timers
        except (TypeError, ValueError):
            return False
    # -- 生化模式的定时 tick ----------------------------------------------
    # 原来**没有任何周期性 tick**：`Biochem.tick()`（补箱子、感染倒计时兜底、
    # 回合时间到判人类赢）从来没被调用过，`biochem.winner` 也只有 check_win
    # 里会置位、置位后没人结束回合 —— 表现就是「人类全变僵尸了但回合不结束、
    # 箱子只掉开局那一波、到时间不判胜负」。
    def _start_bio_tick(self) -> None:
        import asyncio
        self._stop_bio_tick()
        if self.biochem is None or self.fight_over or self.round_over:
            return
        try:
            self._bio_handle = asyncio.get_event_loop().call_later(1.0, self._bio_tick)
        except Exception:
            self._bio_handle = None
            (log.debug("无法启动生化 tick", exc_info=True) if log.isEnabledFor(10) else None)

    def _stop_bio_tick(self) -> None:
        h = getattr(self, "_bio_handle", None)
        if h is not None:
            try:
                h.cancel()
            except Exception:
                pass
        self._bio_handle = None

    def _bio_tick(self) -> None:
        self._bio_handle = None
        bio = self.biochem
        if bio is None or self.fight_over or self.round_over:
            return
        try:
            bio.tick()
        except Exception:
            log.exception("biochem tick 失败 room=%s", self.room.roomid)
        if bio.winner:
            self.end_round(bio.winner)
            return
        # 幽灵脱战自动回血（BioProperty.healWait / healSpeed）。
        # 客户端状态栏那个倒计时就是 healWait：期间没挨打就开始回血。
        try:
            self._bio_heal_tick(bio)
        except Exception:
            log.exception("biochem 脱战回血失败 room=%s", self.room.roomid)
        self._start_bio_tick()

    def _bio_heal_tick(self, bio) -> None:
        """每秒一次：幽灵脱战满倒计时后按 healSpeed 回血，直到 hp_max。

        三个必须同时成立的约束（用户实测反馈）：
          * **时间基准统一用 time.time()**。`f.born_at` 存的是墙钟，原来这里
            混用 `time.monotonic()`，差值会是天文数字，倒计时判定全乱。
          * **受击立即中断**。不再只依赖 `settle_shoot` 上报的 hits（护甲吃满、
            bot 结算、补给箱等路径都可能漏），改为每 tick 比对 hp 快照：
            只要血量比上一 tick 低就重置倒计时，回血期间挨打当帧就停。
          * **起点对齐客户端状态栏条**。条用 Time.deltaTime 累加，实机比墙上
            时钟慢，用 CONFIG.biochem_heal_wait_scale 把服务端起点往后推。
        """
        import time as _time
        from . import biochem as _bio
        from ..config import CONFIG
        now = _time.time()
        state = getattr(self, "_bio_heal_state", None)
        if state is None:
            state = self._bio_heal_state = {}
        hurt = getattr(self, "_bio_last_hurt", None) or {}
        try:
            scale = float(getattr(CONFIG, "biochem_heal_wait_scale", 1.8) or 1.8)
        except (TypeError, ValueError):
            scale = 1.8
        # 【狂暴版】脱战回血等待**绝对覆盖**（默认 5 秒）。> 0 时顶掉
        # BioProperty.healWait（官方 15s），不再乘 scale。
        try:
            _wait_override = float(getattr(CONFIG, "biochem_heal_wait_seconds", 0.0) or 0.0)
        except (TypeError, ValueError):
            _wait_override = 0.0
        for rid in list(bio.zombies):
            f = self.fighters.get(rid)
            if f is None or not f.born:
                continue
            hp = float(getattr(f, "hp", 0) or 0)
            if hp <= 0:
                # 【兜底】血量已经归零却还「活着」——只可能是某条伤害路径
                # 没走到 on_kill（历史 bug：服务端 hp_max 比客户端血条大，
                # 客户端显示 0 血、服务端还剩几百血，脱战回血一开就「原地复活」）。
                # 这里补一刀死亡结算，避免出现打不死的幽灵。
                log.warning("biochem %s hp=%.1f 但仍 born -> 补结算死亡", rid, hp)
                try:
                    self.on_kill(0, int(rid), 0)
                except Exception:
                    log.exception("补结算死亡失败 role=%s", rid)
                continue
            prop = _bio.bio_property_of(int(getattr(f, "actorid", 0) or 0))
            try:
                wait = (_wait_override if _wait_override > 0
                        else float(prop.get("healWait") or 15) * scale)
                speed = float(prop.get("healSpeed") or 300)
            except (TypeError, ValueError):
                wait = _wait_override if _wait_override > 0 else 15.0 * scale
                speed = 300.0
            if wait < 0 or speed <= 0:
                continue
            hp = float(getattr(f, "hp", 0) or 0)
            st = state.get(int(rid))
            if st is None:
                born = float(getattr(f, "born_at", 0) or 0) or now
                st = state[int(rid)] = {"last": born, "hp": hp}
            # 掉血 = 刚挨打（含只掉护甲后扣血、bot 结算等所有路径）
            if hp < float(st["hp"]) - 0.5:
                st["last"] = now
            st["hp"] = hp
            # settle_shoot 里也写了受击时刻，取较新的那个做双保险
            last = max(float(st["last"]), float(hurt.get(int(rid), 0) or 0))
            st["last"] = last
            if now - last < wait:
                continue
            cap = float(getattr(f, "hp_max", 0) or 0) or hp
            if cap > 0 and hp > cap + 0.5:
                # 服务端血量超过上限（历史数据/补血溢出）：夹回去并告诉客户端，
                # 否则客户端血条比服务端多，会出现「还有血却被打死」。
                f.hp = cap
                st["hp"] = cap
                try:
                    self.send_all(ID.SC_ADD_HP, roleid=int(rid),
                                  addhp=float(cap - hp))
                except Exception:
                    (log.debug("血量夹回同步失败 role=%s", rid, exc_info=True) if log.isEnabledFor(10) else None)
                continue
            if hp >= cap:
                continue
            gain = min(speed, cap - hp)
            if gain <= 0:
                continue
            f.hp = hp + gain
            st["hp"] = float(f.hp)
            self.send_all(ID.SC_ADD_HP, roleid=int(rid), addhp=float(gain))

    def start_round(self) -> None:
        if self.started or self.round_over or self.fight_over:
            return
        # 如果上一回合的间隔定时器还挂着（例如外部提前催开始），先作废，
        # 否则它稍后会再准备一次，造成重复 ScBornPrepare / 重复起局。
        intermission = getattr(self, "_intermission_timer", None)
        self._intermission_timer = None
        if intermission is not None:
            try:
                intermission.cancel()
            except Exception:
                pass
        # 新回合已经开始：递增序号，任何之前捕获的 _next_round_prepare
        # 回调都立即失效，不能再清场。
        self._intermission_seq += 1
        self._round_phase = "round"
        timer = self._timer
        self._timer = None
        if timer is not None:
            timer.cancel()
        self.round += 1
        self.started = True
        self.round_started_at = time.time()
        self.bomb.reset()

        from . import biochem
        is_bio = biochem.is_biochem(self.room.gamemode)

        # Native GameRule is the single source for HUD and server deadline.
        _rule = gamedata.rule(self.room.levelid) or {}
        _rt = (self.challenge.times[0] if self.challenge is not None
               else int(_rule.get("roundTime") or 0))
        if is_bio and _rt > 0:
            # RoundStart computes NoticeBio time as remaining - rule.roundTime.
            _rt += max(0, int(_rule.get("infectTime") or 0))
        self._stop_round_clock()
        self._round_deadline = time.monotonic() + _rt if _rt > 0 else None
        self._arm_round_clock()
        (log.info("room %s round %d starts (%ds)", self.room.roomid, self.round,
                 _rt) if log.isEnabledFor(20) else None)
        self.send_all(ID.SC_ROUND_PREPARE, remaintime=3)
        # round_time <= 0：**完全不发 ScRoundStart** —— 客户端 HUD 的倒计时
        # 就是这条消息带出来的（最早能玩团战时没有它，也就没有倒计时）。
        if _rt > 0:
            self.send_all(ID.SC_ROUND_START, remaintime=_rt)
        self.send_all(ID.SC_MY_MONEY, money=8000)
        self.send_all(ID.SC_MY_DIAMOND, diamond=0)
        if is_bio:
            if self.biochem is None:
                self.biochem = biochem.Biochem(self)
            # **倒计时结束的这一刻**才从人类里选母体（对齐原版：ScRoundStart
            # 之后才出现幽灵）。选完后走客户端原本的「选僵尸角色」流程：
            #   ScBioBoss -> ScBornPrepare -> ZombieSelectWindow
            #   -> CsChooseEquip(0, 僵尸actor, {}) -> ScBorn（僵尸形象）
            # 不要替玩家用默认 1001 出生 —— 原版是玩家自己选完才出现。
            self.biochem.begin()
            self._start_bio_tick()

    def _stop_round_clock(self):
        timer = getattr(self, "_round_clock", None)
        if timer is not None:
            timer.cancel()
        self._round_clock = None

    def _tick_interval(self) -> float:
        """本房间的战斗 tick 间隔。

        含 BOT 的房间用 `bot_tick_hz`（默认 20Hz）：10Hz 下 0.12s 一发的枪
        会被量化成 0.1/0.2 交替，听感是「两连点」；20Hz 量化到 0.05s，
        连发基本顺滑。纯真人房间保持 10Hz，不额外吃 CPU。
        """
        try:
            from . import bots as _bots
            from ..config import CONFIG as _CFG
            hz = float(getattr(_CFG, "bot_tick_hz", 0) or 0)
            if hz > 0 and any(_bots.is_bot(rid) for rid in self.fighters):
                return 1.0 / max(5.0, min(50.0, hz))
        except Exception:
            pass
        return TICK_INTERVAL

    def _arm_round_clock(self):
        """固定相位排下一次 tick，补偿本次执行耗时。

        原来是「每次 tick 结束后 call_later(0.25)」，真实间隔 =
        0.25 + 本次 tick 耗时，且一旦某次 tick 慢了就永久漂移。这里用
        单调递增的 `_tick_next` 保持 10Hz；落后超过一个周期就重新起步，
        不追赶（追赶会引发连续空转，反而更卡）。
        """
        import asyncio
        import time as _t
        now = _t.monotonic()
        _itv = self._tick_interval()
        nxt = getattr(self, "_tick_next", None)
        if nxt is None or nxt <= now - _itv:
            nxt = now + _itv
        self._tick_next = nxt + _itv
        delay = max(0.001, nxt - now)
        self._round_clock = asyncio.get_running_loop().call_later(
            delay, self._round_clock_tick)

    def _bot_tick_cost(self, dt: float) -> None:
        """累计 BOT tick 耗时，每 30 秒输出一次（仅 CF_BOT_TICK_STATS=1）。"""
        import time as _t
        st = getattr(self, "_bot_tick_stat", None)
        if st is None:
            st = self._bot_tick_stat = {"n": 0, "sum": 0.0, "max": 0.0, "t": _t.monotonic()}
        st["n"] += 1
        st["sum"] += dt
        if dt > st["max"]:
            st["max"] = dt
        now = _t.monotonic()
        if now - st["t"] >= 30.0:
            n = max(1, st["n"])
            (log.info(
                "BOT tick 耗时 room=%s ticks=%d bots=%d avg=%.2fms max=%.2fms",
                self.room.roomid, n, len(self.fighters),
                st["sum"] / n * 1000.0, st["max"] * 1000.0) if log.isEnabledFor(20) else None)
            st.update(n=0, sum=0.0, max=0.0, t=now)

    def _round_clock_tick(self):
        self._round_clock = None
        if BATTLES.get(self.room.roomid) is not self or self.fight_over or self.round_over or not self.started:
            return
        try:
            from . import bots as _bots, grenades
            grenades.tick(self)
            if self.round_over or self.fight_over:
                return
            if self.challenge is not None:
                self.challenge.tick()
            else:
                # 【v28】可选：BOT tick 耗时统计（CF_BOT_TICK_STATS=1 时每 30s 打一条）。
                # 用来量化 20Hz -> 30Hz 到底多吃多少 CPU，默认关闭、零开销。
                _t0 = None
                try:
                    from ..config import CONFIG as _CFG3
                    if bool(getattr(_CFG3, "bot_tick_stats", False)):
                        import time as _t
                        _t0 = _t.monotonic()
                except Exception:
                    _t0 = None
                _bots.tick(self, self._tick_interval())
                if _t0 is not None:
                    self._bot_tick_cost(_t.monotonic() - _t0)
        except Exception:
            log.exception("bots tick failed room=%s", self.room.roomid)
        try:
            self.check_round()
        except Exception:
            log.exception("round clock failed room=%s", self.room.roomid)
        if not self.fight_over and not self.round_over and self._round_clock is None:
            self._arm_round_clock()

    def check_round(self):
        if self.fight_over or self.round_over or not self.started:
            return
        mode = int(self.room.gamemode)
        deadline = getattr(self, "_round_deadline", None)
        expired = deadline is not None and time.monotonic() >= deadline
        if mode == 4:
            # The 1.9 SOLO record sorts by kills, fewer deaths, then score.
            standings = sorted(
                ((f.kills, -f.deaths, f.score, f.roleid) for f in self.fighters.values()
                 if f.born or f.born_at or f.kills or f.deaths),
                reverse=True,
            )
            leader = standings[0] if standings else (0, 0, 0, 0)
            if expired or (self.win_kill_count > 0 and leader[0] >= self.win_kill_count):
                # Equal personal records have no sole winner in the local rules.
                tied = len(standings) > 1 and standings[1][:3] == leader[:3]
                winrole = 0 if tied else leader[3]
                self._winrole = int(winrole)
                (log.info("SOLO-FINISH room=%s expired=%s winrole=%s", self.room.roomid, expired, winrole) if log.isEnabledFor(20) else None)
                self.send_all(ID.SC_ROUND_END, winside=0)
                self.end_fight(0, winrole=winrole)
            return
        winner = -1
        if mode in (1, 9):
            police, terrist = self.team_kills()
            target = self.win_kill_count
            # VirtualServer.GetRoundResult, token 0x06000b50 in original APK.
            if target > 0 and police >= target:
                winner = 1
            elif target > 0 and terrist >= target:
                winner = 2
            elif expired:
                winner = 1 if police > terrist else 2 if terrist > police else 4
        elif mode == 3:
            police = sum(f.born for f in self.fighters.values() if f.side == 1)
            terrist = sum(f.born for f in self.fighters.values() if f.side == 2)
            if all(any(f.side == side for f in self.fighters.values()) for side in (1, 2)):
                if police == 0:
                    winner = 2
                elif terrist == 0:
                    winner = 1
                elif expired:
                    winner = 1 if police > terrist else 2 if terrist > police else 4
        elif mode == 4:
            # 【v19】SOLO 战（FFA）：最先击杀 winKillCount(20) 的人获胜。
            # 原来 check_round 完全没有 mode4 分支 -> winner 永远 -1，
            # 自建房与英雄联赛匹配到的 SOLO 都会永不结算（硬阻塞）。
            # 不能用 self.win_kill_count：special_modes.kill_target() 会按
            # 房间人数缩放（mode4 的 maxTeamer=1 会把 20 缩成 2）；用户要
            # 的是固定 20 杀，直接读规则表原值。
            _solo_rule = gamedata.rule(self.room.levelid) or {}
            try:
                _need = int(_solo_rule.get("winKillCount") or 20)
            except (TypeError, ValueError):
                _need = 20
            _top = None
            for g in self.fighters.values():
                if _top is None or (int(getattr(g, "kills", 0) or 0)
                                    > int(getattr(_top, "kills", 0) or 0)):
                    _top = g
            if _top is not None:
                self._winrole = int(_top.roleid)
                _top_side = 1 if int(getattr(_top, "side", 1) or 1) == 1 else 2
                if int(getattr(_top, "kills", 0) or 0) >= _need or expired:
                    winner = _top_side
            if winner == -1 and expired:
                winner = 1
        elif mode == 2:
            # 爆破模式（重建实现）。优先级：本 tick 炸弹自己结算（爆炸→匪胜 / 拆除→警胜，
            # 见 bomb.py）> 一方全灭 > 超时未安包判警察（side1）胜。
            # 安放/拆除的**完成**由服务端按时长裁决并下发 operate=2/5：客户端在线时只发
            # 1/3/4/6 且本地不改状态，2 和 5 不可能由客户端产生。
            if self.bomb.tick():
                return
            police = sum(f.born for f in self.fighters.values() if f.side == 1)
            terrist = sum(f.born for f in self.fighters.values() if f.side == 2)
            # 包已安放后，任一方全灭都不再立刻定胜负 —— 原版此时只认「拆掉」或「炸掉」。
            if self.bomb.planted:
                pass
            elif police == 0:
                winner = 2
            elif terrist == 0:
                winner = 1
            elif expired:
                winner = 1
        elif self.biochem is not None:
            self.biochem.tick()
            if self.biochem.winner:
                winner = self.biochem.winner
            elif expired:
                # 超时同样按活人判：人类全死光时不能判人类胜。
                winner = 1 if self.biochem.alive_humans() else 2
        if winner != -1:
            (log.info("ROUND_CHECK room=%s mode=%s expired=%s kills=%s winner=%s", self.room.roomid, mode, expired, self.team_kills(), winner) if log.isEnabledFor(20) else None)
            # 【v19】SOLO(mode4) 是单回合 FFA，首个到 20 杀直接结束整场，
            # 不能落进多回合准备流程。
            self.end_round(winner, finish=(mode in (1, 9, 4)))

    def on_relive(self, session: Session, msg: dict) -> None:
        if self.round_over or self.fight_over or self.bio_eliminated(session.roleid):
            return
        f = self.fighters.get(session.roleid)
        if f is None:
            return
        # **已经活着就直接返回。** 客户端会重复发 CsRelive，每发一次就重跑
        # born() -> 重发 ScBorn -> 客户端又弹一次选装备界面。
        # 实测症状：「选完武器又要选」（日志里同一个人 17 秒内 born 了两次）。
        if f.born and f.hp > 0:
            (log.info("role %s 已经活着，忽略重复的 CsRelive", f.roleid) if log.isEnabledFor(20) else None)
            return
        if self.challenge is not None and not self.challenge.revives.authorize(f.roleid, f.roleid):
            return
        # 被近战武器打死的幽灵本回合不能再复活。
        _bio = getattr(self, "biochem", None)
        if (_bio is not None and _bio.is_zombie(f.roleid)
                and not _bio.can_relive(f.roleid)):
            (log.info("role %s 被近战击杀，本回合禁止复活", f.roleid) if log.isEnabledFor(20) else None)
            return
        if self.biochem is not None and self.biochem.is_zombie(f.roleid):
            if f.roleid in self.biochem.pending:
                self.on_choose_equip(session, msg)
            else:
                self.born(f)
            return
        try:
            actorid = int(msg.get("actorid") or f.actorid)
        except (TypeError, ValueError):
            actorid = int(f.actorid or 0)
        f.actorid = actorid
        # A manual relive can carry a real equipmap; validate it exactly like the
        # choose path.  When empty, keep the already chosen equipment (or load
        # the saved group if this fighter has none yet).
        self._apply_player_equipment(
            f, msg.get("equipindex", f.equipindex), msg.get("equipmap"),
            "relive", prefer_saved=not bool(f.equipmap))
        (log.info("role %s relives with group=%s equip=%d", f.roleid,
                 f.equipindex, len(f.equipmap)) if log.isEnabledFor(20) else None)
        if self.challenge is None:
            self._charge_relive(session, f)
        self.born(f, f.syncpos if self.challenge is not None else None)

    def _charge_relive(self, session, f) -> None:
        """扣一次快速复活的钱并同步余额；任何异常都不能挡住 born()。"""
        try:
            from . import handlers as _h
            from .wallet import change
            world = _h.world
            if world is None:
                return
            role = world.role(int(f.roleid))
            if role is None:
                return
            unit = next((int(r.get("gem") or 0)
                         for r in gamedata.table("Price")
                         if int(r.get("id") or 0) == 5), 0)
            if unit <= 0:
                return
            n = int(getattr(self, "_relive_paid", {}).get(int(f.roleid), 0)) + 1
            cost = unit * n
            if int(role.gold) < cost:
                # 客户端 CanBuy 一般已拦下；服务端兜底不扣成负数，也不拒绝
                # 复活（否则玩家会卡在死亡界面）。
                (log.info("RELIVE-COST role=%s 第%d次复活需%d钻，余额%d不足，跳过扣费",
                         f.roleid, n, cost, int(role.gold)) if log.isEnabledFor(20) else None)
                return
            change(world, role, gems=-cost)
            if getattr(self, "_relive_paid", None) is None:
                self._relive_paid = {}
            self._relive_paid[int(f.roleid)] = n
            (log.info("RELIVE-COST role=%s 第%d次快速复活 -%d钻 余额=%d",
                     f.roleid, n, cost, int(role.gold)) if log.isEnabledFor(20) else None)
            # ScAcountSync 属于 item 包，客户端只在大厅连接上更新余额；
            # CsRelive 走的是房间服连接，所以两边都要推，避免「钱扣了、
            # 界面还显示旧余额」。和 reward_players 用的是同一套取法。
            _sync = (world.session_of_role(int(f.roleid), "gs")
                     or world.session_of_role(int(f.roleid)))
            _targets = []
            for _s in (_sync, session):
                if _s is not None and not any(_s is t for t in _targets):
                    _targets.append(_s)
            for _s in _targets:
                if not getattr(_s, "closed", False):
                    _s.send(ID.SC_ACOUNT_SYNC, gold=int(role.gold),
                            money=int(role.money), diamond=int(role.diamond))
        except Exception:
            log.exception("RELIVE-COST 扣费失败 role=%s（不影响复活）", f.roleid)

    def on_kill(self, killerid: int, victimid: int, weaponid: int = 0) -> None:
        if self.bio_eliminated(victimid):
            return
        eliminated = False
        hero_fell = False
        # 生化模式：僵尸「杀」人类不是死亡，是感染。这条必须先走。
        if self.biochem is not None:
            kz = self.biochem.is_zombie(killerid)
            vz = self.biochem.is_zombie(victimid)
            if kz and not vz:
                # 僵尸抓人 = 感染，不是死亡。刀杀提示（ScBioKnifeKill）在
                # biochem.on_kill 的「人类刀幽灵」分支里发，这里不要重复。
                # 【狂暴版】人类**英雄**被僵尸击杀：直接死亡进观战，
                # 不再变成僵尸、本回合也不许复活。
                _heroes = getattr(self.biochem, "heroes", None) or set()
                if int(victimid) in _heroes:
                    self.biochem.hero_down(int(victimid), int(killerid),
                                           int(weaponid or 0))
                    if self.biochem.winner:
                        self.end_round(self.biochem.winner)
                    # 【v51】英雄出局也必须补发 ScWaitRelive：客户端只有收到
                    # 它才走 ClientManager.WaitRelive() -> ShowDeath +
                    # BattleDeath.View(true)，自动切到队友的观战视角、死亡窗
                    # 左右箭头可继续切人（歼灭战同一条链路）。原来这里提前
                    # return 跳过了消息，摄像机就停在尸体原地俯视（用户实测）。
                    # waittime=0：生化房的复活按钮被 IsBiochemMode 隐藏，
                    # 就算客户端发 CsRelive 也会被 biochem.can_relive
                    # （no_relive 名单）挡住，不会真的复活。
                    _hvs = None
                    from . import handlers as _hh
                    if _hh.world is not None:
                        _hvs = (_hh.world.session_of_role(int(victimid), "room")
                                or _hh.world.session_of_role(int(victimid)))
                    if _hvs is not None and not _hvs.closed:
                        _hvs.send(ID.SC_WAIT_RELIVE, waittime=0)
                    return
                self.biochem.infect(victimid, killerid)
                if self.biochem.winner:
                    self.end_round(self.biochem.winner)
                return
            self.biochem.on_kill(killerid, victimid, knife=_is_melee(weaponid),
                                 weaponid=weaponid)
            eliminated = self.bio_eliminated(victimid)
            if eliminated:
                self._cancel_relive(victimid)

        killer = self.fighters.get(killerid)
        victim = self.fighters.get(victimid)
        if victim is not None:
            victim.deaths += 1
            victim.born = False
            victim.dead_at = time.time()
        if killer is not None:
            killer.kills += 1
            killer.score += 1
            # 连杀（combokill）：竞技模式（非生化）的「双杀/三杀/超神」提示。
            # 客户端 `ClientManager.Kill` 里 `combokill > 1` 才播（2=双杀 …
            # 8=八杀，>8 超神），且 `!IsBiochemMode` 才显示。killer 死亡时清零。
            _combo = 0
            if self.biochem is None:
                if not hasattr(self, "combo"):
                    self.combo = {}
                _combo = int(self.combo.get(int(killerid), 0)) + 1
                self.combo[int(killerid)] = _combo
            # 芯片 lifeDrain（炎龙礼包）：**击杀时回血**，绝对值。
            # 客户端 Commander 里是 `playerRecord.Drain(chipLifeAcc)` +
            # `ClientManager.AddHP(...)`，所以这条不用发包 —— 客户端自己会加，
            # 服务端只要别把血量算得比客户端少就行。
            try:
                _drain = int(chip_bonus(_role_obj(killerid)).get("lifeDrain", 0))
            except Exception:
                _drain = 0
            if _drain > 0 and float(killer.hp or 0) > 0:
                _cap = float(getattr(killer, "hp_max", 0) or 0) or float(killer.hp)
                _before = float(killer.hp)
                killer.hp = min(_cap, _before + _drain)
                # 真加了多少就发多少（满血时是 0，不能发固定值把血条顶爆）
                _real = max(0.0, float(killer.hp) - _before)
                if _real > 0:
                    self.send_all(ID.SC_ADD_HP, roleid=killerid,
                                  addhp=float(_real))
                (log.info("role %s 芯片吸血 +%s -> %.0f", killerid, _real,
                         killer.hp) if log.isEnabledFor(20) else None)
            # 芯片 怒龙（Gift.giftLevel=11）：**击杀立刻把当前弹匣补满**。
            # 只补弹匣、不动备弹。客户端没有「只补弹匣」的协议，所以在
            # `AGun.FillBulletStop` 里留了个暗号：count == -999 →
            # 「弹匣拉满、备弹原样」（clientpatch/patch_dragon.py 注入）。
            #
            # 【v9】无条件发：原来要求 `账本里 clip < 弹匣容量` 才发，
            # 而账本是按 Gun 表逐发扣的 —— 新版枪（v1.2 那批）与霰弹枪
            # （怒龙-打击者）在账本里要么没有行、要么扣减对不上，
            # 条件永远不成立 → 「对怒龙完全不生效」。现在只要拥有芯片就发，
            # 客户端自己会把弹匣拉满（已经满的时候再拉一次没有副作用）。
            try:
                from . import shop as _shop
                _kr = _role_obj(killerid)
                _owned = set(_shop.owned_gifts(_kr) or ()) if _kr is not None else set()
                if ANGRY_DRAGON_GIFT in _owned:
                    from . import player_ammo as _pa
                    _slot = int(_pa.held_slot(self, killer) or 0)
                    if _slot not in (11, 12):
                        _slot = int(getattr(killer, "weaponpos", 0) or 0)
                    rows = _pa.snapshot(self, killer)
                    _row = rows.get(_slot)
                    if _row is not None:
                        _row[0] = int(_row[2])      # 账本一起拉满，防切枪回旧值
                    self.send_all(ID.SC_FILL_BULLET_STOP,
                                  roleid=int(killerid),
                                  weaponpos=int(_slot or 11),
                                  finishtimes=-999)
                    (log.info("role %s 怒龙芯片：弹匣补满 slot=%s（账本 %s）",
                             killerid, _slot,
                             "有" if _row is not None else "无")
                     if log.isEnabledFor(20) else None)
            except Exception:
                (log.debug("怒龙芯片补弹失败", exc_info=True) if log.isEnabledFor(10) else None)
            # **weaponid 必须是一个真实存在的武器 id。**
            # 客户端击杀播报是这么取图标的：
            #     Item item = GameData.instance.getItem(killNotice.weaponid);
            #     weapon = item.sketchSprite;
            # 传 0 或无效 id 时查不到武器，就落到默认图标 ——
            # 实测症状「击杀人是一个骷髅头标志，不是正常的击杀图标」。
            wid = int(weaponid or 0)
            if wid <= 0:
                wid = _main_weapon_of(killer)
            self.send_all(ID.SC_KILL, roleid=victimid, killerid=killerid,
                          weaponid=wid, killtype=0, combokill=_combo)
            self.send_all(ID.SC_SCORE, roleid=killerid, killnum=killer.kills,
                          deathtimes=killer.deaths, score=killer.score)
            # ScRoundKill 是**双方队伍总击杀数**（policekill/terristkill），
            # 不是某个人的 —— 原来发 roleid/killnum 两个字段都不存在，等于没发。
            police, terrist = self.team_kills()
            self.send_all(ID.SC_ROUND_KILL, policekill=police,
                          terristkill=terrist)
            # 击杀播报 —— **只发给凶手**。
            # 客户端处理是「你击杀了 X」（ClientManager.MyKill），发给全场的话
            # 死者也会看到「你击杀了」，而且会触发他自己的连杀/奖励提示。
            ks = None
            from . import handlers as _h
            if _h.world is not None:
                ks = (_h.world.session_of_role(killerid, "room")
                      or _h.world.session_of_role(killerid))
            if ks is not None and not ks.closed:
                ks.send(ID.SC_MY_KILL, killtype=0, combokill=_combo,
                        score=killer.score, comboscore=0, killedid=victimid)
        if victim is not None:
            # 死亡打断连杀：这个受害者自己的连杀数清零。
            if not hasattr(self, "combo"):
                self.combo = {}
            self.combo[int(victimid)] = 0
        if victim is not None and not eliminated:
            # **只发给死者本人。**
            # 客户端收到 ScWaitRelive 会进「等待复活」状态
            # （ScWaitRelive.process -> ClientManager.WaitRelive(waittime)）。
            # 发给全场的话，两个人会同时进入等待复活、都停止渲染 ——
            # 实测症状「杀了人一次后就互相看不到对方」。
            vs = None
            from . import handlers as _h
            if _h.world is not None:
                vs = (_h.world.session_of_role(victimid, "room")
                      or _h.world.session_of_role(victimid))
            if self.challenge is not None:
                if not self._is_server_bot(victimid):
                    self.challenge.revives.death(victimid, self.reborn_time)
            elif vs is not None and not vs.closed:
                vs.send(ID.SC_WAIT_RELIVE, waittime=self.reborn_time)
            # **倒计时结束后自动复活**（客户端不会自己发 CsRelive）。
            # 只有 rebornItem=True 的免费复活模式才自动；歼灭战等要花钻石的
            # 模式必须等玩家自己按复活（CsRelive），不替他花钱。
            if self.reborn_item:
                self._arm_relive(victimid)
        if hero_fell:
            from .biochem import ID as BID
            self.biochem.heroes.discard(victimid)
            self.send_all(BID.SC_BIO_HERO, heros=sorted(self.biochem.heroes))
        if eliminated and (winner := self.biochem.check_win()):
            self.end_round(winner)

    # -- 复活定时器 --------------------------------------------------------
    def _next_relive_token(self, roleid: int) -> int:
        token = int(self._relive_seq.get(roleid, 0)) + 1
        self._relive_seq[roleid] = token
        return token

    def _relive_is_current(self, roleid: int, token: Optional[int]) -> bool:
        # `token is None` keeps direct/manual calls working; scheduled callbacks
        # always pass the token captured when they were armed.
        if token is None:
            return True
        return int(token) == int(self._relive_seq.get(roleid, 0))

    @staticmethod
    def _is_server_bot(roleid: int) -> bool:
        try:
            from . import bots
            return bool(bots.is_bot(roleid))
        except Exception:
            return False

    def _arm_relive(self, roleid: int) -> None:
        """Schedule the rule's death countdown for one victim.

        Real players: `rebornTime` -> ScBornPrepare -> choose window -> born.
        Server BOTs have no client to press 确认, so they must skip the extra
        equip window and spawn directly at `rebornTime`.  The delay always comes
        from GameRule.rebornTime (10s in ranked mode 1, 2s in biochem), never a
        hard-coded 0/3/45.
        """
        import asyncio
        if self.round_over or self.fight_over:
            return
        # 被**近战武器**打死的幽灵本回合不能再复活（生化规则）。
        # 原来只在客户端 `CsRelive` 那条路上检查，而自动复活根本不走那条，
        # 于是刀杀之后照样 2 秒站起来 —— 这条规则等于从来没生效。
        _bio = getattr(self, "biochem", None)
        if _bio is not None and _bio.is_zombie(roleid) and not _bio.can_relive(roleid):
            (log.info("BOT-RELIVE role=%s 被近战击杀，本回合不排复活", roleid) if log.isEnabledFor(20) else None)
            return
        self._cancel_relive(roleid)
        token = self._next_relive_token(roleid)
        is_bot = self._is_server_bot(roleid)
        callback = self._bot_relive_born if is_bot else self._relive_prepare
        loop = asyncio.get_event_loop()
        try:
            self._relive_timers[roleid] = loop.call_later(
                self.reborn_time, callback, roleid, token)
            (log.info("RELIVE-ARM role=%s kind=%s delay=%ss",
                     roleid, "bot" if is_bot else "player", self.reborn_time) if log.isEnabledFor(20) else None)
        except Exception:
            (log.debug("无法安排复活定时器 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)

    def _cancel_relive(self, roleid: int) -> None:
        t = self._relive_timers.pop(roleid, None)
        if t is not None:
            try:
                t.cancel()
            except Exception:
                pass
        # Invalidates callbacks that already left the event loop queue.
        self._relive_seq[roleid] = int(self._relive_seq.get(roleid, 0)) + 1

    def _alive_now(self, roleid: int) -> bool:
        f = self.fighters.get(roleid)
        return bool(f is not None and f.born and f.hp > 0)

    def _bot_relive_born(self, roleid: int, token: Optional[int] = None) -> None:
        """BOT death countdown finished: spawn with its existing loadout.

        No ScBornPrepare is sent: the BOT has no session and cannot answer the
        equip window.  This removes the previous extra 45s stuck-at-选背包 wait.
        """
        if not self._relive_is_current(roleid, token):
            (log.info("BOT-RELIVE role=%s ignored stale callback token=%s", roleid, token) if log.isEnabledFor(20) else None)
            return
        self._relive_timers.pop(roleid, None)
        if self.fight_over or self.round_over or self._alive_now(roleid):
            return
        f = self.fighters.get(roleid)
        if f is None or not self.room.members.get(roleid):
            return
        (log.info("BOT-RELIVE role=%s countdown=%ss -> auto born (no equip window)",
                 roleid, self.reborn_time) if log.isEnabledFor(20) else None)
        self.born(f)

    def _relive_prepare(self, roleid: int, token: Optional[int] = None) -> None:
        """倒计时到了：发 ScBornPrepare，让客户端走 Prepare（清 WaitingRelive +
        开选装备界面），对齐离线端的 `ClientManager.Prepare(15)`。"""
        if not self._relive_is_current(roleid, token):
            (log.info("RELIVE role=%s ignored stale prepare token=%s", roleid, token) if log.isEnabledFor(20) else None)
            return
        self._relive_timers.pop(roleid, None)
        if self.fight_over or self.round_over or self._alive_now(roleid):
            return
        f = self.fighters.get(roleid)
        if f is None:
            return
        if self._is_server_bot(roleid):
            # Defensive: an old/other caller must never send a BOT into the
            # human equip window.
            self._bot_relive_born(roleid, token)
            return
        if self.bio_eliminated(roleid):
            return
        # **生化幽灵复活也要能选生化角色，但绝不能复用感染的 request_pick。**
        # request_pick 会 force_born_zombie(... position=f.syncpos) 原地出生
        # （那是「原地被感染、原地变僵尸」的正确行为），用在被击杀复活上就
        # 变成「被打死后原地站起来」。这里改用独立的 `relive_pick`：
        # 只进 pending + 发 ScBornPrepare，出生交给 born(f) 走出生点，
        # 超时仍由下面的 _relive_born 兜底（不会卡在死亡界面）。
        _bio = getattr(self, "biochem", None)
        _relive_picking = False
        if _bio is not None and _bio.is_zombie(roleid):
            try:
                _bio.relive_pick(roleid)
                _relive_picking = True
                (log.info("role %s 幽灵复活 -> 选生化角色（出生点复活）", roleid) if log.isEnabledFor(20) else None)
            except Exception:
                (log.debug("幽灵复活选角色失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        if not _relive_picking:
            self._send_to(roleid, ID.SC_BORN_PREPARE, remaintime=PREPARE_TIME)
        (log.info("role %s 复活倒计时结束 -> ScBornPrepare(%ds)", roleid, PREPARE_TIME) if log.isEnabledFor(20) else None)
        import asyncio
        loop = asyncio.get_event_loop()
        next_token = self._next_relive_token(roleid)
        try:
            self._relive_timers[roleid] = loop.call_later(
                PREPARE_TIME, self._relive_born, roleid, next_token)
        except Exception:
            (log.debug("无法安排复活定时器2 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)

    def _relive_born(self, roleid: int, token: Optional[int] = None) -> None:
        """选装备窗口也过了还没动静 -> 兜底直接复活，别让人卡在死亡界面。"""
        if not self._relive_is_current(roleid, token):
            (log.info("RELIVE role=%s ignored stale fallback token=%s", roleid, token) if log.isEnabledFor(20) else None)
            return
        self._relive_timers.pop(roleid, None)
        if self.fight_over or self.round_over or self._alive_now(roleid):
            return
        f = self.fighters.get(roleid)
        if f is None or not self.room.members.get(roleid):
            return
        if self._is_server_bot(roleid):
            self._bot_relive_born(roleid, token)
            return
        (log.info("role %s 选装备窗口超时，服务端兜底复活", roleid) if log.isEnabledFor(20) else None)
        self.born(f)

    def _send_to(self, roleid: int, type_id: int, **fields) -> None:
        """只发给某一个人（走房间服连接）。"""
        from . import handlers as _h
        if _h.world is None:
            return
        s = (_h.world.session_of_role(roleid, "room")
             or _h.world.session_of_role(roleid))
        if s is not None and not s.closed:
            s.send(type_id, **fields)

    # -- 结算 ------------------------------------------------------------
    def team_kills(self) -> tuple:
        """双方队伍总击杀。"""
        police = sum(f.kills for f in self.fighters.values() if f.side == 1)
        terrist = sum(f.kills for f in self.fighters.values() if f.side == 2)
        return police, terrist

    def end_round(self, winside: int, finish: bool = False) -> None:
        """一个回合结束。

        顺序对齐客户端：ScRoundEnd -> ScWinRound，打满 round 局再 ScFightEnd。
        `winside`：1 = 警察/人类胜，2 = 匪徒/僵尸胜（生化见 FightResultByBioSide）。
        """
        if self.round_over or self.fight_over:
            return
        self.round_over = True
        self.started = False
        self._round_phase = "intermission"
        self._stop_round_clock()
        self._stop_bio_tick()
        # 回合结束就不要再有复活定时器在跑（否则下一回合会被上一回合的定时器干扰）
        for rid in list(self._relive_timers):
            self._cancel_relive(rid)
        # **上一回合的「选僵尸」超时必须作废**：感染时排的 20 秒定时器如果
        # 活到下一回合、而 round_over 已经被重置，就会 force_born_zombie，
        # 把人类变成第二只幽灵（实测「下一局两只幽灵、0 个人类」）。
        if self.biochem is not None:
            self.biochem.cancel_picks()
        (log.info("room %s round %s end: winside=%s (%s:%s)", self.room.roomid,
                 self.round, winside, self.police_wins, self.terrist_wins) if log.isEnabledFor(20) else None)

        self.send_all(ID.SC_ROUND_END, winside=int(winside))
        if int(winside) == 1:
            self.police_wins += 1
        elif int(winside) == 2:
            self.terrist_wins += 1
        self.send_all(ID.SC_WIN_ROUND, policewinround=self.police_wins,
                      terristwinround=self.terrist_wins)

        # 「先赢 N 局」模式（歼灭 mode 3、爆破 mode 2 等 round > 1 的多回合局）：
        # 任一方先赢到 `(total_rounds+1)//2` 局就结束，而不是打满 total_rounds。
        # 原来只判 `round >= total_rounds`，导致 6:0 打满 11 局还不进结算
        # （用户实测「到达 6 局还能继续打几局」）。
        #
        # **生化模式例外**：GameRule.round=5 是「总共打 5 回合」，不是先赢 3 局。
        # 上一版把这条规则无条件套到所有模式，结果 3:1 打到第 4 回合就结算了
        # （用户实测「本来打 5 回合，打了 4 回合就结算」）。生化必须打满。
        _mode = int(self.room.gamemode or 0)
        _need = (self.total_rounds + 1) // 2
        _win_reached = (_mode not in (8, 10)
                        and (self.police_wins >= _need
                             or self.terrist_wins >= _need))

        done = (finish or self.round >= self.total_rounds or _win_reached)
        if done:
            # 【v19】SOLO 把「最先 20 杀」的 roleid 带进 ScFightResult.winrole，
            # 客户端结算面板才知道 MVP 是谁；其它模式沿用 0。
            self.end_fight(winside, getattr(self, "_winrole", 0))
        elif int(self.room.gamemode or 0) in (8, 10):
            # 生化模式下一回合必须**重新走一遍选装备 -> ScBorn**：
            # 客户端 RoundPrepare 里会 ClearTPSPlayers()，场上一个人都不剩；
            # 直接 start_round 只发 ScRoundStart，第 2 回合开始所有人都是
            # 隐形的（GameRule.round = 5，从第 2 局起就没人）。
            self._arm_bio_intermission()
        else:
            # **普通多回合模式（爆破 mode2 / 歼灭 mode3 等）也必须重新准备。**
            # 旧实现把所有 fighter.born 清掉后立刻 start_round，只给 BOT
            # 重生，真人没有 ScBornPrepare、也不会再发 CsChooseEquip ——
            # 从第 2 回合起一直观战。
            #
            # 原生路径（work/decomp_181）：
            #   VirtualServer.CalcResult -> ClientManager.RoundEnd
            #   -> 未结束则 FightServer.Connect(3f)
            #   -> FightServer.Connection -> ClientManager.Prepare(15)
            #      + RoundPrepare(15) -> 等 15s -> BornAll -> RoundStart
            # 所以这里只安排结算间隔；真正的重新准备在 _next_round_prepare，
            # 由真人选装备或准备超时触发 Born，再 start_round。
            self._arm_round_intermission()

    def _arm_round_intermission(self) -> None:
        """普通模式回合结束 -> 留 ROUND_INTERMISSION 秒结算 -> 重新准备。"""
        import asyncio
        old = getattr(self, "_intermission_timer", None)
        self._intermission_timer = None
        if old is not None:
            try:
                old.cancel()
            except Exception:
                pass
        self._round_phase = "intermission"
        self._intermission_seq += 1
        seq = self._intermission_seq
        (log.info("room %s 普通回合 %s 结束，%ss 后重新准备下一回合",
                 self.room.roomid, self.round, ROUND_INTERMISSION) if log.isEnabledFor(20) else None)
        try:
            loop = asyncio.get_running_loop()
            self._intermission_timer = loop.call_later(
                ROUND_INTERMISSION, self._next_round_prepare, seq)
        except Exception:
            # 没有正在运行的事件循环（离线单测/嵌入调试）时不能把回合卡死：
            # 同步走一遍准备，但仍由 _next_round_prepare 做空房/阶段检查，
            # 不允许为了测试让空房重新起局。
            (log.debug("无法安排普通回合间隔，立即重新准备下一回合",
                      exc_info=True) if log.isEnabledFor(10) else None)
            self._next_round_prepare(seq)

    def _next_round_prepare(self, seq: Optional[int] = None) -> None:
        """普通模式下一回合的准备阶段：清回合内状态 -> ScRoundPrepare
        -> ScBornPrepare -> BOT 出生 -> 等真人 CsChooseEquip / 准备超时。

        **不能复用 _next_bio_round**：生化会把 side 重置成人类、恢复
        human_actorid / human_equipmap，并新建 Biochem；普通模式的阵营、
        装备方案、付费复活规则都必须原样保留。

        `seq` 是 _arm_round_intermission 发的有效序号。旧回调（例如上一回合
        捕获、在新回合已经开始后才被手动/延迟调用）序号不匹配，或者阶段
        已不是 intermission，必须直接丢弃，绝不能再次清场。
        """
        if seq is not None and seq != self._intermission_seq:
            (log.info("room %s 忽略过期的回合间隔回调 seq=%s current=%s",
                     self.room.roomid, seq, self._intermission_seq) if log.isEnabledFor(20) else None)
            return
        if self.fight_over or self.started or self._round_phase != "intermission":
            (log.info("room %s 忽略非法的下一回合准备回调 phase=%s started=%s "
                     "fight_over=%s", self.room.roomid, self._round_phase,
                     self.started, self.fight_over) if log.isEnabledFor(20) else None)
            return
        self._intermission_timer = None
        if not self.room.members:
            (log.info("room %s 回合间隔内没人了，不再准备下一回合",
                     self.room.roomid) if log.isEnabledFor(20) else None)
            return
        # Defense in depth: no death timer from the finished round may survive
        # into the next prepare phase.
        for rid in list(self._relive_timers):
            self._cancel_relive(rid)
        from . import biochem as _bio
        if _bio.is_biochem(self.room.gamemode):
            # 防御：生化 8/10 永远走自己的路径，别被普通模式状态重置污染。
            self._next_bio_round()
            return

        self._round_phase = "prepare"
        self.round_over = False
        self.started = False
        self.prepare_until = time.time() + NEXT_ROUND_PREPARE_TIME
        self._bot_shot_at = {}
        self._bot_motion = {}
        self._bot_last_sent = {}   # v63: 回合切换丢掉旧位置基准
        # 只清「回合内」状态。kills/deaths/score、阵营、装备方案、actorid
        # 全部保留：下一回合超时出生时仍用玩家原来的装备（客户端真实
        # CsChooseEquip 的 equipmap 是空字典，服务端按 equipindex 回查）。
        for f in self.fighters.values():
            f.hp = 100.0
            f.born = False
            f.born_at = 0.0
            f.dead_at = 0.0
            f.syncpos = None
            f.weaponpos = 0

        old = getattr(self, "_timer", None)
        self._timer = None
        if old is not None:
            try:
                old.cancel()
            except Exception:
                pass

        # 顺序与原生一致：RoundPrepare（清上一回合 TPS 对象/倒计时）
        # 先于 BornPrepare（开装备界面），最后才是 ScBorn。
        # 续回合窗口用 NEXT_ROUND_PREPARE_TIME=15（离线镜像校准值），
        # 首局 PREPARE_TIME=45 与生化现有值都不动。
        self.send_all(ID.SC_ROUND_PREPARE,
                      remaintime=NEXT_ROUND_PREPARE_TIME)
        self.send_all(ID.SC_BORN_PREPARE,
                      remaintime=NEXT_ROUND_PREPARE_TIME)
        self._spawn_prepared_bots()
        import asyncio
        try:
            self._timer = asyncio.get_running_loop().call_later(
                NEXT_ROUND_PREPARE_TIME, self._prepare_expired)
        except Exception:
            (log.debug("无法安排下一回合准备超时，立即出生并起局", exc_info=True) if log.isEnabledFor(10) else None)
            self._prepare_expired()

    def _arm_bio_intermission(self) -> None:
        """生化回合结束 -> 留 BIO_INTERMISSION 秒结算 -> 重新准备下一回合。"""
        import asyncio
        (log.info("room %s 生化回合 %s 结束，%ss 后进入下一回合",
                 self.room.roomid, self.round, BIO_INTERMISSION) if log.isEnabledFor(20) else None)
        try:
            asyncio.get_event_loop().call_later(BIO_INTERMISSION,
                                                self._next_bio_round)
        except Exception:
            (log.debug("无法安排生化回合间隔，立即开始下一回合", exc_info=True) if log.isEnabledFor(10) else None)
            self._next_bio_round()

    def _next_bio_round(self) -> None:
        if self.fight_over:
            return
        if not self.room.members:
            # 回合间隔里人全退了，别再开一个幽灵回合
            (log.info("room %s 生化回合间隔内没人了，不再开下一回合",
                     self.room.roomid) if log.isEnabledFor(20) else None)
            return
        from . import biochem as _bio
        if self.biochem is not None:
            self.biochem.cancel_picks()       # 旧回合的选僵尸定时器全部作废
        for rid in list(self._relive_timers):
            self._cancel_relive(rid)          # 旧回合的死亡倒计时同样作废
        # 新建一个**空僵尸集合**的 Biochem：born() 会按「不是僵尸 = side 1」
        # 给所有人人类出生点，不会沿用上一回合的僵尸阵营。
        self.biochem = _bio.Biochem(self)
        self.round_over = False
        self.started = False
        self._round_phase = "prepare"
        self.prepare_until = time.time() + PREPARE_TIME
        self._bot_shot_at = {}
        self._bot_motion = {}
        self._bot_last_sent = {}   # v63: 回合切换丢掉旧位置基准
        for f in self.fighters.values():
            f.hp = 100.0
            f.born = False
            f.born_at = 0.0
            f.syncpos = None
            f.side = 1                    # 上一回合的僵尸阵营必须清掉
            f.weaponpos = 0               # 上一回合可能是英雄刀(50)
            if f.human_actorid:
                f.actorid = f.human_actorid
            if f.human_equipmap:
                f.equipmap = dict(f.human_equipmap)
        # Restore human BOT machine guns before any ScBorn this round.  Ammo is
        # reset only here (new round), never by born()/respawn.
        try:
            from . import bots as _round_bots
            _round_bots.on_round(self)
        except Exception:
            (log.debug("bot round loadout hook failed", exc_info=True) if log.isEnabledFor(10) else None)
        old = getattr(self, "_timer", None)
        if old is not None:
            try:
                old.cancel()
            except Exception:
                pass
        if self.biochem is not None:
            # Clear the previous round's TPS objects BEFORE new Born messages.
            self.send_all(ID.SC_ROUND_PREPARE, remaintime=PREPARE_TIME)
        self.send_all(ID.SC_BORN_PREPARE, remaintime=PREPARE_TIME)
        if self.biochem is not None:
            self._spawn_prepared_bots()
        import asyncio
        try:
            self._timer = asyncio.get_event_loop().call_later(
                PREPARE_TIME, self._prepare_expired)
        except Exception:
            (log.debug("无法安排下一回合准备超时", exc_info=True) if log.isEnabledFor(10) else None)

    def end_fight(self, winside: int, winrole: int = 0) -> None:
        """整场战斗结束：ScFightEnd（关房间服连接）+ ScFightResult（走大厅服）。"""
        if self.fight_over:
            return
        self.fight_over = True
        # 整场结束：立即释放该房间的重连 grace，不等到 120 秒超时。
        try:
            from . import room_handlers as _rh
            _rh.cancel_room_reconnect_graces(self.room.roomid, "fight end")
        except Exception:
            (log.debug("取消失败 room=%s 的整场结束重连 grace",
                      self.room.roomid, exc_info=True) if log.isEnabledFor(10) else None)
        # 战斗结束：让所有已捕获的普通回合间隔回调失效。
        self._intermission_seq += 1
        self._round_phase = "fight"
        timer = self._timer
        self._timer = None
        if timer is not None:
            timer.cancel()
        # 回合间隔/下一回合准备定时器也必须作废：战斗已经结束，
        # 旧 timer 不能再准备或起一局「幽灵回合」。
        intermission = getattr(self, "_intermission_timer", None)
        self._intermission_timer = None
        if intermission is not None:
            try:
                intermission.cancel()
            except Exception:
                pass
        self._stop_round_clock()
        self.started = False
        self._stop_bio_tick()
        # **房间也要回到「等待开始」。**
        # `Room.started` 原来一旦开打就再也没人清（全仓库只有一处 `started = True`），
        # 于是打完一局之后房间列表里它永远显示「战斗中」，退出的人再想进同一个房间
        # 会被服务端按 JOIN_STARTED(7) 拒掉 —— 客户端提示的正是
        # 「不在战斗中或房间已满」（用户看到的就是「显示在战斗中或者满员」）。
        try:
            self.room.started = False
            from . import bots as _end_bots, room_fill
            for member in self.room.members.values():
                member.ready = _end_bots.is_bot(member.roleid)
            room_fill.fill(self.room)
        except Exception:
            (log.debug("重置 room.started 失败", exc_info=True) if log.isEnabledFor(10) else None)
        for rid in list(self._relive_timers):
            self._cancel_relive(rid)
        (log.info("room %s fight end: winside=%s 警察%s:%s匪徒", self.room.roomid,
                 winside, self.police_wins, self.terrist_wins) if log.isEnabledFor(20) else None)

        self.send_all(ID.SC_FIGHT_END)

        # ScFightResult 必须走**大厅服**那条连接 —— ScFightEnd 已经把房间服的关了。
        from . import handlers
        world = handlers.world
        table = self.result_table()
        for f in self.fighters.values():
            if world is None:
                continue
            s = world.session_of_role(f.roleid, "gs") or world.session_of_role(f.roleid)
            if s is None or s.closed:
                continue
            s.send(ID.SC_FIGHT_RESULT, roomid=self.room.roomid,
                   winside=int(winside), winrole=int(winrole),
                   resulttable=table)
        # 结算奖励（经验/金币）另发，见 reward_players()
        self.reward_players(winside, winrole)

        # **打完再推一次房间信息**：客户端收到 ScFightResult 后会回大厅，
        # 房间就空了 → 下一局只能重建。补一条 ScSyncRoomInfo（走大厅服连接）
        # 把客户端拉回房间界面，这样同一个房间可以接着开下一局。
        try:
            from . import room_handlers as _rh
            _rh._sync_room(self.room)
            (log.info("room %s 结算后重推房间信息（可接着开下一局）", self.room.roomid) if log.isEnabledFor(20) else None)
        except Exception:
            (log.debug("重推房间信息失败", exc_info=True) if log.isEnabledFor(10) else None)

    def result_table(self) -> Dict[int, Dict[str, int]]:
        """map<roleid, FightResultInfo>。

        FightResultInfo: diecount, killcount, starscore, side, equipbeststar

        必须包含**每个**玩家 —— ClientManager.OnBattleClose 里：
            if (!scFightResult.resulttable.ContainsKey(DataPool.HeroID))
                CurrentRoom.instance.Clear();
        漏掉谁，谁的房间状态就被清空。
        """
        out: Dict[int, Dict[str, int]] = {}
        for f in self.fighters.values():
            out[f.roleid] = {
                "diecount": int(f.deaths),
                "killcount": int(f.kills),
                "starscore": int(f.score),
                "side": int(f.side),
                "equipbeststar": 0,
            }
        return out

    def reward_players(self, winside: int, winrole: int = 0) -> None:
        """按 Kill/Death 发经验和金币。赢了翻倍。

        同时给每个人发一条 `ScSelfFightDetail`（结算面板的数据源）。客户端
        `RewardDialog.OnEnable` 在 `CurrentRoom.selfFightDetail == null` 时只
        订阅 `FightManager.onSelfFightDetail` 等待，**没有这条消息就永远不渲染**
        —— 表现是结算界面空白（只有胜负图标，经验/金币/分数都不显示）。
        """
        from . import handlers, leveling
        world = handlers.world
        if world is None:
            return
        for f in self.fighters.values():
            role = world.role(f.roleid)
            if role is None:
                continue
            solo = self.room.gamemode == 4
            won = f.roleid == winrole if solo else f.side == int(winside)
            # 养成型节奏：基础奖励整体 ×10（用户要求结算金币/经验各乘十倍）。
            # 截图 22 杀原来显示 540 金币 / 240 EXP，现在 5400 / 2400。
            # 系数（goldRewardRatio、周卡 addGold/addExp）仍按原样叠在放大后的
            # 基数上，PENDING_DOUBLE 与 ScSelfFightDetail 同步用最终值。
            # 【抖M版】结算经验/金币恢复**原始倍率 1**（正式版是 ×10）。
            # 正式版为了养成节奏整体放大十倍；受虐版不要这份放大。
            REWARD_SCALE = 1
            exp = (f.kills * 10 + (20 if won else 5)) * REWARD_SCALE
            gold = (f.kills * 20 + (100 if won else 30)) * REWARD_SCALE
            limit = getattr(self.room, "equiplimitid", 0)
            if limit:
                from . import special_modes
                gold = int(gold * special_modes.rule(limit)["goldRewardRatio"])
            # 周卡/月卡收益（Card.addGold / addExp 是百分比）。
            # 以前只记了到期时间，加成一项都没生效。
            try:
                from . import shop as _shop
                _cb = _shop.card_bonus(role)
                if _cb.get("addExp"):
                    exp = int(round(exp * (1 + _cb["addExp"] / 100.0)))
                if _cb.get("addGold"):
                    gold = int(round(gold * (1 + _cb["addGold"] / 100.0)))
            except Exception:
                (log.debug("周卡加成失败 role=%s", f.roleid, exc_info=True) if log.isEnabledFor(10) else None)
            old_rank = new_rank = 0
            try:
                if solo:
                    old_rank = role.level
                    world.award_local(role.roleid, {}, exp=exp)
                    new_rank = role.level
                else:
                    old_rank, new_rank = leveling.apply_exp(world, role, exp)
                from .wallet import change
                from . import bots as _bots, rank_profiles as _rank
                change(world,role,coins=gold)
                _rt = _rank.rank_type(self.room)
                # 普通房：每击杀 100 钻（生化 20 杀 = 2000 钻）。
                # 高难房取消这一条，改由下面的 RANK-SETTLE 按入口口径发。
                # 【抖M版】普通房击杀钻回到 ×1（正式版 ×100）。
                _gem_reward = int(f.kills) * 1 if _rt is None else 0
                if _gem_reward > 0:
                    change(world, role, gems=_gem_reward)
                    (log.info("role %s 结算钻石奖励：%d 击杀 -> +%d 钻",
                             f.roleid, int(f.kills), _gem_reward) if log.isEnabledFor(20) else None)
                # 【v19】高难房只对**真人**做钻石奖惩（单机只有真人有养成）。
                if _rt is not None and not _bots.is_bot(int(f.roleid)):
                    _kills = max(0, int(getattr(f, "kills", 0) or 0))
                    _deaths = max(0, int(getattr(f, "deaths", 0) or 0))
                    _steps = []
                    if _rt == _rank.LEAGUE:
                        # 【2.0.2】联赛结算顺序严格按用户口径：
                        #   **先奖励胜利 -> 再算击杀 -> 最后扣死亡**。
                        # 胜利奖励必须最先入账，否则下面的死亡扣款按「还没加
                        # 胜利奖励的余额」clamp，赢家反而少扣一大截。
                        _gm = int(getattr(self.room, "gamemode", 0) or 0)
                        if _gm == 4:
                            # SOLO 每个玩家 side 唯一，`won` 的 1/2 映射不可靠，
                            # 改比 `_winrole`（check_round 写的是击杀最高者的
                            # roleid）；且严格按「击杀满 20」判第一。
                            _won_here = (
                                _kills >= int(_rank.LEAGUE_SOLO_KILLS)
                                and int(f.roleid) == int(
                                    getattr(self, "_winrole", 0) or 0))
                        else:
                            _won_here = bool(won)
                        # 1) 胜利奖励：团队 5000 / SOLO 第一 20000 / 黑暗 100000
                        if _won_here:
                            _bonus = _rank.league_win_reward(self.room)
                            if _bonus > 0:
                                change(world, role, gems=_bonus)
                                _steps.append("联赛胜利(mode%d)+%d" % (_gm, _bonus))
                        # 2) 退票：统一走 rank_queue.consume_ticket()，账本里
                        # 一笔票全局只能消费一次。与胜负无关，属于门票结算。
                        from . import rank_queue as _rq
                        _ticket = _rq.consume_ticket(self.room, world, role)
                        if _ticket:
                            _steps.append("退票+%d" % _ticket)
                        # 3) 击杀：kills*1200 替代普通房 kills*1
                        if _kills:
                            _gain = _kills * _rank.KILL_REWARD
                            change(world, role, gems=_gain)
                            _steps.append("%d杀+%d" % (_kills, _gain))
                        # 4) 死亡：**最后**扣。clamp 到此刻的余额
                        # （已经含胜利奖励 + 退票 + 击杀），wallet.change
                        # 余额<0 会抛异常，账号钻石不允许为负。
                        _penalty = min(int(role.gold), _deaths * _rank.DEATH_PENALTY)
                        if _penalty > 0:
                            change(world, role, gems=-_penalty)
                            _steps.append("%d死-%d" % (_deaths, _penalty))
                    elif _rt == _rank.QUALIFYING and won:
                        # 排位：取消击杀钻，改本局胜利 1680 钻，只给真人
                        change(world, role, gems=_rank.WIN_REWARD)
                        _steps.append("胜利+%d" % _rank.WIN_REWARD)
                    if _steps:
                        (log.info("RANK-SETTLE role=%s rt=%s 余额=%d钻 明细=%s",
                                 f.roleid, _rt, int(role.gold), " -> ".join(_steps)) if log.isEnabledFor(20) else None)
            except Exception:
                (log.debug("发奖励失败 role=%s", f.roleid, exc_info=True) if log.isEnabledFor(10) else None)
                if solo:
                    continue
            # 「双倍奖励」按钮（CsDoubleReward）要用的原始数额：只对**本局**
            # 有效，用掉即作废（见 on_double_reward）。
            PENDING_DOUBLE[int(f.roleid)] = {
                "exp": int(exp), "gold": int(gold),
                "at": time.time(), "roomid": int(self.room.roomid),
            }
            # 打完一局 -> 「房间首胜」标成可领；分数记进最高分
            try:
                from . import rewards
                rewards.mark_claimable(role, 1)
                rewards.record_score(role, "room", f.score)
                from . import tasks
                tasks.record_room(self, role)
            except Exception:
                (log.debug("记录奖励状态失败 role=%s", f.roleid, exc_info=True) if log.isEnabledFor(10) else None)
            s = (world.session_of_role(f.roleid, "gs")
                 or world.session_of_role(f.roleid))
            if s is not None and not s.closed:
                s.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                       diamond=role.diamond)
                s.send(ID.SC_SELF_FIGHT_DETAIL,
                       exp=int(exp), gold=int(gold), vipexp=0,
                       money=int(gold), vipmoney=0, bloodgem=0,
                       firstwinbloodgem=0, durableloss={}, reparecost=0,
                       score=int(f.score))
                # 升级弹窗：客户端靠 ScUserInfo.property.rank 变大来识别升级
                try:
                    leveling.push_if_ranked_up(s, role, old_rank, new_rank)
                except Exception:
                    (log.debug("推送升级失败 role=%s", f.roleid, exc_info=True) if log.isEnabledFor(10) else None)
                # 领奖面板的按钮状态也跟着刷
                try:
                    from . import rewards
                    rewards.push_all(s, world.role(f.roleid) or role)
                except Exception:
                    (log.debug("推送奖励状态失败 role=%s", f.roleid,
                              exc_info=True) if log.isEnabledFor(10) else None)

    def on_report(self, session: Session, msg: dict) -> None:
        """Position update -> relay to everyone else."""
        roleid = int(msg.get("roleid") or session.roleid or 0)
        status = msg.get("status") or {}
        self.send_others(roleid, ID.SC_ROLE_STATUS_SYNC,
                         rolestatuses={roleid: {
                             "state": {
                                 "quat": status.get("quat") or dict(IDENTITY_QUAT),
                                 "pos": status.get("pos") or _vec3(0, 0, 0),
                                 "speed": status.get("speed") or _vec3(0, 0, 0),
                             },
                             "timestamp": int(time.time() * 1000),
                         }},
                         servertime=int(time.time() * 1000))


# roomid -> Battle
BATTLES: Dict[int, Battle] = {}

# roleid -> 本局可翻倍的奖励（CsDoubleReward）。用完即作废，5 分钟过期。
PENDING_DOUBLE: Dict[int, Dict[str, Any]] = {}
DOUBLE_REWARD_PRICE_ID = 4          # Price 表：购买双倍奖励 = 5 钻石
DOUBLE_REWARD_TTL = 300.0


def _room_of(roleid: int) -> Optional[R.Room]:
    """The RoomManager lives in room_handlers; import lazily to avoid a cycle."""
    from . import room_handlers
    return room_handlers.MANAGER.room_of(roleid)


def battle_for(room: R.Room, create: bool = True) -> Optional[Battle]:
    b = BATTLES.get(room.roomid)
    if b is None and create:
        b = Battle(room)
        BATTLES[room.roomid] = b
    return b


def drop(roomid: int) -> None:
    # 删房/新一局会 drop 战场：立即释放该房间的重连 grace。
    try:
        from . import room_handlers as _rh
        _rh.cancel_room_reconnect_graces(roomid, "battle drop")
    except Exception:
        (log.debug("取消失败 room=%s 的战场清理重连 grace", roomid,
                  exc_info=True) if log.isEnabledFor(10) else None)
    b = BATTLES.pop(roomid, None)
    if b is not None:
        if b.challenge is not None:
            b.challenge.stop()
            b.challenge.support.stop()
        b.fight_over = True
        b.started = False
        # Battle 已从 BATTLES 移除：任何已排队的普通回合间隔/准备回调
        # 都必须作废，否则它会继续持有这个已废弃的 Battle 并重新清场。
        b._intermission_seq += 1
        b._round_phase = "fight"
        b._stop_round_clock()
        b._stop_bio_tick()
        for rid in list(b._relive_timers):
            b._cancel_relive(rid)
        timer = getattr(b, "_timer", None)
        b._timer = None
        if timer is not None:
            timer.cancel()
        intermission = getattr(b, "_intermission_timer", None)
        b._intermission_timer = None
        if intermission is not None:
            try:
                intermission.cancel()
            except Exception:
                pass
        if b.biochem is not None:
            b.biochem.cancel_picks()


# --------------------------------------------------------------------------
# room-server routes
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_CHOOSE_EQUIP, "gclient.CsChooseEquip")
async def on_choose_equip(session: Session, msg: dict) -> None:
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        log.warning("CsChooseEquip with no room for roleid=%s", session.roleid)
        return
    b = BATTLES.get(room.roomid)
    if b is None:
        # the player pressed 确定 before we opened the prepare screen
        b = battle_for(room)
        b.begin()
    b.on_choose_equip(session, msg)


@ROUTER.register(ID.CS_ROLE_STATUS_REPORT, "gclient.CsRoleStatusReport")
async def on_status_report(session: Session, msg: dict) -> None:
    """**位置上报走 UDP，这里刻意不转发。**

    客户端 PosSyncherServer 是用 UdpChannel.instance.Send() 发的，服务端的
    crisisfire/net/udp.py 已经在转发同一条消息。TCP 这边再转一次的话，
    客户端会收到两份互相打架的坐标 —— 表现就是人卡在墙里、位置乱跳。

    留这个路由只是为了**兜底**：万一客户端某次走了 TCP（例如 UDP 建连前），
    至少不报「未注册消息」。收到就丢，不转发。
    """
    return


@ROUTER.register(ID.CS_RELIVE, "gclient.CsRelive")
async def on_relive(session: Session, msg: dict) -> None:
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = BATTLES.get(room.roomid)
    if b is not None:
        b.on_relive(session, msg)


# ---------------------------------------------------------------------------
# 服务端命中兜底（客户端 CaptureHit 抓不到人时自己算）
# ---------------------------------------------------------------------------
HIT_FALLBACK = True         # 总开关
TARGET_HEIGHT = 1.75        # 人物胶囊高度（米）
# 出生点抬高（米）。实测 S_bloodstrike 部分 police 点 y=0.41~0.47，
# 客户端角色会站在 layer 20（HackLayer）上，300 帧后 `Warrior.Update`
# 自己 `ClientManager.Report(2, userId, "In HackLayer")` + `GameUIFacade.onQuit()`，
# 表现就是「角色进图/复活几秒后自动退出」。抬高 20cm 让胶囊落到正常地面。
SPAWN_Y_LIFT = 0.20


def lift_spawn(pos):
    """给出生点 Y 加一点高度；坐标不合法时原样返回。"""
    try:
        if isinstance(pos, dict):
            out = dict(pos)
            out["y"] = int(round(float(out.get("y") or 0) + SPAWN_Y_LIFT * 100))
            return out
        return (float(pos[0]), float(pos[1]) + SPAWN_Y_LIFT, float(pos[2]))
    except (TypeError, ValueError, IndexError):
        return pos


TARGET_HEAD = 1.60          # 头部中心高度（米，自瞄用）

# 自瞄锁定事件（给 GM 面板实时显示用）。最多留最近 40 条。
AIM_EVENTS: "deque[dict]" = deque(maxlen=40)
TARGET_RADIUS = 0.45        # 胶囊半径（米，略放宽以补偿客户端丢命中）
SHOOT_MAX_RANGE = 120.0     # 有效射程（米）
RAY_STEP = 0.10             # 射线采样步长（米）


def _melee_fan_cast(b: "Battle", shooterid: int, me, origin, direction,
                    damage) -> List[dict]:
    """近战扇形兜底：以射击点为心、Melee.range 为半径、fanAngle 为张角，
    取**最近的**那个敌人。

    客户端 `ClientManager.IsAlarmEnemy` 用的是它自己的实时坐标，本来是最准的；
    但它 `return targetHit` 写在 foreach 里 —— 只取遍历顺序里的第一个，混战时
    可能报了个更远的，服务端复核就丢了。客户端干脆没报时这里补一刀。
    """
    try:
        ox, oy, oz = (float(origin.get(k) or 0) / 100.0 for k in ("x", "y", "z"))
    except (TypeError, ValueError):
        return []
    slot, weaponid = damage.active_weapon(me)
    # **幽灵的爪击不是刀。** 幽灵身上 equipmap[50] 通常没有近战武器，
    # `melee_range()` 返回 0 -> 整个函数直接 return []，
    # 于是「抓人有音效、掉不了血」。改用 BioProperty.range / fanAngle。
    _bio = getattr(b, "biochem", None)
    if _bio is not None and _bio.is_zombie(int(shooterid)):
        from .biochem import bio_property_of
        prop = bio_property_of(int(getattr(me, "actorid", 0) or 0)) or {}
        try:
            rng = float(prop.get("range") or 2.7)
        except (TypeError, ValueError):
            rng = 2.7
        try:
            half = float(prop.get("fanAngle") or 160.0) / 2.0
        except (TypeError, ValueError):
            half = 80.0
        # bot 幽灵的爪击判定范围与距离各 -20%（玩家当幽灵时原样保留）
        try:
            from . import bots as _bots
            if _bots.is_bot(int(shooterid)):
                rng *= 0.8
                half *= 0.8
        except Exception:
            pass
    else:
        # 【v51】屠龙芯片 meleerange 只加给真人玩家（BOT 不加），与
        # damage.resolve_shoot 的 reach 口径一致：原来这里漏传 scale，
        # 玩家满级芯片实际能砍 3.5m、兜底扇形却还按 2.0m 判，会漏刀。
        try:
            from . import bots as _fan_bots
            _fan_is_bot = _fan_bots.is_bot(int(shooterid))
        except Exception:
            _fan_is_bot = False
        _fan_scale = 1.0
        if not _fan_is_bot:
            try:
                _fan_scale = 1.0 + float(
                    getattr(me, "chip_meleerange", 0) or 0) * 0.01
            except (TypeError, ValueError):
                _fan_scale = 1.0
        rng = damage.melee_range(slot, weaponid, scale=_fan_scale)
        row = (damage._table("Melee") or {}).get(int(weaponid)) or {}
        try:
            half = max(0.0, float(row.get("fanAngle") or 100.0)) / 2.0
        except (TypeError, ValueError):
            half = 50.0
    if not rng or rng <= 0:
        return []
    # 朝向取水平分量；方向缺失时不做角度限制（只按距离）
    fx = float((direction or {}).get("x") or 0)
    fz = float((direction or {}).get("z") or 0)
    flen = math.hypot(fx, fz)

    best = None
    for f in b.fighters.values():
        if f.roleid == int(shooterid) or not f.born or f.hp <= 0:
            continue
        p = getattr(f, "syncpos", None)
        if p is None:
            continue
        if same_team(b, int(shooterid), f.roleid):
            continue
        tx, ty, tz = float(p[0]), float(p[1]), float(p[2])
        d = math.dist((ox, oy, oz), (tx, ty, tz))
        if d > rng:
            continue
        if flen > 1e-6:
            vx, vz = tx - ox, tz - oz
            vlen = math.hypot(vx, vz)
            if vlen > 1e-6:
                cosang = (fx * vx + fz * vz) / (flen * vlen)
                ang = math.degrees(math.acos(max(-1.0, min(1.0, cosang))))
                if ang > half:
                    continue
        if best is None or d < best[0]:
            best = (d, f)
    if best is None:
        return []
    d, f = best
    p = f.syncpos
    return [{
        "targetid": f.roleid,
        # sd 必须 ≤ reach，否则 resolve_shoot 那道客户端校验会把它丢掉
        "sd": min(d, rng),
        # 近战部位按胸算（客户端那条路径会用瞄准角度冒充部位，见上一轮讨论）
        "hitpart": damage.PART_CHEST,
        "hitpos": {"x": int(p[0] * 100), "y": int((p[1] + 1.2) * 100),
                   "z": int(p[2] * 100)},
        "targetpos": {"x": int(p[0] * 100), "y": int(p[1] * 100),
                      "z": int(p[2] * 100)},
    }]


def server_raycast(b: "Battle", shooterid: int, origin, direction, ammo=None) -> List[dict]:
    """当客户端 `targets` 为空时，服务端自己做射线-胶囊检测。

    背景：实测 364 发里只有 **16 发**带 `targets`（4%）—— 客户端
    `AGun.OneShot -> CaptureHit` 基本抓不到人，所以服务端永远收不到命中，
    表现就是「打不死人」。但 `CsShoot` 里带着**发射点和方向**，而所有人的
    UDP 坐标服务端都收得到（`Fighter.syncpos`），所以这里兜底自己算。

    返回和客户端 `TargetHit` 同构的 dict 列表，直接喂给现有裁决流程。
    """
    from . import damage
    me = b.fighters.get(int(shooterid))
    if me is None:
        return []
    # 近战不投射线，改走**扇形兜底**：客户端 `ClientManager.IsAlarmEnemy`
    # 会漏报（它 `return targetHit` 只取遍历到的第一个，常被判失败），
    # 客户端没报命中时服务端按 Melee.range + fanAngle 自己找最近的目标。
    if damage.uses_melee(b, me):
        return _melee_fan_cast(b, shooterid, me, origin, direction, damage)
    ox, oy, oz = (float(origin.get(k) or 0) / 100.0 for k in ("x", "y", "z"))
    dx, dy, dz = (float(direction.get(k) or 0) / 100.0 for k in ("x", "y", "z"))
    n = math.sqrt(dx * dx + dy * dy + dz * dz)
    if n <= 1e-6:
        return []
    dx, dy, dz = dx / n, dy / n, dz / n

    cands = []
    for f in b.fighters.values():
        if f.roleid == int(shooterid) or not f.born or f.hp <= 0:
            continue
        if f.syncpos is None:
            continue
        # 队友不掉血（生化模式除外：僵尸打人 / 人打僵尸）
        if same_team(b,int(shooterid),f.roleid):
            continue
        cands.append(f)
    if not cands:
        return []

    out: List[dict] = []
    dist = 0.0
    reach = SHOOT_MAX_RANGE
    if ammo:
        gun = damage._table("Gun")[damage.active_weapon(me)[1]]
        reach = gun["maximumRange"] + ammo["maxRangePlus"]
    while dist <= reach:
        px = ox + dx * dist
        py = oy + dy * dist
        pz = oz + dz * dist
        for f in cands:
            if f.roleid in [t["targetid"] for t in out]:
                continue
            tx, ty, tz = f.syncpos
            # 竖直胶囊的轴：脚 -> 头，(px,py,pz) 到轴段的最近距离
            h = min(max(py - ty, 0.0), TARGET_HEIGHT)
            ax, ay, az = tx, ty + h, tz
            if (math.sqrt((px - ax) ** 2 + (py - ay) ** 2 + (pz - az) ** 2)
                    <= TARGET_RADIUS):
                local = py - ty
                if local > 1.45:
                    part = 1        # 头
                elif local > 1.00:
                    part = 2        # 胸
                elif local > 0.60:
                    part = 3        # 腹
                else:
                    part = 4        # 腿
                out.append({
                    "targetid": f.roleid,
                    "sd": dist,
                    "hitpart": part,
                    "hitpos": {"x": int(px * 100), "y": int(py * 100),
                               "z": int(pz * 100)},
                    "targetpos": {"x": int(tx * 100), "y": int(ty * 100),
                                  "z": int(tz * 100)},
                })
        if out:
            break
        dist += RAY_STEP
    if out:
        return out
    # ---- 宽容救援：主判定没中（瞄偏 / 10Hz 坐标脱节），在瞄准锥内补一刀 ----
    return _raycast_assist(ox, oy, oz, dx, dy, dz, reach, cands)

    return out


def _raycast_assist(ox, oy, oz, dx, dy, dz, reach, cands) -> List[dict]:
    """主射线没命中时的宽容救援（真人专用，由 `fill_empty_player_shot` 走）。

    只在主判定漏判时才触发，把**瞄准方向锥内最近的非队友**补判为命中——
    专救黑暗模式那种「看不清->瞄不准、小图贴脸混战坐标脱节」导致的打空，
    又不会削弱瞄得准的射击，也不同于 `aim_lock`（后者是无条件锁头）。

    设计要点（避免变成远程自瞄）：
      - 夹角用「到敌人竖直胶囊轴最近点」算，消除胸口比脚高 1m 造成的
        竖向抬高（否则偏 25 度这种本该补中的会被吃掉）；
      - 硬上限 16m：远距不放宽，仍需自己瞄；
      - 锥角随距离收紧：<=4m 用 40 度 x 倍率，之后线性收到 5 度。
    """
    from ..config import CONFIG as _CFG
    scale = float(getattr(_CFG, "player_hit_assist", 1.0) or 0.0)
    if scale <= 0:
        return []
    ASSIST_MAX = 16.0
    pick = None  # (score, f, d, tx, ty, tz)
    for f in cands:
        tx, ty, tz = f.syncpos
        # 敌人竖直胶囊轴最近点（消除竖向抬高）：y 夹到 [ty, ty+TARGET_HEIGHT]
        ay = max(ty, min(oy, ty + TARGET_HEIGHT))
        vx, vy, vz = tx - ox, ay - oy, tz - oz
        d = math.sqrt(vx * vx + vy * vy + vz * vz)
        if d <= 0.01 or d > min(reach, ASSIST_MAX):
            continue
        cosang = (dx * vx + dy * vy + dz * vz) / d
        cosang = max(-1.0, min(1.0, cosang))
        ang = math.degrees(math.acos(cosang))
        max_cone = max(5.0, 40.0 * (4.0 / max(d, 4.0))) * scale
        if ang > max_cone:
            continue
        # 优先：角度更小，其次更近
        score = ang + d * 0.4
        if pick is None or score < pick[0]:
            pick = (score, f, d, tx, ty, tz)
    if pick is None:
        return []
    _s, f, d, tx, ty, tz = pick
    px, py, pz = ox + dx * d, oy + dy * d, oz + dz * d
    return [{
        "targetid": f.roleid, "sd": d, "hitpart": 2,
        "hitpos": {"x": int(px * 100), "y": int((ty + 1.0) * 100),
                   "z": int(pz * 100)},
        "targetpos": {"x": int(tx * 100), "y": int(ty * 100),
                      "z": int(tz * 100)},
    }]

def aim_lock(b: "Battle", shooterid: int, origin, direction) -> List[dict]:
    """**服务端自瞄 / 锁**：把这一枪强行判到最近的敌人身上。

    开启方式（环境变量，见 config.py）：

        CF_AIM_ASSIST=0   关闭（默认）
        CF_AIM_ASSIST=1   锁最近敌人（判成胸口命中）
        CF_AIM_ASSIST=2   锁最近敌人 + **必中头部**
        CF_AIM_ASSIST_FOV 只锁准星锥角内的目标（度；0 = 360° 全向锁）

    **为什么做在服务端**：本游戏的伤害**完全由服务端裁决** —— 客户端只发
    `CsShoot(TargetHit)` 报「打中谁、打哪」，扣血是 `damage.resolve_shoot`
    算的。所以改这里就等于「锁头」，不用注入客户端、不碰 `libtersafe`、
    也不用管客户端的模型加载，只对**自己这台私服**生效。

    只在本机/好友私服用；公共服开了就是作弊，别那么干。
    """
    from ..config import CONFIG as _CFG

    mode = int(getattr(_CFG, "aim_assist", 0) or 0)
    if mode <= 0:
        return []
    # 白名单：CF_AIM_ASSIST_IDS=100004,100003 时只对这几个号生效
    only = str(getattr(_CFG, "aim_assist_ids", "") or "").replace(" ", "")
    if only:
        ids = {int(x) for x in only.split(",") if x.strip().isdigit()}
        if ids and int(shooterid) not in ids:
            return []
    from . import damage
    me = b.fighters.get(int(shooterid))
    if me is None or damage.uses_melee(b, me):
        return []

    ox, oy, oz = (float(origin.get(k) or 0) / 100.0 for k in ("x", "y", "z"))
    fov = float(getattr(_CFG, "aim_assist_fov", 0.0) or 0.0)
    dirv = None
    if fov > 0 and direction:
        dx, dy, dz = (float(direction.get(k) or 0) / 100.0
                      for k in ("x", "y", "z"))
        n = math.sqrt(dx * dx + dy * dy + dz * dz)
        if n > 1e-6:
            dirv = (dx / n, dy / n, dz / n)

    best = None
    best_d = None
    _dbg_why = []
    for f in b.fighters.values():
        if f.roleid == int(shooterid):
            continue
        if not f.born:
            if log.isEnabledFor(logging.DEBUG):
                _dbg_why.append("%s:未出生" % f.roleid)
            continue
        if f.hp <= 0:
            if log.isEnabledFor(logging.DEBUG):
                _dbg_why.append("%s:已死" % f.roleid)
            continue
        if f.syncpos is None:
            if log.isEnabledFor(logging.DEBUG):
                _dbg_why.append("%s:无坐标" % f.roleid)
            continue
        # 队友不锁（生化模式除外：僵尸/人类互相都能锁）
        if same_team(b,int(shooterid),f.roleid):
            continue
        tx, ty, tz = f.syncpos
        hx, hy, hz = tx, ty + TARGET_HEAD, tz
        d = math.sqrt((hx - ox) ** 2 + (hy - oy) ** 2 + (hz - oz) ** 2)
        if d <= 0.01 or d > SHOOT_MAX_RANGE:
            continue
        if dirv is not None:
            cosang = ((hx - ox) * dirv[0] + (hy - oy) * dirv[1]
                      + (hz - oz) * dirv[2]) / d
            cosang = max(-1.0, min(1.0, cosang))
            if math.degrees(math.acos(cosang)) > fov:
                continue
        if best_d is None or d < best_d:
            best, best_d = f, d

    if best is None:
        from ..config import CONFIG as _CFG2
        if int(getattr(_CFG2, "aim_assist", 0) or 0) > 0:
            (log.info("AIMDBG role=%s 无可锁目标: 原因=[%s] fighters=%d", shooterid,
                     "; ".join(_dbg_why[:12]), len(b.fighters)) if log.isEnabledFor(20) else None)
        return []
    tx, ty, tz = best.syncpos
    head = mode >= 2
    hit_y = ty + (TARGET_HEAD if head else 1.20)
    # 记一条给 GM 面板看（谁锁了谁、多远、打哪、对方还剩多少血）
    try:
        if log.isEnabledFor(logging.DEBUG):
            AIM_EVENTS.append({
            "ts": time.time(),
            "shooter": int(shooterid),
            "target": int(best.roleid),
            "dist": round(float(best_d or 0.0), 2),
            "part": 1 if head else 2,
            "hp": round(float(best.hp), 1),
        })
    except Exception:
        pass
    return [{
        "targetid": best.roleid,
        "sd": best_d,
        "hitpart": 1 if head else 2,          # 1=头 2=胸
        "hitpos": {"x": int(tx * 100), "y": int(hit_y * 100),
                   "z": int(tz * 100)},
        "targetpos": {"x": int(tx * 100), "y": int(ty * 100),
                      "z": int(tz * 100)},
    }]


def fill_empty_player_shot(b: "Battle", shooterid: int, shoot: dict, ammo=None) -> dict:
    """Recover missing player ray hits while preserving explicit targets."""
    if not HIT_FALLBACK or shoot.get("targets"):
        return shoot
    extra = server_raycast(b, shooterid, shoot.get("position") or {}, shoot.get("dir") or {}, ammo)
    if not extra:
        return shoot
    (log.debug("SHOOTDBG role=%s fallback targets=%s", shooterid,
              [(hit["targetid"], hit["hitpart"]) for hit in extra]) if log.isEnabledFor(10) else None)
    return {**shoot, "targets": extra}


@ROUTER.register(ID.CS_SHOOT, "gclient.CsShoot")
async def on_shoot(session: Session, msg: dict) -> None:
    """命中判定 + 伤害裁决。

    协议把职责划得很清楚：`CsShoot(TargetHit)` 只报「打中了谁、打在哪」，
    **伤害由服务端算**，再通过 `ScShoot(TargetDamage)` 下发。之前这里只转发、
    不裁决，所以服务端根本不知道谁打死了谁 —— 生化的感染链也就无从触发。
    """
    from . import damage
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = battle_for(room, create=False)
    if b is None:
        return
    shoot = msg.get("shoot") or {}
    is_bio = b.biochem is not None

    # 【v61】玩家侧弹药记账（只用于切枪回包，不参与伤害裁决）。
    # 客户端在线模式不把弹药发给服务端，这里按 Gun 表逐发扣减，
    # 否则 `WeaponChange` 只能回 -1 -> 客户端把备弹补满。
    try:
        from . import player_ammo as _pammo
        _shooter = b.fighters.get(session.roleid)
        if _shooter is not None and _shooter.roleid < 900000:
            from . import human as _human
            # 【v62】槽位交给 `player_ammo.held_slot`（内部走 active_weapon），
            # 不要用 `f.weaponpos` —— 出生后到第一次主动换枪之前它是 0。
            _slot, _iid = damage.active_weapon(_shooter)
            _info = _human.load_gun(_iid) if _iid else None
            _pammo.on_shot(b, _shooter,
                           max(1, int(getattr(_info, "fire_per_shot", 1) or 1))
                           if _info is not None else 1)
    except Exception:      # 记账失败绝不能影响裁决
        pass

    # 诊断：确认客户端的 CsShoot 到底有没有到服务端。
    # 背景：客户端**本地**也会算伤害（VirtualServer 那套），所以它自己能播死亡
    # 动画、自己跑复活倒计时。而 ScWaitRelive 只有服务端 on_kill 才发 ——
    # 一旦 CsShoot 没到，服务端就永远不知道有人死了，倒计时归零后客户端一直等，
    # 表现就是「倒计时归零也无法自动复活」。
    # 实测日志里整局没有任何 on_kill —— 先确认这条路通不通。
    (log.info("SHOOTDBG role=%s 收到 CsShoot: %s", session.roleid,
             {k: v for k, v in shoot.items() if k != "hits"}
             if isinstance(shoot, dict) else type(shoot).__name__) if log.isEnabledFor(20) else None)

    # 挑战模式（PVE）：客户端把命中怪物的 targetid 也塞进 CsShoot.targets，
    # 但真正的 hp 归服务端管，所以先把怪物那部分吃掉再走玩家裁决。
    if b.challenge is not None:
        settle_shoot(b, session.roleid, shoot, False, log_tag="SHOOTDBG", player_reported=True)
        return

    # **服务端自瞄优先**（CF_AIM_ASSIST）：直接把这一枪判到最近的敌人身上，
    # 客户端报的 targets 会被覆盖 —— 这才是「暴力锁」的效果，而且伤害本来就是
    # 服务端算的，所以换弹道/换枪都不影响。
    locked = aim_lock(b, session.roleid,
                      shoot.get("position") or {},
                      shoot.get("dir") or {})
    if locked:
        shoot = dict(shoot)
        shoot["targets"] = locked
        (log.info("AIMDBG role=%s 自瞄锁定 %s -> 部位=%s",
                 session.roleid,
                 [t["targetid"] for t in locked],
                 [t["hitpart"] for t in locked]) if log.isEnabledFor(20) else None)
    # **客户端没报命中时，服务端自己算。** 实测客户端只有 4% 的射击带 targets，
    # 不兜底就永远打不死人（原因见 server_raycast 的注释）。

    # 怪物不是 Fighter，resolve_shoot 不会处理；把 pve 算出来的命中拼进去，
    # 后面统一走 ScShoot 下发 —— 客户端怪物血条就是靠这条消息掉的。
    settle_shoot(b, session.roleid, shoot, is_bio,
                 log_tag="SHOOTDBG", player_reported=True)


def settle_shoot(b: "Battle", shooterid: int, shoot: dict, is_bio: bool,
                 extra_hits=(), log_tag: str = "", *, player_reported=False) -> int:
    """一枪的结算出口：算伤害 -> 下发 ScShoot -> 判死。

    `on_shoot`（客户端报上来的枪）和 `bots.fire`（服务端替机器人开的枪）共用这一条，
    保证两种来源的枪走**完全相同**的伤害、下发和击杀链 —— 否则会出现「玩家能打死
    机器人、机器人打不死玩家」这类只修一半的洞。

    客户端侧 `ClientManager.Shoot` 靠 `DataPool.IsUnrelated(shooterid)` 决定要不要
    播弹道/枪口，所以服务端替谁开枪都行，只要那个 roleid 没被 ManageAI 标成机器人。
    返回命中数。
    """
    from . import damage
    shooter=b.fighters.get(int(shooterid))
    if shooter is None or not shooter.born or shooter.hp<=0 or b.round_over or b.fight_over:
        return 0
    # 【v8】Lv4 听觉：记下每个射手的最后开枪时刻，BOT 用 `bot_hear_range`
    # 判断「没看见人但听到枪声」，从而转向/前去查看。
    try:
        import time as _st_time
        _shots = getattr(b, "_last_shot_at", None)
        if _shots is None:
            _shots = b._last_shot_at = {}
        _shots[int(shooterid)] = _st_time.monotonic()
    except Exception:
        pass
    # **BOT 攻击去重**（用户长期反馈的「卡顿后爪击/子弹瞬间结算多次」）。
    # 一个 tick 里 `for _ in range(fired)` 会连续多次调这里、定时器重入也会
    # 把同一发裁决两遍，高伤武器一帧就能把 1300 血打空。20ms 远小于最快枪
    # 的射击间隔（~80ms），只拦同一 tick 内的重复，不削正常射速。
    # 只作用于 BOT 路径；真人 CsShoot 与霰弹 ScMultiShoot 都不经过这里。
    if str(log_tag or "").startswith("BOT"):
        import time as _time
        _now = _time.monotonic()
        _gate = getattr(b, "_bot_shoot_gate", None)
        if _gate is None:
            _gate = b._bot_shoot_gate = {}
        if _now - float(_gate.get(int(shooterid), -1e9)) < 0.02:
            return 0
        _gate[int(shooterid)] = _now
    from . import premium_ammo
    ammo, paid_rays = premium_ammo.spend(b, shooter) if player_reported else ({}, 0)
    if not paid_rays:
        ammo = {}
    challenge = getattr(b, "challenge", None)
    if challenge is not None:
        extra_hits = challenge.on_shoot(shooterid, shoot, ammo=ammo)
    elif player_reported:
        shoot = fill_empty_player_shot(b, shooterid, shoot, ammo)
    hits = list(damage.resolve_shoot(b, shooterid, shoot, is_biochem=is_bio, ammo=ammo) or [])
    if extra_hits:
        hits = hits + list(extra_hits)
    from . import room_ai
    room_ai.note_shot(b, shooter, hits)
    # 记下受击时刻：脱战回血（_bio_heal_tick）靠它重置倒计时。
    # **时间基准必须是 time.time()**（和 f.born_at / _bio_heal_tick 一致），
    # 原来用 monotonic 与墙钟混算会让「差多久」变成天文数字。
    # 所有命中都算受击（含只掉护甲的 absorb 命中），否则客户端重置了
    # 倒计时条、服务端没重置，就会「条没走完就开始回血」。
    if is_bio and hits and getattr(b, "biochem", None) is not None:
        import time as _time
        _now = _time.time()
        _hurt = getattr(b, "_bio_last_hurt", None)
        if _hurt is None:
            _hurt = b._bio_last_hurt = {}
        for _h in hits:
            try:
                _hurt[int(_h.targetid)] = _now
            except (TypeError, ValueError, AttributeError):
                continue
    if is_bio and hits:
        from . import bot_recoil
        bot_recoil.register(b,shooterid,hits)
    if log_tag:
        (log.info("%s role=%s 裁决结果: %d 个命中 %s", log_tag, shooterid,
                 len(hits),
                 [(h.targetid, round(getattr(h, "hpdamage", 0), 1))
                  for h in hits] if hits else "") if log.isEnabledFor(20) else None)
    if not hits:
        # 没打中人也要转发，别人要看到弹道
        b.send_others(shooterid, ID.SC_SHOOT,
                      shoot=damage.shoot_damage_payload(shoot,[]),shooterid=shooterid)
        # UC premium_ammo.spend already accounts for empty shots.
        return 0

    # 服务端算出的伤害发回房间（包括射手自己，客户端靠它显示掉血）
    payload = damage.shoot_damage_payload(shoot, hits)
    b.send_all(ID.SC_SHOOT, shoot=payload, shooterid=shooterid)

    for h in hits:
        (log.debug("shoot %s -> %s part=%s dmg=%s hp=%s", shooterid,
                  h.targetid, h.hitpart, h.hpdamage, h.hp_left) if log.isEnabledFor(10) else None)
        if h.died and h.targetid in b.fighters:
            b.on_kill(shooterid, h.targetid, _killer_weapon(b, shooterid))
    if challenge is not None:
        _, weapon = damage.active_weapon(shooter)
        challenge.send_deaths(shooterid, weapon,
                              (h.targetid for h in extra_hits if h.died))
    return len(hits)


def consume_cart_ammo(b, roleid: int) -> None:
    """穿甲弹：每开一发**真实扣仓库 1 发**，扣空自动回切普通弹。

    客户端那边穿甲弹是个**开关**（`BulletChange` bullettype=2/4），数量只是
    「还剩几发」，所以服务端必须自己扣。两件事缺一不可：

      1. `stackable.take_item` 写库（真扣，退出对局也不恢复）；
      2. `ScPackageSync(synctype=2)` 把新数量推给客户端。

    以前只做了 1，客户端一直拿登录时的旧数量，退出对局回到大厅就显示
    「又变回原来的数量」—— 看起来像没扣，其实是客户端缓存没同步。
    """
    from . import damage as _dmg, stackable
    f = b.fighters.get(int(roleid))
    if f is None:
        return
    try:
        slot, weaponid = _dmg.active_weapon(f)
        ammo_id, _row = _dmg.cart_ammo(b, roleid, slot, weaponid)
    except Exception:
        return
    if not ammo_id:
        return
    role = _role_obj(roleid)
    if role is None:
        return
    from . import handlers as _h
    world = getattr(_h, "world", None)
    try:
        if not stackable.take_item(role, ammo_id, 1, world):
            left = 0
        else:
            left = int(stackable.item_count(role, ammo_id) or 0)
    except Exception:
        (log.debug("穿甲弹扣减失败 role=%s ammo=%s", roleid, ammo_id,
                  exc_info=True) if log.isEnabledFor(10) else None)
        return
    # **关键**：把扣完的数量同步给客户端，否则大厅里还是旧数量。
    try:
        from . import equip as _eq
        s = None
        if world is not None:
            s = (world.session_of_role(int(roleid), "room")
                 or world.session_of_role(int(roleid)))
        if s is not None and not getattr(s, "closed", False):
            _eq.push_stack_counts(s, role, [int(ammo_id)])
    except Exception:
        (log.debug("穿甲弹数量同步失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
    if left > 0:
        return
    # 打空了：开关弹回普通弹，并让客户端去商城买（Text 314）
    normal = 1 if int(slot or 0) == 11 else 3
    if not hasattr(b, "ammo_cart"):
        b.ammo_cart = {}
    b.ammo_cart[int(roleid)] = normal
    try:
        from . import relay as _relay
        b.send_all(_relay.ID.BULLET_CHANGE, roleid=int(roleid),
                   bullettype=normal)
    except Exception:
        (log.debug("穿甲弹回切广播失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
    (log.info("role %s 穿甲弹 %s 已耗尽 -> 回切普通弹(%s)", roleid, ammo_id, normal) if log.isEnabledFor(20) else None)


def _killer_weapon(b, roleid: int) -> int:
    """击杀结算用的武器 id —— 取该玩家当前手上那把。"""
    from . import damage
    try:
        f = b.fighters.get(int(roleid))
        if f is None:
            return 0
        _slot, iid = damage.active_weapon(f)
        return int(iid or 0)
    except Exception:
        return 0


@ROUTER.register(ID.WEAPON_CHANGE, "gclient.WeaponChange")
async def on_weapon_change(session: Session, msg: dict) -> None:
    """换枪。服务端必须记住这个槽位 —— `CsShoot` 里没有 weaponid。

    WeaponChange(roleid, weaponpos, bulletnum) 发的是**装备槽**（11 主武器 /
    12 副武器 / 50 近战），伤害裁决时用角色的 equipmap 反查物品 id。
    """
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = battle_for(room, create=False)
    if b is None:
        return
    f = b.fighters.get(session.roleid)
    slot = int(msg.get("weaponpos") or 0)
    # 【v61】近战槽（50）永远放行：`equipmap` 可能因为装备方案/限制模式
    # 没带刀，但「快速切换」本身是客户端行为，服务端只需不被这条过滤挡住。
    if (getattr(room, "equiplimitid", 0) and slot != 50
            and (f is None or slot not in f.equipmap)):
        return
    if f is not None:
        f.weaponpos = slot
    # **必须含发起者自己**（send_all）。客户端 FPSOnlineBehaviour.ChangeWeapon
    # 发完 CsWeaponChange 后**本地不切枪**，等这条回包 `ClientManager.WeaponChange
    # -> playerData.PullWeapon(weaponpos)` 才真正换枪；上一版误改成
    # send_others 后玩家自己收不到回包，快速切换/列表点选/手雷全部失效。
    #
    # bulletnum 是「总弹数(clip+reserve)」，客户端用 `bulletnum - ammoInClip`
    # 反推备弹。真人玩家发切枪时 FPSOnlineBehaviour 固定发 -1（在线模式的
    # 设计：子弹数由本地 AArsenal/PlayerData 维护），服务端对真人没有弹药
    # 模型，只能把玩家发来的值原样回传，客户端 `-1 - ammoInClip` 会得到负数
    # 被 AArsenal 兜底 —— 这里不做任何 `or 0` 归一，否则 -1 会被抹成 0。
    bulletnum = msg.get("bulletnum")
    try:
        bulletnum = int(bulletnum)
    except (TypeError, ValueError):
        bulletnum = -1
    # 【v61】客户端在线模式固定发 -1（弹药交给本地 AArsenal 维护）。服务端
    # 原样回传时，客户端 `ClientManager.WeaponChange` 算
    # `reserve = bulletnum - ammoInClip` 得到负数，`AGun.SetAmmo` 里
    # `if (ammoReserve < 0) ammoReserve = ammoTotalReserve;` —— **每切一次
    # 枪备弹就补满一次**。这里用服务端自己记的弹药填真值；近战（50）与
    # 没有弹药模型的槽保持 -1 原样。
    if bulletnum < 0 and f is not None:
        from . import player_ammo
        _total = player_ammo.total(b, f, slot)
        if _total is not None:
            bulletnum = int(_total)
    b.send_all(ID.WEAPON_CHANGE,
               roleid=session.roleid,
               weaponpos=slot,
               bulletnum=bulletnum)


@ROUTER.register(ID.CS_ACTION, "gclient.CsAction")
async def on_action(session: Session, msg: dict) -> None:
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = BATTLES.get(room.roomid)
    if b is not None:
        b.send_all(ID.SC_ACTION,
                      roleid=session.roleid, action=int(msg.get("action") or 0))


@ROUTER.register(ID.CS_JUMP, "gclient.CsJump")
async def on_jump(session: Session, msg: dict) -> None:
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = BATTLES.get(room.roomid)
    if b is not None:
        b.send_all(ID.SC_JUMP,
                      roleid=session.roleid,
                      pos=msg.get("pos") or _vec3(0, 0, 0),
                      speed=msg.get("speed") or _vec3(0, 0, 0))


@ROUTER.register(ID.CS_GRENADE_THROW, "gclient.CsGrenadeThrow")
async def on_grenade(session: Session, msg: dict) -> None:
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = BATTLES.get(room.roomid)
    if b is not None:
        from . import grenades
        grenades.throw(b, session.roleid, int(msg.get("grenadeid") or 0),
                       msg.get("pos") or {}, msg.get("speed") or {})


@ROUTER.register(ID.CS_TICK, "gclient.CsTick")
async def on_tick(session: Session, msg: dict) -> None:
    """Optional client heartbeat; the independent clock owns deadlines."""
    room = _room_of(session.roleid) if session.roleid else None
    b = battle_for(room, create=False) if room else None
    if b is not None:
        b.check_round()


@ROUTER.register(ID.KEEP_ALIVE, "gclient.KeepAlive")
async def on_keepalive(session: Session, msg: dict) -> None:
    """只收不回。回的话会和客户端的自动回发形成死循环（见 handlers.on_keepalive）。"""
    return


# ---------------------------------------------------------------------------
# 战斗内的小交互：补弹 / 队友复活 / PVE 增益
# ---------------------------------------------------------------------------
def _active_battle(session: Session) -> Optional["Battle"]:
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return None
    return BATTLES.get(room.roomid)


@ROUTER.register(ID.CS_FILL_AMMO, "gclient.CsFillAmmo")
async def on_fill_ammo(session: Session, msg: dict) -> None:
    """补弹按钮（OperationAgent 按住 -> CsFillAmmo(0)，松手 -> CsFillAmmo(2)）。

    客户端 `ClientManager.FillAmmo(roleid, result)`：result=1 才真正 FillBullet +
    播音效 + 关面板；2 = 取消。服务端原来没有 handler，按住补弹按钮毫无反应
    （PVE 的弹药箱/补给点用不了）。
    """
    b = _active_battle(session)
    if b is None:
        return
    oper = int(msg.get("oper") or 0)
    if b.challenge is not None:
        b.challenge.support.fill_ammo(session.roleid, oper)
        return
    result = 1 if oper == 0 else oper
    b.send_all(ID.SC_FILL_AMMO, roleid=session.roleid, result=result)


@ROUTER.register(ID.CS_RELIVE_OTHERS, "gclient.CsReliveOthers")
async def on_relive_others(session: Session, msg: dict) -> None:
    """队友复活：ScReliveOthers(roleid=救人者, reliveid=被救者)。

    客户端收到后会把被救者的 hp 设成 0.1（`ClientManager.Response(ScReliveOthers)`），
    所以服务端状态也要跟上，否则下一次裁决会把他当成「还活着」。
    """
    b = _active_battle(session)
    target = int(msg.get("reliveid") or 0)
    if b is None or not target or b.bio_eliminated(target):
        return
    f = b.fighters.get(target)
    if f is None:
        return
    if f.born and f.hp > 0:
        (log.info("role %s 想复活 %s，但对方还活着", session.roleid, target) if log.isEnabledFor(20) else None)
        return
    if b.challenge is not None:
        if target == session.roleid or not b.challenge.revives.authorize(session.roleid, target):
            return
    # 被近战击杀的幽灵，队友也救不起来
    _bio = getattr(b, "biochem", None)
    if (_bio is not None and _bio.is_zombie(target)
            and not _bio.can_relive(target)):
        (log.info("role %s 想复活 %s，但他被近战击杀、本回合禁止复活",
                 session.roleid, target) if log.isEnabledFor(20) else None)
        return
    f.hp = 0.1
    f.born = True
    try:
        b._cancel_relive(target)
    except Exception:
        pass
    b.send_all(ID.SC_RELIVE_OTHERS, roleid=session.roleid, reliveid=target)
    (log.info("role %s 复活了队友 %s (hp=0.1)", session.roleid, target) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_ADD_BUFF, "fight.CsAddBuff")
async def on_add_buff(session: Session, msg: dict) -> None:
    from . import pve_support
    pve_support.select_buff(session, msg, remove=False)


@ROUTER.register(ID.CS_REMOVE_BUFF, "fight.CsRemoveBuff")
async def on_remove_buff(session: Session, msg: dict) -> None:
    from . import pve_support
    pve_support.select_buff(session, msg, remove=True)


# ---------------------------------------------------------------------------
# 结算面板「双倍奖励」
# ---------------------------------------------------------------------------
def _double_reward_price() -> int:
    for row in gamedata.table("Price"):
        if int(row.get("id") or 0) == DOUBLE_REWARD_PRICE_ID:
            return int(row.get("gem") or 0)
    return 0


@ROUTER.register(ID.CS_DOUBLE_REWARD, "fight.CsDoubleReward")
async def on_double_reward(session: Session, msg: dict) -> None:
    """BattleRewardPanel 的「双倍奖励」按钮。

    客户端流程（BattleRewardPanel.onDbleReward）::

        Price price = GameData.instance.getPrice(4);      // 5 钻石
        if (UserManager.CanBuy(price, 1u)) FightManager.DoubleReward();  // CsDoubleReward

    服务端原来没有 handler，点了没反应（按钮一直发光、奖励不翻倍）。这里按
    `reward_players` 记下的本局 exp/gold 再发一遍，并扣 5 钻石；**每局只能一次**
    （用掉就从 PENDING_DOUBLE 里删掉）。
    """
    from . import handlers as _h
    from . import leveling
    world = _h.world
    roleid = int(session.roleid or 0)
    info = PENDING_DOUBLE.get(roleid)
    if (info is None or world is None
            or time.time() - float(info.get("at") or 0) > DOUBLE_REWARD_TTL):
        session.send(ID.SC_DOUBLE_REWARD_RET, retcode=1, exp=0, money=0)
        return
    role = world.role(roleid)
    cost = _double_reward_price()
    if role is None or int(role.gold or 0) < cost:
        (log.info("role %s 双倍奖励失败：钻石不足（%s<%s）", roleid,
                 getattr(role, "gold", 0), cost) if log.isEnabledFor(20) else None)
        session.send(ID.SC_DOUBLE_REWARD_RET, retcode=1, exp=0, money=0)
        return

    PENDING_DOUBLE.pop(roleid, None)
    exp = int(info.get("exp") or 0)
    money = int(info.get("gold") or 0)
    from .wallet import change
    change(world,role,coins=money,gems=-cost)
    old_rank, new_rank = leveling.apply_exp(world, role, exp)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    session.send(ID.SC_DOUBLE_REWARD_RET, retcode=0, exp=exp, money=money)
    try:
        leveling.push_if_ranked_up(session, role, old_rank, new_rank)
    except Exception:
        (log.debug("双倍奖励后推送升级失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
    (log.info("role %s 双倍奖励：- %s 钻石，再 +%s exp / +%s 金币",
             roleid, cost, exp, money) if log.isEnabledFor(20) else None)
