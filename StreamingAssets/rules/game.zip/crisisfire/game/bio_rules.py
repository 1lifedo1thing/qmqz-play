"""Round-scoped rules for UC's local Bio Hero mode."""
from functools import lru_cache
import random

from .. import gamedata


HERO_MODE = 10
BOT_MORPH_TIME = 5.0  # UC ClientManager.Infected's Zombie_Fps_Morph duration.


def select_mothers(roleids, mode, preferred=0):
    # Leave a human in short rooms. The native rule normally fills eight seats.
    # 【v58】用户口径：**任何模式开局都只出 1 个母体**。
    # 原版生化英雄会给 2 个（两处母体同时带队），实测太乱，统一改成 1。
    count = min(1, max(0, len(roleids) - 1))
    if count == 0:
        return []
    if preferred in roleids:
        return [preferred, *random.sample([role for role in roleids if role != preferred], count - 1)]
    return random.sample(roleids, count)


@lru_cache(maxsize=1)
def zombie_choices():
    from .biochem import bio_property_of, bio_skill_of

    return tuple(row["id"] for row in gamedata.table("Role")
                 if row.get("camp") == 3 and row.get("visible")
                 and bio_property_of(row["id"]) and bio_skill_of(row["id"]))
