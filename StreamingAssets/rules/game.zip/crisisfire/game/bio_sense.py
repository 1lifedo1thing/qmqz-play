"""Observations supplied to the human defenders' existing bio tactics."""
import math
from types import SimpleNamespace

from . import human, room_ai


def nearby_steps(here, enemies, colliders, state, now, hearing):
    previous = state.get("nearby_steps", {})
    current = {rid: (now, enemy.syncpos) for rid, enemy in enemies.items()
               if math.dist(here, enemy.syncpos) <= hearing}
    state["nearby_steps"] = current
    for rid, (_, position) in current.items():
        sample = previous.get(rid)
        if sample is None or not 0 < now - sample[0] <= .75:
            continue
        if math.dist(position, sample[1]) < .30:
            continue
        start = here[0], here[1] + 1.0, here[2]
        end = position[0], position[1] + .7, position[2]
        if colliders is not None and colliders.clear(start, end):
            yield rid, position


def threats(battle, fighter, nav, colliders, here, state, now):
    from . import bots

    enemies = {other.roleid: other for other in battle.fighters.values()
               if other.born and other.hp > 0 and other.syncpos is not None
               and battle.biochem.is_zombie(other.roleid)}
    settings = room_ai.training()
    memory = state.setdefault("known_ghosts", {})
    visible = {rid for rid, enemy in enemies.items()
               if room_ai.visible(here, enemy.syncpos, colliders, state, settings)}
    for rid in visible:
        memory[rid] = (enemies[rid].syncpos, now + 2.0)
    for _, _, rid, at, origin in room_ai.heard_enemies(battle, fighter.roleid, here, enemies, now,
                                                         settings["hearRange"]):
        if rid not in visible:
            memory[rid] = (origin, at + 2.0)
    # Close running in the same lane is audible, even when the defender is
    # looking elsewhere. An unseen ghost is never a valid firing target.
    for rid, pos in nearby_steps(here, enemies, colliders, state, now, settings["hearRange"]):
        if rid not in visible:
            memory[rid] = (pos, now + 1.0)
    for rid, (_, expires) in list(memory.items()):
        if expires <= now or rid not in enemies:
            del memory[rid]

    origin = nav.locate(here) if nav is not None else None
    result = []
    for rid, (pos, _) in memory.items():
        dest = nav.locate(pos) if origin is not None else None
        reachable = bool(dest is not None and nav.component[dest[0]] == nav.component[origin[0]])
        speed = bots._zombie_prop(enemies[rid].actorid).get("runSpeed", 0)
        result.append(human.Threat(rid, pos, math.dist(here, pos), rid in visible, speed, reachable))
    return result


def short_routes(here, nav, colliders, radius):
    from .bots import _grounded_step

    if nav is None or colliders is None or not (ground := nav.ground(here)):
        return
    foot = max(0, min(.5, here[1] - ground[1]))
    for index in range(8):
        yaw = math.tau * index / 8
        goal = (here[0] + radius * math.sin(yaw), here[1], here[2] + radius * math.cos(yaw))
        reached = _grounded_step(nav, colliders, here, goal, foot, radius + .15)
        if math.dist(here, reached) >= radius * .75:
            yield index, reached


def hold_heading(here, nav, colliders, initial_yaw, high):
    # Exposed waypoints are only for transit. A ground post has rear cover
    # and separated escape directions on the original collision surface.
    if high:
        return initial_yaw
    exits = list(short_routes(here, nav, colliders, 2.5))
    if not any(min((a - b) % 8, (b - a) % 8) >= 2 for a, _ in exits for b, _ in exits):
        return None
    eye = here[0], here[1] + 1.45, here[2]
    for offset in (0, .5, -.5, 1, -1, 1.5, -1.5):
        yaw = initial_yaw + offset
        rear = eye[0] - 2 * math.sin(yaw), eye[1], eye[2] - 2 * math.cos(yaw)
        front = eye[0] + 3 * math.sin(yaw), eye[1], eye[2] + 3 * math.cos(yaw)
        if not colliders.clear(eye, rear) and colliders.clear(eye, front):
            return yaw
    return None


def post_safe(here, threats, safe):
    for threat in threats:
        same_level = threat.pos[1] >= here[1] - .8
        can_approach = threat.visible or (same_level and threat.reachable)
        if can_approach and (threat.dist <= human.ZOMBIE_REACH + .5 or (same_level and threat.dist <= safe)):
            return False
    return True


def break_contact(here, nav, colliders, threats):
    if not threats:
        return None
    before = min(math.dist(here, threat.pos) for threat in threats)
    candidates = []
    for _, point in short_routes(here, nav, colliders, 2.5):
        clearance = min(math.dist(point, threat.pos) for threat in threats)
        mid = tuple((a + b) / 2 for a, b in zip(here, point))
        if clearance > before + .3 and all(math.dist(mid, t.pos) >= before - .15 for t in threats):
            candidates.append((clearance, point))
    return max(candidates, default=(0, None))[1]


def facing(fighter, observed, state, holding, now):
    if observed is not None:
        state.pop("watch_yaw", None)
        return SimpleNamespace(syncpos=observed.pos)
    if not holding:
        state.pop("watch_yaw", None)
        return fighter
    center = state.setdefault("watch_yaw", state.get("guard_yaw", state.get("bot_facing", 0.0)))
    # A stationed defender periodically checks both sides of its lane.
    yaw = center + .65 * math.sin(now * 1.3 + fighter.roleid % 8)
    x, y, z = fighter.syncpos
    return SimpleNamespace(syncpos=(x + math.sin(yaw), y, z + math.cos(yaw)))
