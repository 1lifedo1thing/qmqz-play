"""生化模式 (gameMode 8) 的战斗逻辑.

官方实现的依据全部来自客户端自带的那套「假服务端」—— `ClientManager` 的
`IsBiochemMode` 分支和 `DataPool`：

    // DataPool
    public static bool IsBiochemMode => GameMode == 8;
    public static int BioLevel(PlayerData data)
    {
        int need = data.IsZombie ? rule.zombieExpNeed : rule.humanExpNeed;
        return need < 1 ? 0 : data.bioExp / need;
    }

    // ClientManager
    private static void Infected(int roleid, bool matrix)
    {
        if (matrix) { DataPool.MatrixRoleid = roleid; AudioTools.PlayAudio(10023); }
        PlayerData pd = DataPool.GetPlayerData(roleid);
        if (pd != null && !pd.IsZombie)      // 只感染「还不是僵尸」的
        {
            pd.side = 2;                     // 人类 = 1，僵尸 = 2
            pd.IsMatrix = matrix;
            pd.bioExp = 0;
        }
    }
    private static void FightResultByBioSide(int side)   // 1 = 人类胜, 2 = 僵尸胜

数值全部来自配置表，不自己编：

    GameRule(gameMode=8)  humanExpNeed=2  zombieExpNeed=2  infectTime=15
                          supplyTime=15   BoxIntervalTime=20
                          ammoBoxNum=3    bioBoxNum=3       round=5  roundTime=210
    BioProperty           母体用 mumHpBase，普通僵尸用 hpBase，hpPerCapita 按人头加
    BioSkill              狂暴/刚体/雾化 (+ 变异版)，cd 15s duration 5s
    Role(camp=3)          1001/1002/1011/1021 -> bioProperty + bioSkill
"""
from __future__ import annotations

import logging
import random
import time
from functools import lru_cache
from typing import Any, Dict, List, Optional, Set

from .. import gamedata
from ..net.server import ROUTER, Session
from . import rooms as R

log = logging.getLogger("crisisfire.biochem")

# 阵营：人类 1，僵尸 2（对齐 ClientManager.Infected 里 pd.side = 2）
SIDE_HUMAN = 1
SIDE_ZOMBIE = 2
FIRST_BOX_ID = 7001


class ID:
    SC_BIO_BOSS = 1441957
    SC_BIO_INFECTED = 1441958
    SC_BIO_EXP = 1441960
    SC_BIO_BOX_DROP = 1441961
    SC_BIO_BULLET_BOX_DROP = 1441962
    CS_BIO_USE_SKILL = 1441963
    SC_BIO_USE_SKILL_RES = 1441964
    SC_BIO_USE_SKILL_BRD = 1441965
    SC_BIO_PROTECT_LAYER = 1441966
    SC_BIO_ACC_DAMAGE = 1441967
    SC_BIO_KNIFE_KILL = 1441968
    SC_BIO_HERO = 1441970


# 人类保护层：客户端在 protect < 1 时播 10019（护盾破碎）
# 防化服只有 1 层：第一爪被防化服挡下（不掉血、播破盾音效），
# 第二爪才打到肉体 / 感染。原来是 3 层，等于「三下破盾 + 第四下才掉血」。
PROTECT_LAYER = 1
# 生化防化服道具 id（商城 Shop id=998 卖的那个，100 钻 / 7 天）。
# 【v46】用户口径：不再强制每局给真人发防化服，改成**买了才生效**。
PROTECT_SUIT_ITEM = 1003

_world = None


def bind_world(world) -> None:
    """拿到 world 才能查「这个玩家有没有买防化服」。"""
    global _world
    _world = world


def owns_protect_suit(roleid: int) -> bool:
    """这个真人有没有买过生化防化服（仓库里有 1003）。

    没绑 world（离线/单测）时退回旧行为（给），避免整套护盾凭空消失。
    """
    if _world is None:
        return True
    try:
        role = _world.role(int(roleid))
    except Exception:
        (log.debug("查防化服失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        return True
    if role is None:
        return False
    try:
        return int(PROTECT_SUIT_ITEM) in {
            int(i) for i in (role.data or {}).get("pkg_items", [])}
    except (TypeError, ValueError):
        return False


# 英雄战刀（英雄的专属近战）。近战击杀奖励防化服时**排除**它：英雄刀击杀
# 只负责永久禁复活，不给防化服；其余所有 equipPos=50 的近战武器都给。
HERO_MELEE_ID = 8001
# 每级加的血用 BioProperty.hpPlus；客户端也会自己按 hpmax += Δlevel * hpPlus
# 算一遍（ClientManager.Response(ScBioExp)），这里只负责把 exp 发对。


# 客户端 `Judger.IsBiochemistry(mode)` 认的是 **8 或 10**：
#   8  = 生化模式
#   10 = 生化英雄（GameMode.json 里 id=10、规则 11001~11004）
# 服务端原来只认 8，玩家选「生化英雄」时整个生化逻辑都不跑：
# 不选母体、不发 ScBioBoss/保护层、双方按普通模式分边 —— 但客户端仍然
# `IsBiochemMode == true`，会用 actor 的 camp 重新算 side（人类一律 1），
# 于是两个人都去抢同一个 police[0]，物理互相挤 → 穿模下坠 / 站到
# layer 2 的碰撞体上 300 帧后客户端自己 `GameUIFacade.onQuit()` 退出。
from . import bio_rules

BIOCHEM_MODES = (8, bio_rules.HERO_MODE)


def is_biochem(gamemode: Optional[int]) -> bool:
    return int(gamemode or 0) in BIOCHEM_MODES


def rule_of(room: R.Room) -> Dict[str, Any]:
    row = gamedata.rule(room.levelid) or {}
    return row if int(row.get("gameMode") or 0) in BIOCHEM_MODES else {}


def _prop(pid: int) -> Dict[str, Any]:
    for row in gamedata.table("BioProperty"):
        if int(row.get("id") or 0) == int(pid):
            return row
    return {}


def _role_row(actorid: int) -> Dict[str, Any]:
    for row in gamedata.table("Role"):
        if int(row.get("id") or 0) == int(actorid):
            return row
    return {}


def bio_property_of(actorid: int) -> Dict[str, Any]:
    """生化角色的 BioProperty（按 Role.bioProperty 查）。"""
    return _prop(int(_role_row(actorid).get("bioProperty") or 0))


def bio_skill_of(actorid: int) -> Dict[str, Any]:
    """生化角色的 BioSkill（按 Role.bioSkill 查）。"""
    want = int(_role_row(actorid).get("bioSkill") or 0)
    for row in gamedata.table("BioSkill"):
        if int(row.get("id") or 0) == want:
            return row
    return {}


def zombie_hp(actorid: int, players: int, matrix: bool) -> int:
    """母体 / 被感染者的血量**两套不同算法**。

    * 母体（``matrix=True``）—— ``mumHpBase + hpPerCapita × (人数-1)``，
      开局只有它一只，所以要按人头补强，10 人局大致 2750~3700。
    * 被感染者（``matrix=False``）—— 直接用 ``hpBase``，**不加人头系数**。
      人类是一个个被转化的，场上幽灵越多、每个越肉的话局面会失控；
      而且原版这里本来就该比母体薄一大截（800~1300 vs 2800~3700）。
    """
    p = bio_property_of(actorid)
    per = int(p.get("hpPerCapita") or 0)
    if matrix:
        base = int(p.get("mumHpBase") or 0)
        if not base:
            base = int(p.get("hpBase") or 1500)
        return base + per * max(0, players - 1)
    return int(p.get("hpBase") or 0) or 800


def bio_level(bio_exp: int, is_zombie: bool, rule: Dict[str, Any]) -> int:
    """等级 = 经验 / 每级所需。

    【狂暴版】**取消等级上限**（原来封顶 humanMaxLv=10 / zombieMaxLv=5）。
    现在人类士气、僵尸血量等级都能无限叠加，配合「终极生化」按对方人数补级
    就能滚起来。客户端 BioLevelBar 是拿 exp 自己算等级的，所以经验值本身
    也不再截断，UI 会跟着显示真实等级。
    """
    need = int(rule.get("zombieExpNeed" if is_zombie else "humanExpNeed") or 0)
    if need < 1:
        return 0
    return max(0, int(bio_exp)) // need


def level_cap_exp(bio_exp: int, is_zombie: bool,
                  rule: Dict[str, Any]) -> int:
    """【狂暴版】不再封顶 —— 原样返回经验值（保留函数名，调用方无需改动）。"""
    return max(0, int(bio_exp))


@lru_cache(maxsize=8)
def _box_positions(scene: str) -> tuple:
    """Supply locations on walkable ground around this map's spawn groups."""
    from . import geometry, human
    from .battle import _spawnpoints

    nav = geometry.grid_for_scene(scene)
    if nav is None:
        return ()
    table = _spawnpoints().get(scene) or {}
    positions = {}
    for side in ("police", "terrist"):
        for authored in table.get(side, ()):
            spawn = geometry.spawn_ground(scene, tuple(authored[:3]))
            if spawn is None:
                continue
            for candidate in [spawn] + human.nav_candidates(nav, spawn, 3.0, 12.0):
                ground = nav.ground(candidate)
                if ground is None:
                    continue
                p = tuple(round(v * 100) for v in ground)
                if p in positions:
                    continue
                wire_ground = tuple(v / 100 for v in p)
                if nav.scene.stand_clear(wire_ground) and human._same_component(nav, spawn, wire_ground):
                    positions[p] = None
    return tuple(positions)


# --------------------------------------------------------------------------
# 一场生化战斗
# --------------------------------------------------------------------------
class Biochem:
    """挂在 Battle 上的生化状态机。

    人类 = side 1，僵尸 = side 2。开局随机一名玩家当母体（matrix），
    之后僵尸「杀死」人类就把他转化成僵尸。
    """

    def __init__(self, battle) -> None:
        self.battle = battle
        self.rule = rule_of(battle.room)
        # 【v17】补给箱统一口径：双方上限 6 个、刷新间隔 10 秒。
        # 覆盖的是副本 —— rule_of() 返回 gamedata 里的共享行，直接改会
        # 污染别的房。刷新时机（感染瞬间 force + 独立计时器）保持不动。
        from ..config import CONFIG as _C
        _r = dict(self.rule)
        try:
            _lim = int(getattr(_C, "biochem_box_limit", 6) or 0)
            _itv = float(getattr(_C, "biochem_box_interval", 10) or 0)
        except (TypeError, ValueError):
            _lim, _itv = 6, 10.0
        if _lim > 0:
            _r["bioBoxNum"] = _lim
            _r["ammoBoxNum"] = _lim
        if _itv > 0:
            _r["BoxIntervalTime"] = _itv
            _r["supplyTime"] = _itv
        self.rule = _r
        self.matrix: int = 0                  # 母体 roleid
        self.matrices: Set[int] = set()
        self.zombies: Set[int] = set()
        self.eliminated: Set[int] = set()
        self.hero: int = 0                    # 生化英雄（人类阵营的核心）
        self.bio_exp: Dict[int, int] = {}     # roleid -> bioExp
        self.protect: Dict[int, int] = {}     # roleid -> 保护层
        self.skill_cd: Dict[int, float] = {}  # roleid -> 技能就绪时刻
        # 【v15】roleid -> 本回合「对幽灵累计伤害」的余数，用来触发重创图标。
        self.acc_damage: Dict[int, int] = {}
        # 【v49】「重创」图标冷却时间戳：roleid -> 上次发包的 time.time()
        self.acc_cd: Dict[int, float] = {}
        # roleid -> (过期时刻, 技能行)。四个幽灵的技能原来只播了特效广播、
        # 服务端裁决完全不认，所以「刚体减伤」等对服务端伤害无效。
        self.skill_active: Dict[int, Any] = {}
        self.boxes: List[Dict[str, Any]] = []
        # 【v17】本回合全图补给箱候选点（每局重新随机，见 _box_points）。
        self.box_points = None
        # Keep IDs unique across rounds so a delayed pickup cannot claim a new box.
        if not hasattr(battle, "next_bio_box_id"):
            battle.next_bio_box_id = FIRST_BOX_ID
        self._box_timer = 0.0
        # 弹药箱有自己的间隔（GameRule.supplyTime），和生化箱的
        # BoxIntervalTime 不是同一个值，不能共用一个计时器。
        self._ammo_timer = 0.0
        self._bot_actors: List[int] = []
        # 人类英雄（ScBioHero）。空集合 = 本回合还没出现英雄。
        self.heroes: Set[int] = set()
        self.hero_awakened = False
        self.started_at = 0.0
        self.infect_deadline = 0.0            # 感染倒计时（rule.infectTime）
        self.winner: int = 0
        # begin() 只能跑一次：如果被 start_round / _prepare_expired 重复调用，
        # 会**选两次母体** —— 2 人房直接变成「两只幽灵、0 个人类」。
        self.begun: bool = False
        self.infection_started: bool = False
        # 正在「选僵尸角色」的人（客户端 ZombieSelectWindow 还没点开始）
        self.pending: Set[int] = set()
        self._pick_timers: Dict[int, Any] = {}
        # 「被击杀后复活」的选僵尸角色，与感染选角（self.pending）分开：
        # 感染是原地变僵尸 -> 原地出生；被击杀是从出生点重新出生。
        # 两者都要能选生化角色，但**出生位置完全不同**，不能混用一套流程。
        self.relive_picks: Set[int] = set()
        # 被**近战武器**打死的幽灵禁止复活（只能等下一回合）。
        # 原版这条规则是用来克制「贴脸拿刀砍僵尸」的刷分流派的。
        self.no_relive: Set[int] = self.eliminated
        # 【狂暴版】终极对决时刻起，僵尸爪击的**平点数**加伤（不是百分比）：
        #   普通僵尸 = 每个存活人类 +30 点，母体 = 查表（300/400/.../4600）
        self.zombie_dmg_bonus: float = 0.0     # 旧字段（已不参与结算）
        self.zombie_dmg_flat: float = 0.0      # 普通僵尸
        self.matrix_dmg_flat: float = 0.0      # 母体

    # -- 查询 ------------------------------------------------------------
    def is_zombie(self, roleid: int) -> bool:
        return roleid in self.zombies

    def is_matrix(self, roleid: int) -> bool:
        return roleid in self.matrices

    def side_of(self, roleid: int) -> int:
        return SIDE_ZOMBIE if self.is_zombie(roleid) else SIDE_HUMAN

    def humans(self) -> List[int]:
        return [roleid for roleid in self.battle.fighters
                if roleid not in self.zombies and roleid not in self.eliminated]

    def zombie_list(self) -> List[int]:
        return sorted(self.zombies)

    def exp_of(self, roleid: int) -> int:
        """经验值本身也封顶到满级所需 —— 客户端 BioLevelBar 是拿 exp 自己
        算等级的，光在 bio_level() 里 clamp 挡不住 UI 溢出到 12 级。"""
        raw = int(self.bio_exp.get(roleid) or 0)
        return level_cap_exp(raw, self.is_zombie(roleid), self.rule)

    def level_of(self, roleid: int) -> int:
        return bio_level(self.exp_of(roleid), self.is_zombie(roleid), self.rule)

    def human_attack_bonus(self, roleid: int) -> int:
        # Local formula matching the flat bonus displayed by BioLevelBar.
        maximum = int(self.rule["humanMaxLv"])
        return min(self.level_of(roleid), maximum) * int(self.rule["humanAtkPerLv"])

    # -- 开局 ------------------------------------------------------------
    def begin(self) -> None:
        """选母体、发保护层、起感染倒计时。"""
        from ..config import CONFIG
        if getattr(self, "begun", False):
            log.warning("biochem begin() 重复调用，忽略（避免选出第二只母体）")
            return
        ids = list(self.battle.fighters)
        if not ids:
            return
        self.begun = True
        self.started_at = time.time()
        self.infect_deadline = self.started_at + max(0, int(self.rule.get("infectTime") or 0))

        # 人数门槛：客户端只认 CurrentRoom.IsFull（playerlimits == 人数），
        # 所以 rooms._player_limits 把生化房的 playerlimits 设成了
        # CONFIG.biochem_min_players（默认 2，官方 roomMinTeamer 是 8）。
        # 这里按**有效门槛**判断，否则按官方的 8 会每局误报。
        need = int(getattr(self.battle.room, "playerlimits", 0) or 0)
        if need and len(ids) < need:
            log.warning("biochem room %s 只有 %d 人（门槛 %d），开局人数不足",
                        self.battle.room.roomid, len(ids), need)
        elif len(ids) < 8:
            (log.info("biochem room %s: %d 人开局（官方 8 人，僵尸血量按人头加成会偏弱）",
                     self.battle.room.roomid, len(ids)) if log.isEnabledFor(20) else None)

        (log.info("BIO-PHASE waiting room=%s infect_delay=%ss", self.battle.room.roomid,
                 max(0, int(self.rule.get("infectTime") or 0))) if log.isEnabledFor(20) else None)
        if self.infect_deadline <= self.started_at:
            self._activate_infection()

    def _activate_infection(self) -> None:
        if self.infection_started or self.winner:
            return
        from ..config import CONFIG
        ids = [rid for rid, f in self.battle.fighters.items() if f.born and f.hp > 0]
        if not ids:
            return
        want = int(getattr(CONFIG, "biochem_matrix_role", 0) or 0)
        mothers = bio_rules.select_mothers(ids, self.battle.room.gamemode, want)
        if not mothers:
            return
        self.infection_started = True
        self.matrix = mothers[0]
        self.matrices.update(mothers)
        for roleid in mothers:
            self._make_zombie(roleid, matrix=True, announce_boss=True)
        for roleid in mothers:
            self.request_pick(roleid)
        from . import bots as _bots
        _protect_chance = float(getattr(CONFIG, "biochem_protect_chance", 1.0) or 0.0)
        for rid in ids:
            if rid in self.zombies:
                continue
            # 没抽中 / 没买的都明确回一条 0，否则会残留上一局的护盾。
            # 【v46】真人**不再白送**：仓库里有「生化防化服(1003)」才给护盾；
            # bot 维持原来的概率（bot 不会买东西，砍光会让局面失衡）。
            if _bots.is_bot(rid):
                _layers = PROTECT_LAYER if random.random() < _protect_chance else 0
            else:
                _layers = PROTECT_LAYER if owns_protect_suit(rid) else 0
            self.protect[rid] = _layers
            self.battle.send_all(ID.SC_BIO_PROTECT_LAYER, roleid=rid,
                                 protect=_layers, attackid=0)
            self.bio_exp.setdefault(rid, 0)
        (log.info("BIO-PHASE active room=%s matrices=%s humans=%s",
                 self.battle.room.roomid, mothers, len(self.humans())) if log.isEnabledFor(20) else None)
        (log.info("BIO-PROTECT room=%s 防化服发放率=%.2f 有盾=%s",
                 self.battle.room.roomid, _protect_chance,
                 sum(1 for r in ids if self.protect.get(r, 0) > 0)) if log.isEnabledFor(20) else None)
        (log.info("BIO-PHASE active room=%s matrix=%s humans=%s",
                 self.battle.room.roomid, self.matrix, len(self.humans())) if log.isEnabledFor(20) else None)
        self._tick_boxes(force=True)

    # -- 选僵尸角色 ------------------------------------------------------
    @staticmethod
    def is_zombie_actor(actorid: int) -> bool:
        """这个 actorid 是不是僵尸角色（Role.camp == 3）。"""
        return int(_role_row(int(actorid)).get("camp") or 0) == 3

    @staticmethod
    def default_actor() -> int:
        """兜底僵尸角色：Role.camp == 3 的第一个（1001 生化幽灵）。"""
        return next(iter(bio_rules.zombie_choices()), 0)

    def request_pick(self, roleid: int) -> None:
        """让这个玩家去「选僵尸角色」。

        客户端的完整链路（反编译确认）：

            ScBornPrepare(remaintime)
              -> ClientManager.Prepare(remaintime)
                 -> SetupEquipWindow(remaintime)
                    -> DataPool.IsHeroZombie ? GameUIFacade.ShowZombieSelect()
                                             : GameUIFacade.ShowEquip()

        所以这条 ScBornPrepare **只能发给本人** —— 广播会让所有人类也重新
        弹选装备界面。玩家点了「开始」之后客户端会发

            CsChooseEquip(0, <僵尸角色 actorid>, {})      // equipmap 是空字典

        服务端在 `Battle.on_choose_equip` 里认出这个分支（`f.roleid in
        self.pending`），把他的 actorid 换成僵尸角色再重新 ScBorn。
        """
        from . import battle as _battle
        if roleid not in self.battle.fighters or roleid in self.eliminated or roleid in self.pending:
            return
        from . import bots
        if bots.is_bot(roleid):
            # Bots cannot interact with ZombieSelectWindow. Recreate their model now.
            self.pending.discard(roleid)
            if not self._bot_actors:
                self._bot_actors = list(bio_rules.zombie_choices())
                random.shuffle(self._bot_actors)
            actor = self._bot_actors.pop() if self._bot_actors else self.default_actor()
            import asyncio
            self.pending.add(roleid)
            self._pick_timers[roleid] = asyncio.get_event_loop().call_later(
                bio_rules.BOT_MORPH_TIME, self._pick_timeout, roleid, actor)
            return
        self.pending.add(roleid)
        self.battle.send_to_role(roleid, _battle.ID.SC_BORN_PREPARE,
                                 remaintime=_battle.PREPARE_TIME)
        import asyncio
        old = self._pick_timers.pop(roleid, None)
        if old is not None:
            try:
                old.cancel()
            except Exception:
                pass
        try:
            loop = asyncio.get_event_loop()
            self._pick_timers[roleid] = loop.call_later(
                float(_battle.PREPARE_TIME), self._pick_timeout, roleid)
        except Exception:
            (log.debug("无法安排选僵尸超时 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)

    def relive_pick(self, roleid: int) -> None:
        """「被击杀后复活」让玩家选生化角色 —— **不复用感染的 request_pick**。

        感染那条路会 `force_born_zombie(... position=f.syncpos)` 原地出生，
        还会排一个 45 秒的 `_pick_timeout` 把人强生成默认幽灵；击杀后复活
        必须回**出生点**，超时由 Battle._relive_born 兜底。
        这里只做两件事：把 roleid 放进 pending（让 CsChooseEquip 被识别成
        「选僵尸角色」）、发 ScBornPrepare（让客户端弹选角窗口）。
        """
        if roleid not in self.battle.fighters:
            return
        from . import bots
        if bots.is_bot(roleid):
            return
        from . import battle as _battle
        self.pending.add(roleid)
        self.relive_picks.add(roleid)
        self.battle.send_to_role(roleid, _battle.ID.SC_BORN_PREPARE,
                                 remaintime=_battle.PREPARE_TIME)

    def cancel_picks(self) -> None:
        """取消所有「选僵尸」定时器并清空 pending。

        回合结束时必须调用：否则上一回合感染时排的 20 秒超时会活到下一回合，
        在 `round_over` 被重置后触发 `force_born_zombie`，把本来是人类的人
        生成成第二只幽灵（实测「下一局两只幽灵、0 个人类」）。
        """
        for t in list(self._pick_timers.values()):
            try:
                t.cancel()
            except Exception:
                pass
        self._pick_timers.clear()
        self.pending.clear()
        self.relive_picks.clear()
        # 【v49】重创图标的累计与冷却跟着回合一起清，新回合第一发不受上一局冷却影响
        try:
            self.acc_damage.clear()
            self.acc_cd.clear()
        except AttributeError:
            pass

    def _pick_timeout(self, roleid: int, actor=0) -> None:
        self._pick_timers.pop(roleid, None)
        # 这个 Biochem 已经被下一回合替换掉了：定时器作废
        # （fake battle 可能没有 biochem 字段，那种情况照常执行）
        current = getattr(self.battle, "biochem", None)
        if current is not None and current is not self:
            return
        if roleid not in self.pending:
            return
        self.pending.discard(roleid)
        if self.battle.round_over or self.battle.fight_over:
            return
        fighter = self.battle.fighters.get(roleid)
        if fighter is None or roleid in self.eliminated:
            return
        if actor not in bio_rules.zombie_choices():
            actor = fighter.actorid if fighter.actorid in bio_rules.zombie_choices() else self.default_actor()
        (log.info("biochem %s 选僵尸超时，用默认僵尸角色 %s 出生", roleid, actor) if log.isEnabledFor(20) else None)
        self.battle.force_born_zombie(roleid, actor)
    def refresh_hp(self, roleid: int) -> int:
        """按**当前僵尸角色**重算血量上限。

        `_make_zombie` 是在 actorid 还没换成僵尸角色时跑的（人变僵尸那一刻
        身上还是人类角色 101，`bio_property_of(101)` 查不到 BioProperty，会掉进
        `or 1500` 的兜底）。客户端是等 ScBorn 带上真正的僵尸 actor 之后，自己按
        `mumHpBase + hpPerCapita*(人数-1)` 算上限的 —— 实测 12 人局服务端发 1500、
        客户端显示 3300，两边差 2.2 倍，服务端会把僵尸提前判死。
        所以僵尸角色一旦定下来（选人 / 超时兜底）就要在这里补算一次。
        """
        # 【v8】复活/重生时技能立刻可用（不做冷却倒计时）。
        self.skill_cd.pop(int(roleid), None)
        f = self.battle.fighters.get(roleid)
        if f is None or roleid not in self.zombies:
            return 0
        actor = int(getattr(f, "actorid", 0) or 0)
        hp = zombie_hp(actor, len(self.battle.fighters), self.is_matrix(roleid))
        # 幽灵 BOT 血量系数（与 battle.born 保持一致，别选完角色又掉回去）
        try:
            from . import bots as _bots
            if _bots.is_bot(roleid):
                from ..config import CONFIG as _cfg
                hp = int(hp * max(0.1, float(getattr(
                    _cfg, "biochem_bot_hp_scale", 1.0) or 1.0)))
        except Exception:
            pass
        # 死亡重生后保留等级血量：等级越高，血量越厚。
        # 客户端 BioLevelBar 显示「LV.X 生命值+{X*hpPlus}」，Service 端
        # 原来重生只按 hpBase 设血，没把 level×hpPlus 加回来 —— 结果
        # 僵尸升级后一死，血量又掉回基础值。
        prop = bio_property_of(actor)
        hp_plus = int(prop.get("hpPlus") or 0)
        lv = self.level_of(roleid)
        if hp_plus > 0 and lv > 0:
            hp += hp_plus * lv
        f.hp = float(hp)
        f.hp_max = float(hp)
        (log.info("biochem role %s 僵尸血量按 actor=%s 重算 -> %s (matrix=%s, lv=%s)",
                 roleid, actor, hp, self.is_matrix(roleid), lv) if log.isEnabledFor(20) else None)
        return hp

    def _make_zombie(self, roleid: int, matrix: bool, announce_boss: bool) -> None:
        if roleid in self.zombies:
            return
        self.zombies.add(roleid)
        f = self.battle.fighters.get(roleid)
        if f is not None:
            # 对齐 ClientManager.Infected：side 改成 2、经验清零
            f.side = SIDE_ZOMBIE
            # Infected removes the visible model. A pending actor cannot act.
            f.born = False
            f.weaponpos = 50
            # 变僵尸后不再有护甲（客户端也不给僵尸算 ac）
            f.ac = 0.0
            # 幽灵**任何时候都没有出生无敌**：母体、被感染者、复活都一样。
            # 否则变僵尸后带着免伤还能抓人，人类完全打不动。
            try:
                f.no_inv_once = True
            except Exception:
                pass
        self.bio_exp[roleid] = 0
        self.protect.pop(roleid, None)
        # 【v8】被感染 / 被选为母体的这一刻，技能立刻可用（用户要求）。
        self.skill_cd.pop(int(roleid), None)
        # 此刻 actorid 往往还是人类角色，先按"将要用的僵尸角色"算，
        # 等真正的僵尸 actor 定下来后由 refresh_hp() 再补算一次。
        f2 = self.battle.fighters.get(roleid)
        hp = None
        if f2 is not None:
            actor = int(getattr(f2, "actorid", 0) or 0)
            if not self.is_zombie_actor(actor):
                actor = self.default_actor() or actor
            hp = zombie_hp(actor, len(self.battle.fighters), matrix)
            f2.hp = float(hp)
            f2.hp_max = float(hp)
        self.battle.send_all(
            ID.SC_BIO_BOSS if (matrix and announce_boss) else ID.SC_BIO_INFECTED,
            roleid=roleid)
        (log.info("biochem %s -> 僵尸 (matrix=%s, hp=%s)", roleid, matrix, hp) if log.isEnabledFor(20) else None)

    # -- 感染 ------------------------------------------------------------
    def infect(self, victimid: int, killerid: int = 0) -> bool:
        """把人类变成僵尸。返回是否真的转化了。"""
        if victimid in self.zombies:
            return False
        f = self.battle.fighters.get(victimid)
        if f is None:
            return False
        self._make_zombie(victimid, matrix=False, announce_boss=False)
        # 英雄被感染 -> 从名单里摘掉并重发 ScBioHero，客户端才会清掉
        # 「英雄出现」的 UI（heros 为空时 Response 直接 return，但会先
        # DataPool.BioHeros.Clear()）。
        heroes = getattr(self, "heroes", None)
        if heroes is not None and victimid in heroes:
            heroes.discard(victimid)
            self.battle.send_all(ID.SC_BIO_HERO, heros=sorted(heroes))
        # 被感染的人同样要走「选僵尸角色」，否则在别人眼里他的模型已经被
        # Infected() 删掉了，永远回不来。
        self.request_pick(victimid)
        # 感染者拿经验（rule.infectHumanExp）
        if killerid and killerid in self.zombies:
            self.add_exp(killerid, int(self.rule.get("infectHumanExp") or 0))
        self._maybe_heroes(after_infection=True)
        # 士气：场上少了一个人类，其余活着的人类各涨 N 级
        self._morale_on_infect(victimid)
        self.check_win()
        return True

    def hero_down(self, victimid: int, killerid: int = 0,
                  weaponid: int = 0) -> None:
        """【狂暴版】人类英雄被僵尸击杀：直接死亡 → 观战，本回合不复活。

        原版英雄被抓只会变成僵尸；现在英雄是「人类最后的希望」，
        死了就真的出局：从 heroes 名单摘掉（客户端清英雄 UI）、
        进 no_relive（请求复活会被挡）、血量归零、born=False，
        再补一条 ScKill 让全场看到击杀播报。
        """
        victimid = int(victimid)
        heroes = getattr(self, "heroes", None)
        if heroes is not None and victimid in heroes:
            heroes.discard(victimid)
            self.battle.send_all(ID.SC_BIO_HERO, heros=sorted(heroes))
        self.no_relive.add(victimid)
        f = self.battle.fighters.get(victimid)
        if f is not None:
            f.hp = 0.0
            f.born = False
            try:
                f.dead_at = time.time()
            except (TypeError, ValueError):
                pass
        # 击杀播报：weaponid 必须是真实武器 id，否则客户端落到骷髅图标
        wid = int(weaponid or 0)
        try:
            from . import battle as _battle
            if wid <= 0:
                wid = _battle._main_weapon_of(self.battle.fighters.get(int(killerid)))
            self.battle.send_all(_battle.ID.SC_KILL, roleid=victimid,
                                 killerid=int(killerid), weaponid=wid,
                                 killtype=0, combokill=0)
        except Exception:
            (log.debug("英雄击杀播报失败", exc_info=True) if log.isEnabledFor(10) else None)
        (log.info("biochem 英雄 %s 被 %s 击杀 -> 直接出局（观战）",
                 victimid, killerid) if log.isEnabledFor(20) else None)
        self.check_win()

    def _morale_on_infect(self, victimid: int) -> None:
        """有人类被感染 -> 其余存活人类 +N 级士气（CF_BIOCHEM_INFECT_MORALE）。"""
        from ..config import CONFIG
        levels = int(getattr(CONFIG, "biochem_infect_morale_levels", 1) or 0)
        need = int(self.rule.get("humanExpNeed") or 0)
        if levels <= 0 or need <= 0:
            return
        for rid, f in list(self.battle.fighters.items()):
            if rid == victimid or not getattr(f, "born", False):
                continue
            if float(getattr(f, "hp", 0.0) or 0.0) <= 0 or self.is_zombie(rid):
                continue
            self.add_exp(rid, need * levels)
            (log.info("biochem %s 被感染 -> 人类 %s 士气 +%s 级", victimid, rid,
                     levels) if log.isEnabledFor(20) else None)

    def add_exp(self, roleid: int, amount: int) -> None:
        """加生化经验并发 ScBioExp（客户端据此算等级、加血、播升级音效）。"""
        if amount <= 0:
            return
        before = self.level_of(roleid)
        cap = level_cap_exp(self.exp_of(roleid) + int(amount),
                            self.is_zombie(roleid), self.rule)
        self.bio_exp[roleid] = cap
        after = self.level_of(roleid)
        self.battle.send_all(ID.SC_BIO_EXP, roleid=roleid,
                             exp=self.exp_of(roleid), starscore=0)
        if after > before:
            # **活着升级要实时加血。**
            # 客户端 ScBioExp 只做 `hpmax += Δlevel * hpPlus`，当前 hp 不动，
            # 所以玩家看到「等级提升，生命值增加！」但血条数字不涨 ——
            # 只有吃补血箱（走 ScAddHp）才涨。这里服务端同步加 hp_max/hp，
            # 并补一条 ScAddHp 让客户端当前血量一起涨。
            self._apply_level_hp(roleid, after - before)
            (log.info("biochem %s 升到 %s 级 (exp=%s)", roleid, after,
                     self.exp_of(roleid)) if log.isEnabledFor(20) else None)

    def _apply_level_hp(self, roleid: int, levels: int) -> None:
        """幽灵升级时把 Δlevel × hpPlus 实时加到服务端的 hp_max / hp 上。

        **hpPlus 必须和客户端 BioProperty 表里的值完全一致。**
        客户端的加血是 `ClientManager.Response(ScBioExp)` 里自己算的：

            playerData.hpmax += (newLv - oldLv) * playerData.Property.hpPlus;

        它读的是客户端资源包里的表，不是服务端的 gamedata。只要两边 hpPlus
        不一致，服务端的血量上限就会和客户端血条对不上 —— 症状就是
        「血条已经空了却打不死（服务端还剩几百血）」和「吃箱子血不涨
        （客户端已经被自己的 hpmax 顶住了）」。

        所以这里**只按角色自己的 hpPlus 加**，查不到就不加（人类角色
        bioProperty=0，客户端 Property 也是 null，本来就不加）。
        """
        levels = int(levels or 0)
        if levels <= 0 or not self.is_zombie(roleid):
            return
        f = self.battle.fighters.get(roleid)
        if f is None or float(getattr(f, "hp", 0) or 0) <= 0:
            return
        prop = bio_property_of(int(getattr(f, "actorid", 0) or 0))
        hp_plus = int(prop.get("hpPlus") or 0)
        if hp_plus <= 0:
            # 还没选僵尸角色（actorid 仍是人类角色）时客户端也没有
            # Property，不会加 hpmax —— 服务端同样不加，保持同步。
            return
        gain = float(hp_plus * levels)
        try:
            old_max = float(getattr(f, "hp_max", 0) or 0) or float(f.hp)
            f.hp_max = old_max + gain
            before_hp = float(f.hp)
            f.hp = min(f.hp_max, before_hp + gain)
            real = max(0.0, float(f.hp) - before_hp)
        except (TypeError, ValueError):
            return
        if real <= 0:
            return
        try:
            from . import battle as _battle
            self.battle.send_all(_battle.ID.SC_ADD_HP,
                                 roleid=int(roleid), addhp=float(real))
        except Exception:
            (log.debug("幽灵升级实时加血广播失败 role=%s", roleid,
                      exc_info=True) if log.isEnabledFor(10) else None)
        (log.info("biochem %s 升级实时加血 +%s -> %.0f/%.0f (hpPlus=%s)",
                 roleid, real, f.hp, f.hp_max, hp_plus) if log.isEnabledFor(20) else None)

    def heal_full(self, roleid: int, reason: str = "") -> float:
        """把（幽灵的）血量补满，并把差额用 ScAddHp 推给客户端。

        客户端捡起生化箱时是**本地**执行 `playerData.Damage(-1000, -acmax, 0)`
        —— 直接把血补到 hpmax。服务端原来只发经验、不动血，两边立刻错位：
        客户端是满血、服务端还是残血，之后就会「血条空了却打不死」。
        所以服务端必须在同一时刻把 hp 顶到 hp_max。
        """
        f = self.battle.fighters.get(int(roleid))
        if f is None:
            return 0.0
        cap = float(getattr(f, "hp_max", 0) or 0)
        before = float(getattr(f, "hp", 0) or 0)
        if cap <= 0 or before >= cap:
            return 0.0
        f.hp = cap
        gain = cap - before
        try:
            from . import battle as _battle
            self.battle.send_all(_battle.ID.SC_ADD_HP,
                                 roleid=int(roleid), addhp=float(gain))
        except Exception:
            (log.debug("补满血广播失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        (log.info("biochem %s 补满血 %+.0f -> %.0f/%.0f (%s)",
                 roleid, gain, f.hp, cap, reason) if log.isEnabledFor(20) else None)
        return gain

    def heal_amount(self, roleid: int, amount: float,
                    reason: str = "") -> float:
        """【v20】按固定量回血，**硬 clamp 到 hp_max**。

        用户：「英雄拾取补给箱加血记得不能超过上限」。客户端 SC_ADD_HP
        是做加法的，服务端发多少它就加多少；所以差额必须在服务端先算好，
        否则英雄 hp_max=5000 时会被顶到 6500，之后血条和伤害全乱。
        """
        f = self.battle.fighters.get(int(roleid))
        if f is None:
            return 0.0
        cap = float(getattr(f, "hp_max", 0) or 0)
        before = float(getattr(f, "hp", 0) or 0)
        if cap <= 0 or before >= cap:
            return 0.0
        gain = max(0.0, min(float(amount), cap - before))
        if gain <= 0:
            return 0.0
        f.hp = before + gain
        try:
            from . import battle as _battle
            self.battle.send_all(_battle.ID.SC_ADD_HP,
                                 roleid=int(roleid), addhp=float(gain))
        except Exception:
            (log.debug("补量血广播失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        (log.info("biochem %s 补血 %+.0f -> %.0f/%.0f (%s)",
                 roleid, gain, f.hp, cap, reason) if log.isEnabledFor(20) else None)
        return gain

    def on_kill(self, killerid: int, victimid: int, knife: bool = False,
                weaponid: int = 0) -> None:
        """击杀事件。生化模式下僵尸杀人 = 感染，不是死亡。"""
        kz, vz = self.is_zombie(killerid), self.is_zombie(victimid)
        if kz and not vz:
            # 僵尸抓人类 = 感染。刀杀提示（ScBioKnifeKill）属于「人类刀幽灵」，
            # 原来发在这里是反的 —— 客户端播的是「幽灵刀人」的字样。
            self.infect(victimid, killerid)
            return
        if not vz:
            return
        # 走到这里死者一定是幽灵：被人类打死，或者被另一只幽灵打死。
        if killerid and killerid != victimid:
            self.add_exp(killerid, int(self.rule.get("killZombieExp") or 0))
        # 英雄刀（人类英雄的专属近战）击杀幽灵：永久禁止复活（本回合）。
        # 单独判断，不依赖 knife 参数是否正确（英雄的 weaponpos 可能还没切到 50，
        # 导致 `_is_melee(weaponid)` 误判为枪杀，从而漏掉禁复活）。
        is_hero = killerid in (getattr(self, "heroes", None) or set())
        if (knife and not kz) or (is_hero and not kz):
            # 人类用近战武器打死幽灵：播提示 + 本回合禁止复活。
            self.no_relive.add(int(victimid))
            self.battle.send_all(ID.SC_BIO_KNIFE_KILL, roleid=killerid,
                                 killedid=victimid)
            (log.info("biochem %s 被 %s 近战击杀，本回合禁止复活 (hero=%s)",
                     victimid, killerid, is_hero) if log.isEnabledFor(20) else None)
        # 人类用**非英雄刀的近战武器**击杀幽灵 -> 奖励 1 层防化服（上限 1 层）。
        # 英雄刀（8001 英雄战刀）不计入，其余所有 equipPos=50 的近战武器
        # （匕首、商城各款刀）都算。只给真人（BOT 无 protect 显示概念）。
        if knife and not kz and not is_hero and int(weaponid or 0) != HERO_MELEE_ID:
            try:
                from . import bots as _bots
                if not _bots.is_bot(int(killerid)):
                    self.grant_protect(int(killerid))
            except Exception:
                (log.debug("近战击杀奖励防化服失败 killer=%s", killerid,
                          exc_info=True) if log.isEnabledFor(10) else None)
        self._grow_on_zombie_death(victimid)
        # **幽灵被击杀后必须判胜**：原来 check_win() 只在 infect() 里调，
        # 结果「人类全被感染」能结算、「幽灵全被砍死」永远不结算。
        self.check_win()

    def grant_protect(self, roleid: int) -> None:
        """给人类 +1 层防化服，上限 1 层，已有则不动。"""
        cur = int(self.protect.get(roleid) or 0)
        if cur >= PROTECT_LAYER:
            return
        self.protect[roleid] = PROTECT_LAYER
        self.battle.send_all(ID.SC_BIO_PROTECT_LAYER, roleid=roleid,
                             protect=PROTECT_LAYER, attackid=0)
        (log.info("biochem %s 近战击杀奖励防化服 +%s", roleid, PROTECT_LAYER) if log.isEnabledFor(20) else None)

    def can_relive(self, roleid: int) -> bool:
        """这个幽灵本回合还能不能复活（被近战击杀的不行）。"""
        return int(roleid) not in self.no_relive

    def _grow_on_zombie_death(self, roleid: int) -> None:
        """幽灵每死亡一次 **涨** 经验（永久，不清空、不扣）。

        原来这里是 `_deduct_on_zombie_death`：按 GameRule.zombieDieDeductExp=4
        往**下**扣，正好扣掉一整级 —— 死一次掉一级，越打越弱，和官方
        「幽灵死得越多越强」完全相反。

        现在：普通幽灵 +1 点、母体 +2 点（1 级 = zombieExpNeed = 4 点）。
        """
        from ..config import CONFIG
        if self.is_matrix(roleid):
            gain = int(getattr(CONFIG, "biochem_matrix_death_exp", 2) or 0)
        else:
            gain = int(getattr(CONFIG, "biochem_zombie_death_exp", 1) or 0)
        if gain > 0:
            self.add_exp(roleid, gain)
            (log.info("biochem %s 死亡 -> 经验 +%s (lv=%s)", roleid, gain,
                     self.level_of(roleid)) if log.isEnabledFor(20) else None)

    # -- 保护层 ----------------------------------------------------------
    def damage_protect(self, roleid: int, attackid: int = 0) -> bool:
        """消耗一层保护。返回 True 表示这次攻击被护盾挡下。"""
        cur = int(self.protect.get(roleid) or 0)
        if cur <= 0:
            return False
        cur -= 1
        self.protect[roleid] = cur
        from . import room_ai
        room_ai.note_attack(self.battle, self.battle.fighters.get(attackid), (roleid,))
        self.battle.send_all(ID.SC_BIO_PROTECT_LAYER, roleid=roleid,
                             protect=cur, attackid=attackid)
        # 【v15】这里原来多发了一条 ScBioAccDamage(roleid=被破盾的人)。
        # 反编译确认客户端 `ClientManager.Response(ScBioAccDamage)` 是
        #     if (DataPool.IsHero(damage.roleid))
        #         Notice_Private(PrivateKillNotice.Type.Blow)   // 「重创」图标
        # 于是「防化服被击破」反而弹出「重创1000」，而真正对幽灵打满伤害时
        # 却没人发这条协议。破盾图标由 ScBioProtectLayer 自己负责：
        # `protection > 0 && protection < 1` -> 10019 + Type.Shield（英雄则 603）。
        # 所以这里什么都不用发。
        return True

    def note_zombie_damage(self, attackerid: int, amount: float) -> None:
        """累计「人类打幽灵」的伤害，每满一档发一次 ScBioAccDamage。

        客户端只在本机 roleid 匹配时显示「重创」图标，所以 roleid 必须是
        **攻击者本人**，不是被打的那只幽灵。一次结算最多发一条（哪怕这一发
        伤害就超过好几档），否则会连弹好几个图标。

        【v49】再加一道**全局冷却**：图标本体要 1.8s 才播完，冷却期内
        （默认 2.0s）打出的伤害直接丢弃、不累计 —— 用户口径「等图标显示完
        才做下次判定」。`CF_BIO_ACC_DMG_CD=0` 可退回 v15 的逐发判定。
        """
        if amount <= 0:
            return
        from ..config import CONFIG
        try:
            step = int(getattr(CONFIG, "biochem_acc_damage_step", 1000) or 0)
        except (TypeError, ValueError):
            step = 1000
        if step <= 0:
            return
        rid = int(attackerid)
        now = time.time()
        try:
            cd = float(getattr(CONFIG, "biochem_acc_damage_cooldown", 2.0) or 0.0)
        except (TypeError, ValueError):
            cd = 2.0
        if cd > 0 and now - float(self.acc_cd.get(rid, -1e9)) < cd:
            # 图标还在播，这一发不计入（丢弃，不补发）
            return
        total = int(self.acc_damage.get(rid, 0)) + int(amount)
        if total >= step:
            total %= step
            self.acc_cd[rid] = now
            self.battle.send_all(ID.SC_BIO_ACC_DAMAGE, roleid=rid)
            (log.info("BIO-ACC-DMG role=%s 对幽灵累计伤害达标 +%s (step=%s)",
                     rid, int(amount), step) if log.isEnabledFor(20) else None)
        self.acc_damage[rid] = total

    # -- 技能 ------------------------------------------------------------
    def active_skill(self, roleid: int) -> Dict[str, Any]:
        """当前正在生效的技能行；过期自动清掉，返回 {}。"""
        rec = self.skill_active.get(int(roleid))
        if not rec:
            return {}
        try:
            expire, row = rec
        except (TypeError, ValueError):
            return {}
        if time.time() >= float(expire or 0):
            self.skill_active.pop(int(roleid), None)
            return {}
        return row or {}

    def skill_damage_reduce(self, roleid: int) -> float:
        """刚体 / 恶魔刚体：steelHpRate（百分比）-> 0~0.95 的减伤系数。"""
        row = self.active_skill(roleid)
        if not row:
            return 0.0
        try:
            rate = float(row.get("steelHpRate") or 0)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(0.95, rate / 100.0))

    def skill_speed_plus(self, roleid: int) -> float:
        """狂暴 / 变异狂暴：rageSpeedPlus（米/秒 的**平点加速**）。

        注意口径：客户端 `Warrior.SpeedDown` 里是
            num -= skillSpeedPlus;   // SpeedDown 再被 _speed 减掉
        所以最终的移动速度 = runSpeed + rageSpeedPlus，是「加 2 米/秒」，
        不是「乘以 3」。BOT 的位移是服务端算的，必须用同一个口径，
        否则 BOT 幽灵开狂暴会有 22 m/s。
        """
        row = self.active_skill(roleid)
        if not row:
            return 0.0
        try:
            return max(0.0, float(row.get("rageSpeedPlus") or 0))
        except (TypeError, ValueError):
            return 0.0

    def skill_speed_delta(self, roleid: int) -> float:
        """技能对**移动速度**的净变化（米/秒，可正可负）。BOT 专用。

        * 狂暴 / 变异狂暴 -> +rageSpeedPlus
        * 刚体 / 恶魔刚体 -> -biochem_steel_speed_minus（默认 -2 m/s）
        * 雾化 / 魅影雾化 -> -fogSpeedMinus
        真人玩家这一层由客户端 `Warrior` 自己算（刚体在客户端只改
        `skillRecedeRate`＝击退/推力，不改跑速，所以真人开刚体不会变慢）。
        """
        row = self.active_skill(roleid)
        if not row:
            return 0.0
        from ..config import CONFIG
        try:
            if int(row.get("steelHpRate") or 0) > 0 or int(row.get("steelAcRate") or 0) > 0:
                return -abs(float(getattr(CONFIG, "biochem_steel_speed_minus", 2.0) or 0.0))
            fog = float(row.get("fogSpeedMinus") or 0)
            if fog != 0:
                return -fog
            return max(0.0, float(row.get("rageSpeedPlus") or 0))
        except (TypeError, ValueError):
            return 0.0

    def skill_fog(self, roleid: int) -> bool:
        """雾化 / 魅影雾化：fogDetect=1 期间不被 BOT 主动索敌。"""
        row = self.active_skill(roleid)
        return bool(row) and int(row.get("fogDetect") or 0) > 0

    def use_skill(self, roleid: int, skillid: int) -> int:
        """CsBioUseSkill -> ScBioUseSkillRes。返回 result（0 成功，1 失败）。"""
        if roleid not in self.zombies:
            return 1
        f = self.battle.fighters.get(roleid)
        if f is None:
            return 1
        own = bio_skill_of(f.actorid)
        if not own:
            return 1
        # 【狂暴版】技能**按 ID 严格绑定**：只允许角色自己的 bioSkill，
        # 不再放行 `want + 3`（变异版）通道 —— 否则 ID1 生化幽灵（want=1）
        # 也能放出 skill4 变异狂暴，ID1/ID4 的差异化就没了。
        # 客户端 RoleListItem 只取角色自身 bioSkill 发 CsBioUseSkill，
        # 本来就不会发 want+3，所以切断该分支对正常玩法无影响。
        want = int(own.get("id") or 0)
        if int(skillid) != want:
            return 1
        # 变异版（want+3）参数不同：rageSpeedPlus 1.5 vs 1.0、
        # steelCrickMinus 65 vs 60 —— 必须按**实际 skillid**取行。
        skill = {}
        for row in gamedata.table("BioSkill"):
            if int(row.get("id") or 0) == int(skillid):
                skill = row
                break
        if not skill:
            skill = own
        now = time.time()
        if now < float(self.skill_cd.get(roleid) or 0.0):
            return 1
        cd = float(skill.get("cd") or 15)
        duration = float(skill.get("duration") or 5)
        # 【v9】冷却必须是「技能结束之后」才开始走 —— 客户端 UI 本来就是
        # `Setup(duration, cd)`：先等 duration 秒（技能持续时间），再从 cd
        # 递减。服务端原来写 `now + cd`，cd(5) < duration(6) 时技能还没结束
        # 就已经「冷却好了」，女鬼 bot 因此能无缝隐身。
        self.skill_cd[roleid] = now + duration + cd
        # 记下生效窗口，服务端伤害/移动裁决要读它
        self.skill_active[int(roleid)] = (now + duration, dict(skill))
        # 狂暴要扣血（rageHpMinus）。扣血会重置脱战回血计时，符合原版行为。
        minus = int(skill.get("rageHpMinus") or 0)
        if minus > 0:
            before = float(f.hp)
            f.hp = max(1.0, before - minus)
            # 【v49】客户端 `RageSkillTask` 只加跑速、**不扣血**（它只在按技能前
            # 判 `hp > rageHpMinus`），所以服务端扣完必须同步一次，
            # 否则客户端血条比服务端多 500，后面挨枪会「看起来有血却死了」。
            # ScAddHp 的负值在 `ClientManager.AddHP` 里就是 `Damage(-addhp)`。
            real = before - float(f.hp)
            if real > 0:
                try:
                    from . import battle as _bt
                    self.battle.send_all(_bt.ID.SC_ADD_HP,
                                         roleid=int(roleid), addhp=-real)
                except Exception:
                    (log.debug("狂暴扣血同步失败 role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        self.battle.send_all(ID.SC_BIO_USE_SKILL_BRD, roleid=roleid,
                             skillid=int(skillid))
        (log.info("biochem %s 用技能 %s (cd=%.0fs 生效 %.0fs)",
                 roleid, skillid, cd, duration) if log.isEnabledFor(20) else None)
        return 0

    # -- 补给箱 ----------------------------------------------------------
    def _tick_boxes(self, force: bool = False) -> None:
        """Keep each supply type on its own GameRule timer and live-box limit."""
        now = time.time()
        bio_interval = float(self.rule.get("BoxIntervalTime") or 20)
        ammo_interval = float(self.rule.get("supplyTime") or bio_interval)
        if force or now - self._box_timer >= bio_interval:
            self._box_timer = now
            self._drop_box("bio", int(self.rule.get("bioBoxNum") or 3), ID.SC_BIO_BOX_DROP)
        if force or now - self._ammo_timer >= ammo_interval:
            self._ammo_timer = now
            self._drop_box("ammo", int(self.rule.get("ammoBoxNum") or 3), ID.SC_BIO_BULLET_BOX_DROP)

    def _box_points(self):
        """【v17】本回合的补给箱候选点 —— 与复活点同一套全图网格机制。

        `grid_zone_points(scene, per_zone)` 按地图 AABB 切 4×2 八区，每区
        随机抽 N 个「站得下、能寻路」的地面节点（默认 4 → 32 点），铺满
        整张图而不是只围在出生区。Biochem 每回合新建，所以每局自动重新随机。
        返回厘米整数 tuple（与旧 `_box_positions` 同格式）；网格不可用时
        退回旧表，保证箱子还能刷出来。
        """
        from ..config import CONFIG as _C
        cached = getattr(self, "box_points", None)
        if cached:
            return cached
        row = gamedata.map_row(self.battle.room.mapid) or {}
        scene = row.get("scene") or ""
        try:
            per = max(1, int(getattr(_C, "biochem_box_points_per_zone", 4) or 4))
            from .battle import grid_zone_points
            pts = grid_zone_points(scene, per)
            if pts:
                out = tuple((round(p[0] * 100), round(p[1] * 100),
                             round(p[2] * 100)) for p in pts)
                self.box_points = out
                (log.info("BIO-BOX-POINTS scene=%s 本局 %d 个全图候选点",
                         scene, len(out)) if log.isEnabledFor(20) else None)
                return out
        except Exception:
            log.exception("生成全图补给点失败，退回出生点区")
        out = _box_positions(scene)
        self.box_points = out
        return out

    def _drop_box(self, kind: str, limit: int, type_id: int) -> None:
        if sum(b["kind"] == kind for b in self.boxes) >= limit:
            return
        # AItemPicker uses a rotated 3 m wide trigger. Space boxes on each floor.
        occupied = [box["pos"] for box in self.boxes]
        pts = [
            (x, y, z) for x, y, z in self._box_points()
            if all(abs(y - p["y"]) >= 100
                   or (x - p["x"]) ** 2 + (z - p["z"]) ** 2 >= 450 ** 2
                   for p in occupied)
        ]
        if not pts:
            return
        pos = dict(zip(("x", "y", "z"), random.choice(pts)))
        dropid = self.battle.next_bio_box_id
        self.battle.next_bio_box_id += 1
        self.boxes.append({"kind": kind, "dropid": dropid, "pos": pos})
        self.battle.send_all(type_id, dropid=dropid, pos=pos)

    def owns_box_id(self, dropid: int) -> bool:
        return FIRST_BOX_ID <= dropid < self.battle.next_bio_box_id

    def take_box(self, dropid: int, roleid: int) -> Optional[Dict[str, Any]]:
        """Consume once and notify clients through their normal pickup handler."""
        from . import bots, relay

        fighter = self.battle.fighters.get(roleid)
        box = next((b for b in self.boxes if b["dropid"] == dropid), None)
        if (box is None or fighter is None or not fighter.born or fighter.hp <= 0
                or self.winner or self.battle.round_over or self.battle.fight_over):
            # 拾取被拒要有日志：否则线上只能看到「箱子没反应」，
            # 分不清是客户端没发包、dropid 对不上，还是本人已死/回合已结束。
            (log.info("BIO-PICKUP-REJECT room=%s role=%s dropid=%s box=%s "
                     "fighter=%s born=%s hp=%s winner=%s",
                     self.battle.room.roomid, roleid, dropid,
                     box is not None, fighter is not None,
                     getattr(fighter, "born", None), getattr(fighter, "hp", None),
                     self.winner) if log.isEnabledFor(20) else None)
            return None
        if self.is_zombie(roleid) != (box["kind"] == "bio"):
            (log.info("BIO-PICKUP-REJECT room=%s role=%s dropid=%s kind=%s "
                     "zombie=%s（箱子类型和阵营不匹配）",
                     self.battle.room.roomid, roleid, dropid, box["kind"],
                     self.is_zombie(roleid)) if log.isEnabledFor(20) else None)
            return None
        if box["kind"] == "ammo" and bots.is_bot(roleid):
            bots.refill_reserves(self.battle, fighter)
        self.boxes.remove(box)
        if box["kind"] == "bio":
            # 僵尸补给箱：客户端收到 ScPickupItem 时**本地**执行
            #     playerData.Damage(-1000f, -acmax, 0);   // 直接补到 hpmax
            # 服务端必须做同样的事，否则血条两边对不上。先加经验（ScBioExp
            # 会把客户端 hpmax 抬上去），再补满，客户端才装得下这次回血。
            from ..config import CONFIG as _cfg
            self.add_exp(roleid, int(getattr(_cfg, "biochem_bio_box_exp", 4) or 4))
            self.heal_full(roleid, "bio-box")
        else:
            # 弹药箱：人类 +N 级士气（保留 +1），并【v18】回满血。
            # 客户端 ScPickupItem 的 AmmoBox 分支只 FillAmmoAll / ReFull，
            # 不回血（只有 BiochemBox 才 Damage(-1000,...)），所以必须靠
            # heal_full() 显式广播 SC_ADD_HP，否则两边血条对不上。
            from ..config import CONFIG as _cfg
            if not self.is_zombie(roleid):
                self.add_exp(roleid, int(getattr(_cfg, "biochem_ammo_box_exp", 1) or 0))
                # 【v20】上一轮规划落地：由「补满」改为 +1500，且服务端先
                # clamp 到 hp_max —— 客户端 SC_ADD_HP 是纯加法，发多了血条
                # 会超过上限。士气经验照常保留。
                _heal = int(getattr(_cfg, "biochem_ammo_box_heal", 1500) or 0)
                if _heal < 0:
                    self.heal_full(roleid, "ammo-box")
                elif _heal > 0:
                    self.heal_amount(roleid, _heal, "ammo-box")
        self.battle.send_all(relay.ID.SC_PICKUP_ITEM, roleid=roleid, dropid=dropid)
        (log.info("BIO-PICKUP room=%s role=%s kind=%s dropid=%s",
                 self.battle.room.roomid, roleid, box["kind"], dropid) if log.isEnabledFor(20) else None)
        return box

    # -- 胜负 ------------------------------------------------------------
    def check_win(self) -> int:
        """人类全变僵尸 = 僵尸胜；僵尸全死 = 人类胜。返回胜方（0 = 未结束）。

        对齐 ClientManager.FightResultByBioSide：1 = 人类胜，2 = 僵尸胜。
        """
        if self.winner:
            return self.winner
        if not self.begun or not self.infection_started or not self.battle.fighters:
            return 0
        # `self.zombies` 是「本回合被感染过的所有人」，**死亡不会移除**，
        # 直接 `elif not self.zombies` 永远不成立 —— 玩家把幽灵全砍了也
        # 不结算（实测「英雄杀光僵尸不弹胜利」）。
        # 真正的「僵尸全灭」= 场上没有活着的、也没有还能复活的幽灵。
        alive_z = []
        for rid in self.zombies:
            _f = self.battle.fighters.get(rid)
            if _f is not None and (float(getattr(_f, "hp", 0) or 0) > 0
                                   or self.can_relive(rid)):
                alive_z.append(rid)
        # ★ 必须用 `alive_humans()`：`humans()` 是「不在 zombies 里的人」，
        # 死掉的人类仍然留在 fighters 里，所以英雄全被打死时 humans() 依旧
        # 非空 —— 母体杀光所有英雄也不结算（用户实测）。客户端顶栏显示的
        # 「人类 0」就是按存活数算的，服务端必须同口径。
        if not self.alive_humans():
            self.winner = SIDE_ZOMBIE
        elif not alive_z:
            self.winner = SIDE_HUMAN
        return self.winner

    def time_up(self) -> bool:
        """回合时间到 —— 还剩人类就是人类赢（守住了）。"""
        rt = int(self.rule.get("roundTime") or 210) + max(0, int(self.rule.get("infectTime") or 0))
        if not self.started_at:
            return False
        if time.time() - self.started_at < rt:
            return False
        if not self.winner:
            # 同样按「活人」算：时间到时人类已经全死，就该判幽灵胜。
            self.winner = (SIDE_HUMAN if self.alive_humans()
                           else SIDE_ZOMBIE)
        return True

    # -- 人类英雄（ScBioHero 1441970） -----------------------------------
    def time_left(self) -> float:
        """本回合还剩多少秒（按 GameRule.roundTime）。"""
        rt = int(self.rule.get("roundTime") or 210) + max(0, int(self.rule.get("infectTime") or 0))
        if not self.started_at:
            return float(rt)
        return max(0.0, rt - (time.time() - self.started_at))

    def _maybe_heroes(self, *, after_infection=False) -> None:
        """回合剩余固定秒数时，把当时还活着的人类**一次性全部**升成英雄。

        两个生化模式分开：
          * GameMode 8「生化模式」—— **永远不倒计时变英雄**（保持不变）
          * GameMode 10「生化英雄」—— 剩余 CF_BIOCHEM_HERO_TIME（默认 **52**）秒时，
            不看幸存人数，活着的全变英雄，统一进入决战

        ★ 2.0.1 起**只有倒计时一个触发口**：以前 `infect()` 附带一条
        「人类 ≤2 立刻变英雄」的抢跑判定会把 52 秒吃掉，已删除。

        到点时会先跑一次 `_ultimate_grants()`（按对方阵营人数补等级），
        再 `promote_heroes()`。官方没有把「什么时候出英雄」写进配置，
        所以用 CF_BIOCHEM_HERO_TIME（剩余秒数）控制，0 = 关闭。
        """
        if self.battle.room.gamemode != bio_rules.HERO_MODE or self.hero_awakened or self.heroes:
            return
        humans = [roleid for roleid in self.humans() if self.battle.fighters[roleid].born
                  and self.battle.fighters[roleid].hp > 0]
        if not humans:
            return
        from ..config import CONFIG
        after = int(getattr(CONFIG, "biochem_hero_time", 0) or 0)
        if after <= 0:
            return
        # 【2.0.1】删掉「剩余 ≤2 人立刻变英雄」的抢跑分支。
        # 以前 `infect()` 每转化一个人都会回调本方法，只要场上人类 ≤2 就当场全体
        # 变英雄，于是 52 秒倒计时被吃掉、最后一小撮人提前单挑。
        # 现在**只认倒计时**：剩余 `biochem_hero_time`（52）秒时，把当时还活着的
        # 人类一次性全部升成英雄，统一进入决战。
        # `after_infection` 仅为兼容调用点保留，不再影响判定。
        if self.time_left() > after:
            return
        self._ultimate_grants()
        self.hero_awakened = bool(self.promote_heroes(humans))

    def alive_humans(self) -> List[int]:
        """真正还站在场上的活人。

        必须排除 `born == False`（还没出生 / 准备阶段）的占位 fighter ——
        否则一个空位就会让「人类全灭」永远不成立。
        """
        out = []
        for rid in self.humans():
            f = self.battle.fighters.get(rid)
            if f is None:
                continue
            if not bool(getattr(f, "born", False)):
                continue
            try:
                if float(getattr(f, "hp", 0) or 0) <= 0:
                    continue
            except (TypeError, ValueError):
                continue
            out.append(rid)
        return out

    def alive_zombies(self) -> List[int]:
        out = []
        for rid in self.zombies:
            f = self.battle.fighters.get(rid)
            if f is not None and float(getattr(f, "hp", 0) or 0) > 0:
                out.append(rid)
        return out

    @staticmethod
    def _table(text: str, fallback: List[float]) -> List[float]:
        """把 ``"5,12,20"`` 解析成数字表；坏数据退回默认表。"""
        out: List[float] = []
        for part in str(text or "").replace("；", ",").replace(" ", ",").split(","):
            part = part.strip()
            if not part:
                continue
            try:
                out.append(float(part))
            except ValueError:
                continue
        return out or list(fallback)

    @staticmethod
    def _pick(values: List[float], n: int, tail_step: float) -> float:
        """取第 n 个（n 从 1 开始）；超出表长按 tail_step 线性外推。"""
        n = max(0, int(n))
        if n <= 0 or not values:
            return 0.0
        if n <= len(values):
            return float(values[n - 1])
        return float(values[-1]) + tail_step * (n - len(values))

    def _ultimate_grants(self) -> None:
        """【狂暴版】终极生化结算（倒计时到点、全员变英雄的那一刻）。

        人类：按**存活僵尸数**给非线性士气等级（用户给定表）
              1→+5 / 2→+12 / 3→+20 / 4→+30 / 5→+42 / 6→+55 / 7→+80
              1v7 时人类一次 +80 级 = 士气 +1600 点伤害，英雄刀一刀一个非母体
        僵尸：也补等级，公式 max(0, 4×存活人类数 − 1) 级（4n−1）；
              另外加爪击伤害（服务端裁决，客户端只显示数字）
              普通僵尸：每个存活人类 +100 点（线性）
              母体：按存活人类数查表 +300/400/500/700/1100/2100/5000
        只结算一次（`_ultimate_done` 守卫）。
        """
        from ..config import CONFIG
        if int(getattr(CONFIG, "biochem_ultimate_enabled", 0) or 0) <= 0:
            return
        if getattr(self, "_ultimate_done", False):
            return
        self._ultimate_done = True

        humans = self.alive_humans()
        zombies = self.alive_zombies()

        need_h = int(self.rule.get("humanExpNeed") or 0)
        lv_tab = self._table(getattr(CONFIG, "biochem_ultimate_human_levels",
                                     "5,12,20,30,42,55,80"),
                             [5, 12, 20, 30, 42, 55, 80])
        lv_h = int(self._pick(lv_tab, len(zombies), 25.0))
        if lv_h > 0 and need_h > 0:
            for rid in list(humans):
                self.add_exp(rid, need_h * lv_h)

        # 僵尸补等级：4n−1（n = 存活人类数），n=0 时不补。
        need_z = int(self.rule.get("zombieExpNeed") or 0)
        lv_z = max(0, 4 * len(humans) - 1)
        if lv_z > 0 and need_z > 0:
            for rid in list(zombies):
                self.add_exp(rid, need_z * lv_z)

        # 僵尸加伤（平点数，不是百分比）
        try:
            per_human = float(getattr(
                CONFIG, "biochem_ultimate_zombie_dmg_per_human", 30.0) or 0.0)
        except (TypeError, ValueError):
            per_human = 30.0
        m_tab = self._table(getattr(CONFIG, "biochem_ultimate_matrix_dmg",
                                    "300,400,500,700,1100,2100,5000"),
                            [300, 400, 500, 700, 1100, 2100, 5000])
        self.zombie_dmg_flat = per_human * len(humans)
        self.matrix_dmg_flat = self._pick(m_tab, len(humans), 2500.0)
        # 旧字段保留（其它地方若还引用不会炸），但不再参与结算
        self.zombie_dmg_bonus = 0.0
        (log.info("biochem ULTIMATE 人类=%s(+%s级) 僵尸=%s(+%s级, "
                 "普通+%.0f/母体+%.0f)",
                 len(humans), lv_h, len(zombies), lv_z,
                 self.zombie_dmg_flat, self.matrix_dmg_flat) if log.isEnabledFor(20) else None)

    def promote_heroes(self, roleids: List[int]) -> List[int]:
        """把这些人变成人类英雄并广播 ScBioHero，返回实际升的人。

        `ClientManager.Response(ScBioHero)` 收到名单后自己完成全部表现：
            IsHunter = true；hpmax < 5000 时 hpmax *= 50；
            actorid = 1999；equips = {50: 8001}；Born(playerData, online)
        所以服务端**不用**再发 ScBorn，只要把血量/装备对齐，
        否则服务端按 100 血判死、客户端按 5000 血显示，两边会越差越远。
        """
        from ..config import CONFIG
        hp = float(getattr(CONFIG, "biochem_hero_hp", 5000.0) or 5000.0)
        if getattr(self, "heroes", None) is None:
            self.heroes = set()
        out: List[int] = []
        for rid in roleids:
            f = self.battle.fighters.get(rid)
            if f is None or not f.born or f.hp <= 0 or self.is_zombie(rid):
                continue
            f.hp = max(float(f.hp or 0.0), hp)
            f.hp_max = float(hp)
            f.actorid = 1999
            f.equipmap = {50: 8001}
            # 英雄只有一把战刀，没有防弹衣
            f.ac = 0.0
            f.ac_max = 0.0
            # 英雄**保留**防化服（用户要求）。原先这里把 protect 清成 0 是
            # 为了修「抓英雄有音效没伤害」，但真正的根因是清盾后客户端
            # 与服务端状态不同步；保留 1 层后一爪破盾、第二爪打肉体，
            # 节奏正常，英雄也不会被两只幽灵瞬间换死。
            # 客户端只剩英雄战刀；服务端把当前槽位也切到近战，
            # 免得伤害裁决还去 equipmap[11] 找一把已经被清掉的枪。
            f.weaponpos = 50
            self.heroes.add(rid)
            out.append(rid)
        if out:
            self.battle.send_all(ID.SC_BIO_HERO, heros=sorted(self.heroes))
            (log.info("biochem %s 人类英雄出现: %s (hp=%.0f)",
                     self.battle.room.roomid, out, hp) if log.isEnabledFor(20) else None)
        return out

    def tick(self) -> None:
        """每个战斗 tick 调一次。"""
        if self.winner:
            return
        if not self.begun:
            return
        if not self.infection_started and time.time() >= self.infect_deadline:
            self._activate_infection()
        if not self.infection_started:
            return
        if self.check_win():
            return
        self._maybe_heroes()
        self._tick_boxes()
        self.time_up()
        # 兜底：复活计时器到期、最后一只幽灵彻底不能复活等情况
        if not self.winner:
            self.check_win()


# --------------------------------------------------------------------------
# 路由
# --------------------------------------------------------------------------
# 直接挂在模块级 ROUTER 上：handlers.py 一 import 本模块，装饰器就生效。
# （原先写成 install(router) 但没人调用，CsBioUseSkill 根本没注册上。）
@ROUTER.register(ID.CS_BIO_USE_SKILL, "gclient.CsBioUseSkill")
async def on_bio_skill(session: Session, msg: dict) -> None:
    from .battle import battle_for, _room_of
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return
    b = battle_for(room, create=False)
    bio = getattr(b, "biochem", None) if b is not None else None
    if bio is None:
        return
    # 以会话身份为准，不信任客户端发来的 roleid
    rid = session.roleid
    skillid = int(msg.get("skillid") or 0)
    result = bio.use_skill(rid, skillid)
    session.send(ID.SC_BIO_USE_SKILL_RES, result=result, skillid=skillid)
    if result != 0:
        (log.info("biochem 技能失败 roleid=%s skillid=%s", rid, skillid) if log.isEnabledFor(20) else None)
