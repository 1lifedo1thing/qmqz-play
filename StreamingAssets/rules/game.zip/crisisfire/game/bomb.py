# -*- coding: utf-8 -*-
"""爆破模式（gameMode 2）的安包 / 拆包状态机。

**重建实现**：官方服务端已停运，以下行为全部依据客户端自身的读取与驱动逻辑重建，
不是官方还原。语义证据来自 1.8.1 的 Assembly-CSharp 反编译
（`D:\\gamingcode\\全民枪战\\sy37_181\\work\\decomp_181`）。

operate 取值（`ClientManager.BombOper(roleid, operate)` 的完整 switch）
---------------------------------------------------------------------
1 安放中   按下安放键       OperationAgent.cs:402  BombRequest(pressed ? 1 : 3)
2 已安放   **服务端裁决**   客户端置 BombPlanted=true、播 Bomb_Plant、
                           起 CountDown(GameRule.boomBlastTime)
3 取消安放 松开安放键
4 拆除中   按下拆除键       OperationAgent.cs:408  BombRequest(pressed ? 4 : 6)
5 已拆除   **服务端裁决**   客户端置 BombPlanted=false、播 Bomb_Defuse、藏包
6 取消拆除 松开拆除键
7 取包     客户端自发       AItemPicker.cs:151（side==2 拾取 ItemType.Bomb）
8 丢包

关键点：`Commander.BombOper` 在 `Status.online` 时**只发不等、本地不改状态**，
所以 2 和 5 客户端自己从不产生 —— 必须由服务端下发，否则永远进不了「已安放」。
下行消息（`CodecManager` 注册，字段见 `proto/spec.json`）
    ScBombOper   1441926  int roleid, int operate
    ScBombPos    1441927  Vec3 pos                     -> ClientManager.BombPos(explosivePos)
    ScBombExplode 1441928 int roleid, int grenadeid, List<TargetDamage> targets
Vec3 是三个 short，线上单位是 1/100 米（`resolve_grenade` 同样按 /100 还原）。

时长与爆炸参数（`gamedata/GameRule.json`，mode2 行实测）
    boomPlantTime=4  boomDefusedTime=5  boomBlastTime=40  blastId=711011
    blastId 直接是 `Grenade` 表的一行（blastRange=40 maxDamage=400 minDamage=10），
    所以爆炸伤害复用 `damage.resolve_grenade`，不另写一套。

已显式保留的重建限制（不假装成官方行为）
- 服务端没有地图炸弹区体积（那是客户端 `ABlastArea` 的触发盒），因此**不校验安放点**，
  只校验阵营/存活/状态互斥。拆除同理不校验距离。
- `resolve_grenade` 带同阵营免伤且排除发起者，故包爆只伤警（side1）；
  原版会伤到所有人。这里沿用手雷那套已真机验证过的结算，差异如实标注。
"""
from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, Optional

from .. import gamedata

log = logging.getLogger("crisisfire.bomb")

PLANT_START, PLANTED, PLANT_CANCEL = 1, 2, 3
DEFUSE_START, DEFUSED, DEFUSE_CANCEL = 4, 5, 6
PICK_UP, DROP = 7, 8

SC_BOMB_OPER = 1441926
SC_BOMB_POS = 1441927
SC_BOMB_EXPLODE = 1441928

POLICE, TERRIST = 1, 2


def _secs(rule: Dict[str, Any], key: str, default: int) -> int:
    try:
        v = int(rule.get(key) or 0)
    except (TypeError, ValueError):
        v = 0
    return v if v > 0 else default


def _wire_pos(fighter) -> Optional[Dict[str, int]]:
    p = getattr(fighter, "syncpos", None)
    if not p:
        return None
    return {"x": int(round(float(p[0]) * 100.0)),
            "y": int(round(float(p[1]) * 100.0)),
            "z": int(round(float(p[2]) * 100.0))}


class Bomb:
    """一个战斗实例一份炸弹状态。由 `Battle` 在回合开始重置、由回合时钟 tick。"""

    #: 场上没有真人匪徒时，隔多少秒让一个活着的匪方 BOT 发起安放。
    #: 爆破模式若没人安包，回合永远只能「超时警胜」，模式本身不成立；
    #: 而本工程的 BOT 是站桩的（bots.py 无 tick），所以由这里代它走**与真人
    #: 完全相同的 request() 入口**，服务端裁决链不分叉。重建实现，非官方 AI 行为。
    BOT_PLANT_AFTER = float(os.environ.get('CF_BOMB_BOT_PLANT_AFTER', '25'))

    def __init__(self, battle) -> None:
        self.b = battle
        self.reset()

    def reset(self) -> None:
        self.holder = 0
        self.planted = False
        self.planted_by = 0
        self.pos: Optional[Dict[str, int]] = None
        self.plant: Optional[tuple] = None
        self.defuse: Optional[tuple] = None
        self.blast_deadline: Optional[float] = None
        self.defused_by = 0
        self.ended = False
        self.bot_planted = False
        # 与计时器同一把单调时钟，别和 time.time() 混用
        self.round_mono = time.monotonic()

    def _request_bot_plant(self) -> None:
        """没有真人匪徒时，让一个活着的匪方 BOT 发起安放。"""
        if self.BOT_PLANT_AFTER <= 0 or self.planted or self.plant or self.bot_planted:
            return
        if time.monotonic() - self.round_mono < self.BOT_PLANT_AFTER:
            return
        from . import bots
        humans_t = [r for r, f in self.b.fighters.items()
                    if getattr(f, 'side', None) == TERRIST
                    and getattr(f, 'born', False) and not bots.is_bot(r)]
        if humans_t:
            return                      # 有真人匪徒，交给他自己安
        cand = [r for r, f in self.b.fighters.items()
                if getattr(f, 'side', None) == TERRIST
                and getattr(f, 'born', False) and bots.is_bot(r)
                and getattr(f, 'syncpos', None)]
        if not cand:
            return
        roleid = sorted(cand)[0]
        self.bot_planted = True
        (log.info("bomb: 场上无真人匪徒，代匪方 BOT role=%s 发起安放", roleid) if log.isEnabledFor(20) else None)
        self.request(roleid, PICK_UP)
        self.b.send_all(SC_BOMB_OPER, roleid=roleid, operate=PICK_UP)
        self.request(roleid, PLANT_START)
        self.b.send_all(SC_BOMB_OPER, roleid=roleid, operate=PLANT_START)

    # ---- 客户端请求入口（relay.py 转发过来）----

    def request(self, roleid: int, operate: int) -> None:
        if int(getattr(self.b.room, "gamemode", 0) or 0) != 2:
            return
        if self.ended or self.b.round_over or self.b.fight_over:
            return
        rule = gamedata.rule(self.b.room.levelid) or {}
        f = self.b.fighters.get(roleid)
        side = getattr(f, "side", None) if f is not None else None
        alive = bool(getattr(f, "born", False)) if f is not None else False

        if operate == PICK_UP:
            self.holder = roleid
        elif operate == DROP:
            if self.holder == roleid:
                self.holder = 0
        elif operate == PLANT_START:
            self.defuse = None
            if self.planted or side != TERRIST or not alive:
                (log.info("bomb: 安放被拒 role=%s side=%s alive=%s planted=%s",
                         roleid, side, alive, self.planted) if log.isEnabledFor(20) else None)
                self.plant = None
            else:
                self.plant = (roleid, time.monotonic()
                              + _secs(rule, "boomPlantTime", 4))
        elif operate == PLANT_CANCEL:
            if self.plant and self.plant[0] == roleid:
                self.plant = None
        elif operate == DEFUSE_START:
            self.plant = None
            if not self.planted or side != POLICE or not alive:
                (log.info("bomb: 拆除被拒 role=%s side=%s alive=%s planted=%s",
                         roleid, side, alive, self.planted) if log.isEnabledFor(20) else None)
                self.defuse = None
            else:
                self.defuse = (roleid, time.monotonic()
                               + _secs(rule, "boomDefusedTime", 5))
        elif operate == DEFUSE_CANCEL:
            if self.defuse and self.defuse[0] == roleid:
                self.defuse = None
        else:
            (log.info("bomb: 未认识的 operate=%s role=%s", operate, roleid) if log.isEnabledFor(20) else None)

    # ---- 计时推进；返回 True 表示本 tick 已经结算掉回合 ----

    def tick(self) -> bool:
        if self.ended or self.b.round_over or self.b.fight_over:
            return False
        now = time.monotonic()
        self._request_bot_plant()

        for label in ("plant", "defuse"):
            job = getattr(self, label)
            if not job:
                continue
            roleid, _deadline = job
            f = self.b.fighters.get(roleid)
            if f is None or not getattr(f, "born", False):
                (log.info("bomb: %s 因 role=%s 阵亡中止", label, roleid) if log.isEnabledFor(20) else None)
                setattr(self, label, None)
                self.b.send_all(SC_BOMB_OPER, roleid=roleid,
                                operate=PLANT_CANCEL if label == "plant" else DEFUSE_CANCEL)

        if self.plant and now >= self.plant[1]:
            roleid = self.plant[0]
            self.plant = None
            self._complete_plant(roleid)

        if self.defuse and now >= self.defuse[1]:
            roleid = self.defuse[0]
            self.defuse = None
            self._complete_defuse(roleid)
            return True

        if self.planted and self.blast_deadline and now >= self.blast_deadline:
            self._explode()
            return True
        return False

    # ---- 三个终局动作 ----

    def _complete_plant(self, roleid: int) -> None:
        rule = gamedata.rule(self.b.room.levelid) or {}
        f = self.b.fighters.get(roleid)
        self.planted = True
        self.planted_by = roleid
        self.pos = _wire_pos(f) if f is not None else None
        self.blast_deadline = time.monotonic() + _secs(rule, "boomBlastTime", 40)
        (log.info("bomb: role=%s 安放完成，%ss 后爆炸 pos=%s",
                 roleid, int(self.blast_deadline - time.monotonic()), self.pos) if log.isEnabledFor(20) else None)
        self.b.send_all(SC_BOMB_OPER, roleid=roleid, operate=PLANTED)
        if self.pos is not None:
            self.b.send_all(SC_BOMB_POS, pos=self.pos)
        else:
            log.warning("bomb: 安放者无坐标可报，跳过 ScBombPos（客户端包体位置会留在默认值）")

    def _complete_defuse(self, roleid: int) -> None:
        (log.info("bomb: role=%s 拆除完成 -> 警胜", roleid) if log.isEnabledFor(20) else None)
        self.planted = False
        self.defused_by = roleid
        self.blast_deadline = None
        self.pos = None
        self.ended = True
        self.b.send_all(SC_BOMB_OPER, roleid=roleid, operate=DEFUSED)
        self.b.end_round(POLICE)

    def _explode(self) -> None:
        from . import damage
        rule = gamedata.rule(self.b.room.levelid) or {}
        blastid = int(rule.get("blastId") or 0) or 711011
        pos = self.pos or {"x": 0, "y": 0, "z": 0}
        targets = damage.resolve_grenade(self.b, self.planted_by, pos, blastid,
                                         is_biochem=self.b.biochem is not None)
        (log.info("bomb: 爆炸 blastid=%s 命中 %d 人: %s", blastid, len(targets),
                 ", ".join("%s -%s" % (t.get("targetid"), t.get("hpdamage")) for t in targets)) if log.isEnabledFor(20) else None)
        self.ended = True
        self.planted = False
        self.blast_deadline = None
        self.b.send_all(SC_BOMB_EXPLODE, roleid=self.planted_by,
                        grenadeid=blastid, targets=targets)
        for t in targets:
            v = self.b.fighters.get(int(t.get("targetid") or 0))
            if v is not None and float(getattr(v, "hp", 0.0) or 0.0) <= 0 and v.born:
                self.b.on_kill(self.planted_by, int(t.get("targetid") or 0))
        self.b.end_round(TERRIST)
