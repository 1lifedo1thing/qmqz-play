"""Keep a committed BOT flight through infection/model replacement.

An airborne Y is not a foot offset. Continue the already validated trajectory,
or its elapsed landing, instead of creating a permanent half-metre hover.
"""
import copy,math,time


def prepare(battle,fighter,position):
    from . import bots,parkour
    if not bots.is_bot(fighter.roleid) or position is None:return position,None
    old=getattr(battle,'_bot_motion',{}).get(int(fighter.roleid),{})
    if not old:return position,None
    foot=old.get('foot')
    if foot is None:return position,None
    now=time.monotonic();state={'foot':float(foot),'updated_at':now}
    jump=old.get('jump')
    if jump is None:return position,state
    # Only carry the flight which actually produced this position. Never pull
    # an unrelated respawn back to a previous route or a guessed safe anchor.
    expected=parkour.point(jump,jump['elapsed'])
    if math.dist(tuple(position),expected)>.04:return position,state
    jump=copy.deepcopy(jump)
    elapsed=jump['elapsed']+max(0.,now-float(old.get('updated_at',now)))
    jump['elapsed']=min(jump['duration'],elapsed)
    if elapsed>=jump['duration']:
        position=jump['end']
    else:
        position=parkour.point(jump,jump['elapsed'])
        state.update(jump=jump,form_airborne=True,form_air_at=now)
    bots.log.info('BOT-FORM-AIR role=%s foot=%.3f elapsed=%.3f/%.3f position=%s',
                  fighter.roleid,foot,jump['elapsed'],jump['duration'],position)
    return tuple(position),state


def landing_tail(height=1.):
    """Bound the native remote DoJump cleanup using its own constants.

    VirtualServer/Warrior use |v| in FreeFallTime. For our allowed .85m drop,
    max landing speed is sqrt(2*g*(1+.85)); the probe distance is <=JumpHeight
    and DoJump adds .2m, then waits downTime-.2 and .47 for JumpDown.
    """
    gravity=10.;velocity=math.sqrt(2*gravity*(height+.85))
    down=(math.sqrt(velocity*velocity+2*gravity*(height+.2))+velocity)/gravity
    return max(0.,down-.2)+.47
