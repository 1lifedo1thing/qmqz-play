"""Local difficulty for UC's reconstructed room opponents and challenge allies."""
from dataclasses import dataclass
import math
from random import Random


@dataclass(frozen=True)
class Profile:
    reaction: float
    shot_gap: float
    aim_error: float
    damage_scale: float


STANDARD = Profile(0.75, 0.90, 4.2, 0.65)
ELIMINATION = Profile(1.15, 0.95, 5.0, 0.55)
INFECTION = Profile(0.75, 0.30, 4.2, 0.68)
CHALLENGE = Profile(0.70, 0.32, 4.0, 0.55)
PROFILES = {3: ELIMINATION, 8: INFECTION, 10: INFECTION, 12: CHALLENGE}


def profile(battle):
    return PROFILES.get(getattr(getattr(battle, "room", None), "gamemode", 0), STANDARD)


def damage(battle, roleid, amount, *, claw=False, gun=None, distance=0):
    from .bots import is_bot
    from .room_ai import enabled

    if amount <= 0 or not is_bot(roleid):
        return amount
    if gun and enabled(battle) and distance > gun["effectiveRange"]:
        maximum, effective = gun["maximumRange"], gun["effectiveRange"]
        if distance >= maximum:
            return 0
        base = gun["basicDamage"]
        if base > 0:
            amount *= 1 + (gun["minDamage"] / base - 1) * (distance - effective) / (maximum - effective)
    return max(1, int(amount * (0.8 if claw else profile(battle).damage_scale)))


def ready(battle, fighter, target, visible, now, state):
    if not visible or target is None:
        state.pop("acquisition", None)
        return False
    targetid = target.roleid
    acquisition = state.get("acquisition")
    if acquisition is None or acquisition[0] != targetid:
        delay = profile(battle).reaction + 0.11 * ((fighter.roleid + targetid) % 5)
        state["acquisition"] = targetid, now + delay
        return False
    return now >= acquisition[1]


def aim_offset(battle, roleid, sequence, moving=False, *, weaponid=None):
    # Reconstruct the native robot's randomized sight deviation. Choose a
    # deterministic seed per shot so identical matches can be compared.
    rng = Random((roleid * 2654435761) ^ (sequence * 40503))
    from . import damage as combat, room_ai

    bio = getattr(battle, "biochem", None)
    defender = bio is not None and not bio.is_zombie(roleid)
    if weaponid is not None and (room_ai.enabled(battle) or defender):
        gun = combat._table("Gun").get(weaponid)
        if gun:
            # AGun::GetAimRay samples the posture's min/max distribution;
            # RobotConsts::Distribute adds 3 degrees at training rank 1.
            pose = "Run" if moving else "Stand"
            distribution = rng.uniform(gun["minDistribution" + pose], gun["maxDistribution" + pose])
            azimuth = math.tau * rng.random()
            return rng.uniform(0, .33 * (distribution + 3.0)), azimuth
    spread = profile(battle).aim_error + (2.0 if moving else 0.0)
    return spread * math.sqrt(rng.random()), math.tau * rng.random()


def smooth_facing(state, entry, dt):
    if entry is None:
        return
    quat = entry["state"]["quat"]
    desired = 2 * math.atan2(quat["y"], quat["w"])
    yaw = state.get("bot_facing", desired)
    delta = (desired - yaw + math.pi) % math.tau - math.pi
    limit = math.radians(160) * min(dt, 0.25)
    yaw += max(-limit, min(limit, delta))
    state["bot_facing"] = yaw
    entry["state"]["quat"] = dict(x=0, y=round(math.sin(yaw / 2) * 20000),
                                  z=0, w=round(math.cos(yaw / 2) * 20000))


def gun_tick(battle, fighter, target, distance, visible, colliders, state, now, *, aligned=True):
    """The ordinary BOT gun path shares the existing pistol magazine lifecycle."""
    from . import battle as protocol, bots, damage as combat, human

    slot, _ = combat.active_weapon(fighter)
    ammo = state.get("room_ammo")
    if ammo is None:
        ammo = state["room_ammo"] = human.AmmoState.from_loadout(fighter.equipmap)
    ammo.switch(slot, now)
    if slot not in ammo.slots:
        return
    if (loaded := ammo.update(now)) is not None:
        bots._send_reload_stop(battle, fighter, *loaded)
    if not ammo.clip:
        if ammo.start_reload(now):
            bots._send_reload_start(battle, fighter, slot)
        elif not ammo.reserve and not ammo.reloading(now):
            next_slot = next((other for other in ammo.slots if other != slot and ammo.total(other)),
                             50 if fighter.equipmap.get(50) else 0)
            if next_slot:
                fighter.weaponpos = next_slot
                battle.send_all(protocol.ID.WEAPON_CHANGE, roleid=fighter.roleid, weaponpos=next_slot,
                                bulletnum=ammo.total(next_slot) if next_slot in ammo.slots else 0)
        ready(battle, fighter, None, False, now, state)
        return
    if (ready(battle, fighter, target, visible, now, state) and aligned
            and now - ammo.last_shot >= profile(battle).shot_gap and ammo.consume(now)):
        bots._fire(battle, fighter, target, distance, colliders=colliders, state=state)
