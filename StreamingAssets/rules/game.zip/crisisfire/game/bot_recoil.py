"""Mirror Warrior.RecedeTask for server-controlled zombie BOTs only.

Gun.bioHit is duration, bioHitSpeed velocity. Warrior.OnHurt applies this only
to isUser; remote BOTs need their controller to execute the same motion.
"""
import math


def register(battle, shooterid, hits):
    """给被击中的僵尸 BOT 登记一次击退（曲线与客户端 RecedeTask 相同）。

    【v48】两个新倍率：
      * ``bot_recoil_push``  —— 推力倍率（**只乘速度**，位移线性放大）。
        标定：M4A1 系 0.10s/5m/s 10 发/秒 连打时 1 秒被推
        ``0.10*5*2/3*10 = 3.333m``；× 1.95 = **6.5m**（用户定的靶）。
      * ``bot_recoil_stack_max`` —— 霰弹叠加：一枪 N 颗弹丸命中时按
        ``min(N, 本值)`` 倍推力（旧行为是覆盖写，8 颗只算 1 次）。
        只对真霰弹（``bulletPerShoot > firePerShoot``）生效，
        三连发枪（M93R/FAMAS/M16A4，bps == fps）不会被误叠。
    """
    from . import bots,damage,battle as B
    bio=getattr(battle,'biochem',None)
    shooter=battle.fighters.get(int(shooterid))
    if bio is None or shooter is None or bio.is_zombie(shooterid):return
    gun=damage._table('Gun').get(B._main_weapon_of(shooter),{})
    duration=float(gun.get('bioHit') or 0.);speed=float(gun.get('bioHitSpeed') or 0.)
    if duration<=0 or speed<=0:return
    origin=getattr(shooter,'syncpos',None)
    if origin is None:return
    motion=getattr(battle,'_bot_motion',None)
    if motion is None:motion=battle._bot_motion={}
    # --- v48：推力倍率 / 霰弹叠加上限 ---
    push = 1.0
    stack_max = 1
    try:
        from ..config import CONFIG
        push = max(0.0, float(getattr(CONFIG, "bot_recoil_push", 1.0) or 0.0))
        stack_max = max(1, int(getattr(CONFIG, "bot_recoil_stack_max", 1) or 1))
    except (TypeError, ValueError):
        push, stack_max = 1.0, 1
    try:
        _pellets = int(gun.get('bulletPerShoot') or 1) > int(gun.get('firePerShoot') or 1)
    except (TypeError, ValueError):
        _pellets = False
    counts = {}
    if _pellets and stack_max > 1:
        for hit in hits:
            try:
                _t = int(hit.targetid)
            except (TypeError, ValueError):
                continue
            counts[_t] = counts.get(_t, 0) + 1
    for hit in hits:
        rid=int(hit.targetid);f=battle.fighters.get(rid)
        if not bots.is_bot(rid) or not bio.is_zombie(rid) or f is None or not f.born or f.hp<=0:continue
        if hit.hpdamage<=0 or f.syncpos is None:continue
        dx,dz=f.syncpos[0]-origin[0],f.syncpos[2]-origin[2];n=math.hypot(dx,dz)
        if n<1e-6:continue
        # 刚体 / 恶魔刚体：steelCrickMinus 减轻击退（`100 - steelCrickMinus` 百分比）。
        # 真人玩家由客户端 Warrior.SteelSkillTask -> skillRecedeRate 本地结算；
        # BOT 的位移是服务端驱动的，这里必须同样乘减推力系数，否则开了盾
        # 照样被完整击退（与真人表现不一致）。
        rate = 1.0
        try:
            row = bio.active_skill(int(rid))
            if row:
                # 客户端只有一个 skillRecedeRate：狂暴用 rageCrickMinus、
                # 刚体用 steelCrickMinus，谁最后开算谁。原来只读 steel，
                # 狂暴（-20%/-30%）被漏掉。
                _crick = (float(row.get("steelCrickMinus") or 0)
                          or float(row.get("rageCrickMinus") or 0))
                if _crick > 0:
                    rate = max(0.05, (100.0 - _crick) / 100.0)
        except Exception:
            rate = 1.0
        # 整体系数（老开关，默认 1.0 = 与真人一致；历史削弱用的通道）。
        try:
            from ..config import CONFIG
            _scale = float(getattr(CONFIG, "bot_recoil_scale", 1.0) or 1.0)
            rate *= max(0.05, _scale)
        except Exception:
            pass
        mult = min(counts.get(rid, 1), stack_max) if counts else 1
        motion.setdefault(rid,{})['recoil']={'duration':duration*rate,
                                             'speed':speed*rate*push*mult,
                                             'elapsed':0.,'dir':(dx/n,dz/n)}


def lock_move() -> bool:
    """【v48】击退期间是否**接管** BOT 的移动（与真人一致）。

    客户端 `Warrior.Speed` 在 `recedeTime > 0` 时直接返回 `-recedeSpeed`，
    玩家自己的前进输入被完全忽略。这里用同一个开关让服务端驱动的僵尸 BOT
    也走「替代」语义：

        CF_BOT_RECOIL_LOCK=1（默认）  击退那一 tick 不推进，只被推
        CF_BOT_RECOIL_LOCK=0          回到 v13 的「前进 + 叠加击退」
    """
    try:
        from ..config import CONFIG
        return float(getattr(CONFIG, "bot_recoil_lock_move", 1.0) or 0.0) > 0.0
    except (TypeError, ValueError):
        return True


def displacement(state,dt):
    """Integrate the native recoil curve over the simulated tick."""
    r=state.get('recoil')
    if r is None:return None
    total=r['duration'];start=r['elapsed'];end=min(total,start+dt)
    def integral(t):return t-t*t*t/(3*total*total)
    length=r['speed']*(integral(end)-integral(start))
    r['elapsed']=end
    if end>=total-1e-8:state.pop('recoil',None)
    return r['dir'][0]*length,r['dir'][1]*length
