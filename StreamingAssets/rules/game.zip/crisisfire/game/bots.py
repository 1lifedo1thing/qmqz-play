"""PvP 房间人机：按1.8.1客户端数据重建的服务端控制器。

默认 bots_drive 通过 ScBorn / ScRoleStatusSync / ScShoot 驱动远程角色，
攻击复用玩家共用结算链；巡游、避让与路径算法为重建实现。
移动读取本包导航及静态碰撞，不给未知地图添加穿墙直线兜底。

另有独立实验开关 bots_ai：ScManageAI(1441905) 将 roleid 写入客户端
robots 字典，RobotDesc 必须取真实表内 id，且必须先于 ScBorn 下发。
它与 bots_drive 互斥：ClientManager.RoleStatusSync 跳过 IsRelated 角色。
旧设备记录已证明单独下发 ManageAI 未能启动本包的完整 AI，不能称它已可用。
僵尸还受 AArsenal 的非僵尸 TPS 上枪条件限制，默认走服务端控制器。

客户端依据：ClientManager、PosSyncClient、BeanConverter、ABiochemHand、
AArsenal、Robot、TPSOnlineBehaviour；服务一侧始终是本地重建实现。
"""
from __future__ import annotations

import logging
import math
import time
from typing import Any, Dict, List, Optional, Tuple

from .. import gamedata
from ..config import CONFIG
from . import rooms as R
from . import damage, special_modes
from . import human
from . import squad
from . import weapon_fire

log = logging.getLogger("crisisfire.bots")


class ID:
    SC_MANAGE_AI = 1441905

# 机器人 roleid 段：和真实角色（十万级）、PVE 怪物（1000001+）都错开
BOT_ID_BASE = 900_000
BOT_NAMES = ["机器人·阿尔法", "机器人·贝塔", "机器人·伽马", "机器人·德尔塔"]


_actors_cache: Dict[int, List[int]] = {}


def actors_of_camp(camp: int) -> List[int]:
    """Role.json 里属于某个阵营的角色 id（camp 1=警、2=匪、3=僵尸）。

    机器人**必须**拿一个真实存在的 actorid。客户端 `PlayerData.Init()` 是：

        Role roleById = CsRoleMgr.instance.GetRoleById(actorid);
        IsZombie = roleById.camp == 3;        // roles 查不到 -> null -> NRE

    而 `GetRoleById` 未命中直接回 null，所以此前 `f.actorid = 1`（Role 表里
    最小的 id 是 101）会让整条 ScBorn 在客户端**抛空引用后什么也不画** ——
    这就是名单里有人、场上却是「幽灵」的原因。
    """
    if camp not in _actors_cache:
        try:
            rows = gamedata.table("Role") or []
        except Exception:
            log.exception("读 Role 表失败")
            rows = []
        _actors_cache[camp] = sorted({int(r.get("id") or 0) for r in rows
                                      if int(r.get("camp") or 0) == camp
                                      and int(r.get("id") or 0) > 0})
    return _actors_cache[camp]


def pick_actor(side: int, index: int = 0) -> int:
    ids = actors_of_camp(2 if side == 2 else 1)
    if not ids:
        return 0
    return ids[index % len(ids)]


_rows: Optional[List[Dict[str, Any]]] = None


def _desc_rows() -> List[Dict[str, Any]]:
    """RobotDesc 表（id 0 是客户端 levelRobots 排除掉的样板，一并跳过）。

    【v1.0.2 边界说明】服务端读这张表**只为了给联机 BOT 挑一个 AI 原型 id**
    （取 level / actorId），绝不用它的 primWeapon 发枪。PVE 机器人关卡的
    BOT 是客户端 OfflineAssist.BornRobot 用**客户端 Configs 里同一张表**的
    primWeapon 装配的，两边是两套独立数据，别把一边的改动当成另一边的修法。
    """
    global _rows
    if _rows is None:
        try:
            _rows = [r for r in gamedata.table("RobotDesc") or []
                     if int(r.get("id") or -1) > 0]
        except Exception:
            log.exception("读 RobotDesc 表失败")
            _rows = []
    return _rows


def pick_robotid(level: int, actorid: int = 0) -> Optional[Dict[str, Any]]:
    """挑一个**客户端查得到**的 RobotDesc 行。

    `RobotConfigs.GetRobotDesc(id)` 未命中回 null，而 `ManageAI` 紧接着就
    `robotDesc.level` —— 越界 id = 客户端空引用。所以这里只从表里真实存在的
    id 里选，并且优先挑 actorId 和机器人当前模型一致的那一行（和客户端单机
    侧 `RandomPrototype(level, camp)` 的思路一致）。档位没有则就近借档。
    """
    rows = _desc_rows()
    if not rows:
        return None
    exact = [r for r in rows if int(r.get("level") or 0) == int(level)]
    cand = exact or rows
    match = [r for r in cand if int(r.get("actorId") or 0) == int(actorid)]
    pool = match or cand
    pool.sort(key=lambda r: int(r.get("id") or 0))
    return pool[0]


def manage_ai(battle, fighter) -> int:
    """给机器人下发 ScManageAI —— 让客户端自己跑它的 AI。

    证据见模块 docstring（`TPSOnlineBehaviour` 只在 `DataPool.IsRobot(roleid)`
    时才替这台机器人发 `CsShoot`，而 `IsRobot` 就是 `ManageAI` 填进去的字典）。

    **必须发在 ScBorn 之前** —— 这不是保险，是硬要求，链条是：

        AArsenal.cs:204   if (DataPool.IsRobot(warrior.roleid))
                              warrior.GetComponent<Robot>().EquipWeapon(id);
        Robot.cs:164      EquipWeapon -> Startup()
        Robot.cs:178      Startup -> StartCoroutine(Ranging())   // AI 的心跳

    出生时的 TPS 枪械加载协程只跑**一次**。ManageAI 若晚于 ScBorn，那一刻
    IsRobot 还是 false ⇒ `Robot.EquipWeapon` 永远不会被调 ⇒ `Startup` 没跑过
    ⇒ 组件挂上了也没有心跳，机器人照样立正。（真机实测正是这个顺序：44 条
    ScManageAI 都发了、客户端 logcat 一条 Unity 异常都没有，但服务端收到的
    CsShoot 仍然全是玩家一个人的。）
    反过来先发 ManageAI：`OnRoleCreated`（ClientManager.cs:1331）会在出生时按
    `robots` 字典补挂 `Robot`，随后枪械加载时 IsRobot 已为真，AI 才起步。

    返回用到的 robotid（没发则 0）。
    """
    if not CONFIG.bots_ai or not is_bot(fighter.roleid):
        return 0
    desc = pick_robotid(CONFIG.bots_ai_level, int(fighter.actorid or 0))
    if desc is None:
        log.warning("RobotDesc 表没有可用行，%s 保持站桩", fighter.roleid)
        return 0
    robotid = int(desc.get("id") or 0)
    battle.send_all(ID.SC_MANAGE_AI, roleid=int(fighter.roleid),
                    robotid=robotid)
    (log.info("人机接管 AI role=%s robotid=%s level=%s actor=%s",
             fighter.roleid, robotid, desc.get("level"), desc.get("actorId")) if log.isEnabledFor(20) else None)
    return robotid


def _bot_seed(battle) -> int:
    return int.from_bytes(getattr(battle.room, "token", b""), "big")


def _bot_equipmap(battle, roleid: int) -> Dict[int, int]:
    """Base equipment chosen independently of every player's inventory."""
    from . import equip, weapon_catalog, rank_profiles
    limit = int(getattr(battle.room, "equiplimitid", 0) or 0)
    rule = special_modes.rule(limit) or {}
    category = weapon_catalog.CATEGORY_BY_SUBTYPE.get(rule.get("mainEquipType"), "")
    # 【v19】高难房按房间级星级区间发枪：排位 4-7★、联赛 7-9★；
    # 普通房 / 生化房传 None，沿用原来的全局池（行为不变）。
    # 【v29 临时测试】联赛 BOT 主武器强制枪种（"" = 正常随机）。
    # 手枪局仍会被 special_modes.equipmap 裁回手枪，不受影响。
    try:
        from ..config import CONFIG as _CFG
        _force_cat = str(
            getattr(_CFG, "bot_league_force_category", "") or "").strip().lower()
    except Exception:
        _force_cat = ""
    _idx = _bot_index(roleid)
    if _force_cat and rank_profiles.rank_type(battle.room) == rank_profiles.LEAGUE:
        category = _force_cat
    # 【v30】生化房 BOT 枪池：禁用骑士/龙（tex=99）。
    # 【v47】星级区间 1-7★ -> **4-8★**（用户 2026-11-09 口径）。
    _stars = rank_profiles.gun_stars(battle.room)
    _allow_knights = None
    if _is_bio_room(battle):
        _stars = (4, 8)
        _allow_knights = False
    weapons = weapon_catalog.basic_bot_loadout(
        _idx, seed=_bot_seed(battle), main_category=category,
        stars=_stars, allow_knights=_allow_knights)
    equipmap = {**equip.COMMON, **weapons}
    # **在源头就按 SpecialRule 裁剪。**
    # 原来只靠 `born()` 事后调 `special_modes.equipmap()`，但 BOT 的
    # `AmmoState` 已经按主武器建好了，切枪逻辑仍然会选 11 槽，
    # `f.weaponpos=11` 而 equipmap 里没有 11 —— 客户端就显示他端着枪跑，
    # 刀战模式尤其明显（明明只能带刀）。
    result = special_modes.equipmap(equipmap, limit)
    # 【v50】高难 BOT 换护甲三件套（普通房 / 生化房一律不动）。
    # 核查结论：BOT **本来就穿甲**，`equip.COMMON` 自带 31/32/33
    # 战斗三件套；`battle._apply_combat_stats` 会按 Armor.maxAc 算 f.ac，
    # `damage.armor_of(fighter, hitpart)` 再按命中部位取对应槽的 Armor 行，
    # `split_by_armor` 在 ac>0 时确实做减伤 —— 链路完整、有效。
    # 这里只把高难房那三件换成用户指定的系列（同档位跨槽 023 / 024）。
    try:
        _rt = rank_profiles.rank_type(battle.room)
    except Exception:
        _rt = None
    # 【抖M版】排位的 BOT **性能**对齐联赛：护甲也换成 PASGT-第四代系列。
    # 枪池不受影响 —— 排位仍是 GUN_STARS[QUALIFYING] = 4-7★（用户口径：
    # 「排位的 bot 替换为联赛的 bot，武器池还是用原来排位的」）。
    if _rt in (rank_profiles.QUALIFYING, rank_profiles.LEAGUE):
        result = dict(result)
        result.update({31: 811024, 32: 821024, 33: 831024})
    return result


def install(battle, count: int = 2) -> int:
    """确保机器人进入战斗。只装一次。

    两个来源：
    * room_fill 预填的成员（房间满员 → 客户端才肯开始）——补建 fighter；
    * 房间没满时按 count 再补。
    """
    if getattr(battle, "_bots_installed", False):
        return 0
    battle._bots_installed = True
    if getattr(battle.room, 'bot_roster_managed', False):
        count = 0  # The lobby roster includes deliberate vacancies after kicks.

    added = 0
    # 预填成员已有 bot roleid：只补 fighter，不动成员表
    for roleid, member in list(battle.room.members.items()):
        if is_bot(roleid) and roleid not in battle.fighters:
            f = battle.add(member)
            f.equipmap = _bot_equipmap(battle, roleid)
            f.equipindex = 0
            f.actorid = pick_actor(int(getattr(member, "side", 1) or 1), added)
            _ensure_human_loadout(battle, f, reset_ammo=True)
            added += 1
            (log.info("预填机器人入战斗 roleid=%s name=%s side=%s actor=%s 装备=%s",
                     roleid, member.name, member.side, f.actorid, f.equipmap) if log.isEnabledFor(20) else None)

    for i in range(count):
        limit = max(0, int(getattr(battle.room, 'playerlimits', 0) or 0)
                    - int(getattr(battle.room, 'bot_vacancies', 0) or 0))
        if limit > 0 and len(battle.room.members) >= limit:
            break
        roleid = BOT_ID_BASE + i + 1
        if roleid in battle.room.members or roleid in getattr(battle.room, 'kicked_bot_ids', ()):
            continue
        side = 1 if i % 2 == 0 else 2
        name = BOT_NAMES[i % len(BOT_NAMES)]
        member = R.Member(roleid=roleid, name=name, level=30, iconid=1,
                          side=side, ready=True)
        battle.room.members[roleid] = member
        f = battle.add(member)
        f.equipmap = _bot_equipmap(battle, roleid)
        f.equipindex = 0
        f.actorid = pick_actor(side, i)
        _ensure_human_loadout(battle, f, reset_ammo=True)
        added += 1
        (log.info("加入机器人 roleid=%s name=%s side=%s 装备=%s",
                 roleid, name, side, f.equipmap) if log.isEnabledFor(20) else None)

    if added:
        (log.info("房间 %s 共加入 %d 个机器人", battle.room.roomid, added) if log.isEnabledFor(20) else None)
    # Pre-filled room members may already have a Fighter; install must still
    # apply the biochem loadout before their first ScBorn.
    for f in getattr(battle, "fighters", {}).values():
        if is_bot(f.roleid):
            _ensure_human_loadout(battle, f, reset_ammo=True)
    return added


def is_bot(roleid: int) -> bool:
    return BOT_ID_BASE < int(roleid or 0) < BOT_ID_BASE + 10_000


# ==========================================================================
# 生化人类 BOT：装备 / 弹量 / 协议
# ==========================================================================
#
# 所有数值来自 Item/Gun/Melee 表与 equipment_audit 的资源清单，策略值是重建
# 实现（见 human.py / weapon_catalog.py）。普通模式、真人装备、英雄 {50: 8001}
# 和僵尸形态都不进入这里。
#
# 战术切换：主/副/近战都来自真实 equipmap 槽位。切换只发 WeaponChange（复用
# 已装备槽位），ScGunChange 仅用于初始装备/ScBorn 后的有限弹量同步；切枪不会
# 重建枪械、不会回满弹。持握/冷却值见 human.MIN_HOLD_SECONDS 等。
def _is_bio_room(battle) -> bool:
    try:
        return int(getattr(battle.room, "gamemode", 0) or 0) in human.BIOCHEM_MODES
    except (TypeError, ValueError):
        return False


def _bot_index(roleid: int) -> int:
    return max(0, int(roleid or 0) - BOT_ID_BASE - 1)


def _is_human_bot(battle, f) -> bool:
    """所有拿枪的 bot 都走这条（弹药系统 + 战术移动）。

    原来这里要求 `_is_bio_room(battle)`，所以**只有生化房的人类 bot** 才用
    `human.AmmoState`（真实射速/弹匣/换弹/散布）；竞技、团队、刀战全部走
    `_profile()` 那条旧路径，开火间隔被写死成 `HUMAN_INTERVAL = 0.9s` ——
    步枪（AK 0.12s）被砍成 7.5 倍慢，狙击（1.15s）反而被加速 1.28 倍。
    现在放开房间限制，僵尸和生化英雄仍然排除在外（他们不吃枪械数据）。
    """
    if not is_bot(getattr(f, "roleid", 0)):
        return False
    bio = getattr(battle, "biochem", None)
    if bio is None:
        return True
    return (not bio.is_zombie(f.roleid)
            and f.roleid not in getattr(bio, "heroes", set()))


def _ammo_states(battle) -> Dict[int, human.AmmoState]:
    states = getattr(battle, "_bot_ammo", None)
    if states is None:
        states = battle._bot_ammo = {}
    return states


def _tactical_states(battle) -> Dict[int, human.TacticalState]:
    states = getattr(battle, "_bot_tactical", None)
    if states is None:
        states = battle._bot_tactical = {}
    return states


def _route_state(battle, roleid: int):
    """Route preference store keyed by roleid (Fighter is __slots__).

    The main coordinator can call ``human.notify_route_state`` on this object
    (or hand its own RouteState to ``human.weapon_preference``).  It only
    records a preference; it never moves or jumps.
    """
    if human.WC is None:
        return None
    table = getattr(battle, "_bot_route", None)
    if table is None:
        table = battle._bot_route = {}
    state = table.get(int(roleid))
    if state is None:
        state = table[int(roleid)] = human.WC.RouteState()
    return state


def route_state(battle, roleid: int):
    """Public main-coordinator hook: get the persistent per-BOT RouteState.

    Usage:
        st = bots.route_state(battle, roleid)
        human.notify_route_state(st, route="parkour", safe=True)
        human.request_mobility_weapon(st, now, duration=1.5)
    This only records a preference; the BOT tactical layer decides when a
    legal WeaponChange may happen.  No movement or jump is performed here.
    """
    return _route_state(battle, roleid)


def _melee_for(f, state) -> Optional[human.MeleeInfo]:
    iid = int((getattr(f, "equipmap", {}) or {}).get(human.POS_MELEE) or 0)
    cached = state.get("melee")
    if cached is not None and int(cached[0]) == iid:
        return cached[1]
    info = human.load_melee(iid) if iid else None
    state["melee"] = (iid, info)
    return info


def _send_weapon_change(battle, f, slot: int) -> None:
    """WeaponChange reuses an already-equipped slot; it never rebuilds a gun.

    `ClientManager.WeaponChange(roleid, weaponpos, bulletnum)` (ClientManager.cs
    :200-221) calls `PlayerData.PullWeapon(weaponpos)` and then
    `ChangeWeapon(roleid, weaponid, AmmoID, bulletnum - ammoInClip, ammoInClip)`
    where `ammoInClip = playerData.GetAmmoInClip(weaponpos)` is the client's
    current magazine.  So the wire field `bulletnum` is the **total** held
    rounds (clip + reserve), not a clip and not a reserve: the client subtracts
    its own clip to obtain reserve (AWeapon.Attach: ammoReserve = reserve,
    ammoInClip = inClip).  Sending only clip or only reserve would rotate the
    displayed reserve to the wrong number.

    ScGunChange (ClientManager.GunChange -> PlayerData.PickWeapon) replaces the
    gun row and is reserved for initial equip/after ScBorn.  A tactical switch
    must use WeaponChange so clip/reserve stay exactly what the server holds.
    """
    from . import battle as B
    st = _ammo_state(battle, f)
    total = 0
    if st is not None and int(slot) in st.slots:
        total = st.total(int(slot))
    battle.send_all(B.ID.WEAPON_CHANGE, roleid=int(f.roleid),
                    weaponpos=int(slot), bulletnum=int(total))


def _ensure_human_loadout(battle, f, reset_ammo: bool = False) -> bool:
    """Apply the biochem human loadout before ScBorn, and on every round reset.

    The same dict is stored in human_equipmap so _next_bio_round restores the
    machine gun instead of an empty/generic loadout.  Ammo is only refilled by
    reset_ammo=True (new round), never by a respawn inside the round.
    """
    if not _is_human_bot(battle, f):
        return False
    gamemode = int(getattr(battle.room, "gamemode", 0) or 0)
    index = _bot_index(f.roleid)
    round_index = int(getattr(battle, "_bot_round_seq", 0) or 0)
    states = _ammo_states(battle)
    # Fast path for the per-tick call: compare against the already-resolved
    # loadout, so no Item/Gun lookup or AmmoState rebuild happens every tick.
    applied = dict(getattr(f, "human_equipmap", {}) or {})
    if (not reset_ammo and int(f.roleid) in states and applied
            and dict(getattr(f, "equipmap", {}) or {}) == applied):
        return True
    loadout = human.equip_for_bot(
        gamemode, index, is_bot=True, is_zombie=False, is_hero=False,
        round_index=round_index, seed=_bot_seed(battle))
    if not loadout:
        # `equip_for_bot` 只给生化房（gamemode 8/10）分配装备，其他模式返回
        # None。这里**沿用 bot 出生时已经拿到的装备**，只为它建一套弹药模型
        # —— 否则竞技/团队的 bot 会因为「没有 loadout」直接卡死不动。
        existing = {int(k): int(v) for k, v in
                    (getattr(f, "equipmap", {}) or {}).items() if int(v or 0) > 0}
        if not existing:
            log.warning("HUMAN-BOT no loadout and no equipment role=%s", f.roleid)
            return False
        loadout = existing
    changed = dict(getattr(f, "equipmap", {}) or {}) != loadout
    f.equipmap = dict(loadout)
    f.human_equipmap = dict(loadout)
    new_state = int(f.roleid) not in states
    if changed or reset_ammo or new_state:
        states[int(f.roleid)] = human.AmmoState.from_loadout(loadout)
    if changed or reset_ammo or new_state:
        (log.info("HUMAN-BOT EQUIP role=%s items=%s ammo_reset=%s",
                 f.roleid, sorted(loadout.items()),
                 bool(reset_ammo or changed or new_state)) if log.isEnabledFor(20) else None)
    return True


def _ammo_state(battle, f) -> Optional[human.AmmoState]:
    states = _ammo_states(battle)
    st = states.get(int(f.roleid))
    if st is None:
        if not _ensure_human_loadout(battle, f):
            return None
        st = states.get(int(f.roleid))
    if st is not None:
        # 【v35】仅 BOT：狙击间隔按模式分档（联赛 1x / 排位 2x / 普通 3x / 生化 2x）。
        st.bot_sniper_scale = _mode_sniper_scale(battle)
        # 【v61】生化 BOT 多给两个弹匣：一局 8 人 + 十几只僵尸，机枪那点
        # 备弹打完就只能端刀跑。`CF_BIO_BOT_MAGS` 可调，0 = 关闭。
        _apply_mag_bonus(st, _bio_mag_bonus(battle))
    return st


def _bio_mag_bonus(battle) -> int:
    """生化 / 生化英雄房给 BOT 额外的弹匣数（默认 2）。"""
    try:
        if int(getattr(battle.room, "gamemode", 0) or 0) not in (8, 10):
            return 0
    except (TypeError, ValueError, AttributeError):
        return 0
    try:
        from ..config import CONFIG as _cfg
        return max(0, int(getattr(_cfg, "bio_bot_extra_mags", 2) or 0))
    except (TypeError, ValueError):
        return 2


def refill_reserves(battle, f) -> None:
    st = _ammo_state(battle, f)
    if st is None:
        return
    # ClientManager.PickupItem calls FillAmmoAll(false) and ReFull(false).
    st.cancel_reload()
    for state in st.slots.values():
        state.reserve = st.full_reserve(state.info)


def _apply_mag_bonus(st, bonus: int) -> None:
    """【v61】按「多 N 个弹匣」给 BOT 补备弹（只补差额，可重复调用）。"""
    bonus = max(0, int(bonus))
    if int(getattr(st, "mag_bonus", 0) or 0) == bonus:
        return
    for state in st.slots.values():
        cap = int(state.info.reserve) + bonus * int(state.info.clip)
        state.reserve = max(0, min(int(state.reserve) + bonus * int(state.info.clip),
                                   cap))
    st.mag_bonus = bonus


# 【v17】补给箱：BOT 拾取与顺路引导 -------------------------------------
def _bot_ground_anchor(nav, phys, here):
    """【v18】给浮空 BOT 找水平最近的合法落点（米坐标 / None）。

    位置 y 抬高超过 1.2m 后 nav.ground() / nav.locate() 会双双失败，
    _grounded_step() 每帧直接 return here —— BOT 永久浮空且不再自主运动，
    force_roam / BOT-UNSTUCK 只换目标、仍走同一函数，救不回来。只在自愈
    时调用，遍历一次网格（几千节点）的开销可以接受。

    【v46】**必须优先同层**。原来只按水平距离排序，在多层图（封锁地铁的
    1 层地铁轨道 y≈0.6 / 地下通道 y≈-3.7）上，轨道上的 BOT 一旦触发自愈
    就会被「正下方」的地下通道节点吸走 —— 客户端看到的就是「瞬移到下面
    地下通道、卡在圆柱里」。现在先只在 |Δy| ≤ 1.5m 的同层节点里找，
    同层一个都没有时，才按**三维距离**兜底（正下方那个点距离至少 4.3m，
    自然排在远处平地之后）。
    """
    try:
        def _valid(p):
            q = tuple(round(v * 100) / 100 for v in p)
            return q if phys.stand_clear(q) and nav.locate(q) is not None else None

        same = []
        other = []
        for k in nav._links:
            p = nav.point(k)
            dy = abs(p[1] - here[1])
            dh = math.hypot(p[0] - here[0], p[2] - here[2])
            if dh > 60.0:
                continue
            if dy <= 1.5:
                same.append((dh, p))
            else:
                other.append((math.sqrt(dh * dh + dy * dy), p))
        same.sort(key=lambda t: t[0])
        for _, p in same[:80]:
            q = _valid(p)
            if q is not None:
                return q
        other.sort(key=lambda t: t[0])
        for _, p in other[:40]:
            q = _valid(p)
            if q is not None:
                return q
    except Exception:
        (log.debug("BOT-GROUND-FIX 找落点失败", exc_info=True) if log.isEnabledFor(10) else None)
    return None


def _bot_box_targets(battle):
    """场上补给箱 -> [(dropid, kind, (x, y, z) 米)]。"""
    bio = getattr(battle, "biochem", None)
    if bio is None:
        return []
    out = []
    for b in (getattr(bio, "boxes", None) or []):
        p = b.get("pos") or {}
        try:
            out.append((int(b["dropid"]), b.get("kind"),
                        (float(p["x"]) / 100.0, float(p["y"]) / 100.0,
                         float(p["z"]) / 100.0)))
        except (KeyError, TypeError, ValueError):
            continue
    return out


def _bot_try_pickup_box(battle, f, zombie: bool) -> bool:
    """BOT 走到本阵营补给箱旁边就吃。

    原来只有**人类 BOT** 在「所有枪备弹都低于一个弹匣」时才顺手捡 ammo 箱
    （且要求跳跃状态为空），僵尸 BOT 完全没有拾取逻辑 —— 所以看起来
    「bot 吃不到补给箱」。放在 tick() 每个 BOT 处理之前，用上一帧的位置
    判定，不受任何分支 continue / 提前 return 影响。
    """
    bio = getattr(battle, "biochem", None)
    if bio is None:
        return False
    here = _pos(f)
    if here is None:
        return False
    want = "bio" if zombie else "ammo"
    for dropid, kind, p in _bot_box_targets(battle):
        if kind != want or abs(here[1] - p[1]) > 1.0:
            continue
        if (here[0] - p[0]) ** 2 + (here[2] - p[2]) ** 2 <= 2.0 ** 2:
            try:
                return bio.take_box(dropid, int(f.roleid)) is not None
            except Exception:
                log.exception("BOT-BOX 拾取异常 role=%s", f.roleid)
                return False
    return False


def _bot_seek_box(battle, f, state, zombie: bool, now: float):
    """给 BOT 一个「顺路去捡补给箱」的目标点（米坐标 / None）。

    只为**没有正在追的敌人**或**贴脸 8m 内**的箱子改目的地，避免 BOT
    为了捡箱子放弃交战；刚捡过之后给 3 秒正常行动时间。
    """
    try:
        rng = float(getattr(CONFIG, "bot_box_seek_range", 18) or 0)
    except (TypeError, ValueError):
        rng = 18.0
    if rng <= 0:
        return None
    if now < float(state.get("box_until", 0) or 0):
        return None
    here = _pos(f)
    if here is None:
        return None
    want = "bio" if zombie else "ammo"
    boxes = [(d, p) for d, k, p in _bot_box_targets(battle) if k == want]
    if not boxes:
        state.pop("box_dest", None)
        return None
    engaged = state.get("lock_target") is not None
    best = None
    for _d, p in boxes:
        if abs(here[1] - p[1]) > 1.0:
            continue
        dd = math.hypot(here[0] - p[0], here[2] - p[2])
        if dd > (8.0 if engaged else rng):
            continue
        if best is None or dd < best[0]:
            best = (dd, p)
    state["box_dest"] = best[1] if best else None
    return state["box_dest"]


def _spawn_fire_locked(battle, rid, now) -> bool:
    """【v30】出生/复活后 ``bot_spawn_fire_lock`` 秒内禁止开火。

    只锁「扣扳机」：移动、寻路、转身瞄准全部照常，所以 BOT 会端着枪
    跑出来但 1 秒内不放枪 —— 给刚复活的玩家一个喘息窗口。
    """
    from ..config import CONFIG
    try:
        lock = float(getattr(CONFIG, "bot_spawn_fire_lock", 0.0) or 0.0)
    except (TypeError, ValueError):
        lock = 0.0
    if lock <= 0.0:
        return False
    try:
        marks = getattr(battle, "_bot_spawn_at", None)
        if not marks:
            return False
        born = float(marks.get(int(rid), -1e18))
    except (TypeError, ValueError):
        return False
    return (float(now) - born) < lock


def prepare_born(battle, f) -> Tuple[int, int]:
    """battle.born() hook: equip before ScBorn and return reserve counts.

    ScBorn.mainbullet/minorbullet feed PlayerData.Apply -> FillAmmoAll; they are
    reserve counts, not clip+reserve.  Returning -1 lets native FillAmmoAll use
    Gun.ammo-clip for non-BOT players (unchanged).
    """
    if not is_bot(getattr(f, "roleid", 0)):
        return -1, -1
    # 【v30】记下出生时刻，供 _spawn_fire_locked 判定禁火窗口。
    try:
        import time as _t
        _marks = getattr(battle, "_bot_spawn_at", None)
        if _marks is None:
            _marks = battle._bot_spawn_at = {}
        _marks[int(f.roleid)] = _t.monotonic()
    except Exception:
        pass
    if not _is_human_bot(battle, f):
        return -1, -1
    bio = _is_bio_room(battle)
    if not bio:
        # 【v21.2】非生化房（竞技 / SOLO / 团队）的 BOT 复活时必须把弹药补满：
        # 之前这里 early-return -1，于是服务端 AmmoState 沿用死亡前已经打空的
        # 弹药，而客户端因 ScBorn(mainbullet=-1) 走 FillAmmoAll 显示满弹 ——
        # 两端错位 -> weapon_empty=True -> 复活后永远不开枪。每次出生都重建
        # 满弹 AmmoState 即可让服务端 / 客户端一致。生化房维持原行为（on_round
        # 已经在回合开始补满，prepare_born 不重复 reset_ammo）。
        if not _ensure_human_loadout(battle, f, reset_ammo=True):
            return -1, -1
    else:
        if not _ensure_human_loadout(battle, f):
            return -1, -1
    st = _ammo_state(battle, f)
    if st is None:
        return -1, -1
    done = st.update(time.monotonic())
    if done is not None:
        _send_reload_stop(battle, f, done[0], done[1])
    return st.born_reserve()


def current_born_reserve(battle, f) -> Tuple[int, int]:
    """Read-only reserve for snapshot ScBorn of an already spawned BOT."""
    if not is_bot(getattr(f, "roleid", 0)) or not _is_bio_room(battle):
        return -1, -1
    st = _ammo_states(battle).get(int(f.roleid))
    return st.born_reserve() if st is not None else (-1, -1)


def on_round(battle) -> None:
    """battle._next_bio_round() hook: restore every human BOT's loadout.

    This runs before _spawn_prepared_bots(), so the following ScBorn carries
    the machine gun in equipmap; equipment is never changed only server-side.
    """
    if not _is_bio_room(battle):
        return
    # Advance the deterministic round seed BEFORE re-equipping, so a new round
    # gets the next catalog category/variant.  Ammo is reset only here.
    battle._bot_round_seq = int(getattr(battle, "_bot_round_seq", 0) or 0) + 1
    for f in list(getattr(battle, "fighters", {}).values()):
        if is_bot(f.roleid) and _is_human_bot(battle, f):
            _ensure_human_loadout(battle, f, reset_ammo=True)
    battle._bot_tactical = {}
    battle._bot_route = {}
    battle._bot_state = {}
    # 【v57】新回合重新洗牌：上一局的抱团结果不能带过来，否则开局第一次
    # 分组会沿用旧队伍（有人已经换出生点了）。
    squad.forget(battle)


def _send_reload_start(battle, f, slot: int) -> None:
    from . import battle as B
    battle.send_all(B.ID.SC_FILL_BULLET,
                    roleid=int(f.roleid), weaponpos=int(slot))


def _send_reload_stop(battle, f, slot: int, rounds: int) -> None:
    from . import battle as B
    type_id = getattr(B.ID, "SC_FILL_BULLET_STOP", 1441946)
    battle.send_all(type_id, roleid=int(f.roleid),
                    weaponpos=int(slot), finishtimes=int(rounds))


def _send_gun_state(battle, f, slot: int, viewerid: int = 0) -> None:
    """ScGunChange(roleid, weaponpos, gunid, inclip, reserve, reservefull).

    ClientManager.GunChange (ClientManager.cs:1221-1235) calls
    PlayerData.PickWeapon + Warrior.PickWeapon, so it both replaces the gun in
    that slot *and* activates it as the held weapon (AArsenal.Pick ->
    AGun.Initialize).  WeaponChange is not needed; sending both would rebuild
    the gun model twice.  For a non-active slot it still updates that slot's
    PlayerData clip/reserve via AGun.Equipped -> DataPool.AmmoChanged.
    """
    from . import battle as B
    st = _ammo_state(battle, f)
    if st is None or slot not in st.slots:
        return
    s = st.slots[slot]
    fields = dict(roleid=int(f.roleid), weaponpos=int(slot),
                  gunid=int(s.info.itemid), bulletnum=int(s.clip),
                  sumbulletnum=int(s.reserve),
                  maxbulletnum=int(s.info.reserve))
    if viewerid and hasattr(battle, "send_to_role"):
        battle.send_to_role(int(viewerid), B.ID.SC_GUN_CHANGE, **fields)
    else:
        battle.send_all(B.ID.SC_GUN_CHANGE, **fields)


def _send_gun_snapshot(battle, f, viewerid: int = 0) -> None:
    """Re-sync both slots after a ScBorn.

    PlayerData.Apply -> Init -> FillAmmoAll(all:true) always sets
    ammo_main_clip/ammo_minor_clip = Gun.clip (PlayerData.cs:332-359), so the
    client would show a full magazine even when the server has fewer rounds.
    Send the non-active slot first (it also stores its clip/reserve) and the
    active slot last so the held weapon ends up correct.
    """
    st = _ammo_state(battle, f)
    if st is None:
        return
    order = [s for s in (human.POS_VICE_GUN, human.POS_MAIN_GUN)
             if s != st.active and s in st.slots]
    order.append(st.active)
    for slot in order:
        _send_gun_state(battle, f, slot, viewerid=viewerid)


def after_born(battle, f, viewerid: int = 0) -> None:
    """battle.born()/_snapshot_born_to() hook: correct the auto-full clip."""
    if not is_bot(getattr(f, "roleid", 0)) or not _is_bio_room(battle):
        return
    if not _is_human_bot(battle, f):
        return
    if int(f.roleid) not in _ammo_states(battle):
        return
    _send_gun_snapshot(battle, f, viewerid=viewerid)


_PROP_CACHE: Dict[int, Dict[str, Any]] = {}


def _zombie_prop(actorid: int) -> Dict[str, Any]:
    key = int(actorid or 0)
    prop = _PROP_CACHE.get(key)
    if prop is None:
        from .biochem import bio_property_of
        prop = bio_property_of(key) or {}
        _PROP_CACHE[key] = prop
    return prop


def _bot_threats(battle, f, nav, colliders, here) -> List[human.Threat]:
    """All zombie threats, with native run speed and real visibility."""
    from .navigation import distance
    bio = getattr(battle, "biochem", None)
    out: List[human.Threat] = []
    for g in battle.fighters.values():
        if g.roleid == f.roleid or not getattr(g, "born", False):
            continue
        if float(getattr(g, "hp", 0) or 0) <= 0:
            continue
        if bio is not None:
            # 生化房：只有僵尸是威胁
            if not bio.is_zombie(g.roleid):
                continue
            # 生化幽灵「雾化 / 魅影雾化」：fogDetect=1 期间从人类 BOT 的
            # 索敌列表里隐身（客户端只播了雾特效，服务端原来照样锁定）。
            try:
                if bio.skill_fog(int(g.roleid)):
                    continue
            except Exception:
                pass
        elif _side_of(battle, g) == _side_of(battle, f):
            # 非生化房：所有敌对阵营的人都算威胁
            continue
        gp = _pos(g)
        if gp is None:
            continue
        prop = _zombie_prop(getattr(g, "actorid", 0))
        out.append(human.Threat(
            roleid=int(g.roleid), pos=gp, dist=distance(here, gp),
            visible=_visible(colliders, here, gp),
            speed=float(prop.get("runSpeed") or 0.0)))
    return out


def _hear_position(battle, f, here):
    """【v8】官方 Lv4 hearRange：20m 内最近的一声枪响的位置。

    只用来「转向 / 前去查看」，**不等于看见** —— 隔墙照样不能开枪，
    交给 `_visible` 把关。没有声源返回 None。
    """
    from ..config import CONFIG
    try:
        hear = _mode_hear_range(battle)
        # 【v37】生化 10 秒，其余模式 1.5 秒。
        if _is_bio_room(battle):
            mem = float(getattr(CONFIG, "bot_hear_mem_bio", 10.0) or 0.0)
            # 【v47】生化房的**人类 BOT** 与联赛对齐（听距 15m）；僵尸 BOT 仍用
            # 40m「嗅觉」，否则僵尸追人会明显变钝（那不是用户要的）。
            _bio = getattr(battle, "biochem", None)
            if _bio is not None and not _bio.is_zombie(int(f.roleid)):
                hear = min(hear, float(
                    getattr(CONFIG, "bot_hear_league", 15.0) or 15.0))
        else:
            mem = float(getattr(CONFIG, "bot_hear_memory", 1.5) or 0.0)
    except (TypeError, ValueError):
        return None
    if hear <= 0 or mem <= 0 or here is None:
        return None
    shots = getattr(battle, "_last_shot_at", None) or {}
    if not shots:
        return None
    try:
        now = time.monotonic()
    except Exception:
        return None
    mine = _side_of(battle, f)
    best, bd = None, None
    for rid, at in list(shots.items()):
        try:
            if now - float(at or 0.0) > mem:
                continue
        except (TypeError, ValueError):
            continue
        g = battle.fighters.get(int(rid))
        if g is None or int(g.roleid) == int(f.roleid):
            continue
        if not getattr(g, "born", False) or float(getattr(g, "hp", 0) or 0) <= 0:
            continue
        if _side_of(battle, g) == mine:
            continue
        gp = _pos(g)
        if gp is None:
            continue
        d = math.sqrt(sum((a - b) ** 2 for a, b in zip(here, gp)))
        if d > hear:
            continue
        if bd is None or d < bd:
            best, bd = tuple(gp), d
    return best


def _zombie_skill(battle, f, now) -> None:
    # 节流：冷却期间 `use_skill` 会一直返回 1，不必每 tick 都试。
    _gate = getattr(battle, "_bot_skill_gate", None)
    if _gate is None:
        _gate = battle._bot_skill_gate = {}
    if now - float(_gate.get(int(f.roleid), -1e9)) < 0.5:
        return
    _gate[int(f.roleid)] = now
    """【v8】幽灵 BOT 自动放技能：视线内有敌人就放（用户指定的规则）。

    冷却完全交给 `biochem.skill_cd`（BioSkill.cd = 5s，v8 从 15s 降下来）。
    技能持续期间不重复放；冷却未到时 `use_skill` 自己会拒绝。
    """
    bio = getattr(battle, "biochem", None)
    if bio is None:
        return
    try:
        if not bio.is_zombie(int(f.roleid)):
            return
        if bio.active_skill(int(f.roleid)):
            return
        from .biochem import bio_skill_of
        own = bio_skill_of(int(getattr(f, "actorid", 0) or 0))
        sid = int((own or {}).get("id") or 0)
        if sid <= 0:
            return
        res = bio.use_skill(int(f.roleid), sid)
        if res == 0:
            (log.info("ZOMBIE-BOT SKILL role=%s skill=%s", f.roleid, sid) if log.isEnabledFor(20) else None)
    except Exception:
        (log.debug("zombie bot skill failed role=%s", f.roleid, exc_info=True) if log.isEnabledFor(10) else None)


# ==========================================================================
# 服务端驱动的人机大脑（CF_BOTS_DRIVE=1，默认开）
# ==========================================================================
#
# 为什么要在服务端做：客户端自带的 `Robot` 心跳只有一个入口
# （`AArsenal` 的 TPS 上枪分支 -> `Robot.EquipWeapon` -> `Startup`），
# 真机实测服务端把 `ScManageAI` 按正确顺序发过去也不会起步（HANDOFF 第九轮）。
# 而客户端本来就有一套**处理远程真人**的机制，服务端完全可以照它来驱动：
#
#     ClientManager.RoleStatusSync(ScRoleStatusSync)   // 位置：>8m 直接 teleport
#     ClientManager.Shoot(ScShoot)                     // 弹道 + 掉血 + 死亡表现
#
# 所以本模块做的事只有一件：**把机器人当成一个"由服务端操控的远程玩家"** ——
# 每 tick 推位置、按交战距离开一枪，枪走 `battle.settle_shoot`，
# 和玩家上报的 CsShoot 共用同一条伤害/击杀/感染裁决链。
#
# 数值来源（不靠猜）：
#   僵尸 runSpeed / range / atkSpeed / damage  <- BioProperty.json（runSpeed 7.5~8.2、
#     range 2.7、atkSpeed 0.45）；`sd` 超过 range 会被 damage.resolve_shoot 忽略，
#     所以爪击必须真的贴脸。
#   人类的 6.0 m/s、35m 交战距离、0.9s 节奏 = **重建值**（包内没有"玩家移动速度"
#     这类可直接引用的表），只影响观感，不参与任何官方数值。
#   生化 8/10 人类 BOT 已改走 human.py：Gun.shootSpeed 作为射击间隔、Gun.clip/
#     ammo 作为有限弹量。下面的 0.9s 只保留给普通模式的旧路径。

HUMAN_SPEED = 6.0        # 米/秒（重建值）
HUMAN_RANGE = 35.0       # 米：枪械有效交战距离（重建值）
HUMAN_KEEP = 12.0        # 米：压到这个距离就停下开火（重建值）
HUMAN_INTERVAL = 0.9     # 秒：普通模式旧路径（生化走 Gun.shootSpeed）
# 【v63】1.9 新增的两张图在 `parkour_routes_181.json.gz` 里**没有烘焙路线**
# （实测只有 181 版老图）。`parkour.plan()` 是在运行时按地板三角形现算
# 落点，火车工厂是多层地形（车厢顶 y≈3.9 / 轨道 y≈-2.2），算出来的落点
# 与客户端实际几何对不上，BOT 一跳就被推走 —— 用户实拍「复活后瞬移出去、
# 过程中随机瞬移」。这两张图禁用主动跳跃，只保留贴地寻路。
NO_PARKOUR_SCENES = frozenset(("S_huochezhan", "S_bianmaocheng"))
# Reconstructed practice BOT tuning. Player weapons use the original tables.
PISTOL_REACTION = 0.7
PISTOL_INTERVAL = 0.95
PISTOL_KEEP = 6.0
ZOMBIE_KEEP_RATIO = 0.6  # 僵尸要贴到 range 的 60% 以内才爪击

# 【v55】「贴上去了」的同层容差。超过这个高差就必须走可走路径核实，
# 否则会出现「僵尸在站台边缘、人类在下面的轨道里、3D 距离 1.5m」→
# 停步干瞪眼（用户实拍）。0.6 与 `_grounded_step` 的 STEP_UP 对齐。
ENGAGE_LEVEL_TOL = 0.6


def _direct_drop(nav, colliders, here, dest, max_span=3.2):
    """目标在**下一层**且中间没有栏杆时，返回落点；否则 None。

    为什么要单独判一次：`next_waypoint` 只会给「沿可走网格」的下一步，
    站台到轨道那一层的正规入口是楼梯（地铁要绕三十米），于是僵尸会在
    站台边缘跟着下面的人走一路。`_grounded_step` 的 `STEP_DOWN=1.2`
    本来就允许直接落下去，这里只是一句话把这一步从"绕路"改成"跳下去"。

    条件都取保守值：落差 0.45~1.2 m、水平 ≤3.2 m、落点必须踩在地板上、
    且从站位到落点 `walk_clear` 通（有护栏/玻璃就不跳）。
    """
    if nav is None or colliders is None or dest is None:
        return None
    try:
        drop = here[1] - dest[1]
    except (TypeError, ValueError, IndexError):
        return None
    if not (0.45 <= drop <= STEP_DOWN):
        return None
    if math.hypot(dest[0] - here[0], dest[2] - here[2]) > max_span:
        return None
    ground = nav.ground(dest) if hasattr(nav, 'ground') else None
    if ground is None or abs(ground[1] - dest[1]) > 1.0:
        return None
    landing = (ground[0], ground[1], ground[2])
    if not colliders.walk_clear(here, landing):
        return None
    # 落点必须**落在寻路网格上**：地铁轨道床有很多格子被铁轨/道具占着，
    # 掉进去就再也走不动（`_grounded_step` 每一步都会被 `clear` 否掉）。
    # 宁可走楼梯，也不要把 BOT 送进这种口袋。
    key = _nav_key(nav, landing, max_dy=0.8, radius=1)
    if key is None:
        return None
    here_key = _nav_key(nav, here, max_dy=2.6, radius=4)
    comp = getattr(nav, 'component', None)
    if isinstance(comp, dict) and here_key is not None and \
            comp.get(key) != comp.get(here_key):
        return None
    return landing


def _descent_point(nav, colliders, here, dest, max_span=3.2, near=4.0):
    """目标在下一层、但**一步跳不到**（水平超过 max_span）时，先走到朝它
    方向最近的下沉边缘。

    这是用户截图里那条「红波浪线」的直接成因：站台整条边缘都能下到轨道，
    但老逻辑只认「目标是否在一步之内」，一步之外就全交给走廊规划 —— 而
    站台→轨道的正规入口是 z≈-31 的楼梯，于是僵尸沿着站台往南跑三十米，
    目标稍微一动，走廊重算又掉头往北，表现就是站台上原地前后抽。

    这里沿「自己→目标」方向采样 1.5~7m，取第一个「地面比脚下低 0.45~1.2m
    且落点在寻路网格上」的点当这一帧的目标。走到边缘后 `STEP_DOWN=1.2`
    自然就把人放下去，不需要真的跳。
    """
    if nav is None or colliders is None or dest is None:
        return None
    try:
        drop = here[1] - dest[1]
        dxz = math.hypot(dest[0] - here[0], dest[2] - here[2])
    except (TypeError, ValueError, IndexError):
        return None
    if not (0.45 <= drop <= STEP_DOWN):
        return None
    if dxz <= max_span:            # 一步之内：交给 `_direct_drop`
        return None
    ux, uz = (dest[0] - here[0]) / dxz, (dest[2] - here[2]) / dxz
    here_key = _nav_key(nav, here, max_dy=2.6, radius=4)
    comp = getattr(nav, 'component', None)

    weak = None                  # 落点不在网格上时的备选（最后才用）

    def drop_at(p):
        nonlocal weak
        gnd = nav.ground(p) if hasattr(nav, 'ground') else None
        if gnd is None:
            return None
        if not (0.45 <= here[1] - gnd[1] <= STEP_DOWN):
            return None           # 还是同层
        if not colliders.walk_clear(here, p):
            return None           # 中间有栏杆 / 玻璃
        # 落点必须在网格上（掉进铁轨之间那种无网格口袋就出不来了）。
        # 半径给到 2 格：轨道床节点在站台投影下并不总是正对脚下那一格，
        # `radius=1` 实测在 z≈14 之后整段都找不到。
        key = _nav_key(nav, gnd, max_dy=1.0, radius=2)
        if key is None:
            if weak is None:
                weak = (gnd[0], gnd[1], gnd[2])
            return None
        if (isinstance(comp, dict) and here_key is not None
                and comp.get(key) != comp.get(here_key)):
            return None           # 掉下去就回不来，宁可走楼梯
        # 落点必须在**目标附近**（同层 10m 内）。站台上随便找条边跳下去，
        # 落到轨道另一头再沿轨道跑二十米，比绕楼梯还慢 —— 而且地铁轨道
        # z>15 那段头顶只有 0.44m 净空（车顶/台阶压着），本来就没有节点，
        # 跳进去就是死路。宁可老老实实走楼梯。
        if math.hypot(gnd[0] - dest[0], gnd[2] - dest[2]) > 10.0:
            return None
        # 落点必须**对齐到网格节点**：地铁轨道层的节点只到 x=2（x=3 和
        # x=-1 是两条没有任何节点的「缝」，站上去就再也走不动）。直接用
        # 脚下那块地的坐标会正好落在缝里 —— 这是「跳下去了却卡在轨道边」
        # 的成因。
        nk = nav.point(key)
        return (nk[0], nk[1], nk[2])

    def scan():
        # ① 先看正前方（目标方向）4m 内有没有边缘 —— 有就最自然。
        for step in (1.5, 2.0, 2.5, 3.0, near):
            hit = drop_at((here[0] + ux * step, here[1], here[2] + uz * step))
            if hit is not None:
                return hit
        # ② 没有就**就近找**：按「半径由近到远、角度由接近目标方向到背离」扫一圈。
        #    不能沿目标方向一路斜着采样 —— 站台很宽，目标在 15m 外的轨道时
        #    会变成「沿站台斜着跑 11m」，那正是用户截图里那条波浪线。
        #    真人做法是垂直走到最近的边缘跳下去，再到下面沿轨道追。
        base = math.atan2(uz, ux)
        dirs = []
        for k in range(16):
            ang = k * math.pi / 8
            diff = abs(math.atan2(math.sin(ang - base), math.cos(ang - base)))
            dirs.append((diff, ang))
        dirs.sort()
        for r in (2.0, 3.0, 4.0, 5.0, 6.0, 8.0):
            for _, ang in dirs:
                hit = drop_at((here[0] + math.cos(ang) * r, here[1],
                               here[2] + math.sin(ang) * r))
                if hit is not None:
                    return hit
        return None

    hit = scan()
    if hit is not None:
        return hit
    # ③ 整条边缘都找不到「落在网格上」的落点：宁可掉进一个暂时没节点的
    #    格子（v55 起 `next_waypoint` 在 locate 失败时会投影+物理推进，
    #    能自己爬出来），也不要沿着站台跑三十米去楼梯 —— 用户看到的
    #    「波浪线」就是后者。
    return weak


def _walk_span(nav, a, b):
    """两点沿**可走网格**的路径长度；不可达返回 None。

    这是区分「真的站在旁边」和「隔着一层玻璃/一个落差」的唯一可靠办法：
    地铁图站台边缘上下 1~2 m 的两个人，3D 距离很小，但走廊要绕楼梯走
    30 m 才到得了。
    """
    from .navigation import distance
    ka=_nav_key(nav,a); kb=_goal_key(nav,b)
    if ka is None or kb is None:return None
    comp=getattr(nav,'component',None)
    if isinstance(comp,dict) and comp.get(ka)!=comp.get(kb):return None
    keys=nav.corridor(ka,kb)
    if not keys:return None
    pts=[nav.point(k) for k in keys]
    return sum(distance(pts[i],pts[i+1]) for i in range(len(pts)-1))


def _can_engage(nav, here, target_pos, keep, dist, state=None, now=0.0):
    """现在能不能**真的**贴上去（不是隔着站台落差/楼层）。

    True  = 可以按原来的 keep 距离停步（同层，或沿路确实只差几步）
    False = 停不得，得继续沿走廊绕过去
    结果按 0.25 s 缓存在 state 里：走廊 A* 不便宜，而干瞪眼时每 tick 都会问。
    """
    if target_pos is None:return True
    try:
        dy=abs(float(target_pos[1])-here[1])
    except (TypeError,ValueError):
        return True
    if nav is None:return True
    if dy<=ENGAGE_LEVEL_TOL:
        # 同层也可能被站台护栏/玻璃挡住：直连能走就算真贴上，
        # 直连不通再交给下面的走廊长度判断（不通就是绕得到但远）。
        try:
            if nav.clear(here,target_pos):return True
        except (AttributeError,TypeError):
            return True
    cached=state.get('engage_chk') if isinstance(state,dict) else None
    if cached is not None and now-float(cached[0])<0.25:
        return bool(cached[1])
    span=_walk_span(nav,here,target_pos)
    ok=True
    if span is not None:
        ok=span<=max(float(keep)*1.5+2.0,float(dist)*1.5+2.0)
    if isinstance(state,dict):state['engage_chk']=(now,bool(ok))
    return ok

ZOMBIE_FALLBACK = (2.7, 7.5, 0.6)   # range / speed / interval 兜底


def _v3(x: float, y: float, z: float) -> Dict[str, int]:
    """世界坐标 -> 线上 Vec3（short，×100）。

    【v63】必须钳到 short 范围：`battle._vec3` 早就有这道保护，这里漏了。
    极端 dt（tick 被系统延迟后压到 1ms）时 `_step` 算出的 speed 会放大到
    (位移/dt)×100 > 32767，`proto.encode` 用 `struct.pack('<h')` 会直接抛
    `error: 'h' format requires ...` → 整条 `ScRoleStatusSync` 发不出去，
    全场 BOT 位置冻结一帧、下一帧又跳回来（表现就是随机瞬移）。
    """
    def q(v):
        try:
            n = int(round(float(v) * 100))
        except (TypeError, ValueError):
            n = 0
        return max(-32768, min(32767, n))
    return {"x": q(x), "y": q(y), "z": q(z)}


def _pos(f) -> Optional[Tuple[float, float, float]]:
    p = getattr(f, "syncpos", None)
    if not p:
        return None
    return (float(p[0]), float(p[1]), float(p[2]))


def _side_of(battle, f) -> int:
    """敌我划分：生化看"是不是僵尸"，SOLO 看谁都不是队友，其余看 side。"""
    bio = getattr(battle, "biochem", None)
    if bio is not None:
        return 3 if bio.is_zombie(f.roleid) else 1
    # 【v19】SOLO 战（mode4）是 FFA。damage.same_team() 对 mode4 本来就恒
    # 返回 False（客户端 DataPool.IsBothSides: GameMode != 4），伤害侧早已
    # 全员可打；但 BOT 侧原来仍按 side=1/2 分队友 —— 这就是「SOLO 的 BOT
    # 还是团队逻辑」的根因。返回每人唯一的值，复用所有既有 == 比较，
    # 一处改动同时覆盖威胁列表 / 听觉 / 队友避让 / 目标选择。
    if int(getattr(getattr(battle, "room", None), "gamemode", 0) or 0) == 4:
        return int(f.roleid)
    return 1 if int(f.side or 1) == 1 else 2


def _profile(battle, f) -> Tuple[float, float, float, float]:
    """(交战距离, 移动速度, 开火间隔, 压近距离)。"""
    bio = getattr(battle, "biochem", None)
    if bio is not None and bio.is_zombie(f.roleid):
        from .biochem import bio_property_of
        prop = bio_property_of(f.actorid) or {}
        rng = float(prop.get("range") or ZOMBIE_FALLBACK[0])
        spd = float(prop.get("runSpeed") or ZOMBIE_FALLBACK[1])
        # ABiochemHand.FireTask holds Firing for atkRate + atkSpeed;
        # ShootFreq additionally gates requests at atkRate + .1 seconds.
        rate = float(prop.get("atkRate") or .15)
        itv = max(rate + float(prop.get("atkSpeed") or .45), rate + .1)
        # 爪击节奏下限（默认 1.2s）。伤害不动，只把「1.2 秒被贴死」拖开。
        from ..config import CONFIG as _CFG
        _claw = float(getattr(_CFG, "bot_claw_interval", 0.0) or 0.0)
        if _claw > 0:
            itv = max(itv, _claw)
        # 技能对移速的影响（米/秒 平点，和客户端 Warrior 同口径）：
        # 狂暴 +2、刚体 -2（biochem_steel_speed_minus）、雾化 -fogSpeedMinus。
        try:
            spd = max(1.0, spd + bio.skill_speed_delta(int(f.roleid)))
        except Exception:
            pass
        return rng, spd, max(0.2, itv), rng * ZOMBIE_KEEP_RATIO
    if bio is not None and f.roleid in getattr(bio,'heroes',set()):
        # Hero conversion replaces the gun with 8001. The old 12m gun keep
        # distance made sword heroes retreat forever outside their 2.7m reach.
        melee=damage._table('Melee').get(int(f.equipmap.get(50) or 0)) or {}
        if melee:
            rng=float(melee['range']);interval=float(melee['speed'])
            return rng,7.0,interval,rng*.6
    slot, itemid = damage.active_weapon(f)
    reach = damage.melee_range(slot, itemid)
    if reach is not None:
        melee = damage._table("Melee").get(itemid) or {}
        return reach, HUMAN_SPEED, float(melee.get("speed") or HUMAN_INTERVAL), reach * 0.65
    limit = getattr(battle.room, "equiplimitid", 0)
    if limit == special_modes.PISTOL and slot == human.POS_VICE_GUN:
        gun = damage._table("Gun").get(itemid) or {}
        return float(gun.get("effectiveRange") or 0), HUMAN_SPEED, PISTOL_INTERVAL, PISTOL_KEEP
    if limit:
        from . import grenades
        if f.weaponpos == 41:
            reach = float(damage.grenade_row(itemid)["blastRange"])
            return reach, HUMAN_SPEED, float(grenades.hand_launcher()["shootFreq"]), reach * 0.7
    return HUMAN_RANGE, HUMAN_SPEED, HUMAN_INTERVAL, HUMAN_KEEP


def _pick_target(battle, f, nav=None, colliders=None, prev=None):
    """同阵营不算，死人不算，没位置的不算；取最近的一个。

    `prev` 参数保留只为兼容调用方，**v13 起不再生效**：上一版靠它做
    「目标粘性」，结果 BOT 会锁住站在这条路尽头的人、却绕另一条路过去，
    撞着墙一直顶（用户实测）。目标选择回到「谁最近打谁」。

    返回 (target, dist)；没有可打的目标时返回 (None, None)。
    """
    me = _side_of(battle, f)
    here = _pos(f)
    if here is None:
        return None, None
    origin=nav.locate(here) if nav is not None else None
    bio = getattr(battle, 'biochem', None)
    zombie = bio is not None and bio.is_zombie(f.roleid)
    hero = bio is not None and f.roleid in getattr(bio,'heroes',())
    best, bd = None, None
    fallback, fbd = None, None
    for g in battle.fighters.values():
        if g.roleid == f.roleid or not g.born or g.hp <= 0:
            continue
        if _side_of(battle, g) == me:
            continue
        gp = _pos(g)
        if gp is None:
            continue
        d = math.sqrt(sum((a - b) ** 2 for a, b in zip(here, gp)))
        if nav is not None:
            dest=nav.locate(gp)
            connected=(origin is not None and dest is not None
                       and nav.component[origin[0]]==nav.component[dest[0]])
            graph=getattr(nav,'parkour_routes',None)
            if (not connected and graph is not None and origin is not None and dest is not None
                    and (hero or (zombie and gp[1] - here[1] > .35))):
                connected=graph.can_reach(nav.component[origin[0]],nav.component[dest[0]])
            if not connected:
                # A visible target across a gap can still be shot. Otherwise
                # choose a reachable enemy instead of chasing an isolated roof.
                if d>_profile(battle,f)[0] or not _visible(colliders,here,gp):
                    # 幽灵 / 英雄追不可达的高处目标：记一个「最近敌人」兜底。
                    # 否则全场目标都在孤岛站台上时，幽灵一个都锁不到 -> 无目标
                    # 巡逻，而巡逻点同样只在当前 component 里找，直接卡死在
                    # 原地（用户反馈「幽灵 BOT 全僵在低处」）。
                    if zombie or hero:
                        if fbd is None or d < fbd:
                            fallback, fbd = g, d
                    continue
        if bd is None or d < bd:
            best, bd = g, d
    # 没有可达/可见目标时，退回最近敌人（哪怕在不可达的高处），至少让 BOT
    # 朝它脚下移动，而不是停在原地当雕像。
    return (best, bd) if best is not None else (fallback, fbd)


def _turn_towards(f, want_yaw: float, dt: float,
                  dist: Optional[float] = None) -> float:
    """把 BOT 的朝向按 `bot_turn_speed` 限速转过去，返回当前朝向（弧度）。

    朝向单独存在 `f._bot_yaw` 上（`syncpos` 只发位置）。限速之后
    「目标在背后 -> 先转身 -> 才能开火」这件事才有时间成本，
    否则 BOT 每帧瞬间面向目标，等于背后长眼睛。
    """
    from ..config import CONFIG
    try:
        _fast = math.radians(max(1.0, float(
            getattr(CONFIG, "bot_turn_speed", 180.0))))
        _track = math.radians(max(1.0, float(
            getattr(CONFIG, "bot_turn_speed_track", 45.0))))
        _snap = float(getattr(CONFIG, "bot_turn_snap_deg", 30.0))
        _ref = float(getattr(CONFIG, "bot_turn_track_range", 10.0) or 0.0)
        _cap = math.radians(max(1.0, float(
            getattr(CONFIG, "bot_turn_track_max", 120.0) or 120.0)))
    except (TypeError, ValueError):
        _fast, _track, _snap = math.radians(180.0), math.radians(45.0), 30.0
        _ref, _cap = 10.0, math.radians(120.0)
    cur = getattr(f, "_bot_yaw", None)
    if cur is None:
        _set_yaw(f, want_yaw)
        return float(want_yaw)
    diff = (float(want_yaw) - float(cur) + math.pi) % (2.0 * math.pi) - math.pi
    # 【v28】两段式：大角度快转（被人从侧后方打时要能回头），
    # 进入 snapshot 角以内切慢速跟踪（跟枪不再像自瞄吸附，玩家横移能甩掉）。
    # 【v40】跟踪速度按距离自适应：45°/s 是按「10m 处 7m/s 横移」标定的，
    # 目标的角速度 ∝ 1/距离，固定 45°/s 在 3~5m 只剩半个身位就追不上，
    # 枪口偏 30~100° 时连射的子弹全打在墙上（贴脸冲锋枪/机枪打不中人）。
    # 现在 `rate = 45 × 10/距离`，上限 120°/s；10m 及以外完全不变，
    # 3m 内仍低于贴脸绕圈所需的 133°/s，所以不是自瞄吸附。
    _track_eff = _track
    if dist is not None and _ref > 0:
        try:
            _d = max(_ref * 0.375, float(dist))
            _track_eff = min(_cap, _track * (_ref / _d))
        except (TypeError, ValueError):
            _track_eff = _track
    rate = _fast if abs(math.degrees(diff)) > _snap else max(_track, _track_eff)
    step = rate * max(0.0, float(dt))
    if abs(diff) <= step or step <= 0:
        _set_yaw(f, want_yaw)
    else:
        _set_yaw(f, float(cur) + math.copysign(step, diff))
    return float(getattr(f, "_bot_yaw", want_yaw) or 0.0)


def _set_yaw(f, yaw: float) -> None:
    """写 BOT 朝向。

    `Fighter` 是 `__slots__` 类，漏注册字段时赋值会抛 `AttributeError`，
    而这个函数在**每一个** bot 每一步移动里都会被调用 —— 一旦抛出去，
    整条 tick 就断了，全场 bot 一起僵在原地（上一版就是这么翻车的）。
    所以这里吞掉异常并按无朝向处理：转身失效好过整局不动。
    """
    try:
        f._bot_yaw = float(yaw)
    except AttributeError:
        (log.debug("BOT 朝向字段缺失，跳过转身限速 role=%s",
                  getattr(f, "roleid", "?")) if log.isEnabledFor(10) else None)


def _facing_ok(battle, f, target_pos) -> bool:
    """目标是否已经转进视野锥。

    【v19】高难房（排位 / 英雄联赛）用 280°，外面所有非高难房用 CONFIG
    默认的 135°。覆盖只读房间属性，不动全局 CONFIG。
    """
    from . import rank_profiles
    fp = _pos(f)
    yaw = getattr(f, "_bot_yaw", None)
    if fp is None or yaw is None:
        return True
    dx, dz = float(target_pos[0]) - fp[0], float(target_pos[2]) - fp[2]
    if abs(dx) < 1e-6 and abs(dz) < 1e-6:
        return True
    try:
        fov = math.radians(max(10.0, min(360.0, float(_mode_fov(battle)))))
    except (TypeError, ValueError):
        fov = math.pi
    diff = (math.atan2(dx, dz) - float(yaw) + math.pi) % (2.0 * math.pi) - math.pi
    return abs(diff) <= fov / 2.0


def _step(f, target, dist, speed, dt, destination=None) -> Optional[dict]:
    """朝目标走一步，返回要广播的那一条 `SRoleSync`（没动则 None）。

    面向目标用绕 Y 的 quat（线上 ×20000 的 short）。客户端对非本人的角色是按
    pos 插值走位，朝向只影响模型脸朝哪。
    """
    fp, tp = _pos(f), _pos(target)
    if fp is None or tp is None or dt <= 0:
        return None
    if destination is None:
        if dist <= .0001: destination = fp
        else:
            k = min(1.0, (speed * dt) / dist)
            destination = tuple(a+(b-a)*k for a,b in zip(fp,tp))
    nx,ny,nz = destination
    f.syncpos = (nx, ny, nz)
    # Patrol has no enemy to face. Use its actual movement direction.
    heading = (nx-fp[0], nz-fp[2]) if target is f else (tp[0]-fp[0], tp[2]-fp[2])
    _want = math.atan2(heading[0], heading[1])
    # 【v40】只有朝着**敌人**转时才用距离自适应提速；巡逻转身保持原速。
    half = _turn_towards(f, _want, dt, None if target is f else dist) * 0.5
    return {
        "state": {
            "quat": {"w": int(round(math.cos(half) * 20000)), "x": 0,
                     "y": int(round(math.sin(half) * 20000)), "z": 0},
            "pos": _v3(nx, ny, nz),
            "speed": _v3((nx - fp[0]) / dt, (ny - fp[1]) / dt, (nz - fp[2]) / dt),
        },
        "timestamp": int(time.time() * 1000),
    }


def _claw_gate(battle, f, prime_only=False) -> bool:
    """僵尸爪击闸门：首爪蓄力 + 两爪最小间隔。

    `BioProperty` 算出来是 0.6 秒一下（atkRate .15 + atkSpeed .45），
    破防化服 1 下 + 感染 2 下 = **1.2 秒**就被贴上，玩家根本来不及拉开。
    这里不改伤害，只把节奏放到`bot_claw_interval`（默认 1.2 秒），并且
    第一次贴身先愣 `bot_claw_windup`（默认 0.35 秒）给一次反应机会。

    停手超过 3 秒（目标跑远了）会重新蓄力。
    """
    from ..config import CONFIG
    now = time.time()
    try:
        windup = max(0.0, float(getattr(CONFIG, "bot_claw_windup", 0.0) or 0.0))
        interval = max(0.0, float(getattr(CONFIG, "bot_claw_interval", 0.0) or 0.0))
    except (TypeError, ValueError):
        windup = interval = 0.0
    if windup <= 0 and interval <= 0:
        return True

    st = getattr(battle, "_claw_state", None)
    if st is None:
        st = {}
        try:
            battle._claw_state = st
        except Exception:
            return True
    rid = int(f.roleid)
    rec = st.get(rid)
    if rec is None or (rec[1] > 0 and now - rec[1] > 3.0):
        # 第一次接触（或断了 3 秒以上）：进入蓄力，这一下不打
        st[rid] = [now, 0.0]
        return False
    first, last = rec
    if prime_only:
        return False  # Begin windup without consuming an actual attack interval.
    if now - first < windup:
        return False
    if interval > 0 and last > 0 and now - last < interval:
        return False
    st[rid] = [first, now]
    return True


def _is_rank_room(battle) -> bool:
    """排位 / 联赛（高难房）。"""
    from . import rank_profiles
    try:
        return rank_profiles.rank_type(getattr(battle, "room", None)) in (
            rank_profiles.QUALIFYING, rank_profiles.LEAGUE)
    except (TypeError, ValueError):
        return False


def _mode_fov(battle) -> float:
    """【v36】视野锥总张角（度）。实际半角 = 该值 / 2。

    生化 180 / 联赛 180 / 排位 150 / 普通 135。
    180° 时半角 90°，正侧面是边界、看不到背后；>180° 才会背身。
    """
    from ..config import CONFIG
    try:
        if _is_bio_room(battle):
            return float(getattr(CONFIG, "bot_fov_bio", 180.0) or 180.0)
        from . import rank_profiles
        rt = rank_profiles.rank_type(getattr(battle, "room", None))
        if rt == rank_profiles.LEAGUE:
            return float(getattr(CONFIG, "bot_fov_league", 180.0) or 180.0)
        if rt == rank_profiles.QUALIFYING:
            return float(getattr(CONFIG, "bot_fov_qualifying", 150.0) or 150.0)
        return float(getattr(CONFIG, "bot_fov_normal", 135.0) or 135.0)
    except (TypeError, ValueError):
        return 135.0


def _mode_hear_range(battle) -> float:
    """【v36】听觉半径（米）：生化 40 / 联赛 15 / 排位 8 / 普通 5。"""
    from ..config import CONFIG
    try:
        if _is_bio_room(battle):
            return float(getattr(CONFIG, "bot_hear_bio", 40.0) or 0.0)
        from . import rank_profiles
        rt = rank_profiles.rank_type(getattr(battle, "room", None))
        if rt == rank_profiles.LEAGUE:
            return float(getattr(CONFIG, "bot_hear_league", 15.0) or 0.0)
        if rt == rank_profiles.QUALIFYING:
            return float(getattr(CONFIG, "bot_hear_qualifying", 8.0) or 0.0)
        return float(getattr(CONFIG, "bot_hear_normal", 5.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _mode_sniper_scale(battle) -> float:
    """【v35】狙击（actType==6）开火间隔的模式倍率（★ 联赛 = 原始值）。

    联赛 1.0（基准，不动）/ 排位 2.0 / 普通 3.0 / 生化 2.0（保持原值）。
    只作用于 BOT 的 AmmoState，真人面板不受影响。
    """
    from ..config import CONFIG
    try:
        if _is_bio_room(battle):
            return float(getattr(CONFIG, "bot_sniper_scale_bio", 2.0) or 1.0)
        from . import rank_profiles
        rt = rank_profiles.rank_type(getattr(battle, "room", None))
        if rt == rank_profiles.LEAGUE:
            return float(getattr(CONFIG, "bot_sniper_scale_league", 1.0) or 1.0)
        if rt == rank_profiles.QUALIFYING:
            return float(
                getattr(CONFIG, "bot_sniper_scale_qualifying", 2.0) or 1.0)
        return float(getattr(CONFIG, "bot_sniper_scale_normal", 3.0) or 1.0)
    except (TypeError, ValueError):
        return 1.0


def _mode_hit_rate(battle) -> float:
    """【v34】按房间模式返回 BOT 命中率（★ 联赛 = 最高难度基准）。

    联赛 LEAGUE = ``bot_hit_league``(1.00，基准不动)
    排位 QUALIFYING = ``bot_hit_qualifying``(0.75)
    普通（团队/爆破/SOLO 等一切非竞技非生化房）= ``bot_hit_normal``(0.50)
    生化 BIOCHEM = ``bot_hit_bio``(1.00，不变)

    判定顺序：先认生化（生化房不进排位池），再认 rank 标记，
    都不是就当普通房。``rank_type`` 只认 room 上的 ``local_rank_match``。
    """
    from ..config import CONFIG
    try:
        if _is_bio_room(battle):
            v = float(getattr(CONFIG, "bot_hit_bio", 1.0) or 1.0)
        else:
            from . import rank_profiles
            rt = rank_profiles.rank_type(getattr(battle, "room", None))
            if rt == rank_profiles.LEAGUE:
                v = float(getattr(CONFIG, "bot_hit_league", 1.0) or 1.0)
            elif rt == rank_profiles.QUALIFYING:
                v = float(getattr(CONFIG, "bot_hit_qualifying", 0.75) or 0.75)
            else:
                v = float(getattr(CONFIG, "bot_hit_normal", 0.5) or 0.5)
    except (TypeError, ValueError):
        return 1.0
    return max(0.05, min(1.0, v))


def _mode_spread_scale(battle) -> float:
    """【v34】模式命中率 -> 散布倍率（面积反推，×1/√h）。

    命中率 ∝ 1/σ²（二维正态），所以「命中率 ×h」等价于「散布 σ ×1/√h」。
    联赛/生化 h=1.0 -> ×1.000（原样）；排位 ×1.155；普通 ×1.414。
    """
    hit = _mode_hit_rate(battle)
    if hit >= 0.999:
        return 1.0
    return 1.0 / math.sqrt(hit)


def _fast_pistol_spread_scale(info) -> float:
    """【v31】高射速手枪的散布倍率（让 BOT 命中率落到配置值）。

    只作用于 ``category == "pistol"`` 且 ``shot_period <= bot_fast_pistol_period``
    的枪（当前就是格洛克18 全系列，12 发/秒）。命中率与散布面积成反比
    （二维正态，P ∝ 1/σ²），所以倍率 = 1/sqrt(hit_rate)：0.33 -> ×1.741。
    其它枪返回 1.0，完全不受影响。
    """
    from ..config import CONFIG
    try:
        if str(getattr(info, "category", "") or "").lower() != "pistol":
            return 1.0
        period = float(getattr(info, "shot_period", 0.0) or 0.0)
        thr = float(getattr(CONFIG, "bot_fast_pistol_period", 0.15) or 0.15)
        if period <= 0.0 or period > thr:
            return 1.0
        hit = float(getattr(CONFIG, "bot_fast_pistol_hit_rate", 0.33) or 0.33)
        hit = max(0.05, min(1.0, hit))
        return 1.0 / math.sqrt(hit)
    except (TypeError, ValueError):
        return 1.0


def _gun_class(info) -> str:
    """枪种档位：狙击/机枪/冲锋/其它。用来查反应时间与瞄准滞后。"""
    if info is None:
        return "melee"
    cat = str(getattr(info, "category", "") or "")
    return cat if cat in ("sniper", "mg", "smg") else "base"


def _bot_react(info, dist=None, bio_room: bool = False) -> float:
    """目标进入视野后至少要等多久才允许开第一枪（秒）。

    官方 Lv4「军官」不再按枪种分档，而是按**距离**缩放：
    `Adjusttime(adjust, dis) = adjust × clamp(dis/15, 0.3, 1)`，
    rank32 的 adjust = 0.384 → 3m 0.115s / 10m 0.256s / 20m+ 0.384s。
    """
    from ..config import CONFIG
    try:
        base = float(getattr(CONFIG, "bot_react_base", 0.384) or 0.0)
    except (TypeError, ValueError):
        base = 0.384
    # 【v8】狙击单独一档：举枪/架枪比步枪慢一倍（0.384 → 0.77s）。
    # 不再用「强制脱靶」压伤害，靠这一个前摇 + 1.0° 锥角。
    # 只对**非生化房**的狙击加前摇；生化房的狙击回旧口径（用户要求）。
    if _gun_class(info) == "sniper" and not bio_room:
        try:
            base *= max(0.1, float(getattr(CONFIG, "bot_react_sniper_scale",
                                          2.0) or 1.0))
        except (TypeError, ValueError):
            base *= 2.0
    if base <= 0:
        return 0.0
    if dist is None:
        return base
    try:
        k = min(1.0, max(0.3, float(dist) / 15.0))
    except (TypeError, ValueError):
        k = 1.0
    return base * k


def _aim_ok(f, pos, dist) -> bool:
    """枪口是否已经对到目标身上（官方 `Ranger.InAgressire` 的门限）。

    官方只允许在 Aiming / Ballistic 两档开火，判据是
    `Util.CalcYaw(forward, dir) <= clamp(0.5 + 15/距离, 0.5, 30)` 度：
    10m 约 2°、30m 约 1°、贴脸 3m 约 5.5°。
    原来是「135° 视野锥内就能开枪」，等于侧对/半背对也扣扳机。
    """
    from ..config import CONFIG
    fp = _pos(f)
    yaw = getattr(f, "_bot_yaw", None)
    if fp is None or yaw is None:
        return True
    dx, dz = float(pos[0]) - fp[0], float(pos[2]) - fp[2]
    if abs(dx) < 1e-6 and abs(dz) < 1e-6:
        return True
    try:
        base = float(getattr(CONFIG, "bot_aim_deg_base", 0.5))
        span = float(getattr(CONFIG, "bot_aim_deg_dist", 15.0))
    except (TypeError, ValueError):
        base, span = 0.5, 15.0
    tol = base + (span / max(0.5, float(dist))) if span > 0 else base
    tol = max(0.5, min(30.0, tol))
    diff = (math.atan2(dx, dz) - float(yaw) + math.pi) % (2.0 * math.pi) - math.pi
    return abs(math.degrees(diff)) <= tol + 1e-6


def _bot_aim_lag(info) -> float:
    """开火时瞄准「多少秒之前」的目标位置（秒）。"""
    from ..config import CONFIG
    key = _gun_class(info)
    defaults = {"sniper": 0.55, "mg": 0.30, "smg": 0.15, "base": 0.22,
                "melee": 0.0}
    try:
        v = getattr(CONFIG, "bot_aim_lag_" + key, None)
        return float(v if v is not None else defaults.get(key, 0.22))
    except (TypeError, ValueError):
        return defaults.get(key, 0.22)


def _aim_point(hist, now: float, lag: float):
    """从位置历史里取 `lag` 秒之前的那个点（没有就退到最老的一条）。"""
    if not hist or lag <= 0:
        return None
    cut = float(now) - float(lag)
    for t0, p in reversed(hist):
        if float(t0) <= cut:
            return p
    return hist[0][1]


def _fire(battle, f, target, dist, aim_pos=None, info=None, colliders=None,
          seq=None, moving=False, running=False, aim_yaw=None) -> int:
    """替机器人开一枪：走的是和玩家 CsShoot 完全相同的结算出口。

    ``aim_pos`` = 这一枪瞄的点（目标当前位置，或视线断开后最后看到的位置）。
    ``info``    = 手里那把枪。给了就走**真实散布**（Gun.min/maxDistribution
                  + Lv4 精度惩罚），散布外不结算伤害，客户端照样画弹道。
                  不给（僵尸爪击）就沿用「扇区内必中」的老路径。
    """
    from . import battle as B
    bio = getattr(battle, "biochem", None)
    zombie = bool(bio is not None and bio.is_zombie(f.roleid))
    if zombie:
        # 僵尸爪击：只限节奏，伤害不动
        if not _claw_gate(battle, f):
            return 0
    fp, tp = _pos(f), _pos(target)
    if fp is None or tp is None:
        return 0
    if aim_pos is not None:
        tp = (float(aim_pos[0]), float(aim_pos[1]), float(aim_pos[2]))
    if zombie or info is None:
        dx, dy, dz = tp[0] - fp[0], (tp[1] + 1.2) - (fp[1] + 1.5), tp[2] - fp[2]
        n = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
        shoot = {
            "position": _v3(fp[0], fp[1] + 1.5, fp[2]),
            "dir": {"x": int(round(dx / n * 20000)),
                    "y": int(round(dy / n * 20000)),
                    "z": int(round(dz / n * 20000))},
            "targets": [{
                "targetid": int(target.roleid),
                "sd": float(dist),
                "hitpart": 2,
                "hitpos": _v3(tp[0], tp[1] + 1.2, tp[2]),
                "targetpos": _v3(tp[0], tp[1], tp[2]),
            }],
        }
        B.settle_shoot(battle, int(f.roleid), shoot,
                       battle.biochem is not None, log_tag="BOTSHOOT")
        return 1
    from . import weapon_fire
    origin = (fp[0], fp[1] + 1.5, fp[2])
    if aim_yaw is not None:
        # 【v24】沿真实枪口朝向射出：枪口没对准目标时子弹自然打偏，
        # 不再"只要开火就必中"。垂直仍取目标高度，整体接近水平直射。
        direction = (math.sin(float(aim_yaw)),
                     (tp[1] + 1.2) - origin[1],
                     math.cos(float(aim_yaw)))
    else:
        direction = (tp[0] - fp[0], (tp[1] + 1.2) - origin[1], tp[2] - fp[2])
    try:
        # 【v9】散布分模式：
        #   生化房 —— 非狙击 0.4（不变），狙击回到 0.4°；
        #   竞技/团队/爆破 —— 非狙击 0.4472（命中率 = 原来的 80%），
        #                     狙击保持 1.0°（用户说竞技狙击没问题）。
        from ..config import CONFIG as _CFG
        _bio_room = _is_bio_room(battle)
        if _bio_room:
            _scale = float(getattr(_CFG, "bot_spread_scale", 0.4) or 0.4)
            _sniper = float(getattr(_CFG, "bot_sniper_spread_bio", 0.4) or 0.4)
        else:
            _scale = float(getattr(_CFG, "bot_spread_scale_arena", 0.4472) or 0.4472)
            _sniper = None
        spread = weapon_fire.official_spread_deg(
            info, moving=bool(moving), running=bool(running),
            scale=_scale, sniper_deg=_sniper)
    except (TypeError, ValueError):
        spread = 0.0
    # 【v34】四模式命中率分档：普通 ×1.414 / 排位 ×1.155 / 联赛与生化 ×1.0。
    spread = float(spread) * _mode_spread_scale(battle)
    # 【v31】只削弱 BOT 手里的格洛克18（高射速手枪）：命中率压到 50%。
    _fp = _fast_pistol_spread_scale(info) if info is not None else 1.0
    if _fp > 1.0:
        spread = float(spread) * _fp
    if _gun_class(info) in ("mg", "smg"):
        try:
            from ..config import CONFIG as _CFG2
            _sp = float(getattr(_CFG2, "bot_smg_mg_spread_scale", 1.1) or 1.1)
            _hit = float(getattr(_CFG2, "bot_hit_rate_scale", 1.0) or 1.0)
        except (TypeError, ValueError):
            _sp, _hit = 1.1, 1.0
        # 命中率 ∝ 1/散布面积 ∝ 1/σ²（二维正态），所以「命中率 ×h」= 散布 ×1/√h。
        _hit = max(0.05, min(1.0, _hit))
        spread = float(spread) * _sp / math.sqrt(_hit)
    shoots = weapon_fire.aim_shoots(
        int(f.roleid), int(getattr(info, "itemid", 0) or 0),
        int(seq if seq is not None else 0), origin, direction,
        int(target.roleid), (tp[0], tp[1], tp[2]), float(dist), info,
        count=1,
        ray_clear=(colliders.clear if colliders is not None else None),
        aim_spread_deg=spread)
    hit = 0
    for shoot in shoots:
        hit += B.settle_shoot(battle, int(f.roleid), shoot,
                              battle.biochem is not None, log_tag="BOTSHOOT")
    return hit


def _pistol_tick(battle, f, target, dist, can_see, colliders, state, now,
                 dt: float = 0.05):
    """Acquire a visible target, then shoot with a finite magazine and aim error."""
    ammo = state.get("pistol_ammo")
    if ammo is None:
        ammo = state["pistol_ammo"] = human.AmmoState.from_loadout(f.equipmap)
    if ammo.info is None:
        return
    reload_done = ammo.update(now)
    if reload_done is not None:
        _send_reload_stop(battle, f, *reload_done)
    if not ammo.clip:
        if ammo.start_reload(now):
            _send_reload_start(battle, f, ammo.active)
        elif not ammo.reserve and f.equipmap.get(human.POS_MELEE):
            # 【v20】竞技房手枪模式也不许切刀（与 _tick_human_bot 的
            # forbid_melee 同口径）；生化房 / 刀战房保持原行为。
            _pistol_no_melee = (getattr(battle, "biochem", None) is None
                                and int(getattr(battle.room, "equiplimitid", 0) or 0)
                                != special_modes.DAGGER)
            if not _pistol_no_melee:
                f.weaponpos = human.POS_MELEE
                _send_weapon_change(battle, f, f.weaponpos)
        state.pop("pistol_aim", None)
        return
    if not can_see:
        state.pop("pistol_aim", None)
        return
    aiming = state.get("pistol_aim")
    if aiming is None or aiming[0] != target.roleid:
        reaction = PISTOL_REACTION + 0.1 * (f.roleid % 4)
        state["pistol_aim"] = (target.roleid, now + reaction)
        return
    if now < aiming[1] or _spawn_fire_locked(battle, f.roleid, now):
        return
    # 【v31】手枪模式不再用硬编码 PISTOL_INTERVAL(0.95s)：改走 AmmoState.take_shots，
    # 与其它枪完全一致 —— 面板射速 + 时间轴累加（掉帧不掉平均射速）
    # + 每 tick 最多 1 发（不会卡弹后一次吐两发）+ 欠账封顶。
    # 原来 0.95s 把格洛克18（面板 0.082s，12 发/秒）压成 1.05 发/秒，
    # 手枪局 BOT 基本等于不开枪。
    rounds = ammo.take_shots(now, dt)
    if rounds <= 0:
        return

    from . import battle as B
    sx, sy, sz = _pos(f)
    tx, ty, tz = _pos(target)
    origin = (sx, sy + 1.5, sz)
    direction = (tx - sx, ty + 1.2 - origin[1], tz - sz)
    # 【v33】手枪模式也按枪表算散布（不再所有手枪统一 4°/6°）：
    # 与普通模式同源（official_spread_deg × 模式系数），再对高射速手枪加散。
    try:
        from ..config import CONFIG as _CFG
        if _is_bio_room(battle):
            _scale = float(getattr(_CFG, "bot_spread_scale", 0.4) or 0.4)
            _sniper = float(getattr(_CFG, "bot_sniper_spread_bio", 0.4) or 0.4)
        else:
            _scale = float(
                getattr(_CFG, "bot_spread_scale_arena", 0.4472) or 0.4472)
            _sniper = None
        _spread = float(weapon_fire.official_spread_deg(
            ammo.info, moving=bool(state.get("moving")), running=False,
            scale=_scale, sniper_deg=_sniper))
    except (TypeError, ValueError):
        _spread = 4.0
    # 【v34】四模式命中率分档（与 _fire 同一张表，手枪局也按房间模式分档）。
    _spread *= _mode_spread_scale(battle)
    _spread *= _fast_pistol_spread_scale(ammo.info)
    for _i in range(int(rounds)):
        sequence = state.get("pistol_sequence", 0) + 1
        state["pistol_sequence"] = sequence
        shoot, = weapon_fire.aim_shoots(
            f.roleid, ammo.info.itemid, sequence, origin, direction,
            target.roleid, (tx, ty, tz), dist, ammo.info, count=1,
            ray_clear=colliders.clear, aim_spread_deg=_spread)
        B.settle_shoot(battle, f.roleid, shoot, False, log_tag="BOTPISTOL")


def _fire_volleys(battle, f, target, dist, info, rounds, seq=0, events=None,
                  colliders=None, aim_pos=None) -> int:
    """Native trigger-first ray groups -> ScMultiShoot.

    ``events`` is the exact list recorded by AmmoState: one entry per trigger
    first round, even when the trigger's remaining rounds arrive in a later
    dispatch.  The magazine was already charged by take_shots; this function
    never touches ammo.  Single-shot guns stay on _fire above.  Each pellet
    ray is checked against its own static corridor through ``colliders``.
    """
    from . import weapon_fire
    clear = None
    if colliders is not None:
        clear = colliders.clear
    return weapon_fire.bot_fire(battle, f, target, dist, info, int(rounds),
                                seq=seq, log_tag="BOTSHOOT", events=events,
                                ray_clear=clear, aim_pos=aim_pos)



def _world(battle):
    from . import navigation, geometry
    scene = str((gamedata.map_row(battle.room.mapid) or {}).get('scene') or '')
    nav = geometry.grid_for_scene(scene) or navigation.for_scene(scene)
    colliders = geometry.for_scene(scene)
    if int(battle.room.gamemode or 0) in (8,10):
        from . import parkour_routes
        routes=parkour_routes.for_scene(scene)
        if routes is not None:nav=routes.nav
    if getattr(battle,'_bot_world_logged',None) != scene:
        battle._bot_world_logged = scene
        (log.info('BOT-WORLD scene=%s navigation=%s triangles=%s',scene,
                 nav.source_sha256 if nav else 'missing',len(colliders.tris) if colliders else 0) if log.isEnabledFor(20) else None)
    return nav,colliders


def _visible(colliders, a, b):
    if colliders is None:return False
    return colliders.clear((a[0],a[1]+1.5,a[2]),(b[0],b[1]+1.2,b[2]))


def _anchor(nav, here, seed, away=None, occupied=(), recent=()):
    """Local patrol/retreat choice; all candidates must lie on actual ground."""
    from .navigation import distance
    if hasattr(nav,'centers'):
        loc=nav.locate(here)
        if loc is None:return None
        candidates=[p for k,p in nav.centers.items()
                    if nav.component[k]==nav.component[loc[0]] and 2<distance(here,p)<12]
    else:
        candidates=[]
        for dx,dz in ((5,0),(-5,0),(0,5),(0,-5),(4,4),(-4,4),(4,-4),(-4,-4)):
            loc=nav.locate((here[0]+dx,here[1],here[2]+dz))
            if loc:candidates.append(loc[1])
    if not candidates:return None
    if away is not None:
        candidates.sort(key=lambda p:distance(p,away)-.25*distance(here,p),reverse=True)
        candidates=candidates[:8]
    else:
        candidates.sort();offset=seed%len(candidates)
        candidates=candidates[offset:]+candidates[:offset]
        # Score a distributed bounded sample rather than every map cell for
        # every actor. Patrol selection must not stall the shared room clock.
        if len(candidates)>32:
            candidates=[candidates[i*len(candidates)//32] for i in range(32)]
        # Equal seeds used to send neighbours back to the same few offsets.
        # Spread destinations across the connected legal region and prefer
        # places not just visited. This is reconstructed patrol policy.
        def penalty(p):
            crowd=sum(max(0.,3.-math.hypot(p[0]-q[0],p[2]-q[2]))
                      for q in occupied if abs(p[1]-q[1])<1.2)
            revisit=sum(max(0.,2.-distance(p,q)) for q in recent)
            return crowd+2.*revisit
        candidates.sort(key=penalty)
    for p in candidates[:12]:
        if hasattr(nav,'corridor'):
            a,b=nav.locate(here),nav.locate(p)
            if a is not None and b is not None and nav.corridor(a[0],b[0]):return p
        elif nav.path(here,p):return p
    return None


def _nav_key(nav,p,max_dy=1.6,radius=2):
    """取网格键：先精确 locate，失败退回最近节点投影。

    【v54】地铁图楼梯段有 3.1% 的可站立点 `locate()` 直接返回 None（BOT 正好
    停在两行网格之间、`walk_clear` 过不了）。老逻辑 `_grounded_step` 拿到 None
    就 `return here`，等于整段楼梯都过不去 —— 看起来就是「卡在斜坡上怼墙」。
    这里只是把位置投影到最近节点用于**连通性判断**，能不能真的走那一步仍然
    由 `nav.clear()`（含地板连续性）和 `walk_clear` 决定。
    """
    loc=nav.locate(p)
    if loc is not None:return loc[0]
    fn=getattr(nav,'nearest_node',None)
    if fn is None:return None
    hit=fn(p,max_dy=max_dy,radius=radius)
    return hit[1] if hit else None


def _goal_key(nav,p):
    """目标点的网格键：**先同高、再逐级放宽**。

    直接用「最近节点」会取到 BOT 自己那一层（站台）的格子 —— 玩家在下面
    轨道里时，BOT 走到那个格子就停住，看着像「贴着最近处观望」。
    """
    loc=nav.locate(p)
    if loc is not None:return loc[0]
    fn=getattr(nav,'nearest_node',None)
    if fn is None:return None
    for dy,r in ((0.7,2),(1.3,3),(2.6,4)):
        hit=fn(p,max_dy=dy,radius=r)
        if hit is not None:return hit[1]
    return None


def _step_dirs(here, desired, budget):
    """一次位移要试的方向：直线、两个轴分解、左右各 35°/60° 侧绕。

    【v54】地铁图楼梯上实测：朝目标方向 0.2 m 就被挡（`Grid.clear` 能过、
    但胶囊体 `walk_clear` 不过，是扶手/墙角擦身），而侧向 0.6 m 完全通畅。
    老逻辑只会把同一条直线一分再分，4 次全撞同一堵墙 → 原地不动，
    表现出来就是「旁边有路就是不走」。
    """
    from .navigation import distance
    dx,dz=desired[0]-here[0],desired[2]-here[2]
    out=[desired]
    if abs(dx)>1e-6 and abs(dz)>1e-6:
        out.append((here[0],desired[1],desired[2]))      # 只走 z
        out.append((desired[0],desired[1],here[2]))      # 只走 x
    length=max(1e-6,min(budget,distance(here,desired)))
    for deg in (35.0,-35.0,60.0,-60.0):
        a=math.atan2(dz,dx)+math.radians(deg)
        out.append((here[0]+math.cos(a)*length,desired[1],
                    here[2]+math.sin(a)*length))
    return out


STEP_UP = 0.60      # 能直接迈上去的一级台阶（原生 CharacterController stepOffset 量级）
STEP_DOWN = 1.2     # 与 nav.ground 的吸附上限一致：再深的落差一律不算可走


def _step_up_limit():
    """`CF_BOT_STEP_UP` 覆盖值；读不到就用模块默认。"""
    try:
        from ..config import CONFIG as _C
        return max(0.0, float(getattr(_C, 'bot_step_up', STEP_UP)))
    except (TypeError, ValueError):
        return STEP_UP


def _ground_candidates(nav, here, base, step_up=None):
    """落点允许的高度：最近地面 + 抬一级台阶后的地面。

    【v54】地铁站台那一级台阶（0.44~0.57 m）原来上不去：`nav.ground()` 只会
    吸到「离当前 y 最近」的地板，于是 BOT 一直贴着台阶立面走，`walk_clear`
    永远过不了。这里额外把「比当前高不超过 step_up 的地板」也当候选，
    由后面的实体校验决定能不能真的踩上去。
    """
    if step_up is None:step_up=_step_up_limit()
    out=[]
    ground=nav.ground(base)
    if ground is not None:out.append(ground)
    if step_up<=0:return out
    scene=getattr(nav,'scene',None)
    if scene is not None and hasattr(scene,'floors'):
        for y in scene.floors(base[0],base[2]):
            if .02<y-here[1]<=step_up and (ground is None or abs(y-ground[1])>1e-3):
                out.append((base[0],y,base[2]))
    return out


def _grounded_step(nav, colliders, here, desired, foot, budget):
    """Validate the exact transmitted segment, including support and speed."""
    from .navigation import distance, lerp
    # 【v55】连通性只做「能查到就比对」：地铁轨道床那一层没有任何烘焙节点，
    # 老逻辑在 `origin is None` 时直接 return here —— 整层都走不进去。
    # 真正的安全约束是下面每一步的 `nav.clear()`（地板连续）+ `walk_clear`。
    origin_key=_nav_key(nav,here,max_dy=2.6,radius=4)
    comp=getattr(nav,'component',None)
    origin_comp=(comp.get(origin_key)
                 if (isinstance(comp,dict) and origin_key is not None) else None)
    step_up=_step_up_limit()

    def validate(base):
        """这一落点合法就返回带地面高度的坐标，否则 None。"""
        # 限速只看**水平**距离：上下台阶本来就要改变 y，用 3D 距离卡会把
        # 「水平 0.36 m + 落差 0.44 m」判成超速 —— 结果楼梯/台阶上永远只能
        # 走半步甚至一步都走不了，这也是"卡在斜坡上"的第二个成因。
        if math.hypot(base[0]-here[0],base[2]-here[2])>budget+.02:return None
        for ground in _ground_candidates(nav,here,base,step_up):
            candidate=(base[0],ground[1]+foot,base[2])
            dy=candidate[1]-here[1]
            if dy>step_up+.02 or dy<-STEP_DOWN:continue
            # Physics support alone does not imply membership in this baked graph.
            # Infection/ScBorn round positions to centimetres, so validate that
            # exact representation too before allowing the movement.
            candidate=tuple(round(v*100)/100 for v in candidate)
            if math.hypot(candidate[0]-here[0],
                          candidate[2]-here[2])>budget+.02:continue
            key=_nav_key(nav,candidate,max_dy=2.6,radius=4)
            if (key is not None and origin_comp is not None
                    and comp.get(key)!=origin_comp):continue
            # 【v58】同层行走必须**踩在有节点的格子上**。地铁轨道层只有
            # x=-4..-2 和 x=0..2 两带节点（x=-1 两条轨之间、x=3 站台立面底部
            # 是没有任何节点的「缝」，净空不足本来就站不住）。`_nav_key` 用
            # radius=4 太宽松，BOT 会横向漂到 x=3.3 然后每一步都被否 ——
            # 用户看到的「卡在轨道边/角落里反复动」有一半是这个。
            # 跨落差下落（下面那个分支）不查这条：从站台边缘落到轨道节点上时
            # 中间那一步本来就悬空。
            if dy >= -0.35 and nav.locate(candidate) is None:continue
            # 【v58】要「爬上去的矮台」（+0.3~+0.6m）必须本身站得住。
            # 地铁两条轨道中间那道护轨顶面只有 1m 宽、头顶净空又不够，BOT
            # 一旦踩上去就下不来也走不动（用户看到的「在轨道中线上定住」）。
            # 判不住就交给下面的 `_vault` 一次跨过去。
            if 0.3 <= dy <= step_up + 0.02:
                try:
                    if not nav.stand_clear(candidate):continue
                except AttributeError:
                    pass
            # 【v58】跨落差下落（站台→轨道、箱子顶→地面）：
            # 真实 CharacterController 是「走出边缘 → 失去支撑 → 重力落下」，
            # 胶囊体根本不会去撞台阶立面。这里必须**跳过 `nav.clear()`**：
            # 它除了身体净空，还要求线段下方每 0.25m 都有 0.6m 内的地板
            # （地板连续性），而「跨过站台边缘掉下去」本来就有一瞬间脚下
            # 没地板 —— 这正是「站台上明明能跳下去、BOT 却沿站台跑三十米
            # 去楼梯」的最后一道锁。改成只用身体净空（栏杆/玻璃仍然会挡）。
            if dy < -0.35:
                probe=(candidate[0],here[1],candidate[2])
                if (getattr(nav,'scene',None) is not colliders
                        and not nav.scene.walk_clear(here,probe)):continue
                if not colliders.walk_clear(here,probe):continue
                return candidate
            if not nav.clear(here,candidate):continue
            # A collision Grid.clear already performs this same physical query.
            if (getattr(nav,'scene',None) is not colliders
                    and not colliders.walk_clear(here,candidate)):continue
            return candidate
        return None

    # 【v58】目标明显在**上一层**（站台 0.89m、护轨 0.53m）：
    # 先跳/跨，不要在本层试走。否则 `nav.ground` 会在边缘取到低层的 0.52，
    # `validate` 判「同层可走」→ BOT 沿着站台边一厘米一厘米横移（用户截图里
    # 那种贴着边来回蹭）。
    try:
        _want_gnd = nav.ground(desired) if hasattr(nav, 'ground') else None
    except (TypeError, ValueError, IndexError):
        _want_gnd = None
    # 站在「本身就站不住」的地方（地铁护轨顶、窄沿、栏杆上）时，任何方向都
    # 该往外下来：`validate` 给的每个点都还在原地，于是 BOT 一动不动。
    # v58 这里是写死的地铁坐标（x≈-1、y≈1.05），换成通用的「脚下站不住」。
    try:
        _on_rail = (0.9 < here[1] < 1.4) and not colliders.stand_clear(here)
    except (AttributeError, TypeError):
        _on_rail = False
    if _on_rail or (_want_gnd is not None
                    and abs(_want_gnd[1] - here[1]) >= 0.3):
        _hop = _vault(nav, colliders, here, desired, budget)
        if _hop is not None:
            return _hop
    # 常见情况：朝着目标直走就通 —— 这里立刻返回，不付额外开销。
    for attempt in range(4):
        hit=validate(lerp(here,desired,.5**attempt))
        if hit is not None:return hit
    # 【v58】直行失败就先试「跳/跨」：目标在上一层的边缘（站台 0.89m、
    # 护轨 0.53m）时，侧绕只会给出「在本层横移半步」的点，永远上不去 ——
    # BOT 会沿着站台边缘来回蹭。必须抢在侧绕之前处理。
    hit=_vault(nav,colliders,here,desired,budget)
    if hit is not None:return hit
    # 直行被挡：再试轴分解与左右各 35°/60° 的侧绕（只试最大的两级步长）。
    for target in _step_dirs(here,desired,budget)[1:]:
        for attempt in range(2):
            hit=validate(lerp(here,target,.5**attempt))
            if hit is not None:return hit
    return here


def _vault(nav, colliders, here, desired, budget, max_gap=2.2):
    """跨过 ≤0.55m 的矮障碍（地铁两条轨道中间的护轨）。

    客户端角色跳跃高度 1.0m、`stepOffset=0`，真人都是「跳过去」。BOT 原来
    没有这条路径，于是烘焙网格里两条轨道彼此不连通 —— A* 只能绕地下通道
    横穿整张图。用户实测：「我在 a 区（这条轨道），这边站台的僵尸在边缘
    观望；我退到 b 区，它就开始后撤」—— 后撤不是怕，是在往地下通道走。

    判据很保守，避免变成穿墙：
      * 目标点必须与脚下**同层**（±0.2m），水平不超过 2.2m；
      * 「脚下 +1.05m」高度上的水平射线必须通 —— 也就是障碍物低于跳跃高度，
        真要是一堵 1.6m 的墙，这条射线会撞上，不放行。
    """
    if nav is None or colliders is None:
        return None
    try:
        dx, dz = desired[0] - here[0], desired[2] - here[2]
    except (TypeError, ValueError, IndexError):
        return None
    d = math.hypot(dx, dz)
    # The desired point is one server tick away, not the landing point.
    # At 20 Hz several normal movement speeds produce a stride below .3 m;
    # rejecting that direction prevented the validated vault from ever running.
    # Landing clearance, layer, height and minimum .35 m displacement below
    # still constrain the crossing itself.
    if d < 0.02 or d > max_gap:
        return None
    ux, uz = dx / d, dz / d
    comp = getattr(nav, 'component', None)
    here_key = _nav_key(nav, here, max_dy=2.6, radius=4)
    # 由远到近：一次跨到对面轨道的节点上。分两帧走会在护轨顶上停住
    # （x=-1 正好有一个 1.05m 的「墙顶」节点），下一帧又掉回原侧。
    for step in (max_gap, 2.0, 1.6, 1.2, 0.8):
        p = (here[0] + ux * step, here[1], here[2] + uz * step)
        gnd = nav.ground(p) if hasattr(nav, 'ground') else None
        if gnd is None:
            continue
        # 允许「向下越过站台/护轨」也允许「向上 0.95m 跳上站台」（角色跳跃
        # 高度 1.0m）。★ 下界必须放到 STEP_DOWN(1.2)：站台落差 0.88、二段
        # 台阶 0.9 都在这个范围里。v59 之前写 -0.65 时，站台边缘那一步
        # `_vault` 找不到落点 → 返回 None → 继续走 validate 本来也能过；
        # 但 v59 发现它其实会「跨到脚下那块站台面」而返回原地（见下面那条
        # 距离校验），于是把 validate 短路掉，下跳彻底失效。
        if not (-STEP_DOWN <= gnd[1] - here[1] <= 0.95):
            continue
        # 纯几何净空（不能用 nav.clear：它要求线段下方每 0.25m 有地板，
        # 抬到 1.05m 高度后本来就没有「地板」）。
        # 高度取**较低那一层** + 1.05：BOT 已经站在护轨顶上（1.1m）时，
        # 用 here[1] 会把射线抬到 2.15m，正好撞上轨道上方的横梁 —— 明明
        # 人能从下面走过去，它却永远跨不了。
        lift = min(here[1], gnd[1]) + 1.05
        if not colliders.clear((here[0], lift, here[2]), (p[0], lift, p[2]),
                               mask=-1):
            continue
        key = _nav_key(nav, gnd, max_dy=1.0, radius=2)
        if key is None:
            continue
        if (isinstance(comp, dict) and here_key is not None
                and comp.get(key) != comp.get(here_key)):
            continue
        nk = nav.point(key)
        if abs(nk[1] - gnd[1]) > 0.2:
            continue          # 节点在护轨顶上，不是对面地面
        # ★ 必须真的「换了个地方」：站台面常常比烘焙节点宽一圈，沿方向走
        # 0.8~2.2m 时 `nav.ground()` 仍返回**自己脚下**的站台高度，于是
        # `_nav_key` 取回当前节点 → `_vault` 返回原地。调用方
        # （`_grounded_step`）把「非 None」当成「跨过去了」直接 return，
        # 下跳分支永远轮不到 —— 表现就是「站台边缘一步都迈不出去」。
        if math.hypot(nk[0] - here[0], nk[2] - here[2]) < 0.35:
            continue
        return (nk[0], nk[1], nk[2])
    return None


def _separate(nav, colliders, here, desired, rid, neighbours, foot, budget):
    """Local crowd steering; never push/teleport another role or bypass a wall.

    Positions come from one tick-start snapshot so roster iteration order cannot
    bias avoidance. Other floors and dead/unborn actors do not repel. The .9m
    comfort distance is reconstructed policy; the native body radius is .35m.
    """
    from .navigation import distance
    nearby=[(other,p) for other,p in neighbours.items() if other!=rid
            and abs(p[1]-here[1])<1.2
            and math.hypot(p[0]-here[0],p[2]-here[2])<budget+1.2]
    if not nearby:return desired
    def crowd(point):
        return sum(max(0.,.9-math.hypot(point[0]-p[0],point[2]-p[2]))**2
                   for _,p in nearby)
    if crowd(desired)<1e-6:return desired
    rx=rz=0.
    for other,p in nearby:
        dx,dz=here[0]-p[0],here[2]-p[2];d=math.hypot(dx,dz)
        if d>=1.2:continue
        if d<1e-5:
            # A role pair receives opposite deterministic directions at overlap.
            angle=((min(rid,other)*31+max(rid,other)*17)%360)*math.pi/180
            sign=1 if rid<other else -1
            dx,dz,d=math.cos(angle)*sign,math.sin(angle)*sign,1.
            weight=1.2
        else:weight=1.2-d
        rx+=dx/d*weight;rz+=dz/d*weight
    length=math.hypot(rx,rz)
    if length<1e-6:return desired
    ux,uz=rx/length,rz/length
    stride=min(budget,.6)
    candidates=[desired,here]
    dx,dz=desired[0]-here[0],desired[2]-here[2]
    for mix in (0.,.5,1.):
        vx,vz=dx*mix+ux*stride,dz*mix+uz*stride
        n=math.hypot(vx,vz)
        if n>budget:vx*=budget/n;vz*=budget/n
        point=_grounded_step(nav,colliders,here,(here[0]+vx,here[1],here[2]+vz),foot,budget)
        candidates.append(point)
    # Progress matters when clearance is equal; separation wins at overlap.
    return min(candidates,key=lambda p:4.*crowd(p)+.08*distance(p,desired))


def _tick_human_bot(battle, f, nav, colliders, now, dt, motion, neighbours,
                    shots, box_dest=None, squad_info=None) -> Tuple[int, Optional[dict]]:
    """Biochem human BOT: ammo + all-threat ground tactics.

    Movement and firing are independent: retreat/strafe still shoots when the
    target is visible and in range.  Every destination is a baked-grid point
    with corridor validation, not a Euclidean detour.  ``dt`` is the real
    dispatch interval measured by tick(), never a hard-coded 0.25.
    """
    from .navigation import distance, lerp
    rid = int(f.roleid)
    # 【v30】刚出生/复活的那 1 秒只跑位与瞄准，不扣扳机。
    _spawn_locked = _spawn_fire_locked(battle, rid, now)
    here = _pos(f)
    if here is None:
        return 0, None
    if not _ensure_human_loadout(battle, f):
        return 0, None
    st = _ammo_state(battle, f)
    if st is None:
        return 0, None
    state = motion.setdefault(rid, {})
    dt = max(0.0, min(float(dt), 1.0))

    done = st.update(now)
    if done is not None:
        slot, rounds = done
        _send_reload_stop(battle, f, slot, rounds)
        if not st.reloading(now):
            _send_gun_state(battle, f, slot)
        (log.info("HUMAN-BOT %s role=%s slot=%s rounds=%s ammo=%s/%s",
                 'RELOAD-SHELL' if st.reloading(now) else 'RELOAD-DONE',
                 rid, slot, rounds, st.slots[slot].clip, st.slots[slot].reserve) if log.isEnabledFor(20) else None)

    threats = _bot_threats(battle, f, nav, colliders, here)
    safe = human.safe_distance(threats)
    preferred = human.preferred_distance(safe)
    melee = _melee_for(f, state)
    # 一把枪都没有（刀战模式被 SpecialRule 裁光 / 弹药全空）：
    # 枪战的「安全距离 ≈10 m」会让 BOT 一直往后退，玩家追不上也砍不到，
    # 表现就是「进攻性不强、一直后退」。近战 BOT 改成贴身压迫。
    #
    # preferred 必须落在**挥刀距离以内**：原来用 CLOSE_RANGE_M(8m)，而刀
    # range 只有 ~2m，导致两个近战 BOT 都停在 8m 外谁也不贴脸，就是用户
    # 说的「对上就打太极」。这里按近战 range 的 0.7 倍设定贴脸距离。
    if not st.slots:
        safe = 0.0
        _knife_range = float(getattr(melee, "range", 0.0) or 0.0) if melee else 2.0
        preferred = max(0.5, _knife_range * 0.7) if _knife_range > 0 else human.CLOSE_RANGE_M
    perch = state.get('perch')
    hold_perch = (perch is not None and distance(here, perch) < .5
                  and human.perch_safe(here, threats, safe))
    if perch is not None and not hold_perch:
        state.pop('perch')
    gun_infos = [s.info for s in st.slots.values()]
    engage = max((i.effective_range for i in gun_infos), default=HUMAN_RANGE)
    visible = [t for t in threats if t.visible]
    nearest_vis = min((t.dist for t in visible), default=float("inf"))
    # 【v8】追击记忆 + 听觉（官方 pursueTime=20s / hearRange=20m）
    try:
        _pursue_s = float(getattr(CONFIG, "bot_pursue_seconds", 20) or 0)
    except (TypeError, ValueError):
        _pursue_s = 0.0
    _pursue = state.get("pursue") or None
    if _pursue is not None and now >= float(_pursue.get("until", 0) or 0):
        state.pop("pursue", None)
        _pursue = None
    if visible:
        if _pursue is not None:
            state.pop("pursue", None)
            _pursue = None
    else:
        _heard = _hear_position(battle, f, here)
        if _heard is not None:
            _pursue = {"pos": _heard, "until": now + 1.5}
            state["pursue"] = _pursue
    # 目标位置历史（瞄准滞后用）。只记真的看得见的帧，最多留 2.5 秒。
    _track = state.setdefault("track", {})
    for _t in visible:
        _h = _track.setdefault(int(_t.roleid), [])
        _h.append((float(now), tuple(_t.pos)))
        while _h and float(_h[0][0]) < now - 2.5:
            _h.pop(0)

    # parkour_routes keeps its plan in the same per-role motion dict:
    #   state['parkour_route']  = baked hops (start/end/speed)
    #   state['route_index']    = next hop
    #   state['route_mobility'] = route needs a faster/held-light weapon
    #   state['jump']           = committed ballistic arc in flight
    # A jump already in flight must not change its planned horizontal
    # velocity/landing, so the tactical layer freezes the held slot mid-air.
    route_hops = state.get("parkour_route") or ()
    route_index = int(state.get("route_index", 0) or 0)
    route_mobility = bool(state.get("route_mobility"))
    on_route = not hold_perch and bool(route_mobility or (route_hops
                                       and route_index < len(route_hops)))
    airborne = state.get("jump") is not None
    near_cancel = bool(visible) and nearest_vis <= max(human.CLOSE_RANGE_M,
                                                       float(safe or 0.0))

    route = _route_state(battle, rid)
    if route is not None:
        if airborne:
            human.notify_route_state(route, route="parkour", safe=True,
                                     airborne=True, reason="route_airborne")
        elif on_route and not hold_perch:
            if near_cancel:
                # A close threat cancels route mobility (but only grounded:
                # an in-flight jump keeps its committed slot above).
                human.notify_route_state(route, route="engage", safe=False,
                                         reason="route_cancel")
            else:
                human.notify_route_state(route, route="parkour",
                                         safe=True, reason="parkour_route")
                # Preference only: no movement, no jump, no switch here.
                human.request_mobility_weapon(route, now,
                                              reason="parkour_route",
                                              duration=0.6)
        elif not visible and not hold_perch:
            human.notify_route_state(route, route="transfer", safe=True,
                                     reason="transfer")
            human.request_mobility_weapon(route, now, reason="transfer",
                                          duration=0.6)
        else:
            human.notify_route_state(route, route="engage", safe=False,
                                     reason="engage")

    tactical = _tactical_states(battle).get(rid)
    if tactical is None:
        tactical = _tactical_states(battle)[rid] = human.TacticalState(
            held_slot=st.active, held_since=now - 10.0, reason="born")
    if tactical.held_slot in (human.POS_MAIN_GUN, human.POS_VICE_GUN):
        if tactical.held_slot != st.active and tactical.held_slot in st.slots:
            st.switch(tactical.held_slot, now)
    desired, why = human.choose_tactical_slot(
        st, melee, now=now, threat_visible=bool(visible),
        nearest_dist=nearest_vis, route_state=route, safe=safe,
        engage_range=engage, near_threat=near_cancel,
        route_mobility=on_route, airborne=airborne,
        # 非刀战房间：只要手上还有枪（st.slots 非空）就不许切刀跑路。
        # 【v20】竞技/普通房（非生化、非刀战）在源头彻底禁切刀：生化房那套
        # 「打空再切刀守点」的行为不适用于竞技，用户反馈竞技 BOT 满场端刀。
        allow_mobility_melee=not bool(st.slots),
        forbid_melee=(getattr(battle, "biochem", None) is None
                      and bool(st.slots)
                      and int(getattr(battle.room, "equiplimitid", 0) or 0)
                      not in (special_modes.DAGGER,)))
    urgent = (desired in (human.POS_MAIN_GUN, human.POS_VICE_GUN)
              and tactical.held_slot == human.POS_MELEE
              and bool(visible) and nearest_vis <= safe * 1.5)
    switch = None if airborne else human.maybe_switch(
        tactical, st, melee, desired, now, why, urgent=urgent)
    if switch is not None:
        f.weaponpos = int(switch.to_slot)
        _send_weapon_change(battle, f, switch.to_slot)
        state["empty_logged"] = False
        (log.info("HUMAN-BOT SWITCH role=%s %s->%s reason=%s gun=%s ammo=%s/%s",
                 rid, switch.from_slot, switch.to_slot, switch.reason,
                 switch.weapon_id, switch.clip, switch.reserve) if log.isEnabledFor(20) else None)

    held_melee = tactical.held_slot == human.POS_MELEE
    if held_melee:
        action, slot, info = "melee", human.POS_MELEE, None
        reloading = False
        weapon_empty = all(st.total(s) <= 0 for s in st.slots)
        f.weaponpos = human.POS_MELEE
    else:
        if tactical.held_slot in st.slots and st.active != tactical.held_slot:
            st.switch(tactical.held_slot, now)
        action, slot, info = st.ready(now, auto_switch=False)
        # **槽位必须和真正开火的那把枪一致。**
        # 原来这里写死 `tactical.held_slot`，而 `st.ready()` 返回的 slot
        # 在换弹/切枪的那一帧可能不同（也可能为空），于是客户端按
        # WeaponChange 显示的是刀、服务端 `active_weapon()` 却按另一把枪结算，
        # 表现就是「他拿着刀挥，实际是枪在打我」。
        _heldpos = int(slot if slot else tactical.held_slot)
        if int(getattr(f, "weaponpos", 0) or 0) != _heldpos:
            f.weaponpos = _heldpos
            _send_weapon_change(battle, f, _heldpos)
        else:
            f.weaponpos = _heldpos
        # 【v8】官方 Lv4 reloadActive=30%：弹匣剩得不多、且当前看不见敌人时
        # 先换弹，别等打空才换（原来只有 clip<=0 才会换）。
        # 【v36】主动换弹只在「视野内没敌人 且 没有尚未脱离的交战对象」时做。
        # 原来只看 `not visible`：敌人刚缩进掩体、还在按最后位置开火时就会换弹，
        # 表现像「打着人呢枪里还有子弹就换弹」。
        if action == "fire" and not visible and not state.get("engage"):
            try:
                _rk = float(getattr(CONFIG, "bot_reload_active", 0.30) or 0)
            except (TypeError, ValueError):
                _rk = 0.0
            _ss = st.slots.get(int(slot)) if slot else None
            if (_rk > 0 and _ss is not None and _ss.info.clip > 0
                    and _ss.reserve > 0
                    and _ss.clip <= _ss.info.clip * _rk):
                action = "reload"
        if action in ("reload", "reloading"):
            if action == "reload":
                started = st.start_reload(now)
                if started is not None:
                    _send_reload_start(battle, f, slot)
                    (log.info("HUMAN-BOT RELOAD role=%s slot=%s %.2fs ammo=%s/%s",
                             rid, slot, started.reload_seconds,
                             st.slots[slot].clip, st.slots[slot].reserve) if log.isEnabledFor(20) else None)
            reloading = True
            weapon_empty = False
        elif action == "switch":
            _send_weapon_change(battle, f, slot)
            reloading = False
            weapon_empty = False
        elif action == "empty":
            reloading = False
            weapon_empty = True
            if not state.get("empty_logged"):
                state["empty_logged"] = True
                (log.info("HUMAN-BOT EMPTY role=%s slots=%s (explicit no-ammo, "
                         "no ammo invented)", rid, st.snapshot()) if log.isEnabledFor(20) else None)
        else:
            reloading = False
            weapon_empty = False

    if not weapon_empty:
        state["empty_logged"] = False

    speed = human.move_speed(melee if held_melee else info)
    # 生化幽灵技能对移速的影响：客户端 warror 是「平点加减」
    # （_speed + skillSpeedPlus），BOT 的位移是服务端驱动的，必须同口径。
    # 狂暴 +2 / 刚体 −2 / 雾化 −fogSpeedMinus。
    _bio = getattr(battle, "biochem", None)
    if _bio is not None:
        try:
            if _bio.is_zombie(int(f.roleid)):
                _delta = _bio.skill_speed_delta(int(f.roleid))
                if _delta:
                    speed = max(1.0, speed + _delta)
        except Exception:
            pass
    # The longest carried gun is useful for choosing a slot; firing/chasing
    # must use the currently held gun, not an empty long-range primary.
    eng_range=(melee.range if held_melee and melee is not None else
               float(info.effective_range) if info is not None else HUMAN_RANGE)
    # A held knife is a real weapon: "all guns empty" must not suppress the
    # melee swing through the gun-empty retreat branch.
    combat_empty = bool(weapon_empty and not (held_melee and melee is not None))
    visible_target = (min(visible, key=lambda t: t.dist)
                      if visible else None)
    melee_stick = bool(held_melee and melee is not None and weapon_empty
                       and visible_target is not None
                       and visible_target.dist <= melee.range
                       # 【v55】隔着站台落差时 3D 距离也够近，但根本贴不上去：
                       # 这时不要站桩挥空，继续走走廊绕过去（僵尸在上、人类
                       # 在下面轨道里的经典干瞪眼）。
                       and _can_engage(nav, here, getattr(visible_target, "pos", None),
                                       melee.range, visible_target.dist,
                                       state, now))
    if melee_stick:
        # No gun ammo and a zombie already inside Melee.range: stay on the
        # spot and swing.  This does not alter run/jump/damage constants.
        decision = human.Decision(
            "melee_hold", True, visible_target.roleid, "melee_range",
            tuple(t.roleid for t in threats))
    else:
        decision = human.decide(
            here, threats, engage_range=eng_range, safe=safe,
            preferred=preferred, reloading=reloading,
            weapon_empty=combat_empty)
    if hold_perch:
        decision = human.Decision('perch_hold', decision.fire, decision.target_id,
                                  'safe_landing', decision.threat_ids)
    # 【v55】「保持距离」只在真的贴得上时成立。隔着站台落差/楼层时，
    # `dist <= preferred` 一样成立，于是 BOT 会在最近可达点站住干瞪眼
    # （僵尸围观轨道里的人、英雄举刀砍空气）。这里改判成 chase，
    # 让它继续沿走廊（楼梯/斜坡）绕过去。
    #
    # 【v57 修 NameError】这段原来写在 `target = next(…)` **之前**，只要
    # BOT 进入 hold 模式就抛 NameError，被 tick 的 try 吞掉 → 这个 BOT
    # 整帧不动。僵尸在站台「跟着你走但不下来 / 干瞪眼」有一半就是它：
    # hold 是最常见的观望状态。现在先把 decision 的目标取出来再用。
    target = next((t for t in threats if t.roleid == decision.target_id), None)
    if (decision.mode == "hold" and target is not None
            and not _can_engage(nav, here, getattr(target, "pos", None),
                                preferred, float(getattr(target, "dist", 0.0)),
                                state, now)):
        decision = human.Decision("chase", decision.fire, decision.target_id,
                                  "blocked_off_level", decision.threat_ids)
    # 【v13】目标粘性已回退（用户实测会「锁着眼前的人、绕另一条路走、顶墙」）。
    # 现在完全按 `human.decide` 的最近可见目标执行，不再覆盖 target_id。
    target = next((t for t in threats if t.roleid == decision.target_id), None)
    target_f = battle.fighters.get(target.roleid) if target is not None else None

    _bio_room = getattr(battle, "biochem", None)
    if _bio_room is not None:
        allies = {other: pos for other, pos in neighbours.items()
                  if other != rid and not _bio_room.is_zombie(other)}
    else:
        _my_side = _side_of(battle, f)
        allies = {other: pos for other, pos in neighbours.items()
                  if other != rid
                  and _side_of(battle, battle.fighters.get(other)) == _my_side}
    occupied = list(allies.values())
    for other in allies:
        teammate = motion.get(other, {})
        planned = (teammate.get('jump') or {}).get('end')
        if planned is None:
            hops = teammate.get('parkour_route') or ()
            index = teammate.get('route_index', 0)
            planned = hops[index]['end'] if index < len(hops) else None
        planned = planned or teammate.get('patrol') or teammate.get('move_dest')
        if planned is not None and distance(planned, allies[other]) > 1.0:
            occupied.append(planned)
    recent = state.setdefault("visited", [])
    # 生化房开局有一段「感染倒计时」的准备期；非生化房没有这个概念
    preparing = (not getattr(_bio_room, 'infection_started', True)
                 if _bio_room is not None else False)
    # 【v57】生化小队：`squad.plan()` 每 0.45s 在 tick 开头算一次分组。
    #   size>=2 → 已成队：守住队心 SQUAD_HOLD(4.5m)，不再主动抱团；
    #   size==1 → 落单：朝 `toward`（最近小队 / 最近同伴）走过去。
    bio_human = False
    if _bio_room is not None:
        try:
            bio_human = not _bio_room.is_zombie(int(f.roleid))
        except Exception:
            bio_human = False
    _sq = squad_info if isinstance(squad_info, dict) else {}
    _sq_size = int(_sq.get("size", 1) or 1) if bio_human else 1
    _sq_center = _sq.get("center") if _sq_size >= 2 else None
    _sq_toward = _sq.get("toward") if _sq_size < 2 else None
    state['squad_size'] = _sq_size
    # 落单者的 `toward` 必须在**同一张可走网格**上，否则跨层/跨连通块
    # 追过去会一路 NOWP 顶墙。判不出来就当没有汇合点，退回普通巡逻。
    _join_ok = False
    if _sq_toward is not None and nav is not None:
        try:
            _ka = _nav_key(nav, here, 1.6, 2)
            _kb = _goal_key(nav, _sq_toward)
            _join_ok = (_ka is not None and _kb is not None
                        and nav.component.get(_ka) == nav.component.get(_kb))
        except Exception:
            _join_ok = False
    dest = None
    if melee_stick or hold_perch:
        state["patrol"] = None
        state["move_dest"] = None
        state['patrol_ascent'] = False
        if hold_perch:
            state['parkour_route'] = None
            state['route_mobility'] = False
            state.pop('route_air_finished', None)
    elif float(state.get("force_roam", 0.0) or 0.0) > now:
        # 【v9】防死锁：上一轮卡住了，先随便找一个**可达**的点绕过去。
        state["move_dest"] = None
        state["patrol"] = None
        dest = human.pick_patrol(here, nav, threats, occupied=occupied,
                                 recent=recent, seed=rid + int(now * 3))
    elif decision.mode == "patrol":
        state["move_dest"] = None
        if _pursue is not None:
            # 先去看声源 / 目标最后出现的位置；到了就清掉回到正常巡逻。
            _pp = _pursue["pos"]
            if distance(here, _pp) >= 1.5:
                state["patrol"] = None
                dest = _pp
            else:
                state.pop("pursue", None)
                _pursue = None
                dest = state.get("patrol")
        else:
            dest = state.get("patrol")
        arrived = dest is not None and distance(here, dest) < 0.5
        crowded = arrived and human._crowd(here, occupied) > 1.0
        # 【v49】生化房的人类 BOT 主动游走（用户：「不要只后退、要在复活点附近
        # 主动移动」）。规则：不蹲高台，围绕出生点 10m 内每 3~5s 换一个点。
        # 只在 `patrol` 模式下生效 —— 开枪/后退/追击仍由 decide() 决定，
        # 不会为了走位放弃交战。
        # 【v57】成队后换点间隔拉长（守点像守点）；落单时勤换点，像在找人。
        wander = False
        if bio_human:
            if state.get('bio_home') is None:
                state['bio_home'] = here
            _gap = (6.0 if _sq_size >= 2 else 3.0) + (int(rid) * 7919 % 2000) / 1000.0
            if now >= float(state.get('bio_wander_next', 0.0)):
                wander = True
                state['bio_wander_next'] = now + _gap
        if (arrived and not crowded and not bio_human
                and here[1] - state.get('patrol_start_y', here[1]) >= .7):
            state['perch'] = here
            state['patrol'] = None
            state['patrol_ascent'] = False
            hold_perch = True
            dest = None
        elif bio_human and _sq_toward is not None and _join_ok and not crowded:
            # 【v57】落单 → 主动抱团：直接朝最近的同伴 / 最近小队的队心走。
            # 不经过 `pick_patrol` 的「舒服位置」打分 —— 那个打分带 7m 排斥，
            # 会让两个相向而行的 BOT 在 6~7m 处互相绕开，永远进不了 5m。
            dest = _sq_toward
            state["patrol"] = None
            state['patrol_ascent'] = False
        elif dest is None or crowded or wander:
            if dest is not None:
                recent.append(dest)
                del recent[:-4]
            # Keep the opening spread before sending a BOT to an upper perch.
            # Each room can reserve one voluntary uphill approach at a time.
            prefer_high = (not bio_human and
                           not any(distance(here, p) < human.FORMATION_GAP for p in allies.values())
                           and not any(motion.get(other, {}).get('patrol_ascent') for other in allies))
            # 生化人：成队守队心 4.5m（队友排斥半径压到 3m），落单守出生点 10m。
            _anchor = state.get('bio_home') if bio_human else None
            _aradius = 10.0 if bio_human else 0.0
            _maxd = 16.0 if preparing else 12.0
            _cgap = human.FORMATION_GAP
            if bio_human and _sq_center is not None:
                _anchor = _sq_center
                _aradius = squad.SQUAD_HOLD
                # 候选点是以**自己**为圆心 2~max_distance 生成的：队员离队心
                # 较远（迟滞 9m 的两个人）时，9m 半径里根本没有队心那圈点，
                # `pick_patrol` 会退回全圈候选把人派到 20m 外 —— 队伍当场散伙。
                _maxd = max(9.0, distance(here, _sq_center) + squad.SQUAD_HOLD + 2.0)
                _cgap = 3.0
            dest = human.pick_patrol(
                here, nav, threats, occupied=occupied, recent=recent,
                seed=rid + int(state.get("patrol_index", 0)),
                max_distance=_maxd, prefer_high=prefer_high,
                anchor=_anchor, anchor_radius=_aradius, crowd_gap=_cgap)
            state["patrol_index"] = int(state.get("patrol_index", 0)) + 1
            state["patrol"] = dest
            state['patrol_start_y'] = here[1]
            state['patrol_ascent'] = bool(prefer_high and dest is not None and dest[1]-here[1]>=.7)
    else:
        state["patrol"] = None
        state['patrol_ascent'] = False
        key = (decision.mode, decision.target_id)
        if (state.get("move_mode") != key or state.get("move_dest") is None
                or now >= float(state.get("move_until", 0.0))
                or distance(here, state.get("move_dest")) < 0.5):
            if decision.mode == 'chase' and target is not None:
                dest = human.pick_approach(
                    here, nav, threats, target, safe=safe, preferred=preferred,
                    occupied=occupied, recent=recent) or target.pos
            else:
                dest = human.choose_destination(
                    decision, here, nav, threats, safe=safe, preferred=preferred,
                    occupied=occupied, recent=recent, seed=rid)
                # 【v57】落单的人类 BOT 被僵尸追时，逃跑路线优先规划到最近的
                # 小队 / 最近的同伴身上：只在「确实朝汇合点更近」的候选里挑，
                # 安全过滤（走廊不许穿过僵尸）仍是最高优先级。挑不出来就退回
                # 普通撤退点 —— 宁可先活下来，也不许为了汇合往僵尸身上撞。
                if (bio_human and _join_ok and _sq_toward is not None
                        and decision.mode in ("retreat", "reload_retreat",
                                              "empty_retreat", "empty")):
                    try:
                        _alt = human.pick_retreat(
                            here, nav, threats, safe=safe, occupied=occupied,
                            recent=recent, toward=_sq_toward)
                    except Exception:
                        _alt = None
                    if _alt is not None:
                        dest = _alt
            # Stagger re-picks so twelve BOTs never run their corridor queries
            # in the same room-clock tick.
            state.update(move_mode=key, move_dest=dest,
                         move_until=now + 1.0 + (rid % 8) * 0.05)
        else:
            # Keep walking to the cached destination between re-picks.
            dest = state.get("move_dest")

    # 【v17】没有交战任务、又没在贴身刀战/守高处时，顺路去捡补给箱。
    # 不改 chase / retreat / reload 的走位，也不影响下面的闪避与开火。
    if (box_dest is not None and decision.mode == "patrol"
            and not melee_stick and not hold_perch):
        dest = box_dest

    surface = nav.ground(here) if nav is not None else None
    foot = (state.setdefault("foot", max(0.0, min(0.5, here[1] - surface[1])))
            if surface is not None else 0.0)
    budget = speed * dt
    newpos = here
    if dest is not None and nav is not None and colliders is not None:
        if hasattr(nav, "next_waypoint"):
            waypoint = nav.next_waypoint(here, dest, budget=budget,
                                         route=state.setdefault('route', {}))
        else:
            path = nav.path(here, dest)
            waypoint = next((p for p in path[1:]
                             if distance(here, p) > 0.02), None) if path else None
        if waypoint is not None:
            length = distance(here, waypoint)
            if length > 1e-6:
                newpos = lerp(here, waypoint, min(1.0, budget / length))
                newpos = _grounded_step(nav, colliders, here, newpos, foot,
                                        budget)
    if nav is not None and colliders is not None and not hold_perch:
        newpos = _separate(nav, colliders, here, newpos, rid, allies, foot,
                           budget)
        # 【v8】官方 Lv4 交战闪避：看到人之后每 `bot_dodge_freq` 秒横摆一次，
        # 持续 `bot_dodge_time` 秒（2s / 1.25s）。侧移用 `_grounded_step`
        # 校验，走不通就原地不动，不会穿墙也不会掉图。
        _dodge = state.get("dodge") or None
        # 【v36】横摆闪避只在排位 / 联赛启用（CF_BOT_DODGE_RANK_ONLY=0 可全局开）。
        _dodge_on = True
        try:
            if bool(getattr(CONFIG, "bot_dodge_rank_only", True)):
                _dodge_on = _is_rank_room(battle)
        except (TypeError, ValueError):
            _dodge_on = True
        if visible and target_f is not None and not airborne and _dodge_on:
            try:
                _df = float(getattr(CONFIG, "bot_dodge_freq", 2.0) or 0)
                _dtm = float(getattr(CONFIG, "bot_dodge_time", 1.25) or 0)
            except (TypeError, ValueError):
                _df = _dtm = 0.0
            if _df > 0 and _dtm > 0 and now >= float(state.get("dodge_at", 0.0)):
                state["dodge_at"] = now + _df
                _dodge = state["dodge"] = {
                    "until": now + _dtm,
                    "dir": 1.0 if int(now * 100) % 2 == 0 else -1.0,
                }
        if (_dodge is not None and now < float(_dodge.get("until", 0) or 0)
                and target_f is not None):
            _tp = _pos(target_f)
            if _tp is not None:
                _fx, _fz = _tp[0] - newpos[0], _tp[2] - newpos[2]
                _n = math.hypot(_fx, _fz)
                if _n > 1e-6:
                    _sx, _sz = -_fz / _n, _fx / _n
                    _dstep = budget * 0.7 * float(_dodge.get("dir", 1.0))
                    _side = (newpos[0] + _sx * _dstep, newpos[1],
                             newpos[2] + _sz * _dstep)
                    _try = _grounded_step(nav, colliders, newpos, _side, foot,
                                          budget)
                    if distance(_try, newpos) > 1e-3:
                        newpos = _try
        elif _dodge is not None:
            state.pop("dodge", None)
        # A valid uphill walking corridor is already a route to the perch.
        # An optional jump may otherwise pull the BOT back down the stairs.
        walking_upstairs = (decision.mode == 'patrol' and state.get('patrol_ascent')
                            and dest is not None and distance(here,newpos) > .08 and not airborne)
        if walking_upstairs:
            state['parkour_route'] = None
            state['route_mobility'] = False
            state.pop('route_air_finished', None)
        elif getattr(battle, '_bot_no_parkour', False):
            # 【v63】无烘焙跑酷路线的新图：不跳，且把上一版残留的跳跃/路线
            # 状态清干净。否则 `parkour.advance()` 会在下一帧把 BOT 直接
            # 送到上一回合的 `jump['end']`，看起来就是随机瞬移。
            for _k in ('jump', 'parkour_route', 'route_index',
                       'route_mobility', 'route_airborne', 'route_air_finished',
                       'form_airborne', 'form_air_at', 'client_jump_after'):
                state.pop(_k, None)
        elif hasattr(colliders,'floors'):
            from . import parkour
            newpos=parkour.step(battle,f,state,nav,colliders,here,newpos,dest,
                               speed,dt,now,evade='retreat' in decision.mode,
                               occupied=occupied)
    walking = distance(here, newpos) > 0.001
    # 【v9】防死锁：**有敌人**却连续 1.2 秒一步没挪（隔墙、贴墙、退无可退）
    # → 强制 roam 2 秒，下一 tick 换一个可达点绕路。
    # 这修的是「1v1 剩下两个 BOT 隔墙对峙、双双站着不动」的死锁。
    if (not walking and target_f is not None
            and decision.mode in ("chase", "retreat", "reload_retreat",
                                  "empty_retreat")):
        _stall = float(state.get("stall_t", 0.0) or 0.0) + dt
        state["stall_t"] = _stall
        if _stall >= 1.2:
            state["stall_t"] = 0.0
            state["force_roam"] = now + 2.0
            state["patrol"] = None
            state["move_dest"] = None
            state["pursue"] = None
            # 【v58】卡住了说明手上这条走廊走不通（缓存不能继续咬着不放）。
            state.pop('route', None)
            (log.info("HUMAN-BOT UNSTUCK role=%s mode=%s dist=%s",
                     rid, decision.mode,
                     round(target.dist, 1) if target is not None else "-") if log.isEnabledFor(20) else None)
    else:
        state["stall_t"] = 0.0
    if decision.mode == 'patrol' and dest is not None and distance(here, dest) >= .5 and not walking:
        stalled = state.get('patrol_stalled', 0.) + dt
        if stalled >= 1.0:
            recent.append(dest)
            del recent[:-4]
            state['patrol'] = None
            state['patrol_ascent'] = False
            stalled = 0.
        state['patrol_stalled'] = stalled
    else:
        state['patrol_stalled'] = 0.
    facing = target_f if target_f is not None else f
    entry = _step(f, facing, target.dist if target is not None else 0.0,
                  speed, dt, destination=newpos)
    # 【v17】补给箱拾取统一挪到 tick() 循环开头（覆盖人类/僵尸 BOT，
    # 条件从「所有枪备弹不足」放宽为「走到箱子 2m 内」）。
    if entry is not None:
        state["quat"] = entry["state"]["quat"]
    if dest is not None and walking:
        state["last_move_mode"] = decision.mode

    if decision.mode != state.get("mode") or decision.target_id != state.get("target"):
        (log.info("HUMAN-BOT %s role=%s target=%s dist=%s threats=%s reason=%s "
                 "ammo=%d/%d safe=%.1f preferred=%.1f speed=%.2f squad=%s",
                 decision.mode.upper(), rid, decision.target_id,
                 round(target.dist, 1) if target is not None else "-",
                 list(decision.threat_ids),
                 decision.reason, st.clip, st.reserve, safe, preferred, speed,
                 _sq_size) if log.isEnabledFor(20) else None)
        state["mode"], state["target"] = decision.mode, decision.target_id

    fired = 0
    firing = False
    _engaged = False
    # ---- 交战状态机（官方 AttackState 的等价物）-------------------------
    # 官方的「反应时间」只在**进入交战**时算一次，之后一直连发；视线被掩体
    # 短暂擦掉不会重置。原来这里是 `_seen.pop()`：只要有一帧看不见就把计时
    # 清零，于是变成「打 1~2 发 → 停 0.8~1.3 秒 → 再打 1~2 发」。
    _book = state.setdefault("engage", {})
    if target is None or target_f is None or not (
            getattr(target_f, "born", False) and float(target_f.hp) > 0):
        _book.clear()
    else:
        fp = _pos(f)
        _tid = int(target.roleid)
        _e = _book.get(_tid)
        _fresh = _e is None
        if _e is None:
            _e = _book[_tid] = {"since": float(now), "seen": float(now),
                                 "pos": tuple(target.pos)}
        dist = distance(fp, target.pos) if fp is not None else 0.0
        visible = bool(fp is not None and _visible(colliders, fp, target.pos))
        # 视野锥只决定「发现」；开火另有 1~2° 的枪口门限（`_aim_ok`）。
        if visible and not _facing_ok(battle, f, target.pos):
            visible = False
        if visible:
            _e["seen"] = float(now)
            _e["pos"] = tuple(target.pos)
        # 【v39】「连续可见 N 秒才开枪 / 每次丢失目标重新锁定」已按用户要求撤销，
        # 回到 v35 的逻辑：反应时间只在**进入交战**时算一次（`_e["since"]`），
        # 之后一直连发；只有丢视线超过 `bot_los_grace` 才退出交战、下次露头重算。
        # 枪口跟人：官方 OrientState 以 veer 度/秒平滑转，跑位中也要转。
        # **只朝「看得见的位置」转**（丢视线时是最后看到的位置），
        # 否则 BOT 会隔着墙一路锁定你，看起来像透视。
        # 从没看见过的目标不记位置（`_bot_threats` 会给到隔着墙的最近敌人）：
        # 没看见就不许转身、不许提前枪。
        _aim_now = (tuple(target.pos) if visible
                    else (tuple(_e["pos"]) if not _fresh else None))
        if fp is not None and _aim_now is not None:
            _half = _turn_towards(
                f, math.atan2(_aim_now[0] - fp[0], _aim_now[2] - fp[2]),
                dt, dist) * 0.5
            if entry is not None and isinstance(entry.get("state"), dict):
                entry["state"]["quat"] = {
                    "w": int(round(math.cos(_half) * 20000)), "x": 0,
                    "y": int(round(math.sin(_half) * 20000)), "z": 0}
        try:
            grace = float(getattr(CONFIG, "bot_los_grace", 0.35) or 0.35)
        except (TypeError, ValueError):
            grace = 0.35
        lost = float(now) - float(_e["seen"])
        if lost > grace:
            # 目标躲进掩体超过宽限：退出交战，下次露头重新走一遍「反应」。
            # 但记住「最后看到的位置」，按 pursueTime 追过去（官方 20s）。
            if _pursue_s > 0 and _e.get("pos") is not None:
                state["pursue"] = {"pos": tuple(_e["pos"]),
                                   "until": now + _pursue_s}
            _book.pop(_tid, None)
        else:
            # 掩体后仍按**最后看到的位置**继续打 grace 秒（子弹打在墙上）。
            _engaged = True
            _aim = _aim_now
            _adist = dist
            if fp is not None and _aim is not None:
                try:
                    _adist = distance(fp, _aim)
                except (TypeError, ValueError):
                    _adist = dist
            # 【v39】开火许可回到 `_bot_react`（按距离缩放的反应时间），
            # 不再要求「连续可见满 N 秒」。
            _react = _bot_react(None if held_melee else info, _adist,
                                bio_room=_is_bio_room(battle))
            _ready = (float(now) - float(_e["since"])) >= _react
            _aimed = bool(_aim is not None and _aim_ok(f, _aim, _adist))
            try:
                _engage_max = eng_range * float(
                    getattr(CONFIG, "bot_engage_range_scale", 1.2) or 1.2)
            except (TypeError, ValueError):
                _engage_max = eng_range * 1.2
            # 【v24】机枪 / 冲锋枪：枪口追不上横移目标时也持续开火（音效压迫），
            # 子弹沿真实枪口射出自然打偏，不做自瞄吸附；命中率因此自然下降。
            # 【v28】步枪（rifle）与机枪/冲锋枪一样：枪口追不上横移目标时
            # 也持续开火（沿真实枪口射出，自然打偏）。手枪不在内。
            _spray_cat = str(getattr(info, "category", "") or "").lower()                 if info is not None else ""
            _auto_spray = (_spray_cat in ("mg", "smg", "rifle")
                           and _ready and _aim is not None)
            if held_melee:
                # Knife uses Melee.range/speed, never GunInfo.  damage.py
                # rejects sd > Melee.range and same_team() protects friendlies.
                if (not _spawn_locked and visible and melee is not None
                        and human.can_melee(melee, dist)):
                    last = float(state.get("melee_last", -1e18))
                    if now + 1e-9 >= last + melee.shot_period:
                        _fire(battle, f, target_f, dist)
                        state["melee_last"] = now
                        fired = 1
                        (log.info("HUMAN-BOT MELEE role=%s target=%s dist=%.2f "
                                 "knife=%s range=%.2f speed=%.2f dmg=%.1f",
                                 rid, target.roleid, dist, melee.itemid,
                                 melee.range, melee.speed, melee.damage) if log.isEnabledFor(20) else None)
            elif (not _spawn_locked
                  and (decision.fire or lost <= grace) and _ready
                  and (_aimed or _auto_spray)
                  and _aim is not None and not reloading and not weapon_empty
                  and _adist <= _engage_max):
                # **完全连发**：不设组上限，按手里那把枪的射速一直打到
                # 弹匣空 / 目标消失 / 退出交战。丢视线的 0.35 秒里继续对
                # 最后位置开火。
                firing = True
                # 枪口没对准（靠 _auto_spray 放行）时沿枪口射击，命中自然下降
                _auto_fire = bool(_auto_spray and not _aimed)
                _active_info = st.slots[st.active].info if st.active in st.slots else info
                fired = st.take_shots(now, dt)
                gun_info = (st.slots[st.active].info
                            if st.active in st.slots else info)
                _moving = bool(walking)
                _running = bool(walking and speed >= 6.0)
                if fired and gun_info is not None and weapon_fire.needs_multi(gun_info):
                    # 霰弹/多弹丸：一次扣扳机走 ScMultiShoot 整组
                    _fire_volleys(battle, f, target_f, _adist, gun_info, fired,
                                  seq=int(now * 1000) + rid,
                                  events=st.drain_ray_events(),
                                  colliders=colliders, aim_pos=_aim)
                else:
                    _base_seq = int(now * 1000) + rid * 131
                    for _i in range(fired):
                        _fire(battle, f, target_f, _adist, _aim,
                              info=gun_info, colliders=colliders,
                              seq=_base_seq + _i,
                              moving=_moving, running=_running,
                              aim_yaw=(float(getattr(f, "_bot_yaw", 0.0))
                                       if _auto_fire else None))
                if fired and (now - float(state.get("fire_log_at", -1e9)) >= 1.0
                              or state.get("fire_target") != target.roleid):
                    state["fire_log_at"] = now
                    state["fire_target"] = target.roleid
                    (log.info("HUMAN-BOT FIRE role=%s target=%s dist=%.1f "
                             "gun=%s ammo=%d/%d interval=%.3f shots=%d vis=%s",
                             rid, target.roleid, dist,
                             info.itemid if info else 0, st.clip, st.reserve,
                             st.period_of(st.slots.get(st.active)), fired,
                             bool(visible)) if log.isEnabledFor(20) else None)
    if not firing and not held_melee and not _engaged:
        # 不开火的这一 tick 不攒子弹（`take_shots` 有自己的补发上限，
        # 但停顿久了会一次性补一长串，客户端看到的就是瞬间连结算）。
        st.hold(now)

    if walking:
        return 1, entry
    return 0, entry


def tick(battle, dt: float = 0.25) -> int:
    """每个回合 tick 驱动一遍所有机器人。返回动了的个数。

    与 `ScManageAI` 那条路**互斥**：客户端 `RoleStatusSync` 会跳过
    `DataPool.IsRelated` 的角色，而 IsRobot 正是 ManageAI 写进去的。
    两条同时开的话服务端推的位置会被静默丢弃，所以这里直接拒。
    """
    if not CONFIG.bots_drive or CONFIG.bots_ai or not math.isfinite(dt) or dt <= 0:
        return 0
    from . import bot_recoil, parkour, parkour_routes, zombie_jump
    from .navigation import distance, lerp
    nav,colliders = _world(battle)
    # 【v63】无烘焙跑酷路线的 1.9 新图：关掉主动跳跃（见 NO_PARKOUR_SCENES）。
    try:
        _scene = str((gamedata.map_row(battle.room.mapid) or {}).get('scene') or '')
        _no_parkour = _scene in NO_PARKOUR_SCENES
    except Exception:
        _no_parkour = False
    try:
        battle._bot_no_parkour = _no_parkour
    except Exception:
        pass
    now = time.monotonic()
    # Real dispatch interval: the room clock requests 0.25 s but a delayed or
    # coalesced callback must not be replayed as a 0.25 s step (and a faster
    # one must not move/shoot at the old cadence).  Clamp pathological gaps.
    prev = getattr(battle, "_bot_tick_at", None)
    try:
        battle._bot_tick_at = now
    except Exception:
        pass
    if prev is not None:
        measured = now - float(prev)
        if math.isfinite(measured) and 0.0 < measured <= 2.0:
            dt = measured
    # 主循环已是 10Hz；卡顿后**最多补偿 2 个周期**，不能把 1 秒的
    # 积压一次性推进（那会让 BOT 瞬移，并让 take_shots 一次补发
    # 一大串子弹 -> 客户端看到「瞬间结算多次」/ 一帧被打空血）。
    dt = max(1e-3, min(float(dt), 0.2))
    # Fighter 是 __slots__ 类，不能往上挂临时字段，开火时刻记在 battle 上。
    shots: Dict[int, float] = getattr(battle, "_bot_shot_at", None)
    if shots is None:
        shots = battle._bot_shot_at = {}
    motion = getattr(battle,'_bot_motion',None)
    if motion is None:motion=battle._bot_motion={}
    moved = 0
    entries: Dict[int, dict] = {}
    neighbours={int(f.roleid):_pos(f) for f in battle.fighters.values()
                if f.born and f.hp>0 and _pos(f) is not None}
    bio = getattr(battle, 'biochem', None)
    # 【v57】生化人类小队分组：**一帧只算一次**（`squad.plan` 内部还有
    # 0.45s 缓存），7~8 个 BOT 共用同一份结果，避免每个人各算一遍导致
    # 同一帧里 A 看到「已组队」、B 看到「还落单」的撕裂判断。
    _squad_of: Dict[int, dict] = {}
    if bio is not None:
        try:
            _hm: Dict[int, tuple] = {}
            for _f in battle.fighters.values():
                if (is_bot(_f.roleid) and _f.born and _f.hp > 0
                        and not bio.is_zombie(int(_f.roleid))):
                    _p = _pos(_f)
                    if _p is not None:
                        _hm[int(_f.roleid)] = _p
            _squad_of = squad.plan(battle, _hm, now, nav)
        except Exception:
            log.exception("BIO-SQUAD 划分异常（已隔离，不影响 BOT 移动）")
            _squad_of = {}
    for f in list(battle.fighters.values()):
        if not is_bot(f.roleid) or not f.born or f.hp <= 0:
            continue
        rid=int(f.roleid);state=motion.setdefault(rid,{})
        state['updated_at']=now
        # 【v18】位置合法性自愈：一旦脱离地面网格（浮空 / 被刷到高台 /
        # 跳跃落点异常），把 BOT 拉回最近合法节点，并清掉会让下一帧继续
        # 卡住的全部状态。整段隔离，单个 BOT 出错不能拖死整房 tick。
        #
        # 【v46】**正在跳跃 / 跑酷腾空的 BOT 必须跳过这一段**：起跳后 y 必然
        # 高于地面 0.6m 以上（超过 1.2m 时 `nav.ground()` 直接返回 None），
        # 原来这里会把空中的 BOT 当场「拉回地面」，多层图（封锁地铁：1 层
        # 轨道 y≈0.6、地下通道 y≈-3.7）上就会被正下方的节点吸走 ——
        # 玩家看到的就是「BOT 在轨道上瞬移、卡进地下通道的圆柱」。
        try:
            _hp = _pos(f)
            _airborne = bool(state.get('jump') is not None
                             or state.get('form_airborne'))
            if (not _airborne and nav is not None and colliders is not None
                    and _hp is not None):
                _g = nav.ground(_hp)
                if (_g is None or nav.locate(_hp) is None
                        or abs(_hp[1] - _g[1]) > 0.6):
                    _anchor = _bot_ground_anchor(nav, colliders, _hp)
                    if _anchor is not None:
                        _dh = math.hypot(_anchor[0] - _hp[0],
                                         _anchor[2] - _hp[2])
                        # 【v63】原来允许横向拉 12m，客户端 `RoleStatusSync`
                        # 对 >8m 位移直接 teleport —— 多层图上一次自愈就是
                        # 玩家看到的「BOT 瞬移出去」。现在只允许 1.5m 内的
                        # 贴地微调；锚点更远时**绝不搬水平位置**，只把 y
                        # 贴回地面，剩下的交给发包前的连续性钳制。
                        if _dh <= 1.5:
                            f.syncpos = _anchor
                        else:
                            f.syncpos = (_hp[0],
                                         round(_anchor[1] + float(
                                             state.get('foot') or 0.0), 2),
                                         _hp[2])
                        for _k in ('jump', 'form_airborne', 'form_air_at',
                                   'jump_since', 'perch', 'foot', 'patrol',
                                   'move_dest', 'pursue', 'stall_t',
                                   'patrol_stalled', 'dodge', 'box_dest',
                                   'box_until', 'stuck'):
                            state.pop(_k, None)
                        (log.info("BOT-GROUND-FIX role=%s %s -> %s", rid,
                                 tuple(round(v, 2) for v in _hp),
                                 tuple(round(v, 2) for v in _anchor)) if log.isEnabledFor(20) else None)
        except Exception:
            (log.debug("BOT-GROUND-FIX 异常 role=%s", rid, exc_info=True) if log.isEnabledFor(10) else None)
        # **跑酷状态看门狗**：复杂地形里一次跳跃的弧线可能永远等不到落地，
        # `state['jump']` 就会一直留在 motion 里，之后每个 tick 只走下面的
        # airborne 分支、再也不做寻路和射击 —— 表现就是「全场 bot 站原地不动」。
        # 用户实测「打死母体 bot 后它复活就恢复自主行动」，正是因为 born()
        # 会清掉 _bot_motion[rid]。这里给卡住的跳跃加 3 秒超时兜底。
        if state.get('jump') is not None:
            _js = float(state.get('jump_since', 0) or 0)
            if _js <= 0:
                state['jump_since'] = now
            elif now - _js > 3.0:
                for _k in ('jump', 'form_airborne', 'form_air_at', 'jump_since'):
                    state.pop(_k, None)
        else:
            state.pop('jump_since', None)
        zombie = bio is not None and bio.is_zombie(rid)
        # 【v17】BOT 补给箱：用上一帧位置就近拾取，再决定这一帧要不要顺路去捡。
        # 整段隔离：tick() 是整房串行的，这里抛一次就会让本帧后面所有 BOT
        # 都不动（历史上踩过「全场静止」），捡箱子绝不能有这种权限。
        _box_dest = None
        try:
            if _bot_try_pickup_box(battle, f, zombie):
                state["box_until"] = now + 3.0
            _box_dest = _bot_seek_box(battle, f, state, zombie, now)
        except Exception:
            log.exception("BOT-BOX 异常 role=%s（已隔离，不影响其它 BOT）", rid)
        if state.get('jump') is not None and (state.get('form_airborne') or zombie):
            # born() already advanced this arc up to the actual model-change
            # time. A later fighter in this same tick must not advance the
            # whole room interval a second time.
            air_dt = dt
            if state.get('form_airborne'):
                air_dt=max(0.,now-state.get('form_air_at',now-dt))
                state['form_air_at']=now
            here=_pos(f);newpos=parkour.advance(state,air_dt)
            target,dist=_pick_target(battle,f,nav,colliders,
                                     prev=state.get('lock_target'))
            committed = battle.fighters.get(state.get('jump_attack_target'))
            if zombie and zombie_jump.valid_target(battle, committed):
                target = committed
                dist = distance(newpos, target.syncpos)
            if (zombie and zombie_jump.valid_target(battle, target)
                    and not state.get('air_claw_windup')):
                _claw_gate(battle, f, prime_only=True)
                state['air_claw_windup'] = True
            entry=_step(f,target or f,dist or 0.,_profile(battle,f)[1],dt,destination=newpos)
            if entry is not None:entries[rid]=entry
            if distance(here,newpos)>.001:moved+=1
            if zombie:
                zombie_jump.claw(battle, f, target, colliders, shots, now)
            elif target is not None and target.born and target.hp>0:
                # 【v21.2】空中 / 跑酷状态开火：旧实现走 _profile 写死的
                # 0.9s 间隔、且 _fire 不带 info —— 于是既不耗弹、不走枪械
                # 射速、还 100% 命中（扇区必中），狙击被按 0.9s 无限子弹
                # 超模。现在改接 AmmoState：按枪本身的 period_of 限速、消耗
                # 弹匣、走真实散布，与站原地那一条通道完全一致。
                st = _ammo_state(battle, f)
                if st is not None and st.active in st.slots:
                    _ginfo = st.slots[st.active].info
                    _rng = (float(_ginfo.effective_range)
                            if _ginfo is not None else _profile(battle, f)[0])
                    reach = distance(newpos, _pos(target))
                    if (reach <= _rng and _visible(colliders, newpos, _pos(target))
                            and not _spawn_fire_locked(battle, rid, now)):
                        if st.take_shots(now, dt) > 0:
                            shots[rid] = now
                            _fire(battle, f, target, reach, info=_ginfo,
                                  colliders=colliders, moving=False, running=False)
            if state.get('jump') is None:
                state.pop('form_airborne',None)
                state.pop('jump_attack_target',None)
                state.pop('air_claw_windup',None)
            continue
        # 所有拿枪的 bot 都走弹药系统（真实射速/弹匣/换弹/散布）。
        # 排除手枪模式（有独立的 `_pistol_tick`）和手雷模式（投掷不走枪械）。
        _limit = int(getattr(battle.room, "equiplimitid", 0) or 0)
        if (_is_human_bot(battle, f)
                and _limit not in (special_modes.PISTOL, special_modes.GRENADE)):
            # **单个 BOT 出错不能拖死整间房**：tick() 是整房串行的，
            # 这里抛一次异常就会让后面所有 BOT 这一帧都不动（表现为全场静止、
            # 也不开枪）。改成逐个人兜底 + 每房只报一次。
            try:
                m, entry = _tick_human_bot(battle, f, nav, colliders, now, dt,
                                           motion, neighbours, shots,
                                           box_dest=_box_dest,
                                           squad_info=_squad_of.get(rid))
            except Exception:
                _key = "_bot_fail_" + str(rid)
                if getattr(battle, _key, False) is not True:
                    setattr(battle, _key, True)
                    log.exception("HUMAN-BOT 大脑异常 role=%s（已隔离，不影响其它 BOT）", rid)
                continue
            moved += m
            if entry is not None:
                entries[rid] = entry
            continue
        target, dist = _pick_target(battle, f, nav, colliders,
                                    prev=state.get('lock_target'))
        if target is not None:
            state['lock_target'] = int(target.roleid)
        else:
            state.pop('lock_target', None)
        rng, speed, itv, keep = _profile(battle, f)
        here=_pos(f)
        if here is None:continue
        surface=nav.ground(here) if nav is not None else None
        foot=state.setdefault('foot',max(0.,min(.5,here[1]-surface[1]))) if surface is not None else 0.
        if zombie and target is not None:
            airborne = zombie_jump.start(battle, f, target, state, nav, colliders,
                                         speed, dt, now)
            if airborne is not None:
                entry = _step(f, target, dist or 0., speed, dt, destination=airborne)
                if entry is not None:
                    entries[rid] = entry
                moved += int(distance(here, airborne) > .001)
                zombie_jump.claw(battle, f, target, colliders, shots, now)
                continue
        dest=None;visible=False
        if nav is not None and colliders is not None:
            if target is not None:
                visible=_visible(colliders,here,_pos(target))
                if (not zombie and battle.biochem is not None and dist<8
                        and f.roleid not in getattr(battle.biochem,'heroes',set())):
                    dest=state.get('retreat')
                    if (state.get('retreat_enemy')!=target.roleid or dest is None
                            or now>=state.get('retreat_until',0.) or distance(here,dest)<.5):
                        dest=_anchor(nav,here,rid,away=_pos(target))
                        state.update(retreat=dest,retreat_enemy=target.roleid,retreat_until=now+1.)
                elif (dist>keep or not visible
                      or not _can_engage(nav, here, _pos(target), keep, dist,
                                         state, now)):
                    if (visible and dist<=keep
                            and now>=float(state.get('offlevel_log',0.0))):
                        # 【v55】可观测：出现「够近但贴不上」时留一条记录，
                        # 下次真机复现可以直接看是不是这里判的。
                        state['offlevel_log']=now+2.0
                        _tp=_pos(target)
                        (log.info('BOT-OFFLEVEL role=%s here=%s target=%s dy=%.2f '
                                 'keep=%.2f dist=%.2f -> 继续绕路',
                                 rid,tuple(round(v,2) for v in here),
                                 tuple(round(v,2) for v in _tp),
                                 abs(_tp[1]-here[1]),keep,dist) if log.isEnabledFor(20) else None)
                    dest=_pos(target)
            else:
                dest=state.get('patrol')
                if dest is None or distance(here,dest)<.5:
                    recent=state.setdefault('visited',[])
                    if dest is not None:recent.append(dest);del recent[:-4]
                    occupied=[p for other,p in neighbours.items() if other!=rid]
                    occupied += [s['patrol'] for other,s in motion.items()
                                 if other!=rid and other in neighbours and s.get('patrol') is not None]
                    dest=_anchor(nav,here,rid+state.get('patrol_index',0),
                                 occupied=occupied,recent=recent)
                    state['patrol']=dest;state['patrol_index']=state.get('patrol_index',0)+1
        # 【v17】僵尸 BOT 顺路去捡生化补给箱（回满血 + 生化经验）。
        # 有近处人类目标时仍以追人为主，只有贴脸的箱子才值得拐一下。
        if _box_dest is not None and (target is None or (dist or 99.0) > 8.0):
            dest = _box_dest
        newpos=here
        # 【v48】僵尸 BOT 的击退改为**与真人完全一致**（用户口径）。
        #
        # 客户端 `Warrior.Speed` 的 isUser 分支：
        #     if (recedeTime > 0f) { _speed = -recedeSpeed; ...; return -recedeSpeed; }
        # 也就是说击退期间玩家的移动被**整体接管**：前进速度直接变 0，人只被
        # 往后推。而 v13 之后 BOT 是「先正常前进、再把击退位移加上去」，
        # 一边被推一边照跑 7m/s —— 同样一把枪打玩家是「锁住往后滑」，打 BOT
        # 只是「慢一点」，这就是「人类 bot 逼退我、我的枪推不动幽灵」的来源。
        # 现在默认改成「替代」：击退生效的那一 tick 不做寻路推进，只执行
        # 击退位移（曲线与客户端 RecedeTask 同一个公式，见 bot_recoil）。
        #   CF_BOT_RECOIL_LOCK=1（默认）与真人一致
        #   CF_BOT_RECOIL_LOCK=0        回到 v13 的叠加行为
        #   （若出现「僵尸体感上永远打不进去」，先把它设 0 再评估）
        recoil = (bot_recoil.displacement(state, dt)
                  if zombie and nav is not None and colliders is not None else None)
        _lock_move = recoil is not None and bot_recoil.lock_move()
        if dest is not None and not _lock_move:
            # 【v56】目标就在**下一层**、而且中间没有栏杆 → 直接朝它走下去。
            # 老逻辑一律走走廊，于是「站台上看着两米下轨道里的人」会一路跟着
            # 走、被送去绕楼梯，二十秒才下来（用户实拍 1v7 跟边）。物理上
            # `_grounded_step` 的 STEP_DOWN=1.2 本来就允许这个落差，缺的只是
            # 「别把这一步交给绕路规划」。
            # 只给**追击方**（幽灵 / 人类英雄）用：普通人类 BOT 的 dest 往往是
            # 「远离敌人的撤退点」，让它顺着落差往下跳等于送人头。
            _chaser = zombie or (battle.biochem is not None and
                                 f.roleid in getattr(battle.biochem, 'heroes', set()))
            _drop = _direct_drop(nav, colliders, here, dest) if _chaser else None
            if _drop is not None:
                waypoint = _drop
                state.pop('wp_hold', None)
            elif hasattr(nav,'next_waypoint'):
                waypoint=nav.next_waypoint(here,dest,budget=speed*dt,
                                           route=state.setdefault('route', {}))
            else:
                path=nav.path(here,dest)
                waypoint=next((p for p in path[1:] if distance(here,p)>.02),None) if path else None
            # One straight path segment per packet: interpolating a multi-corner
            # displacement would cut back through the obstacle on the client.
            if waypoint is not None:
                length=distance(here,waypoint)
                newpos=lerp(here,waypoint,min(1.,speed*dt/length))
                # Keep a stable foot offset. Treating a shortcut's interpolated
                # Y as a new foot offset each tick accumulates drift on ramps.
                newpos=_grounded_step(nav,colliders,here,newpos,foot,speed*dt)
        if recoil is not None and nav is not None and colliders is not None:
            dx, dz = recoil
            # 【v49】净位移下限：任何武器（含叠 2 颗的霰弹）都不许把僵尸「打飞」。
            # 每 tick 被推的距离上限 = (推进速度 − 下限) × dt，
            # 也就是稳态净位移最低只会是 `bot_recoil_net_min`（默认 −0.50 m/s）。
            # 只削「过猛的那一段速度」，推力倍率与叠加规则都不变。
            try:
                _floor = float(getattr(CONFIG, "bot_recoil_net_min", -0.5))
            except (TypeError, ValueError):
                _floor = -0.5
            _cap = max(0.0, (0.0 if _lock_move else speed) - _floor) * dt
            _plen = math.hypot(dx, dz)
            if _plen > _cap + 1e-9:
                if _cap <= 0.0:
                    dx = dz = 0.0
                else:
                    _k = _cap / _plen
                    dx *= _k
                    dz *= _k
            pushed = (newpos[0] + dx, newpos[1], newpos[2] + dz)
            newpos = _grounded_step(nav, colliders, newpos, pushed, foot,
                                    max(speed*dt, math.hypot(dx, dz)) + 0.02)
            (log.debug('BOT-RECOIL role=%s here=%s to=%s', rid, here, newpos) if log.isEnabledFor(10) else None)
        if recoil is None and nav is not None and colliders is not None:
            newpos=_separate(nav,colliders,here,newpos,rid,neighbours,foot,speed*dt)
            if zombie and hasattr(colliders,'floors'):
                uphill = _pos(target) if target is not None and _pos(target)[1] - here[1] > .35 else None
                routed = parkour_routes.steer(battle,f,state,nav,colliders,here,newpos,
                                              uphill,
                                              speed,dt,now,pursuit=True)
                if routed is not None:
                    newpos = routed
            elif (battle.biochem is not None and f.roleid in getattr(battle.biochem,'heroes',set())
                    and hasattr(colliders,'floors')):
                newpos=parkour.step(battle,f,state,nav,colliders,here,newpos,dest,speed,dt,now)
        walking=distance(here,newpos)>.001
        # **卡住检测。** 有目标却连续 0.8 秒原地不动，说明寻路给了空
        # waypoint 或者被拐角卡住 —— 原来这种情况不会有任何兜底，BOT 就
        # 站在那儿当雕像（幽灵发呆就是这么来的）。直接朝目标挪一步。
        # 【v48】击退接管移动期间不算「卡住」：被顶在墙上原地不动是正常
        # 现象，否则 0.8 秒后会触发 BOT-UNSTUCK 强制推进（1.5×速度），
        # 把「被压制」变成「顶着枪往前窜」。
        if (target is not None and not walking and not _lock_move
                and nav is not None and colliders is not None):
            _stuck = float(state.get('stuck', 0.0)) + dt
            state['stuck'] = _stuck
            if _stuck >= 0.8:
                tp = _pos(target)
                if tp is not None:
                    _len = max(0.05, speed * dt * 1.5)
                    _dx, _dz = tp[0] - here[0], tp[2] - here[2]
                    _dd = math.hypot(_dx, _dz) or 1.0
                    _ux, _uz = _dx / _dd, _dz / _dd
                    # 直线被墙/柱子挡住时，光朝目标推永远推不动（用户反馈
                    # 「幽灵对着墙不动」）。横向绕行：左右各扫几个角度，找
                    # 一个 walk_clear 通过的方向侧移一步，绕出卡点。
                    _moved = False
                    _angles = [0.0, 0.55, -0.55, 1.15, -1.15, 1.75, -1.75]
                    for _ang in _angles:
                        _c = math.cos(_ang); _s = math.sin(_ang)
                        _vx = _ux * _c - _uz * _s
                        _vz = _ux * _s + _uz * _c
                        _push = (here[0] + _vx * _len, here[1],
                                 here[2] + _vz * _len)
                        try:
                            _n = _grounded_step(nav, colliders, here, _push,
                                                foot, _len)
                        except Exception:
                            _n = _push
                        if distance(here, _n) > 0.001:
                            newpos = _n
                            _moved = True
                            break
                    state['stuck'] = 0.0
                    state['patrol'] = None
                    # 【v58】0.8 秒没挪动 = 这条缓存走廊走不通，丢掉重规划。
                    state.pop('route', None)
                    walking = _moved
                    # 【v56】日志补上「是不是不在网格上」和位移量：真机再出现
                    # 「原地左右磨」时，一眼能分清是卡在无网格的口袋里（地板
                    # 低于 1.7m 净空 / 铁轨之间），还是路线本身来回抖。
                    try:
                        _off = nav.locate(here) is None
                    except Exception:
                        _off = None
                    (log.info('BOT-UNSTUCK role=%s target=%s here=%s dy=%.2f '
                             'offgrid=%s moved=%s -> %s',
                             rid, target.roleid,
                             tuple(round(v, 2) for v in here),
                             abs((_pos(target) or here)[1] - here[1]),
                             _off, _moved,
                             tuple(round(v, 2) for v in newpos)) if log.isEnabledFor(20) else None)
        elif walking or _lock_move:
            state['stuck'] = 0.0
        if dest is not None and not walking and target is None:
            # An obsolete/blocked patrol must not pin this actor forever.
            state['patrol']=None
            recent=state.setdefault('visited',[]);recent.append(dest);del recent[:-4]
        # Send an explicit zero velocity when a moving actor stops/loses a target.
        # Keep periodic position samples while idle so timestamps stay current.
        facing=target or f
        e=_step(f,facing,dist or 0.,speed,dt,destination=newpos)
        if e is not None:
            if not walking and target is None and state.get('quat') is not None:
                e['state']['quat']=state['quat']
            state['quat']=e['state']['quat']
            entries[rid]=e
        state['moving']=walking
        if walking:moved+=1
        if (getattr(battle.room, "equiplimitid", 0) == special_modes.PISTOL
                and f.weaponpos == human.POS_VICE_GUN):
            can_see = target is not None and target.born and target.hp > 0
            if can_see:
                dist = distance(_pos(f), _pos(target))
                can_see = dist <= rng and _visible(colliders, _pos(f), _pos(target))
            _pistol_tick(battle, f, target, dist, can_see, colliders, state,
                         now, dt)
            continue
        if target is None or not target.born or target.hp<=0:continue
        dist=distance(_pos(f),_pos(target))
        # 【v8】幽灵 BOT 放技能：视线内有人类就放（不看距离，交给技能自己）。
        if zombie:
            _zf, _zt = _pos(f), _pos(target)
            if (_zf is not None and _zt is not None
                    and _visible(colliders, _zf, _zt)):
                _zombie_skill(battle, f, now)
            zombie_jump.claw(battle, f, target, colliders, shots, now)
            continue
        last = float(shots.get(int(f.roleid), 0.0) or 0.0)
        if (dist <= rng and now - last >= itv
                and not _spawn_fire_locked(battle, rid, now)
                and (visible if not walking else _visible(colliders,_pos(f),_pos(target)))):
            shots[int(f.roleid)] = now
            if getattr(battle.room, "equiplimitid", 0) and f.weaponpos == 41:
                from . import grenades
                grenades.bot_throw(battle, f, target, colliders)
            else:
                _fire(battle, f, target, dist)
    # 一个 tick 一帧位置：全场机器人合进同一条 ScRoleStatusSync。
    # 客户端每收到一条就把 lastSyncServerTime 推到它的 servertime，
    # 拆成多条同毫秒的消息并不会更顺，只会多一倍包。
    # 【v63】**位置连续性硬约束**（用户实拍：排位火车工厂 BOT 在复活点出生后
    # 瞬移出去，过程中也随机瞬移）。寻路链里有好几条路径会单帧给出 2~12m
    # 的落点：`parkour` 跳跃的 `jump['end']`、`_vault` 跨障、自愈锚点（原来
    # 允许横拉 12m）、多层网格把 BOT 判到另一层的节点。客户端
    # `ClientManager.RoleStatusSync` 对 >8m 直接 teleport，2~3m 一帧也会被
    # CharacterController 当成穿墙推出去 —— 看到的都是「瞬移」，而且
    # `speed` 向量同时异常，看起来就是「移动速度不对」。
    # 服务端自己的烘焙网格是逐点自洽的（实测 2877 节点 ground/locate 全通过），
    # 但客户端地图几何与这份网格未必逐点吻合，所以最后统一在**发包前**把
    # 发给客户端的位置钳到上一帧的邻域里：水平不超过 speed*dt + 余量，
    # 垂直不超过 1m。>8m 且落点仍在网格上的位移视为合法复活/换回合，放行。
    # 钳制后写回 f.syncpos，避免下一帧从错误位置继续累计。
    _last = getattr(battle, '_bot_last_sent', None)
    if _last is None:
        _last = battle._bot_last_sent = {}
    _cap = max(0.8, 8.0 * dt + 0.25)
    for _rid, _e in list(entries.items()):
        _st = _e.get('state') or {}
        _p = _st.get('pos')
        if not _p:
            continue
        _cur = (_p['x'] / 100.0, _p['y'] / 100.0, _p['z'] / 100.0)
        _prev = _last.get(_rid)
        if _prev is None:
            _last[_rid] = _cur
            continue
        _dx, _dz = _cur[0] - _prev[0], _cur[2] - _prev[2]
        _dh = math.hypot(_dx, _dz)
        if _dh > _cap:
            # 合法复活 / 换回合：新位置必须还在可走网格上才放行。
            if _dh > 8.0 and nav is not None:
                try:
                    _legal = nav.locate(_cur) is not None
                except Exception:
                    _legal = False
                if _legal:
                    _last[_rid] = _cur
                    continue
            _k = _cap / _dh
            _dy = max(-1.0, min(1.0, _cur[1] - _prev[1]))
            _q = (round(_prev[0] + _dx * _k, 2),
                  round(_prev[1] + _dy, 2),
                  round(_prev[2] + _dz * _k, 2))
            _st['pos'] = _v3(*_q)
            _st['speed'] = _v3((_q[0] - _prev[0]) / dt,
                               (_q[1] - _prev[1]) / dt,
                               (_q[2] - _prev[2]) / dt)
            _f = battle.fighters.get(_rid)
            if _f is not None:
                _f.syncpos = _q
            _last[_rid] = _q
            (log.debug('BOT-STEP-CLAMP role=%s %.2fm -> %.2fm', _rid, _dh, _cap)
             if log.isEnabledFor(10) else None)
        else:
            _last[_rid] = _cur
    if entries:
        battle.broadcast_positions(entries)
    return moved
