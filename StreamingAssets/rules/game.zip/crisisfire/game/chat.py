"""聊天：私聊 / 房间聊天 / 战斗内聊天 / 世界频道。

客户端会发这四条，服务端原来**一条都没有 handler**（`tools/audit_handlers.py`
只扫 spec 里 Cs* 开头的请求，chat 命名空间下的这四条没被扫到）：

    851969  ChatMessage            私聊（ChatGoalBoard：好友 / 悄悄话）
    851998  ChatMessageInTeam      房间聊天（RoomWindow / OperPanel）
    851999  CsChatMessageInFight   战斗内聊天（WarTalker）
    851970  CsBroadcastMessage     世界频道（ChatFreeBoard / Speaker）

没有 handler 的表现：聊天框打出去什么也不会发生 —— 自己看不到、别人也看不到。
服务端日志里同样一片安静（未注册消息只在 DEBUG 级别记一行）。

字段语义（从客户端反编译确认）：

    ChatMessage(roleid, content)        客户端里 roleid 是**收件人**；
                                         服务端转给收件人时要换成**发件人** roleid
    ChatMessageInTeam(roomid, roleid, content)
    CsChatMessageInFight(roomid, target, content)   target = channelid
    ScChatMessageInFight(roomid, roleid, content, target)
    CsBroadcastMessage(content, channel) -> BroadcastMessage(content, roleid, name,
                                          viplevel, monthcard, icon, rank)
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from ..net.server import ROUTER, Session
from . import pve_progress

log = logging.getLogger("crisisfire.chat")


class ID:
    CHAT_MESSAGE = 851969          # 私聊（双向）
    CS_BROADCAST = 851970          # 世界频道：客户端 -> 服务端
    BROADCAST = 851971             # 世界频道：服务端 -> 所有人
    SC_BROADCAST = 851975          # 结果（0 = 成功）
    CHAT_TEAM = 851998             # 房间聊天（双向）
    CS_CHAT_FIGHT = 851999         # 战斗内聊天：客户端 -> 服务端
    SC_CHAT_FIGHT = 852000         # 战斗内聊天：服务端 -> 队伍
    OFFLINE_FRIEND_MSG = 917527    # 离线私聊，登录时补发

CHAT_MAX_LEN = 200                # 单条上限，防超长包
WORLD_COOLDOWN = 1.0             # 世界频道同一人最短间隔（秒）
OFFLINE_MAX = 50                 # 每人最多存这么多条离线私聊

_world_last: Dict[int, float] = {}


def _clean(raw: Any) -> str:
    """客户端已经 Filter 过一次；这里只做长度/空白兜底。"""
    text = str(raw or "").strip()
    return text[:CHAT_MAX_LEN]


def _room_of(roleid: Optional[int]):
    if not roleid:
        return None
    from . import room_handlers
    return room_handlers.MANAGER.room_of(int(roleid))


def _world():
    from . import handlers
    return handlers.world


def _role_of(roleid: int):
    world = _world()
    return world.role(int(roleid)) if world is not None else None


# ---------------------------------------------------------------------------
# 私聊
# ---------------------------------------------------------------------------
@ROUTER.register(ID.CHAT_MESSAGE, "chat.ChatMessage")
async def on_chat_message(session: Session, msg: dict) -> None:
    """ChatMessage(roleid=收件人, content) -> 转发 ChatMessage(roleid=发件人, content)。"""
    target = int(msg.get("roleid") or 0)
    content = _clean(msg.get("content"))
    sender = int(session.roleid or 0)
    world = _world()
    if not (target and content and sender and world is not None):
        return
    if target == sender:
        return
    # 收件人把发件人拉黑了就不打扰他（客户端自己也会过滤好友列表）
    try:
        if world.has_blacklisted(target, sender):
            return
    except Exception:
        pass
    s = (world.session_of_role(target, "gs")
         or world.session_of_role(target))
    if s is None or s.closed:
        # 对方不在线：存成离线私聊，等他登录时用 ScOfflineFriendMessage 补发
        stored = _store_offline(world, target, sender, content)
        (log.info("私聊 %s -> %s 对方不在线，已存离线消息（%s 条）",
                 sender, target, stored) if log.isEnabledFor(20) else None)
        return
    s.send(ID.CHAT_MESSAGE, roleid=sender, content=content)
    (log.info("私聊 %s -> %s: %r", sender, target, content) if log.isEnabledFor(20) else None)


def _offline_msgs(role) -> list:
    raw = (role.data or {}).get("offline_msgs")
    return list(raw) if isinstance(raw, list) else []


def _store_offline(world, target: int, sender: int, content: str) -> int:
    """给离线玩家留一条私聊（上限 OFFLINE_MAX，先进先出）。"""
    role = world.role(int(target))
    if role is None:
        return 0
    msgs = _offline_msgs(role)
    msgs.append({"friendid": int(sender), "time": int(time.time()),
                 "message": content})
    msgs = msgs[-OFFLINE_MAX:]
    world.merge_role_data(role.roleid, offline_msgs=msgs)
    return len(msgs)


def push_offline(session: Session, role) -> None:
    """登录时把离线私聊补发出去（ScOfflineFriendMessage -> TalkManager.Response）。"""
    msgs = _offline_msgs(role)
    if not msgs:
        return
    session.send(ID.OFFLINE_FRIEND_MSG, messages=msgs)
    if _world() is not None:
        _world().merge_role_data(role.roleid, offline_msgs=[])
    (log.info("role %s 补发 %d 条离线私聊", role.roleid, len(msgs)) if log.isEnabledFor(20) else None)


# ---------------------------------------------------------------------------
# 房间聊天
# ---------------------------------------------------------------------------
@ROUTER.register(ID.CHAT_TEAM, "chat.ChatMessageInTeam")
async def on_chat_team(session: Session, msg: dict) -> None:
    """房间聊天：广播给同一个房间的所有人（含自己 —— 客户端不本地回显）。"""
    from . import room_handlers as rh
    roomid = int(msg.get("roomid") or 0)
    content = _clean(msg.get("content"))
    sender = int(session.roleid or 0)
    room = rh.MANAGER.get(roomid) or _room_of(sender)
    if room is None or not content or sender not in room.members:
        return
    for s in rh._sessions_of(room, "gs"):
        s.send(ID.CHAT_TEAM, roomid=room.roomid, roleid=sender, content=content)
    (log.info("房间 %s 聊天 %s: %r", room.roomid, sender, content) if log.isEnabledFor(20) else None)


# ---------------------------------------------------------------------------
# 战斗内聊天
# ---------------------------------------------------------------------------
@ROUTER.register(ID.CS_CHAT_FIGHT, "chat.CsChatMessageInFight")
async def on_chat_fight(session: Session, msg: dict) -> None:
    """战斗内聊天：WarTalker.Recv 只在 roomid 匹配时显示，target 是频道号。"""
    from . import room_handlers as rh
    roomid = int(msg.get("roomid") or 0)
    target = int(msg.get("target") or 0)
    content = _clean(msg.get("content"))
    sender = int(session.roleid or 0)
    room = rh.MANAGER.get(roomid) or _room_of(sender)
    if room is None or not content or sender not in room.members:
        return
    for s in rh._sessions_of(room, "gs"):
        s.send(ID.SC_CHAT_FIGHT, roomid=room.roomid, roleid=sender,
               content=content, target=target)
    (log.info("战斗聊天 room=%s %s (ch=%s): %r", room.roomid, sender, target,
             content) if log.isEnabledFor(20) else None)


# ---------------------------------------------------------------------------
# 世界频道
# ---------------------------------------------------------------------------
@ROUTER.register(ID.CS_BROADCAST, "chat.CsBroadcastMessage")
async def on_broadcast(session: Session, msg: dict) -> None:
    """世界频道：广播给所有在线玩家。

    `BroadcastMessage` 带发送者的名字/VIP/军衔 —— 客户端直接用它渲染气泡，
    不会再去查一次资料，所以这些字段必须填真值。
    """
    content = _clean(msg.get("content"))
    sender = int(session.roleid or 0)
    world = _world()
    role = _role_of(sender)
    if not content or world is None or role is None:
        return
    now = time.time()
    last = _world_last.get(sender, 0.0)
    if now - last < WORLD_COOLDOWN:
        (log.info("世界频道 %s 发太快，丢弃一条", sender) if log.isEnabledFor(20) else None)
        return
    _world_last[sender] = now

    from . import vip
    try:
        vip_level = int(vip.level_of(role))
    except Exception:
        vip_level = int(role.data.get("vipstatus", 0) if role.data else 0)
    payload = dict(
        content=content, roleid=sender, name=role.name or "",
        viplevel=vip_level,
        monthcard=int(pve_progress.month_active(role)),
        icon=int(role.iconid or 0), rank=int(role.level or 1),
    )
    sent = 0
    for rid in list(world._online):
        s = (world.session_of_role(rid, "gs")
             or world.session_of_role(rid))
        if s is not None and not s.closed:
            s.send(ID.BROADCAST, **payload)
            sent += 1
    # 回一个 result=0 的 ack（客户端只对 1/2/3 弹提示）
    session.send(ID.SC_BROADCAST, result=0)
    (log.info("世界频道 %s(%s): %r -> %d 人", sender, role.name, content, sent) if log.isEnabledFor(20) else None)
