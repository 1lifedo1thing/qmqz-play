"""每日签到 + 在线领奖.

Both are handled by `UserManager` on the client and both are **push-driven** --
the server has to volunteer the "info" message at login, the client never asks
for it:

    每日签到 (LoginReward 表 60 行)
        ScDailyRewardInfo(1114133) accday, rewarded      <- 登录时下发
        CsGetDailyReward(1114131)                        <- 客户端点「领取」
        ScDailyRewardRet(1114132) accday, rewardbloodgem, rewarditem, successed

        // DailyPrizeGetItemMgr
        int day = UserManager.scDailyRewardInfo.accday
                  + (UserManager.scDailyRewardInfo.rewarded != 0 ? 0 : 1);
        // DailyPrizeItem
        bool isDone = UserManager.scDailyRewardInfo.accday >= reward.day;

    在线领奖 (OnlineReward 表 5 行)
        ScOnlineRewardInfo(1114137) remaintime, rewardid <- 登录时下发（倒计时）
        CsGetOnlineReward(1114135)                       <- 倒计时归零后客户端来领
        ScGetOnlineReward(1114136) result, gold, bloodgem, exp

币种映射沿用 UserManager.IsEnough 的口径（见 docs/01-protocol.md §9.2）：
配置里的 `blueGem` -> 客户端 gold，`bloodGem` -> diamond，`gold` -> money。
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import equip, leveling

log = logging.getLogger("crisisfire.daily")


class ID:
    CS_GET_DAILY_REWARD = 1114131
    SC_DAILY_REWARD_RET = 1114132
    SC_DAILY_REWARD_INFO = 1114133
    CS_GET_ONLINE_REWARD = 1114135
    SC_GET_ONLINE_REWARD = 1114136
    SC_ONLINE_REWARD_INFO = 1114137

    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117
    SC_PACKAGE_SYNC = 983041


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


def _today() -> str:
    return time.strftime("%Y-%m-%d")


# --------------------------------------------------------------------------
# 每日签到
# --------------------------------------------------------------------------
def daily_rows() -> List[Dict[str, Any]]:
    """LoginReward 按 day 排序。"""
    rows = [r for r in gamedata.table("LoginReward") if int(r.get("day") or 0) > 0]
    return sorted(rows, key=lambda r: int(r["day"]))


def _daily_state(role) -> Dict[str, Any]:
    st = (role.data or {}).get("daily_reward")
    if not isinstance(st, dict):
        st = {}
    today = _today()
    if st.get("last_day") not in (None, today):
        # 新的一天：昨天的「已领」作废
        st = {"accday": int(st.get("accday") or 0), "last_day": today,
              "rewarded": 0}
        _save(role, st)
    st.setdefault("accday", 0)
    st.setdefault("rewarded", 0)
    st["last_day"] = st.get("last_day") or today
    return st


def _save(role, st: Dict[str, Any], key: str = "daily_reward") -> None:
    """写回 Role.data 的某个键.

    `key` 必须显式传：签到和在线领奖共用这一个函数时，在线领奖的状态会被写进
    `daily_reward` —— 两个系统互相覆盖，而且 `online_reward` 永远是空的。
    """
    if _world is not None:
        _world.merge_role_data(role.roleid, **{key: st})


def send_daily_info(session: Session, role) -> None:
    st = _daily_state(role)
    session.send(ID.SC_DAILY_REWARD_INFO, accday=int(st["accday"]),
                 rewarded=int(st["rewarded"]))


def _grant_login_reward(role, row: Dict[str, Any]) -> Dict[str, int]:
    """发一份签到奖励，返回 {diamond, gold, money, itemid}。"""
    def _i(k):
        try:
            return max(0, int(row.get(k) or 0))
        except (TypeError, ValueError):
            return 0

    blue, blood, gold = _i("blueGem"), _i("bloodGem"), _i("gold")
    itemid = _i("rewardItem")

    role.gold += blue
    role.diamond += blood
    role.money += gold
    if blue or blood or gold:
        _world.update_role(role.roleid, gold=role.gold, diamond=role.diamond,
                           money=role.money)
    if itemid:
        equip.grant_items(role, [itemid], _world)
    # 【狂暴版】签到额外赠送一把武器（CF_GRANT_WEAPON，默认 507020 暴烈骑士改·38）。
    # grant_items 对 maxPile==1 的装备自带去重，重复领签到不会重复入库。
    try:
        from ..config import CONFIG as _cfg
        _bonus = int(getattr(_cfg, "grant_weapon_id", 0) or 0)
        if _bonus > 0:
            equip.grant_items(role, [_bonus], _world)
    except Exception:
        (log.debug("狂暴版赠送武器失败", exc_info=True) if log.isEnabledFor(10) else None)
    return {"diamond": blood, "gold": blue, "money": gold, "itemid": itemid}


@ROUTER.register(ID.CS_GET_DAILY_REWARD, "user.CsGetDailyReward")
async def on_daily_reward(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    st = _daily_state(role)
    rows = daily_rows()
    if not rows:
        session.send(ID.SC_DAILY_REWARD_RET, accday=int(st["accday"]),
                     rewardbloodgem=0, rewarditem=0, successed=0)
        return
    if st["rewarded"]:
        # 今天已经领过了
        session.send(ID.SC_DAILY_REWARD_RET, accday=int(st["accday"]),
                     rewardbloodgem=0, rewarditem=0, successed=0)
        return

    st["accday"] = int(st["accday"]) + 1
    st["rewarded"] = 1
    # 第 N 天用 day == N 那行；跑满一轮就从第 1 天重来
    day = int(st["accday"])
    row = next((r for r in rows if int(r["day"]) == day), None)
    if row is None:
        cycle = len(rows)
        row = rows[(day - 1) % cycle] if cycle else None
    if row is None:
        session.send(ID.SC_DAILY_REWARD_RET, accday=day, rewardbloodgem=0,
                     rewarditem=0, successed=0)
        return

    got = _grant_login_reward(role, row)
    _save(role, st)
    (log.info("role %s 签到第 %s 天 -> 金%s 钻%s 钞%s 物品%s", role.name, day,
             got["gold"], got["diamond"], got["money"], got["itemid"] or "-") if log.isEnabledFor(20) else None)

    session.send(ID.SC_DAILY_REWARD_RET, accday=day,
                 rewardbloodgem=got["diamond"],
                 rewarditem=got["itemid"], successed=1)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)


# --------------------------------------------------------------------------
# 在线领奖
# --------------------------------------------------------------------------
def online_rows() -> List[Dict[str, Any]]:
    return sorted((r for r in gamedata.table("OnlineReward")),
                  key=lambda r: int(r.get("time") or 0))


def _online_state(role) -> Dict[str, Any]:
    st = (role.data or {}).get("online_reward")
    if not isinstance(st, dict):
        st = {}
    if st.get("day") != _today():
        st = {"day": _today(), "got": []}
        _save(role, st, "online_reward")
    st.setdefault("got", [])
    return st


def next_online_reward(role) -> Optional[Dict[str, Any]]:
    """还没领过、且条件最低的那一档。"""
    st = _online_state(role)
    got = {int(i) for i in (st.get("got") or [])}
    for row in online_rows():
        if int(row.get("id") or 0) not in got:
            return row
    return None


def _online_elapsed(role) -> int:
    """本次登录已经在线多少秒。"""
    since = (role.data or {}).get("online_since")
    if not since:
        return 0
    try:
        return max(0, int(time.time() - float(since)))
    except (TypeError, ValueError):
        return 0


def send_online_info(session: Session, role) -> None:
    """ScOnlineRewardInfo —— 客户端据此显示倒计时。

    remaintime 是「距离下一档还差多少秒」，rewardid 是那一档的 id；全部领完
    就发 remaintime=0 + 最后那一档的 id，客户端会显示成已领完。
    """
    elapsed = _online_elapsed(role)
    row = next_online_reward(role)
    if row is None:
        last = online_rows()[-1] if online_rows() else {"id": 0}
        session.send(ID.SC_ONLINE_REWARD_INFO, remaintime=0,
                     rewardid=int(last.get("id") or 0))
        return
    need = int(row.get("time") or 0)
    session.send(ID.SC_ONLINE_REWARD_INFO,
                 remaintime=max(0, need - elapsed),
                 rewardid=int(row.get("id") or 0))


@ROUTER.register(ID.CS_GET_ONLINE_REWARD, "user.CsGetOnlineReward")
async def on_online_reward(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    row = next_online_reward(role)
    if row is None:
        session.send(ID.SC_GET_ONLINE_REWARD, result=0, gold=0, bloodgem=0, exp=0)
        return
    if _online_elapsed(role) < int(row.get("time") or 0):
        # 还没到时间（客户端倒计时可能因为重登而不同步）
        session.send(ID.SC_GET_ONLINE_REWARD, result=0, gold=0, bloodgem=0, exp=0)
        send_online_info(session, role)
        return

    def _i(k):
        try:
            return max(0, int(row.get(k) or 0))
        except (TypeError, ValueError):
            return 0

    gold, blood, exp = _i("gold"), _i("bloodGem"), _i("exp")
    if gold or blood:
        from .wallet import change
        change(_world,role,coins=gold,honor=blood)
    if exp:
        leveling.apply_exp(_world, role, exp)

    st = _online_state(role)
    st.setdefault("got", []).append(int(row.get("id") or 0))
    _save(role, st, "online_reward")
    (log.info("role %s 在线领奖 id=%s -> 金%s 钻%s 经验%s", role.name,
             row.get("id"), gold, blood, exp) if log.isEnabledFor(20) else None)

    session.send(ID.SC_GET_ONLINE_REWARD, result=1, gold=gold, bloodgem=blood,
                 exp=exp)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    from .handlers import _property_of
    session.send(ID.SC_USER_INFO, roleid=role.roleid, property=_property_of(role))
    send_online_info(session, role)


# --------------------------------------------------------------------------
# 登录时
# --------------------------------------------------------------------------
def push_on_login(session: Session, role) -> None:
    """记下登录时刻并下发两个 info（客户端自己不会来要）。"""
    if _world is not None:
        _world.merge_role_data(role.roleid, online_since=time.time())
    # 重新读一遍，merge 之后 role.data 才是最新的
    fresh = _world.role(role.roleid) if _world is not None else role
    send_daily_info(session, fresh)
    send_online_info(session, fresh)
