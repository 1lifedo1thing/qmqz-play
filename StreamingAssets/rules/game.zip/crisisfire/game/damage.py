"""命中判定与伤害裁决.

这个游戏的客户端**自己也算一遍伤害**（`VirtualServer.CalcShootDamage`，人机模式下
它就是真服务端），但联机时**服务端才是裁判** —— 协议把职责划得很清楚：

    CsShoot (1441897)   roleid + shoot:ShootHit      客户端只报「打中了谁、打在哪」
    ScShoot (1441898)   shoot:ShootDamage + shooterid 服务端算完伤害再下发

    // ShootHit.targets -> List<TargetHit>   —— 没有伤害字段
    int   targetid;   float sd;   int hitpart;   Vec3 hitpos;  Vec3 targetpos;
    // part: 1 头 / 2 胸 / 3 腹 / 4 腿 / 5 臂

    // ShootDamage.targets -> List<TargetDamage>  —— 伤害是服务端填的
    int targetid;  float hpdamage;  int acdamage;  int sapihpdamage;  int hitpart; ...

官方公式（客户端 VirtualServer + RobotConsts，两边必须算出同一个数）：

    public static int CalcShootDamage(int shooterid, float sd, int part)
    {
        int num = 20;                                          // 默认（空手等）
        float num2 = GameData.instance.GetCoefficient(part)?.Coefficient ?? 1f;
        if (item.equipPos == 11 || item.equipPos == 12)
            num = RobotConsts.GunDamage(gun.basicDamage);
        else if (item.equipPos == 50)
            num = RobotConsts.DaggerDamage(melee.damag);
        return (int)((float)num * num2);
    }
    GunDamage(basic)    = basic * (1 + skillrank * 0.02 + teamrank * 0.01)
    DaggerDamage(basic) = basic * (1 + skillrank * 0.1)

配置表（客户端内嵌，DamageCoefficient / Gun / Melee）：

    DamageCoefficient   普通 Coefficient   生化 bioCoefficient
        1 头                4.01               1.80      <- 生化爆头倍率大幅降低
        2 胸                1.10               1.00
        3 腹                1.25               1.10
        4 腿                0.75               0.90
        5 臂                1.05               1.00
    Gun     basicDamage / bioDamage / ammoBio
    Melee   damag / bioDamage        (生化近战 = 2 倍)

`bioCoefficient` / `mumHpBase` / `hpPerCapita` 这几个字段**在客户端代码里完全没被引用**，
是留给服务端的自由度 —— 客户端只会显示服务端下发的 `hpdamage`。

武器怎么知道？`CsShoot` 里没有 weaponid，靠 `WeaponChange(roleid, weaponpos, bulletnum)`
追踪当前槽位（11 主武器 / 12 副武器 / 50 近战），再用角色的 equipmap 反查物品 id。
"""
from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Optional, Tuple

from .. import gamedata

log = logging.getLogger("crisisfire.damage")


def same_team(battle, firstid, secondid):
    """Native Util.IsSimilar, using current infection state in both bio modes."""
    bio=getattr(battle,'biochem',None)
    if bio is not None:
        return bio.is_zombie(firstid)==bio.is_zombie(secondid)
    if int(getattr(getattr(battle,'room',None),'gamemode',0) or 0)==4:
        return False  # client.DataPool.IsBothSides: GameMode != 4
    first=battle.fighters.get(firstid);second=battle.fighters.get(secondid)
    return (first is not None and second is not None
            and first.side==second.side and first.side!=4)

DEFAULT_DAMAGE = 20          # 对齐 VirtualServer：其它装备一律 20

PART_HEAD = 1
PART_CHEST = 2
PART_BELLY = 3
PART_LEG = 4
PART_ARM = 5

# 装备槽
POS_MAIN_GUN = 11
POS_VICE_GUN = 12
POS_MELEE = 50


# --------------------------------------------------------------------------
# 配置查询（带缓存，305 行 Gun 表每次查会拖慢射击）
# --------------------------------------------------------------------------
_CACHE: Dict[str, Dict[int, Dict[str, Any]]] = {}


def _table(name: str) -> Dict[int, Dict[str, Any]]:
    if name not in _CACHE:
        out: Dict[int, Dict[str, Any]] = {}
        for row in gamedata.table(name):
            try:
                out[int(row.get("id") or row.get("hitPartId") or 0)] = row
            except (TypeError, ValueError):
                continue
        _CACHE[name] = out
    return _CACHE[name]


def item_row(itemid: int) -> Dict[str, Any]:
    return _table("Item").get(int(itemid)) or {}


def equip_pos(itemid: int) -> int:
    try:
        return int(item_row(itemid).get("equipPos") or 0)
    except (TypeError, ValueError):
        return 0


# 生化幽灵的部位判定：**不看客户端上报的 hitpart**，用命中点相对脚底的高度。
#
# 客户端 `APenetrator.Part()` 是按骨骼名映射的（Bip01 Head/Spine/Pelvis...），
# 幽灵模型的骨骼名不在那张表里，全部落到 `default: return 2`，
# 于是「打头/打胸/打腿」伤害完全一样（用狂龙实测就是这个现象）。
ZOMBIE_PART_HEIGHTS = ((1.55, PART_HEAD), (1.00, PART_CHEST),
                       (0.60, PART_BELLY))


def _part_from_hitpos(t: Dict[str, Any], fallback: int = PART_CHEST) -> int:
    """按 `hitpos.y - targetpos.y` 判部位（两者都是 short×100 的世界坐标）。"""
    try:
        hy = float((t.get("hitpos") or {}).get("y") or 0) / 100.0
        gy = float((t.get("targetpos") or {}).get("y") or 0) / 100.0
    except (TypeError, ValueError):
        return fallback
    rel = hy - gy
    if rel <= 0.05:                 # 没有可用高度数据 -> 保持原值
        return fallback
    for height, part in ZOMBIE_PART_HEIGHTS:
        if rel >= height:
            return part
    return PART_LEG


def coefficient(hitpart: int, is_biochem: bool) -> float:
    """部位系数。生化模式用 bioCoefficient（客户端不引用，纯服务端字段）。"""
    part = int(hitpart) if 1 <= int(hitpart or 0) <= 5 else PART_ARM
    row = _table("DamageCoefficient").get(part) or {}
    key = "bioCoefficient" if is_biochem else "Coefficient"
    for k in (key, "Coefficient"):
        try:
            v = float(row.get(k))
            if v > 0:
                return v
        except (TypeError, ValueError):
            continue
    return 1.0


def _f(row: Dict[str, Any], key: str, default: float = 0.0) -> float:
    try:
        return float(row.get(key) or default)
    except (TypeError, ValueError):
        return default


def weapon_base_damage(weaponid: int, is_biochem: bool) -> Tuple[float, str]:
    """武器基础伤害 + 用的是哪套（gun / melee / default）。

    生化模式优先用 bioDamage（`Melee.bioDamage` 正好是 `damag` 的两倍，
    `Gun.bioDamage` 为 0 时回落到 basicDamage）。
    """
    pos = equip_pos(weaponid)
    if pos in (POS_MAIN_GUN, POS_VICE_GUN):
        gun = _table("Gun").get(int(weaponid)) or {}
        if not gun:
            return float(DEFAULT_DAMAGE), "default"
        basic = _f(gun, "basicDamage", DEFAULT_DAMAGE)
        if is_biochem:
            bio = _f(gun, "bioDamage")
            if bio > 0:
                # **原版 Gun.bioDamage 是「加算增量」，不是绝对伤害。**
                # 表里 34 伤的枪加的是 +9/+10/+11/+12（对应 2~5 星），
                # 折合倍率 1.26~1.9。原来这里写成 `basic = bio`，
                # 等于把 34 直接降成 9 —— 数值全错。
                basic = basic + bio
        return basic, "gun"
    if pos == POS_MELEE:
        melee = _table("Melee").get(int(weaponid)) or {}
        if not melee:
            return float(DEFAULT_DAMAGE), "default"
        if is_biochem:
            bio = _f(melee, "bioDamage")
            if bio > 0:
                return bio, "melee"
        return _f(melee, "damag", DEFAULT_DAMAGE), "melee"
    return float(DEFAULT_DAMAGE), "default"


def calc_damage_units(weaponid: int, is_biochem: bool = False,
                      skillrank: int = 0, teamrank: int = 0,
                      bio_level: int = 0, talent: float = 0.0,
                      chip_dmg: float = 0.0) -> float:
    """一次命中的伤害，**尚未乘部位系数**（护甲要在这个基数上算）。

    相较原版多了三项（都是服务端字段，客户端那套公式里没有）：

      * 生化士气：基础伤害 **+ humanAtkPerLv × 等级**（LV.10 = +200 点）。
        官方是加点数不是乘百分比 —— 巴哈姆特实测「后期加伤令 G18 威力
        上升 10 倍」（12 + 200 ≈ 17 倍量级），乘算只有 3 倍，对不上。
        枪械和近战都加：英雄战刀 420 + 200 = 满士气 620（用户定的强度）。
        僵尸爪击不走这里（`zombie_attacker` 直接用 BioProperty.damage），
        所以幽灵不会白拿士气加成。
      * 强化天赋精通：× (1 + 对应枪种等级 * perLevel%)
      * 芯片 addDmg：× (1 + chip_dmg%)
    """
    basic, kind = weapon_base_damage(weaponid, is_biochem)
    if kind == "gun":
        # GunDamage: 技能等级每级 +2%，战队等级每级 +1%
        dmg = basic * (1.0 + int(skillrank) * 0.02 + int(teamrank) * 0.01)
        if is_biochem:
            # 士气：加固定点数（官方的「伤害力 +N」）
            dmg += morale_add(bio_level)
    elif kind == "melee":
        # DaggerDamage: 技能等级每级 +10%
        dmg = basic * (1.0 + int(skillrank) * 0.1)
        if is_biochem:
            # 英雄战刀同样吃士气点数（220 -> 420 基础，满级 620）
            dmg += morale_add(bio_level)
    else:
        dmg = basic
    if talent:
        dmg *= (1.0 + float(talent))
    if chip_dmg:
        # 芯片 addDmg（魔龙礼包 +5 = +5% 伤害）
        dmg *= (1.0 + float(chip_dmg) * 0.01)
    return dmg


def calc_damage(weaponid: int, hitpart: int, is_biochem: bool = False,
                skillrank: int = 0, teamrank: int = 0,
                bio_level: int = 0, talent: float = 0.0) -> int:
    """一次命中的 HP 伤害（不含护甲）。对齐 VirtualServer.CalcShootDamage。"""
    units = calc_damage_units(weaponid, is_biochem, skillrank, teamrank,
                              bio_level, talent)
    return int(units * coefficient(hitpart, is_biochem))


# --------------------------------------------------------------------------
# 士气（生化等级）与强化天赋
#
# 士气的数据来自 GameRule(gameMode=8)：humanAtkPerLv=20、humanMaxLv=10。
# 客户端 BioLevelBar 只把它拼成「伤害力+{等级×20}」一行字，
# VirtualServer.CalcShootDamage 里根本没有这个项 —— 原版由服务端算。
# --------------------------------------------------------------------------
MORALE_MAX_LEVEL = 10        # GameRule.humanMaxLv，调用方可以覆盖


def _atk_per_level() -> float:
    """每级士气加多少点伤害。

    优先读 `GameRule(gameMode=8).humanAtkPerLv`（原版就是 20），
    读不到再退到 `config.biochem_morale_per_point`。
    `humanAtkPerLv` 在当前表里出现过 10 / 20 两个值（老版本是 10），
    所以这里以表为准，不写死。
    """
    for row in gamedata.table("GameRule"):
        try:
            if int(row.get("gameMode") or 0) in (8, 10):
                v = float(row.get("humanAtkPerLv") or 0)
                if v > 0:
                    return v
        except (TypeError, ValueError):
            continue
    from ..config import CONFIG
    try:
        return float(getattr(CONFIG, "biochem_morale_per_point", 20.0))
    except (TypeError, ValueError):
        return 20.0


def morale_add(level: int, max_level: int = 0) -> float:
    """士气带来的**固定加点**：`humanAtkPerLv × 等级`（满级 +200）。

    这是官方机制：客户端 `BioLevelBar` 显示的就是「伤害力 +{等级×20}」，
    是加在基础伤害上的点数，不是乘一个百分比。

    【狂暴版】`max_level` 默认改为 **0 = 不封顶**。原来默认 MORALE_MAX_LEVEL=10，
    导致等级涨到 10 级后伤害就不动了（用户反馈「等级加成没生效」）。
    """
    cap = int(max_level or 0)
    lv = max(0, int(level or 0))
    if cap > 0:
        lv = min(lv, cap)
    if lv <= 0:
        return 0.0
    return _atk_per_level() * lv


def morale_multiplier(level: int, max_level: int = MORALE_MAX_LEVEL) -> float:
    """旧的「每级 +20%」乘算系数。

    **已不参与伤害结算**（官方是加点数，见 `morale_add`）。
    保留只是为了调试对照和外部调用方不炸。
    """
    from ..config import CONFIG
    cap = int(max_level or MORALE_MAX_LEVEL)
    lv = max(0, min(cap, int(level or 0)))
    return 1.0 + float(getattr(CONFIG, "biochem_morale_per_level", 0.2)) * lv


# ResearchTalent.type -> 枪械类别（weapon_catalog.CATEGORY_BY_SUBTYPE 的值）
RESEARCH_CATEGORY = {
    "rifle": 1, "smg": 2, "pistol": 3,
    "sniper": 5, "mg": 6, "shotgun": 7,
}
RESEARCH_BULLET_PROT = 4     # 防弹涂层：被子弹击中减伤
RESEARCH_BLAST_PROT = 9      # 防爆护盾：爆炸减伤
RESEARCH_GRENADE = 10        # 掷弹狂人：手雷增伤

_PER_LEVEL: Dict[int, float] = {}


def _research_per_level(rtype: int) -> float:
    """ResearchTalent 每级百分比（表里 perLevel=1，即每级 +1%）。"""
    rtype = int(rtype)
    if rtype not in _PER_LEVEL:
        per = 1.0
        for row in gamedata.table("ResearchTalent"):
            if int(row.get("type") or 0) == rtype:
                per = _f(row, "perLevel", 1.0) or 1.0
                break
        _PER_LEVEL[rtype] = per
    return _PER_LEVEL[rtype]


def research_percent(fighter, rtype: int) -> float:
    """某类强化天赋的加成百分比（0.05 = +5%）。fighter.research 由 battle 出生时写入。"""
    levels = getattr(fighter, "research", None) or {}
    lv = int(levels.get(int(rtype), 0) or 0)
    if lv <= 0:
        return 0.0
    from ..config import CONFIG
    scale = float(getattr(CONFIG, "research_talent_scale", 1.0) or 1.0)
    return lv * _research_per_level(rtype) * scale / 100.0


def talent_damage_bonus(fighter, weaponid: int) -> float:
    """枪械精通带来的增伤比例（步枪/冲锋/手枪/狙击/机枪/霰弹）。"""
    if fighter is None or not getattr(fighter, "research", None):
        return 0.0
    from .weapon_catalog import CATEGORY_BY_SUBTYPE
    row = _table("Item").get(int(weaponid or 0)) or {}
    category = CATEGORY_BY_SUBTYPE.get(int(row.get("subType") or 0))
    rtype = RESEARCH_CATEGORY.get(category or "")
    if not rtype:
        return 0.0
    return research_percent(fighter, rtype)


# --------------------------------------------------------------------------
# 防弹衣（Armor）
#
# 完全对齐客户端 `Commander.DamagerTarget`：
#
#     bool flag = targetData.ac > 0;
#     Armor armor = GetArmor(targetData, target.hitpart);
#     if (armor != null && flag)
#     {
#         num2(ac 系数) = Clamp(num2 + armor.acCoefficient * penetration - armor.AcChange, 0, num);
#         num3(hp 系数) = Clamp(num3 + armor.hpCoefficient * penetration - armor.DamageChange, 0, num);
#     }
#     ac 吸收 = (int)(damage * num2)；hp 伤害 = damage * num3
#
# 注意 `DamageChange` 的量级是按各自部位调的：头盔 0.09~2.7 对爆头系数 4.01，
# 防弹衣 0.09~0.5 对胸部 1.10，护腿 0.07~0.3 对腿部 0.75。
# 穿甲（Gun.penetration，1~6）反着抵消 —— 穿甲越高，护甲越形同虚设。
# --------------------------------------------------------------------------
ARMOR_SLOT_BY_PART = {PART_HEAD: 31, PART_CHEST: 32, PART_BELLY: 32,
                      PART_ARM: 32, PART_LEG: 33}


def armor_of(fighter, hitpart: int) -> Optional[Dict[str, Any]]:
    from ..config import CONFIG
    if fighter is None or not getattr(CONFIG, "armor_enabled", True):
        return None
    slot = ARMOR_SLOT_BY_PART.get(int(hitpart or 0))
    if not slot:
        return None
    aid = int((getattr(fighter, "equipmap", {}) or {}).get(slot) or 0)
    if aid <= 0:
        return None
    return _table("Armor").get(aid)


def weapon_penetration(weaponid: int, ammo_plus: float = 0.0) -> float:
    """穿甲 = Gun.penetration + Ammo.penetrationPlus（客户端 AimAssistor 的算法）。"""
    gun = _table("Gun").get(int(weaponid or 0)) or {}
    return _f(gun, "penetration") + max(0.0, float(ammo_plus or 0.0))


def cart_of(battle, roleid: int) -> int:
    """这个角色当前选的弹种：1/3 = 普通弹，2/4 = 商店穿甲弹。"""
    try:
        return int((getattr(battle, "ammo_cart", {}) or {}).get(int(roleid), 1))
    except (TypeError, ValueError):
        return 1


def cart_ammo(battle, shooterid: int, slot: int, weaponid: int):
    """(# 弹种 id, Ammo 行)。没在用穿甲弹时返回 (0, {})。

    `BulletChange(1441944)` 的 bullettype 语义（客户端常量）：
        MAIN_BULLET_NORMAL=1 / MAIN_BULLET_SHOP=2
        MINOR_BULLET_NORMAL=3 / MINOR_BULLET_SHOP=4
    选商店弹时客户端把 `playerData.ammoCart` 置 1，`AmmoID` 就去查
    `Gun.vipAmmo` 对应的弹种，伤害/穿甲也是从那张表读的。
    """
    if int(slot or 0) not in (11, 12):
        return 0, {}
    if cart_of(battle, shooterid) not in (2, 4):
        return 0, {}
    gun = _table("Gun").get(int(weaponid or 0)) or {}
    aid = int(gun.get("vipAmmo") or 0)
    if aid <= 0:
        return 0, {}
    return aid, (_table("Ammo").get(aid) or {})


def distance_falloff(weaponid: int, units: float, sd: float,
                     range_plus: float = 0.0,
                     range_scale: float = 1.0) -> float:
    """距离衰减（对齐 AttackProperty.SetGun / AimAssistor.getEffectiveRange）。

        sd <= effectiveRange          -> 满伤
        effective < sd < maximumRange -> 线性降到 minDamage
        sd >= maximumRange            -> 0

    原来服务端**完全没有这一项**，不管隔多远都按 basicDamage 满伤 ——
    这正是「很多枪的伤害对 100 血不合理」的根源之一（远距离也能一枪爆头）。

    生化模式传进来的 `units` 已经是 bioDamage（比 basicDamage 大很多），
    所以衰减按 **minDamage/basicDamage 的比例**走，而不是直接降到 minDamage，
    否则生化伤害会在最大射程处突然掉到 4 点。
    """
    gun = _table("Gun").get(int(weaponid or 0)) or {}
    _rs = max(0.0, float(range_scale or 1.0))
    eff = (_f(gun, "effectiveRange") + max(0.0, float(range_plus or 0.0))) * _rs
    mx = (_f(gun, "maximumRange") + max(0.0, float(range_plus or 0.0))) * _rs
    try:
        d = float(sd or 0.0)
    except (TypeError, ValueError):
        d = 0.0
    if eff <= 0 or d <= eff:
        return units
    if mx > eff:
        if d >= mx:
            return 0.0
        t = (d - eff) / (mx - eff)
    else:
        t = 0.0
    basic = _f(gun, "basicDamage")
    mind = _f(gun, "minDamage")
    ratio = (mind / basic) if (basic > 0 and mind > 0) else 0.15
    ratio = max(0.0, min(1.0, ratio))
    return units * ((1.0 - t) + ratio * t)


def split_by_armor(units: float, coef: float, armor: Optional[Dict[str, Any]],
                   penetration: float, ac: float) -> Tuple[int, int]:
    """把一发子弹拆成 (ac 吸收, hp 伤害)。

    `ac <= 0` 时护甲完全不生效 —— 和客户端的 `bool flag = targetData.ac > 0` 一致。
    """
    if armor is None or ac <= 0:
        return 0, int(units * coef)
    ac_coef = min(coef, max(0.0, coef + _f(armor, "acCoefficient") * penetration
                            - _f(armor, "AcChange")))
    hp_coef = min(coef, max(0.0, coef + _f(armor, "hpCoefficient") * penetration
                            - _f(armor, "DamageChange")))
    absorb = int(units * ac_coef)
    if absorb > ac:                 # 打穿：客户端那段 num7 恒等于 1，多余伤害蒸发
        absorb = int(ac)
    return absorb, int(units * hp_coef)


# --------------------------------------------------------------------------
# 把一次射击应用到战场
# --------------------------------------------------------------------------
class HitResult:
    __slots__ = ("targetid", "hpdamage", "hitpart", "died", "hp_left",
                 "acdamage")

    def __init__(self, targetid: int, hpdamage: int, hitpart: int,
                 died: bool, hp_left: float, acdamage: int = 0):
        self.targetid = targetid
        self.hpdamage = hpdamage
        self.hitpart = hitpart
        self.died = died
        self.hp_left = hp_left
        self.acdamage = acdamage


# 近战距离校验的容差（米）。
# 原来 0.4 是按「静止对砍」定的，实际跑动中 UDP 位置快照的滞后就有 1 米以上。
# 现在距离本身改用包里上报的坐标（没有时差），这 1.5 只是留给斜坡/跳跃的
# Y 差和客户端插值误差。
MELEE_SYNC_TOLERANCE = 1.5


def _vec_m(vec) -> "Optional[Tuple[float, float, float]]":
    """协议里的 Vec3 是 short（×100），换成米；三个分量全 0 视为没填。"""
    if not isinstance(vec, dict):
        return None
    try:
        x = float(vec.get("x") or 0) / 100.0
        y = float(vec.get("y") or 0) / 100.0
        z = float(vec.get("z") or 0) / 100.0
    except (TypeError, ValueError):
        return None
    if x == 0.0 and y == 0.0 and z == 0.0:
        return None
    return (x, y, z)


def _packet_points(shoot, target, shooter, victim):
    """射手 / 目标在包里的坐标（米）；取不到返回 (None, None)。"""
    src = _vec_m((shoot or {}).get("position"))
    if src is None:
        src = getattr(shooter, "syncpos", None)
    dst = _vec_m((target or {}).get("targetpos"))
    if dst is None:
        dst = _vec_m((target or {}).get("hitpos"))
    if dst is None:
        dst = getattr(victim, "syncpos", None)
    if src is None or dst is None:
        return None, None
    try:
        return tuple(src), tuple(dst)
    except (TypeError, ValueError):
        return None, None


def _packet_distance(shoot, target, shooter, victim):
    """射手到目标的三维距离：**优先用 CsShoot 里上报的坐标**，缺了才退回 syncpos。"""
    src, dst = _packet_points(shoot, target, shooter, victim)
    if src is None or dst is None:
        return None
    try:
        return math.dist(src, dst)
    except (TypeError, ValueError):
        return None


def _packet_flat_distance(shoot, target, shooter, victim):
    """水平（x/z）距离 —— `sd` 下限校验用的**保守**基准。

    `sd` 是「射线命中距离 + 穿墙等效距离」，从枪口（眼高）打到人身上任何位置
    都不会小于两者的**水平**距离；而三维距离会因为「枪口在 +1.5m、目标点取
    脚下」多出竖直分量（1.5m 处贴脸时能多出 0.8m），拿它当下限会把正常射击
    全部误判成「上报偏小」并被抬高 —— 抬高 sd 等于凭空加距离衰减。
    """
    src, dst = _packet_points(shoot, target, shooter, victim)
    if src is None or dst is None:
        return None
    try:
        return math.hypot(float(src[0]) - float(dst[0]),
                          float(src[2]) - float(dst[2]))
    except (TypeError, ValueError, IndexError):
        return None


def _sd_floor(battle, shoot, target, shooter, victim, sd, *,
              shooterid: int = 0, weaponid: int = 0) -> Optional[float]:
    """【v39 穿透方案 A】把客户端上报的 ``sd`` 钳到「水平距离 − 容差」以上。

    ``sd`` 的语义是「射线命中距离 + 穿墙等效距离」，穿墙只会让它变大，
    所以正常射击恒有 ``sd >= 水平距离``。低于这个值只能是异常/伪造。
    返回 ``None`` 表示调用方应丢弃这一发（``CF_SD_FLOOR_MODE=drop``）。
    """
    truth = _packet_flat_distance(shoot, target, shooter, victim)
    if truth is None:
        return sd
    try:
        from ..config import CONFIG
        tol = float(getattr(CONFIG, "bullet_sd_floor_tolerance", 0.5) or 0.0)
        mode = str(getattr(CONFIG, "bullet_sd_floor_mode", "clamp") or "clamp")
    except (TypeError, ValueError):
        tol, mode = 0.5, "clamp"
    floor = max(0.0, float(truth) - max(0.0, tol))
    try:
        if float(sd) >= floor:
            return sd
    except (TypeError, ValueError):
        return floor
    try:
        _bad = getattr(battle, "_sd_floor_bad", None)
        if _bad is None:
            _bad = battle._sd_floor_bad = [0]
        _bad[0] += 1
        if _bad[0] <= 5 or _bad[0] % 200 == 0:
            log.warning(
                "SD 低于水平距离（%s）：role=%s gun=%s sd=%.2f 水平=%.2f 差=%.2f 累计=%d",
                mode, shooterid, weaponid, float(sd), float(truth),
                float(truth) - float(sd), _bad[0])
    except Exception:
        (log.debug("sd floor 统计失败", exc_info=True) if log.isEnabledFor(10) else None)
    return None if mode.strip().lower() == "drop" else floor


def active_weapon(fighter) -> Tuple[int, int]:
    """Resolve the held slot, following the client's spawn weapon priority."""
    from . import special_modes
    equipment = getattr(fighter, "equipmap", {}) or {}
    slot = int(getattr(fighter, "weaponpos", 0) or 0)
    if slot == POS_MELEE or equipment.get(slot):
        return slot, int(equipment.get(slot) or 0)
    slot = special_modes.held_slot(equipment)
    return slot, int(equipment.get(slot) or 0)


def melee_range(slot: int, weaponid: int,
                scale: float = 1.0) -> Optional[float]:
    """近战范围。`scale` 用于屠龙芯片（meleerange 百分比累加）。"""
    row = _table("Melee").get(weaponid)
    if row is not None:
        return _f(row, "range") * max(0.0, float(scale or 1.0))
    return 0.0 * max(0.0, float(scale or 1.0)) if slot == POS_MELEE else None


def uses_melee(battle, fighter) -> bool:
    bio = getattr(battle, "biochem", None)
    return ((bio is not None and bio.is_zombie(fighter.roleid))
            or melee_range(*active_weapon(fighter)) is not None)


def zombie_claw_reach(prop, bot=False):
    return max(0., float(prop.get('range') or 2.7)) * (.8 if bot else 1.)


def resolve_shoot(battle, shooterid: int, shoot: Dict[str, Any],
                  is_biochem: bool = False,
                  ranks: Optional[Dict[int, Tuple[int, int]]] = None, ammo=None
                  ) -> List[HitResult]:
    """算出这次射击对每个目标的伤害并扣血。

    不改协议字段，返回结构化结果给调用方决定发什么。
    """
    targets = shoot.get("targets") or []
    if not targets:
        return []
    shooter = battle.fighters.get(shooterid)
    if shooter is None:
        return []

    # 生化模式里僵尸的「武器」是爪子，不是枪：
    #   ABiochemHand.Synch -> BioProperty.atkRate / range / fanAngle
    #   伤害在 BioProperty.damage（1001=30 / 1011=34 / 1021=40 …），range=2.7
    # 原来一律按 shooter.equipmap[weaponpos] 反查武器，僵尸会拿**生前的枪**
    # 算伤害（客户端显示的是爪击，服务端按 AK 的 basicDamage 扣血）。
    bio = getattr(battle, "biochem", None) if is_biochem else None
    zombie_attacker = bool(bio is not None and bio.is_zombie(shooterid))
    zombie_prop: Dict[str, Any] = {}
    if zombie_attacker:
        from .biochem import bio_property_of
        zombie_prop = bio_property_of(shooter.actorid) or {}

    # CsShoot 不带 weaponid：用 WeaponChange 追踪到的槽位反查
    pos, weaponid = active_weapon(shooter)
    if getattr(getattr(battle, "room", None), "equiplimitid", 0) and (
            not shooter.born or shooter.hp <= 0 or pos not in (11, 12, 50) or not weaponid):
        return []
    # ---- 龙芯片（battle.chip_bonus 已按拥有个数累加）-------------------
    # 屠龙 meleerange +5%/个：近战范围 ×(1+0.05n)
    # 血龙 pistolrange +5%/个：只对手枪槽(12)的射程 ×(1+0.05n)
    # 魔龙 addDmg +5%/个：**严格满生命时**才生效（照客户端文案口径）
    _melee_scale = 1.0
    _pistol_scale = 1.0
    _chip_dmg = 0.0
    # 【v51】龙芯片只对真人玩家生效，BOT 一律不吃。
    # born() 里 `_role_obj(bot)` 返回 None，chip_bonus 本来就是全 0；
    # 这里再显式挡一层，防止将来 BOT 复用 role / 存档串味时把加成带进来。
    try:
        from . import bots as _chip_bots
        _shooter_is_bot = _chip_bots.is_bot(int(shooterid))
    except Exception:
        _shooter_is_bot = False
    if not zombie_attacker and not _shooter_is_bot:
        _melee_pct = float(getattr(shooter, "chip_meleerange", 0) or 0)
        _pistol_pct = float(getattr(shooter, "chip_pistolrange", 0) or 0)
        _melee_scale = 1.0 + _melee_pct * 0.01
        if int(pos or 0) == POS_VICE_GUN:
            _pistol_scale = 1.0 + _pistol_pct * 0.01
        try:
            _hp = float(getattr(shooter, "hp", 0) or 0)
            _hpmax = float(getattr(shooter, "hp_max", 0) or 0)
            _full = _hpmax > 0 and _hp >= _hpmax
        except (TypeError, ValueError):
            _full = False
        if _full:
            _chip_dmg = float(getattr(shooter, "chip_adddmg", 0) or 0)
    reach = (zombie_claw_reach(zombie_prop) if zombie_attacker
             else melee_range(pos, weaponid, scale=_melee_scale))
    if zombie_attacker:
        # **只削 bot 幽灵**的命中判定范围和距离（-20%），伤害数值不变。
        # 玩家自己当幽灵时保持 2.7m / 160° 不改。
        try:
            from . import bots as _bots
            if _bots.is_bot(shooterid):
                reach = zombie_claw_reach(zombie_prop, bot=True)
        except Exception:
            pass

    skillrank, teamrank = (ranks or {}).get(shooterid, (0, 0))
    # 士气（生化等级）：只对人类的枪/刀生效，僵尸爪击不吃。
    # 【狂暴版】默认**不封顶**（原来 min(level, humanMaxLv=10)，10 级后伤害就停了）。
    # CF_BIOCHEM_MORALE_CAP > 0 时才按那个上限截断。
    bio_lv = 0
    if bio is not None and not zombie_attacker:
        try:
            from ..config import CONFIG as _mcfg
            _cap = int(getattr(_mcfg, "biochem_morale_cap", 0) or 0)
        except (TypeError, ValueError):
            _cap = 0
        _lv = int(bio.level_of(shooterid) or 0)
        bio_lv = min(_lv, _cap) if _cap > 0 else _lv
    # 枪械精通（强化天赋）
    talent = 0.0 if zombie_attacker else talent_damage_bonus(shooter, weaponid)
    # 穿甲弹：只有 `BulletChange` 选了商店弹（bullettype 2/4）才生效。
    # 数值来自 Ammo 表（basicDamagePlus / penetrationPlus / maxRangePlus），
    # 和客户端 `AimAssistor.getBasicDamage/getPenetration` 是同一份数据。
    # UC 1.9 debits inventory before resolving each trigger/ray group.
    # The supplied profile is authoritative, including an explicit empty one.
    _ammo_row = {} if zombie_attacker else (ammo or {})
    _ammo_dmg = _f(_ammo_row, "basicDamagePlus") if _ammo_row else 0.0
    _ammo_pen = _f(_ammo_row, "penetrationPlus") if _ammo_row else 0.0
    _ammo_rng = _f(_ammo_row, "maxRangePlus") if _ammo_row else 0.0
    penetration = weapon_penetration(weaponid, _ammo_pen)
    out: List[HitResult] = []
    for t in targets:
        try:
            tid = int(t.get("targetid") or 0)
        except (TypeError, ValueError):
            continue
        if not tid or tid == shooterid:
            continue
        victim = battle.fighters.get(tid)
        if victim is None or not victim.born or victim.hp<=0:
            continue
        if reach is not None:
            # **用包里上报的位置，不要用 syncpos。**
            # `syncpos` 是 UDP 10Hz 的快照，双方都在跑时相对位移一帧就有
            # 1.2m；匕首 range 才 2.0，容差 0.4 → 客户端算 2.0m 命中、
            # 服务端算 3.2m 不中，表现就是「刀怎么砍都砍不到」。
            # CsShoot 里带着射击原点 position 和目标脚底 targetpos（都是
            # short×100），和客户端判定用的是同一份数据，没有时差。
            dist = _packet_distance(shoot, t, shooter, victim)
            if (reach <= 0 or dist is None
                    or not (0 <= float(t.get("sd", math.inf)) <= reach)
                    or not (dist <= reach + MELEE_SYNC_TOLERANCE)):
                continue
        if same_team(battle,shooterid,tid):
            continue
        invincible=getattr(battle,'is_invincible',None)
        if invincible is not None and invincible(tid):
            continue
        # 生化模式：僵尸打人类先破「保护层」（开局 ScBioProtectLayer 3 层），
        # 每击消耗一层，护盾还在时这一下**不掉血**。
        if is_biochem and getattr(battle, "biochem", None) is not None:
            _bio = battle.biochem
            if _bio.is_zombie(shooterid) and not _bio.is_zombie(tid):
                if _bio.damage_protect(tid, shooterid):
                    continue
        try:
            part = int(t.get("hitpart") or PART_CHEST)
        except (TypeError, ValueError):
            part = PART_CHEST
        # 生化幽灵的部位倍率不认客户端上报的 hitpart。
        #
        # 客户端 `APenetrator.Part()` 是按骨骼名映射的：
        #     Bip01 Head / Spine / Pelvis / L Thigh ...
        # 幽灵模型的骨骼名不在这张表里，全部落到 `default: return 2`，
        # 于是「打头、打胸、打腿」伤害完全一样（用狂龙实测就是这个现象）。
        # 这里改成用 hitpos 相对脚底的高度自己算，与骨骼名无关。
        if is_biochem and getattr(battle, "biochem", None) is not None \
                and battle.biochem.is_zombie(tid):
            part = _part_from_hitpos(t, part)
        if zombie_attacker:
            # 爪击：固定 BioProperty.damage，乘部位系数（和客户端一样）
            units = float(zombie_prop.get("damage") or 30)
            # 【狂暴版】僵尸等级成长加攻。官方僵尸升级只加血（hpPlus），
            # 这里按 CF_BIO_ZOMBIE_DMG_GROWTH（每级系数）额外乘伤害；
            # 0 = 关闭，恢复官方行为。伤害是服务端裁决的，客户端只显示结果。
            try:
                from ..config import CONFIG as _zcfg
                _growth = float(getattr(_zcfg, "biochem_zombie_dmg_growth", 0.0) or 0.0)
                if _growth > 0 and bio is not None:
                    _zlv = int(bio.level_of(int(shooterid)))
                    if _zlv > 0:
                        units *= (1.0 + _growth * _zlv)
            except Exception:
                (log.debug("僵尸等级加攻读取失败", exc_info=True) if log.isEnabledFor(10) else None)
            # 【狂暴版】终极对决时刻的加伤是**平点数**，不是百分比：
            #   普通僵尸：每个存活人类 +30 点
            #   母体：按存活人类数查表 +300/400/500/700/1100/2100/4600
            # 数值由 biochem._ultimate_grants 结算后挂在 Biochem 上。
            try:
                if bio is not None:
                    _is_mum = int(getattr(bio, "matrix", 0) or 0) == int(shooterid)
                    _attr = "matrix_dmg_flat" if _is_mum else "zombie_dmg_flat"
                    _flat = float(getattr(bio, _attr, 0.0) or 0.0)
                    if _flat > 0:
                        units += _flat
            except (TypeError, ValueError):
                pass
        else:
            units = calc_damage_units(weaponid, is_biochem, skillrank,
                                      teamrank, bio_lv, talent,
                                      chip_dmg=_chip_dmg)
            # 穿甲弹的伤害加成（客户端也是加在 basicDamage 上）
            if _ammo_dmg > 0:
                units += _ammo_dmg
            # 距离衰减：超过 effectiveRange 线性掉伤，maximumRange 外为 0
            try:
                _sd = float(t.get("sd") or 0.0)
            except (TypeError, ValueError):
                _sd = 0.0
            # 【v39 方案 A】枪械才校验（近战 sd 本来就是 0，且不吃距离衰减）。
            if reach is None:
                _sd2 = _sd_floor(battle, shoot, t, shooter, victim, _sd,
                                 shooterid=shooterid, weaponid=weaponid)
                if _sd2 is None:
                    continue
                _sd = float(_sd2)
            units = distance_falloff(weaponid, units, _sd, _ammo_rng,
                                     range_scale=_pistol_scale)
            # 生化模式的人类 BOT 伤害系数。
            # BOT 和真人共用同一条 `settle_shoot`，原来没有任何 bot 系数 ——
            # BOT 端着 AK 和玩家一样疼，一群 BOT 齐射比幽灵还凶。
            if is_biochem:
                from . import bots as _bots
                if _bots.is_bot(shooterid):
                    from ..config import CONFIG as _cfg
                    try:
                        units *= float(getattr(_cfg, "biochem_bot_dmg_scale", 1.0))
                    except (TypeError, ValueError):
                        pass
        if units <= 0:
            continue
        coef = coefficient(part, is_biochem)
        # 【v13】幽灵打「人类英雄」：部位倍率统一按胸部 1.0。
        # 英雄血量厚（5000），原来的头 1.8 / 腿 0.9 让 3 个鬼围 5 个英雄时
        # 一人两爪就倒（头部直接把伤害抬到 1.8 倍），手感是「秒杀」。
        # 现在无论打头打腿，对英雄都按 1.0 结算 —— 只影响僵尸爪对英雄，
        # 人类打僵尸的部位倍率、以及 BOT 打人类照旧。
        if zombie_attacker and is_biochem and bio is not None:
            try:
                _heroes = getattr(bio, "heroes", None) or ()
                if int(tid) in _heroes:
                    coef = 1.0
            except (TypeError, ValueError):
                pass
        # 护甲只挡子弹；僵尸爪击不经过防弹衣（客户端 BioHand 也不查 ac）
        ac = float(getattr(victim, "ac", 0.0) or 0.0)
        armor = None if zombie_attacker else armor_of(victim, part)
        absorb, dmg = split_by_armor(units, coef, armor, penetration, ac)
        # 防弹涂层（强化天赋 4）：被子弹击中减伤
        if dmg > 0 and not zombie_attacker:
            prot = research_percent(victim, RESEARCH_BULLET_PROT)
            if prot > 0:
                dmg = int(dmg * max(0.0, 1.0 - prot))
        # 生化幽灵技能「刚体 / 恶魔刚体」：steelHpRate% 减伤。
        # 伤害是服务端裁决的，客户端只播护盾特效；原来 use_skill 只广播了
        # 特效，服务端不认这个状态，玩家开了盾照样按全额掉血。
        if dmg > 0 and is_biochem and getattr(battle, "biochem", None) is not None:
            _bio = battle.biochem
            try:
                if _bio.is_zombie(tid):
                    _reduce = _bio.skill_damage_reduce(tid)
                    if _reduce > 0:
                        dmg = int(dmg * (1.0 - _reduce))
            except Exception:
                (log.debug("刚体减伤读取失败 tid=%s", tid, exc_info=True) if log.isEnabledFor(10) else None)
        if absorb > 0:
            victim.ac = max(0.0, ac - absorb)
        if dmg <= 0 and absorb <= 0:
            continue
        # 【v11】幽灵爪打「人类英雄」一击必杀。
        # 英雄血量 5000（biochem_hero_hp），生化凶灵（BioProperty 4）爪伤 800，
        # 乘部位系数后胸口 800 / 头 1440 / 腿 720 —— 要 4~7 爪。
        # 用户 1 打 7 时打不完，要求「一爪一个」，这里把伤害补到目标当前血量。
        # 只对英雄生效：普通人类 100 血本来就一爪死，不必改。
        if (dmg > 0 and zombie_attacker and is_biochem):
            _bio1 = getattr(battle, "biochem", None)
            if _bio1 is not None:
                try:
                    _heroes = getattr(_bio1, "heroes", None) or ()
                    if int(tid) in _heroes:
                        from ..config import CONFIG as _hc
                        if int(getattr(_hc, "biochem_zombie_hero_oneshot", 1) or 0):
                            dmg = max(dmg, float(victim.hp))
                except (TypeError, ValueError):
                    pass
        # 【v15】人类（含 BOT）打幽灵的伤害计入「重创」累计图标。
        # 只认真正扣到血上的 dmg（已经过护甲/刚体减伤），护盾、免伤不算。
        _nbio = getattr(battle, "biochem", None)
        if (dmg > 0 and is_biochem and not zombie_attacker
                and _nbio is not None and _nbio.is_zombie(tid)):
            try:
                _nbio.note_zombie_damage(int(shooterid), dmg)
            except Exception:
                (log.debug("累计幽灵伤害失败", exc_info=True) if log.isEnabledFor(10) else None)
        victim.hp = float(victim.hp) - dmg
        died = victim.hp <= 0
        if died:
            victim.hp = 0.0
        out.append(HitResult(tid, dmg, part, died, victim.hp, absorb))
    return out


def shoot_damage_payload(shoot: Dict[str, Any],
                         hits: List[HitResult]) -> Dict[str, Any]:
    """组装 ScShoot 的 `shoot` 字段（ShootDamage）。

    位置和方向原样透传，targets 换成服务端算出来的伤害。
    """
    by_id = {h.targetid: h for h in hits}
    out_targets: List[Dict[str, Any]] = []
    for t in (shoot.get("targets") or []):
        try:
            tid = int(t.get("targetid") or 0)
        except (TypeError, ValueError):
            continue
        h = by_id.get(tid)
        if h is None:
            continue
        out_targets.append({
            "targetid": tid,
            "hpdamage": float(h.hpdamage),
            "acdamage": int(h.acdamage),
            "sapihpdamage": 0,
            "hitpart": h.hitpart,
            "hitpos": t.get("hitpos") or {},
            "targetpos": t.get("targetpos") or {},
            "sd": float(t.get("sd") or 0.0),
        })
    return {
        "position": shoot.get("position") or {},
        "dir": shoot.get("dir") or {},
        "targets": out_targets,
    }

# --------------------------------------------------------------------------
# 手雷爆炸（AoE）
# --------------------------------------------------------------------------
# 客户端**不发**目标列表：
#
#     // FPSOnlineBehaviour.cs / TPSOnlineBehaviour.cs
#     RoomServer.Send(new CsGrenadeExplode(warrior.roleid, from.toBean(),
#                                          grenadeid, serial));
#     // 协议里 CsGrenadeExplode = roleid, pos, grenadeid, serial
#     // ScGrenadeExplode 比它多一个 List<TargetDamage> targets
#
# 所以炸到谁、掉多少血，全得服务端算。原来是直接把 msg.targets（永远是空）
# 转发出去，表现就是「手雷炸了，但没人掉血」。
#
# 算法对齐客户端离线端 Commander.ExplodeGrenade：
#
#     Grenade g = GameData.GetGrenade(grenadeid);
#     Collider[] arr = Physics.OverlapSphere(from, g.blastRange);
#     foreach (Warrior w) {
#         if (VirtualServer.AvoidDamaged(w.roleid)) continue;            // 出生保护
#         if (VirtualServer.AvoidDamaged(w.roleid, shooterid)) continue; // 同阵营
#         float sd = Vector3.Distance(from, w.position);
#         int dmg = VirtualServer.CalcGrenadeDamage(g, sd);
#         list.Add(new TargetDamage(w.roleid, dmg, 0, 0, 2, zero,
#                                   w.position.toBean(), sd));
#     }
#
#     CalcGrenadeDamage(g, sd) = RobotConsts.GrenadeDamage(
#         Mathf.Lerp(g.maxDamage, g.minDamage, sd / g.blastRange));
#     GrenadeDamage(basic, skillrank=0) = (int)basic;
#
# `Util.IsSimilar(side, side2)` = `side == side2 && side != 4` —— side 4 表示
# 「不分组」，所以 4 之间永远不算同队。

GRENADE_PART = 2          # TargetDamage.hitpart：手雷固定 2（和离线端一致）


def grenade_row(grenadeid: int) -> Dict[str, Any]:
    return _table("Grenade").get(int(grenadeid or 0)) or {}


def calc_grenade_damage(grenadeid: int, sd: float, bonus: float = 0.0,
                        is_biochem: bool = False) -> int:
    """离爆心 sd 米处的伤害（Mathf.Lerp 会把 t 夹在 [0,1]）。

    `bonus` 是掷弹狂人（强化天赋 10）的增伤比例，客户端 Commander.ExplodeGrenade
    里是 `CalcGrenadeDamage(...) + GrenaderAcc`（加算平数），这里按统一口径乘算。

    【v46】**生化打击**：`Grenade.bioDamage` 一直是没读的字段 —— 生化手雷
    （711056/711057）、生化威能手雷（711058）、终极生化雷（741111）在表里
    分别是 300/300/400/400，而普通手雷 bioDamage == maxDamage。所以生化房里
    按 bioDamage 等比放大整条衰减曲线就行：普通雷数值不变、生化雷才强化，
    与枪械用 `Gun.bioDamage` 是同一个思路。
    """
    g = grenade_row(grenadeid)
    if not g:
        return 0
    maxd = _f(g, "maxDamage", 0.0)
    mind = _f(g, "minDamage", maxd)
    if is_biochem:
        bio = _f(g, "bioDamage")
        if bio > 0:
            # 【v47】用户口径：bioDamage 整体 ×`grenade_bio_scale`（默认 10）。
            try:
                from ..config import CONFIG
                bio *= float(getattr(CONFIG, "grenade_bio_scale", 10.0) or 1.0)
            except (TypeError, ValueError):
                bio *= 10.0
            if maxd > 0:
                mind = mind * (bio / maxd)
            else:
                mind = bio
            maxd = bio
    rng = _f(g, "blastRange", 0.0) or 1.0
    t = min(1.0, max(0.0, float(sd) / rng))
    return int((maxd + (mind - maxd) * t) * (1.0 + float(bonus or 0.0)))


def resolve_grenade(battle, shooterid: int, pos: Dict[str, Any], grenadeid: int,
                    is_biochem: bool = False) -> List[Dict[str, Any]]:
    """算出这枚手雷的 AoE 伤害、扣血，返回 `ScGrenadeExplode.targets`。

    坐标：协议里的 Vec3 是 short（×100），`Fighter.syncpos` 已经是米。
    """
    g = grenade_row(grenadeid)
    rng = _f(g, "blastRange", 0.0)
    if rng <= 0:
        return []
    shooter = battle.fighters.get(int(shooterid or 0))
    if shooter is None:
        return []
    origin = (float(pos.get("x") or 0) / 100.0,
              float(pos.get("y") or 0) / 100.0,
              float(pos.get("z") or 0) / 100.0)
    same_side_ok = getattr(battle, "is_invincible", None)
    grenade_bonus = research_percent(shooter, RESEARCH_GRENADE)

    out: List[Dict[str, Any]] = []
    for tid, victim in list(battle.fighters.items()):
        tid = int(tid)
        if tid == int(shooterid) or not getattr(victim, "born", False):
            continue
        if float(getattr(victim, "hp", 0.0) or 0.0) <= 0:
            continue
        # 出生保护
        if same_side_ok is not None and same_side_ok(tid):
            continue
        # 同阵营免伤（side 4 = 不分组，永远算不同队）
        if same_team(battle,int(shooterid),tid):
            continue
        p = getattr(victim, "syncpos", None)
        if not p:
            continue
        sd = ((p[0] - origin[0]) ** 2 + (p[1] - origin[1]) ** 2
              + (p[2] - origin[2]) ** 2) ** 0.5
        if sd > rng:
            continue
        dmg = calc_grenade_damage(grenadeid, sd, grenade_bonus,
                                  is_biochem=is_biochem)
        # 防爆护盾（强化天赋 9）
        blast_prot = research_percent(victim, RESEARCH_BLAST_PROT)
        if dmg > 0 and blast_prot > 0:
            dmg = int(dmg * max(0.0, 1.0 - blast_prot))
        if dmg <= 0:
            continue
        # 【v15】手雷炸幽灵同样计入「重创」累计（和 resolve_shoot 同口径）。
        _gbio = getattr(battle, "biochem", None)
        if (is_biochem and _gbio is not None and _gbio.is_zombie(tid)
                and not _gbio.is_zombie(int(shooterid))):
            try:
                _gbio.note_zombie_damage(int(shooterid), dmg)
            except Exception:
                (log.debug("手雷累计幽灵伤害失败", exc_info=True) if log.isEnabledFor(10) else None)
        victim.hp = float(victim.hp) - dmg
        if victim.hp <= 0:
            victim.hp = 0.0
        out.append({
            "targetid": tid,
            "hpdamage": float(dmg),
            "acdamage": 0,
            "sapihpdamage": 0,
            "hitpart": GRENADE_PART,
            "hitpos": {"x": 0, "y": 0, "z": 0},
            "targetpos": {"x": int(p[0] * 100), "y": int(p[1] * 100),
                          "z": int(p[2] * 100)},
            "sd": float(sd),
        })
    return out
