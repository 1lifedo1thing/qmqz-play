"""Starter equipment: the loadouts and backpack the server hands a new player.

Two separate client systems need feeding, and they are easy to confuse:

    ScEquipGroup(786433)  -> EquipManager.Response()   the 选装备 screen's loadouts
    ScPackageSync(983041) -> DepotManager.Response()   the 背包

The equip screen's confirm button does nothing when `EquipManager.EquipCount`
is 0, because `BattleEquip.Render` builds `(EquipCount + 1) / 2` carousel cells
from it -- an empty group list is an empty screen.

Every id here must exist in the `Item` config table.  The client indexes
straight into it without a null check:

    GameData.instance.getItem(value).subType        // EquipManager.UpdateWeaponStatus
    GameData.instance.getItem(pkgItem.id).subType   // DepotManager.SynPkgInitialize

and `getEquipGroup(subType)` must return a row too, or `groupedItems[group]`
is out of range.

Slot numbers come from the EquipFilter table, subType groups from EquipGroup:

    11 主武器   12 副武器   21 弹药   31 头盔   32 护甲   33 靴子
    34 装甲     41 手雷     50 近战
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from .. import gamedata

log = logging.getLogger("crisisfire.equip")

# ScPackageSync(983041)：synctype 1=add / 2=modify / 3=all
SC_PACKAGE_SYNC = 983041

# 传奇改装卡（Item 1002，Icon_LegendCard）。强化界面里的「x N」读的是
# PromoteLegend.ChipNum，而它只会被 ScLegendCardSync(1048638) 写入：

#     // com.gwebtop.shop.ScLegendCardSync
#     protected override void process() { PromoteLegend.Sync(this); }
#     // PromoteLegend.Sync
#     Increase = ChipNum != -1 && sync.cardnum > ChipNum;
#     ChipNum = sync.cardnum;
#     chipnum.text = $"x {Mathf.Clamp(ChipNum, 0, int.MaxValue)}";

# 客户端**从不请求**这条消息（全客户端没有 CsLegendCardSync），所以只能在
# 登录时推，以及每次发卡之后补推。张数单独记在 role.data["legend_cards"]：
# pkg_items 是 id 集合，装不下一张以上的卡（升级一次要 price=4~32 张）。
LEGEND_CARD_ID = 1002
SC_LEGEND_CARD_SYNC = 1048638

# subType -> group, loaded from the client's EquipGroup table
_GROUP_CACHE: Dict[int, int] = {}


def _subtype_group(sub: int) -> int:
    if not _GROUP_CACHE:
        for row in gamedata.table("EquipGroup"):
            try:
                _GROUP_CACHE[int(row["id"])] = int(row["group"])
            except (KeyError, TypeError, ValueError):
                continue
    return _GROUP_CACHE.get(sub, -1)


def _item(itemid: int) -> Dict[str, Any]:
    for row in gamedata.table("Item"):
        if row.get("id") == itemid:
            return row
    return {}


def _valid(itemid: int) -> bool:
    """An id the client can look up without tripping a null dereference."""
    it = _item(itemid)
    if not it:
        log.warning("item %s is not in the Item table; dropping it", itemid)
        return False
    if _subtype_group(int(it.get("subType", -1))) < 0:
        log.warning("item %s (%s) has subType %s with no EquipGroup row",
                    itemid, it.get("name"), it.get("subType"))
        return False
    return True


# --------------------------------------------------------------------------
# loadouts (ScEquipGroup)
# --------------------------------------------------------------------------
COMMON = {
    12: 105021,   # 格洛克17 手枪
    21: 900000,   # 默认枪弹
    31: 811021,   # 战斗头盔
    32: 821021,   # 战斗防弹衣
    33: 831021,   # 战斗军靴
    41: 711051,   # 爆炸手雷
    50: 850001,   # 匕首
}

# slot 11 varies so the carousel has something to scroll through and so
# EquipManager.UpdateWeaponStatus can see a sniper (subType 16) among them
PRIMARIES = [
    (403061, "AK47"),      # 步枪 subType 14
    (601041, "SVD"),       # 狙击 subType 16
    (404061, "M4A1"),      # 步枪
]

POLICE_ACTORS = [101, 102, 103]
TERRIST_ACTORS = [201, 202, 203]


def starter_loadouts() -> List[Dict[str, Any]]:
    """The `equips` list for EquipGroup."""
    out = []
    for primary, _name in PRIMARIES:
        if not _valid(primary):
            continue
        equipmap = {11: primary}
        for slot, iid in COMMON.items():
            if _valid(iid):
                equipmap[slot] = iid
        star = max((int(_item(i).get("star") or 0) for i in equipmap.values()),
                   default=0)
        out.append({"equipmap": equipmap, "star": star})
    if not out:
        log.error("no usable starter loadout -- the equip screen will be empty")
    return out


def equip_group_payload(role=None) -> Dict[str, Any]:
    """The `equipgroup` field of ScEquipGroup(786433).

    With a role, the saved loadouts and the character picks are used so both
    survive a relogin.

    The client falls back when a pick is not in the owned map:

        // EquipManager.Response(ScEquipGroup)
        defaultPoliceactor = equipgroup.curpoliceactor;
        if (!equipgroup.policeactors.ContainsKey(defaultPoliceactor))
            defaultPoliceactor = 101;

    so `curpoliceactor` must be a key of `policeactors`.
    """
    loadouts = loadouts_of(role) if role is not None else starter_loadouts()
    owned = owned_actors(role) if role is not None else default_actor_ownership()
    chosen = chosen_actors(role) if role is not None else {}

    police = owned.get(1, {})
    terrist = owned.get(2, {})
    bio = owned.get(3, {})

    cur_police = int(chosen.get(1) or 0)
    if cur_police not in police:
        cur_police = next(iter(sorted(police)), 0)
    cur_terrist = int(chosen.get(2) or 0)
    if cur_terrist not in terrist:
        cur_terrist = next(iter(sorted(terrist)), 0)
    cur_bio = int(chosen.get(3) or 0)
    if cur_bio not in bio:
        cur_bio = next(iter(sorted(bio)), 0)

    return {
        "activeindex": active_index(role) if role is not None else 0,
        "equips": loadouts,
        "policeactors": {int(k): int(v) for k, v in police.items()},
        "terristactors": {int(k): int(v) for k, v in terrist.items()},
        "bioactors": {int(k): int(v) for k, v in bio.items()},
        "curpoliceactor": cur_police,
        "curterristactor": cur_terrist,
        "curbioactor": cur_bio,
    }


# --------------------------------------------------------------------------
# characters (角色)
# --------------------------------------------------------------------------
# Role table: camp 1 = 联盟/police, camp 2 = 反叛/terrist, camp 3 = biochem
CAMP_NAME = {1: "警察", 2: "匪徒", 3: "生化"}


def role_row(actorid: int) -> Dict[str, Any]:
    for r in gamedata.table("Role"):
        if r.get("id") == actorid:
            return r
    return {}


def actor_camp(actorid: int) -> int:
    try:
        return int(role_row(actorid).get("camp") or 0)
    except (TypeError, ValueError):
        return 0


def actor_name(actorid: int) -> str:
    return str(role_row(actorid).get("name") or actorid)


def actor_price(actorid: int) -> Dict[str, int]:
    """Price of a character, in the client's own currency mapping.

    `UserManager.IsEnough`: bloodGem -> diamond, gem -> gold, gold -> money.
    """
    row = role_row(actorid)
    def _i(k):
        try:
            return max(0, int(row.get(k) or 0))
        except (TypeError, ValueError):
            return 0
    return {"gold": _i("gem"), "diamond": _i("bloodGem"), "money": _i("gold")}


# 【v13 回退】原本想让这 5 个角色「抽到才出现」，靠 DLL 注入过滤角色页 ——
# 但注入的代码一进角色页就闪退（把方法体搬出 .text 后 Mono 读不到，机制风险太高），
# 已彻底回退。现在这 5 个角色**默认拥有**，和普通角色一样显示在角色页。
# 102 赤色彗星 / 202 霸天虎 / 106 猎魔人凯莉 / 207 影战士米拉 / 1002 生化凶灵
DEFAULT_LOCKED_ACTORS = frozenset()


def default_actor_ownership() -> Dict[int, Dict[int, int]]:
    """Every character of camp 1 and 2, permanent (desttime 0)."""
    out: Dict[int, Dict[int, int]] = {1: {}, 2: {}, 3: {}}
    for r in gamedata.table("Role"):
        try:
            camp = int(r.get("camp") or 0)
            aid = int(r["id"])
        except (KeyError, TypeError, ValueError):
            continue
        if camp not in (1, 2, 3):
            continue
        # 【v12】抽卡限定角色默认不拥有：102 赤色彗星 / 202 霸天虎 /
        # 106 猎魔人凯莉 / 207 影战士米拉 / 1002 生化凶灵。
        #   以前靠 `visible=0` 把它们从客户端角色页藏起来 —— 但那样「抽到了」
        #   也不会出现（prototypes 只收 visible != 0 的）。
        #   现在改成：visible 保持 1（进 prototypes），角色页由 DLL 注入的
        #   `EquipManager.IsOwnedActor()` 过滤，只有真正拥有才显示。
        if int(aid) in DEFAULT_LOCKED_ACTORS:
            continue
        try:
            if int(r.get("visible") or 0) == 0:
                continue
        except (TypeError, ValueError):
            continue
        out[camp][aid] = 0
    return out


def owned_actors(role) -> Dict[int, Dict[int, int]]:
    """{camp: {actorid: desttime}}; 0 means permanent."""
    raw = (role.data or {}).get("actors") if role is not None else None
    if not isinstance(raw, dict) or not raw:
        return default_actor_ownership()
    out: Dict[int, Dict[int, int]] = {1: {}, 2: {}, 3: {}}
    for k, v in raw.items():
        try:
            camp = int(k)
        except (TypeError, ValueError):
            continue
        if camp not in out or not isinstance(v, dict):
            continue
        for aid, dest in v.items():
            try:
                out[camp][int(aid)] = int(dest or 0)
            except (TypeError, ValueError):
                continue
    # a character the Role table places elsewhere must not leak into a camp
    for camp, ids in out.items():
        for aid in list(ids):
            if actor_camp(aid) != camp:
                ids.pop(aid, None)
    return out


def save_actors(role, owned: Dict[int, Dict[int, int]], world=None) -> None:
    if world is not None:
        world.merge_role_data(role.roleid,
                              actors={str(k): v for k, v in owned.items()})


def chosen_actors(role) -> Dict[int, int]:
    raw = (role.data or {}).get("chosen_actor")
    if not isinstance(raw, dict):
        return {}
    out = {}
    for k, v in raw.items():
        try:
            out[int(k)] = int(v)
        except (TypeError, ValueError):
            continue
    return out


def buy_actor(role, actorid: int, world=None, free: bool = False) -> int:
    """Add a character to the owned list.  Returns 0 on success, else a code.

    ``free=True`` is for prizes (gacha / events): it must not charge the
    player, and must not fail when they cannot afford the shop price.
    """
    camp = actor_camp(actorid)
    if camp not in (1, 2, 3):
        return 2                                   # unknown character
    owned = owned_actors(role)
    if actorid in owned[camp]:
        return 3                                   # already owned
    if not free:
        price = actor_price(actorid)
        if (price["gold"] > role.gold or price["diamond"] > role.diamond
                or price["money"] > role.money):
            return 1                               # cannot afford
        role.gold -= price["gold"]
        role.diamond -= price["diamond"]
        role.money -= price["money"]
        if world is not None:
            world.update_role(role.roleid, gold=role.gold, diamond=role.diamond,
                              money=role.money)
    owned[camp][actorid] = 0
    save_actors(role, owned, world)
    return 0


def set_default_actor(role, actorid: int, world=None) -> Optional[int]:
    """Pick a character.  The camp decides which slot moves.

    `EquipManager.SetDefaultActor` switches on `Role.camp`, and a police id
    must never land in the terrist slot -- the client would then hand an
    unknown actor to the terrist side in battle.
    """
    camp = actor_camp(actorid)
    if camp not in (1, 2, 3):
        return None
    owned = owned_actors(role)
    if actorid not in owned[camp]:
        return None
    chosen = chosen_actors(role)
    chosen[camp] = actorid
    if world is not None:
        world.merge_role_data(role.roleid,
                              chosen_actor={str(k): v for k, v in chosen.items()})
    return camp


# --------------------------------------------------------------------------
# subjoins / decorations (饰品)
# --------------------------------------------------------------------------
# The client keeps 角色 -> {槽位: Subjoin.id} in two places with the *same*
# shape (work/decomp_181/DepotManager.cs:132..191, SubjoinMap.cs,
# PlayerInfo.cs):
#
#     ScSubjoinList(786485).actorsubjoinmap : Dictionary<int, SubjoinMap>
#     PlayerInfo.subjoins                   : Dictionary<int, SubjoinMap>
#
# 槽位来自 Item.equipPos，只可能是 101..104（DecorationItem.Position 和
# Exhibition.GetSubjoins 的四组）。落盘用同一形状，JSON 会把 int 键写成
# 字符串，所以读写都过一遍 normalize_subjoins()。
SUBJOIN_POSITIONS = (101, 102, 103, 104)

# client decoration groups (DepotManager.groupTypeCount / EquipGroup 4)
_DECORABLE_CAMPS = (1, 2)     # 装饰界面只对人类阵营开放（DecorationItem 588）


def subjoin_row(itemid: int) -> Dict[str, Any]:
    """`Subjoin` config row (actorid / actorPart / addHP / addSpeed ...)."""
    for row in gamedata.table("Subjoin"):
        try:
            if int(row.get("id") or 0) == int(itemid):
                return row
        except (TypeError, ValueError):
            continue
    return {}


def normalize_subjoins(raw: Any) -> Dict[int, Dict[int, int]]:
    """{actorid: {pos: itemid}} with int keys, dropping malformed rows."""
    out: Dict[int, Dict[int, int]] = {}
    if not isinstance(raw, dict):
        return out
    for actor_raw, slots in raw.items():
        try:
            actor = int(actor_raw)
        except (TypeError, ValueError):
            continue
        if actor <= 0 or not isinstance(slots, dict):
            continue
        clean: Dict[int, int] = {}
        for pos_raw, item_raw in slots.items():
            try:
                pos, item = int(pos_raw), int(item_raw)
            except (TypeError, ValueError):
                continue
            if pos in SUBJOIN_POSITIONS and item > 0:
                clean[pos] = item
        if clean:
            out[actor] = clean
    return out


def subjoins_of(role) -> Dict[int, Dict[int, int]]:
    return normalize_subjoins((role.data or {}).get("subjoins"))


def save_subjoins(role, mapping: Dict[int, Dict[int, int]], world=None) -> None:
    if world is not None:
        world.merge_role_data(
            role.roleid,
            subjoins={str(a): {str(p): int(i) for p, i in slots.items()}
                      for a, slots in mapping.items() if slots})


def subjoin_at(role, actor: int, pos: int) -> int:
    """-1 when the slot is empty (客户端的 GetSubjoin 也是这个约定)."""
    return int(subjoins_of(role).get(int(actor), {}).get(int(pos), -1))


def subjoin_list_payload(role) -> Dict[int, Dict[str, Any]]:
    """The `actorsubjoinmap` field of ScSubjoinList(786485).

    Each value is a SubjoinMap struct, i.e. ``{"subjoins": {pos: itemid}}``.
    """
    return {int(actor): {"subjoins": {int(p): int(i) for p, i in slots.items()}}
            for actor, slots in subjoins_of(role).items() if slots}


def _actor_decorable(role, actorid: int) -> bool:
    """The client only opens 饰品 for an owned human character."""
    camp = actor_camp(actorid)
    if camp not in _DECORABLE_CAMPS:
        return False
    return int(actorid) in owned_actors(role).get(camp, {})


def subjoin_attach_valid(role, actor: int, pos: int, itemid: int) -> bool:
    """Every constraint the 1.8.1 client applies before sending CsAttachSubjoin.

    DepotManager.Attach only checks ``Subjoin.actorid`` (Callboard 594); the
    ownership/pos checks happen in the depot UI and must be repeated here.
    """
    if int(pos) not in SUBJOIN_POSITIONS or int(itemid) <= 0:
        return False
    if not _actor_decorable(role, int(actor)):
        return False
    if int(itemid) not in owned_ids(role):
        return False
    item = item_row(int(itemid))
    if not item:
        return False
    try:
        if int(item.get("equipPos") or 0) != int(pos):
            return False
    except (TypeError, ValueError):
        return False
    row = subjoin_row(int(itemid))
    if not row:
        return False
    try:
        restrict = int(row.get("actorid") or 0)
    except (TypeError, ValueError):
        return False
    return restrict == 0 or restrict == int(actor)


def set_subjoin(role, actor: int, pos: int, subjoinid: int, world=None) -> bool:
    """Wear (subjoinid > 0) or remove (-1) one decoration slot.

    Returns False for anything the client would not have been allowed to send;
    the caller then leaves its optimistic UI untouched.
    """
    actor, pos, subjoinid = int(actor), int(pos), int(subjoinid)
    if pos not in SUBJOIN_POSITIONS or not _actor_decorable(role, actor):
        return False
    if subjoinid != -1 and not subjoin_attach_valid(role, actor, pos, subjoinid):
        return False

    mapping = subjoins_of(role)
    slots = dict(mapping.get(actor) or {})
    if subjoinid == -1:
        slots.pop(pos, None)
    else:
        slots[pos] = subjoinid
    if slots:
        mapping[actor] = slots
    else:
        mapping.pop(actor, None)
    save_subjoins(role, mapping, world)
    return True


# --------------------------------------------------------------------------
# backpack (ScPackageSync)
# --------------------------------------------------------------------------
def starter_items() -> List[Dict[str, Any]]:
    """com.gwebtop.item.Item rows: DepotManager keys these by `id`."""
    ids: List[int] = []
    for primary, _n in PRIMARIES:
        ids.append(primary)
    ids.extend(COMMON.values())
    # 用户指定：仓库永远保留的近战/投掷基础件（COMMON 改了也不能丢）
    ids.extend([850001,    # 匕首
                711051])   # 爆炸手雷
    # a couple of upgrades so the backpack is not just the default set
    ids.extend([403062, 404062, 601031, 811022, 821022, 105022])

    seen = set()
    out = []
    for iid in ids:
        if iid in seen or not _valid(iid):
            continue
        seen.add(iid)
        out.append({
            "id": iid,
            "desttime": 0,       # 0 = permanent, no expiry
            "flags": 0,
            "subcount": 1,
            "duration": item_durability(iid),
        })
    return out


def summary() -> Dict[str, Any]:
    loadouts = starter_loadouts()
    return {
        "loadouts": len(loadouts),
        "slots": [sorted(l["equipmap"]) for l in loadouts],
        "backpack": len(starter_items()),
    }


# --------------------------------------------------------------------------
# per-role loadouts (the `equips` list of EquipGroup)
# --------------------------------------------------------------------------
def loadouts_of(role) -> List[Dict[str, Any]]:
    """The role's saved loadouts, falling back to the starter set."""
    rows = (role.data or {}).get("loadouts")
    if not isinstance(rows, list) or not rows:
        rows = starter_loadouts()
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        em = r.get("equipmap") or {}
        timed = role.data.get("pve_reward_items") or {}
        usable = set(owned_ids(role))
        equipmap = {int(slot): int(item) for slot, item in em.items()
                    if depot_item(int(item)) and _item(int(item)).get("equipPos") == int(slot)
                    and (str(item) not in timed or int(item) in usable)}
        star = max((int(_item(item).get("star") or 0) for item in equipmap.values()), default=0)
        out.append({"equipmap": equipmap, "star": star})
    return out or starter_loadouts()


def save_loadouts(role, rows: List[Dict[str, Any]], world=None) -> None:
    if world is not None:
        world.merge_role_data(role.roleid,
                              loadouts=[{"equipmap": r["equipmap"],
                                         "star": r.get("star", 0)} for r in rows])


def active_index(role) -> int:
    try:
        return max(0, int((role.data or {}).get("active_equip", 0)))
    except (TypeError, ValueError):
        return 0


def set_equipped(role, tab: int, position: int, weaponid: int,
                 world=None) -> bool:
    """Put `weaponid` (or -1 to clear) into loadout `tab` at `position`."""
    rows = loadouts_of(role)
    if not rows:
        return False
    if tab < 0 or tab >= len(rows):
        log.warning("equip tab %s out of range (%d loadouts)", tab, len(rows))
        return False
    em = rows[tab]["equipmap"]
    if weaponid is None or int(weaponid) <= 0:
        em.pop(int(position), None)
    else:
        em[int(position)] = int(weaponid)
    rows[tab]["star"] = max(
        (int(_item(i).get("star") or 0) for i in em.values()), default=0)
    save_loadouts(role, rows, world)
    return True


def equipped_of(role, tab: int) -> Dict[int, int]:
    rows = loadouts_of(role)
    if 0 <= tab < len(rows):
        return dict(rows[tab]["equipmap"])
    return {}


# --------------------------------------------------------------------------
# 护甲：全背包同步 + 新背包继承（v24）
# --------------------------------------------------------------------------
ARMOR_SLOTS = (31, 32, 33, 34)   # 31头盔 32护甲 33靴子 34装甲


def armor_ac_of(itemid: int) -> int:
    """单件护甲的强度 = Armor.maxAc；非护甲/未知返回 0。"""
    try:
        iid = int(itemid or 0)
    except (TypeError, ValueError):
        return 0
    if iid <= 0:
        return 0
    for row in gamedata.table("Armor"):
        if int(row.get("id") or 0) == iid:
            return int(row.get("maxAc") or 0)
    return 0


def equip_armor_all_tabs(role, position: int, weaponid: int,
                         world=None) -> List[int]:
    """把一件护甲同步进**所有已解锁背包**的同一槽位，只升不降。

    用户口径：护甲越强越好、没人会自降护甲；快速装备一处，所有背包一起换。
    逐背包按 Armor.maxAc 比较，新护甲更强才替换，比它弱的保留原样。
    返回实际被改动的 tab 列表（当前 tab 由调用方 set_equipped 先改，故通常跳过）。
    """
    try:
        pos = int(position)
        wid = int(weaponid or 0)
    except (TypeError, ValueError):
        return []
    if pos not in ARMOR_SLOTS or wid <= 0:
        return []
    new_ac = armor_ac_of(wid)
    if new_ac <= 0:
        return []
    rows = loadouts_of(role)
    changed: List[int] = []
    for idx, r in enumerate(rows):
        em = r.get("equipmap")
        if not isinstance(em, dict):
            em = r["equipmap"] = {}
        cur = int(em.get(pos) or 0)
        if cur == wid:
            continue
        if armor_ac_of(cur) >= new_ac:
            continue                      # 已有更强/同强，绝不降级
        em[pos] = wid
        r["star"] = max(
            (int(_item(i).get("star") or 0) for i in em.values()), default=0)
        changed.append(idx)
    if changed:
        save_loadouts(role, rows, world)
    return changed


def inherit_armor_equipmap(rows: List[Dict[str, Any]]) -> Dict[int, int]:
    """新背包的初始装备：每个护甲槽继承已有背包里**最强**的那一件。"""
    best: Dict[int, int] = {}
    for slot in ARMOR_SLOTS:
        best_iid, best_ac = 0, -1
        for r in rows:
            iid = int((r.get("equipmap") or {}).get(slot) or 0)
            ac = armor_ac_of(iid)
            if iid > 0 and ac > best_ac:
                best_ac, best_iid = ac, iid
        if best_iid > 0:
            best[slot] = best_iid
    return best


# --------------------------------------------------------------------------
# backpack mutation (shop / gifts / roulette all feed this)
# --------------------------------------------------------------------------
def item_row(itemid: int) -> Dict[str, Any]:
    return _item(itemid)


def item_name(itemid: int) -> str:
    return str(_item(itemid).get("name") or itemid)


def item_durability(itemid: int) -> int:
    """Max durability from the Item table.

    The client treats `com.gwebtop.item.Item.duration` as the CURRENT
    durability and `Item.durability` as the maximum:

        // BattleEquipPicker
        if (item.duration > 0 || mData.durability < 1) { ...show the bar... }
        else { brokenObj.SetActive(true); }          // 损坏

        // DepotManager.GetDisplayedDurationValue
        if (itemDuration <= 0) return 1f;   // config has no wear -> always full
        if (duration <= 0)     return 0f;   // empty bar

    so granting an item with `duration = 0` makes every one of the 236 guns
    with `durability = 10000` show up as 损坏.  Grant them at full durability.
    """
    try:
        return max(0, int(_item(itemid).get("durability") or 0))
    except (TypeError, ValueError):
        return 0


def permanent_ids(role) -> List[int]:
    try:
        return [int(i) for i in (role.data or {}).get("pkg_items", [])]
    except (TypeError, ValueError):
        return []


def owned_ids(role) -> List[int]:
    permanent = set(permanent_ids(role))
    now = int(time.time())
    for item, reward in (role.data.get("pve_reward_items") or {}).items():
        if reward["expiry"] > now:
            permanent.add(int(item))
    from . import premium_ammo
    for item in premium_ammo.paid_rows():
        if premium_ammo.count(role, item):
            permanent.add(item)
        else:
            permanent.discard(item)
    return sorted(permanent)


def all_weapon_ids() -> List[int]:
    """Every weapon in the Item table (equipPos 11/12/50 = 主/副/近战)."""
    out = []
    for row in gamedata.table("Item"):
        try:
            if int(row.get("equipPos") or 0) in (11, 12, 50):
                out.append(int(row["id"]))
        except (KeyError, TypeError, ValueError):
            continue
    return out


NON_BACKPACK_EQUIPMENT = {
    605171: 'Item.name=空; reserved row has no icon or matching texture',
    8001: 'Consts.HeroMeleeID; ClientManager.BioHero assigns it during transformation',
    711001: 'Consts.LauncherID; internal hand-held proxy for actual grenade ammunition',
    711002: 'Consts.Rocket_1_ID; internal/unused Launcher entry, not an ordinary grenade',
    711011: 'Consts.ExplosiveID; mode-assigned C4, not ordinary boots (equipPos=33)',
    711021: 'Consts.ExplosivePadID; internal C4 controller, not ordinary boots',
    731051: 'Reserved Item-only CS row; no behavior table, model or caller',
    742111: 'Reserved Item-only AT4 row; no behavior table, model or caller',
}


_part_map: "Optional[Dict[int, Dict[str, Any]]]" = None
_base_by_model: Optional[Dict[int, int]] = None


def _parts() -> Dict[int, Dict[str, Any]]:
    global _part_map
    if _part_map is None:
        _part_map = {}
        for row in gamedata.table("Part"):
            try:
                _part_map[int(row["id"])] = row
            except (KeyError, TypeError, ValueError):
                continue
    return _part_map


def _base_by_type() -> Dict[int, int]:
    global _base_by_model
    if _base_by_model is None:
        _base_by_model = {}
        for row in gamedata.table("Part"):
            try:
                if int(row.get("version") or 0) != 0:
                    continue
                _base_by_model[int(row.get("modelType") or 0)] = int(row["id"])
            except (KeyError, TypeError, ValueError):
                continue
    return _base_by_model


def base_variant(itemid: int) -> int:
    """强化体系的枪只保留**第一阶段（version=0）基底**；其余原样返回。

    仓库里原来同时躺着同一把枪的每个强化版本（沙鹰 101101/101102/
    101103/101104 四把），又因为本地服「全武器解锁」一次性全发，仓库一眼
    望过去全是重复。强化升版本走 `CsTransform` 换 itemid，是**升出来的**，
    不靠仓库预置，所以把高阶版本从仓库清掉不影响养成。
    """
    try:
        iid = int(itemid)
    except (TypeError, ValueError):
        return 0
    row = _parts().get(iid)
    if not row:
        return iid
    try:
        if int(row.get("version") or 0) == 0:
            return iid
        base = _base_by_type().get(int(row.get("modelType") or 0))
    except (TypeError, ValueError):
        return iid
    return int(base) if base else iid


def all_equipment_ids() -> List[int]:
    """Actual Item catalog: weapons, armor, ammo, grenades and accessories.

    Positive equipPos is the package's equipment classification. Currency,
    gift boxes and other position-zero consumables are outside this grant.
    Internal launchers, mode-assigned items and orphan placeholder rows are
    excluded. Their original tables and battle logic are preserved. Two of
    those rows also stall the original depot's icon loading.

    **强化体系的枪只发基底版本**（见 `base_variant`）—— 否则同一把枪的
    3~10 个强化阶段会全部躺在仓库里。
    """
    return [row["id"] for row in gamedata.table("LocalDepotCatalog")]


def depot_item(itemid):
    item = _item(itemid)
    return _valid(itemid) and (not item.get("equipPos") or itemid in all_equipment_ids())
# 养成版的启动包 —— 仓库里只留这 5 把基底枪 + 1 刀 1 雷，
# 其余道具（含角色配饰、护甲、弹药、碎片）全部清掉。
# 角色本体在 role.data["actors"] / ["chosen_actor"]，不在这里，所以自然保留。
STARTER_ITEMS = (304061,   # TMP
                 403061,   # AK47
                 404061,   # M4A1
                 601041,   # SVD（v0 基底；601031 是另一个不可强化条目）
                 105021,   # 格洛克17
                 850001,   # 匕首
                 711051)   # 爆炸手雷

# 装备方案里被清掉的主武器按枪种换到启动包里对应的那把
_STARTER_BY_SUBTYPE = {11: 403061, 12: 304061, 13: 403061,
                       14: 601041, 15: 403061, 16: 105021}


def ensure_all_equipment(role, world):
    """养成版：**只在首次登录时**把仓库裁成启动包，之后永不再动玩家数据。

    老实现每次进大厅（含神秘转盘抽到任意奖品后的 `push_lobby_state`）都把
    全部装备塞进 `pkg_items`，于是「仓库清空」永远做不到，一登录就是全解锁。

    现在用 `local_equipment_unlock.progression` 做一次性标记：
      * 标记为真的存档 -> 直接返回，**不补发、不清理、不降级**；
      * 其他存档 -> 清一次（只留 STARTER_ITEMS），写标记，之后不再执行。
    """
    target = world.role(role.roleid) or role
    data = dict(target.data or {})
    marker = data.get("local_equipment_unlock")
    if isinstance(marker, dict) and marker.get("progression"):
        return target

    keep = sorted({int(x) for x in STARTER_ITEMS})
    target = world.merge_role_data(
        role.roleid,
        pkg_items=keep,
        local_equipment_unlock={
            'version': 3, 'progression': True, 'starter': keep,
            'source': 'progression starter pack (one-shot)',
            'implementation': 'clear depot, keep 5 guns + knife + grenade'})
    log.info('LOCAL-EQUIPMENT-PROGRESSION role=%s 一次性初始化启动包 %s',
             role.roleid, keep)

    # 装备方案里引用了已被清掉的武器 -> 换到启动包里同枪种的那把。
    rows = (target.data or {}).get("loadouts")
    if isinstance(rows, list) and rows:
        keepset = set(keep)
        changed = False
        fixed = []
        for r in rows:
            if not isinstance(r, dict):
                fixed.append(r)
                continue
            em = r.get("equipmap") or {}
            new_em = {}
            for k, v in em.items():
                try:
                    iid, slot = int(v), int(k)
                except (TypeError, ValueError):
                    new_em[k] = v
                    continue
                if iid in keepset or slot not in (11, 12, 50):
                    new_em[k] = v
                    continue
                if slot == 12:
                    replacement = 105021
                elif slot == 50:
                    replacement = 850001          # 默认匕首
                else:
                    sub = int((_item(iid) or {}).get('subType') or 0)
                    replacement = _STARTER_BY_SUBTYPE.get(sub, 403061)
                new_em[k] = replacement
                changed = True
            fixed.append({"equipmap": new_em, "star": int(r.get("star") or 0)})
        if changed:
            world.merge_role_data(role.roleid, loadouts=fixed)
            log.info('LOCAL-EQUIPMENT-PROGRESSION role=%s 装备方案已指向启动包',
                     role.roleid)
    return target


def legend_card_count(role) -> int:
    """传奇改装卡的张数（强化界面显示的那个数字）。

    **只要 `legend_cards` 字段存在就以它为准**（哪怕是 0）。
    原来的写法是「算出来 <= 0 且背包里有卡 id 就补 1」，于是花了卡之后
    又变回 1 —— 界面上那个数字永远锁在 1，改装永远差 3 张。
    只有老存档（根本没这个字段）才按「有卡 = 1 张」兜底一次。
    """
    data = role.data or {}
    if "legend_cards" in data:
        try:
            return max(0, int(data.get("legend_cards") or 0))
        except (TypeError, ValueError):
            return 0
    if LEGEND_CARD_ID in owned_ids(role):
        # 旧存档只把卡本身塞进了背包，没有张数字段
        return 1
    return 0


def grant_login_test_cards(world, role):
    """【v49】测试用：登录时**一次性**补发 N 张传奇改装卡。

    用户要 100 张用来把 5 把龙改到「改·38」。张数只存在
    `role.data["legend_cards"]`，客户端 `PromoteLegend.ChipNum` 只由
    ScLegendCardSync(1048638) 写入，所以必须在 push_lobby_state 发同步
    **之前**调用。marker `legend_cards_grant_v1` 保证只发一次，之后正常
    消耗（改装会扣卡），不会被反复补满而看不出扣卡。
    `CF_TEST_LEGEND_CARDS=0` 可关；想再发一批就换 marker 名。
    """
    try:
        from ..config import CONFIG
        n = int(getattr(CONFIG, "test_legend_cards", 0) or 0)
    except (TypeError, ValueError):
        n = 0
    if n <= 0 or world is None or role is None:
        return role
    fresh = world.role(role.roleid) or role
    # v59：marker 从 v1 换到 v2，这样 v49 时代已经领过 100 张的账号
    # 也会在第一次登录时再补 500 张（用户要 500 张测怒龙改·38）。
    if (fresh.data or {}).get("legend_cards_grant_v2"):
        return fresh
    total = legend_card_count(fresh) + n
    world.merge_role_data(role.roleid, legend_cards=total,
                          legend_cards_grant_v2=1)
    # push_lobby_state 传进来的可能是游离对象，同步回去让紧随其后的
    # send_legend_cards 读到新张数。
    role.data = dict(fresh.data or {})
    (log.info("TEST-LEGEND-CARDS role=%s +%d -> %d 张", role.name, n, total) if log.isEnabledFor(20) else None)
    return fresh


def send_legend_cards(session, role) -> None:
    """推 ScLegendCardSync（客户端唯一写 PromoteLegend.ChipNum 的地方）。"""
    if session is None or getattr(session, "closed", False):
        return
    session.send(SC_LEGEND_CARD_SYNC, cardnum=legend_card_count(role))


def push_legend_cards(world, role) -> bool:
    """给在线的角色补推一次张数（发卡 / 消费之后调用）。"""
    if world is None:
        return False
    # 传进来的 role 可能是 role_named() 读出的游离对象，data 还没合并；
    # push 必须用 world 里那份最新的。
    fresh = world.role(role.roleid) or role
    # 1048638 属于 1048xxx（大厅服）。打战斗时 _online 指向房间服那条连接，
    # 先找 kind="gs"，找不到再退回默认。
    session = world.session_of_role(role.roleid, "gs") \
        or world.session_of_role(role.roleid)
    if session is None or getattr(session, "closed", False):
        return False
    send_legend_cards(session, fresh)
    return True


def grant_items(role, itemids: List[int], world=None) -> List[int]:
    """Add items to the backpack, skipping ones already owned.

    Returns the ids actually added.  Every id is validated first: the client
    indexes `GameData.getItem(id).subType` with no null check.

    Three kinds of items behave differently:

    * 装备（枪/刀/甲/时装，``maxPile == 1``）—— 拥有即止，重复 id 直接跳过
    * 可叠加道具（碎片 9999、弹药 999999，``maxPile > 1``）—— **数量累加**到
      ``role.data["item_counts"]``，id 仍然进 ``pkg_items``（背包列表靠它渲染）
    * ``LEGEND_CARD_ID`` —— 张数记在 ``legend_cards`` 里

    可叠加道具的累加是「赏金/碎片/强化材料」能真正攒下来的前提：之前
    ``grant_items`` 只去重不计数，买 5 个碎片只发 1 个。
    """
    from . import stackable
    # 传进来的 role 可能是 role_named() 读出的游离对象；以 world 里的为准，
    # 否则同一批里既有卡又有枪时会按旧背包去重 / 张数少算。
    target = world.role(role.roleid) if world is not None else None
    target = target or role
    have = set(permanent_ids(target))
    base_cards = legend_card_count(target)   # 必须在写 pkg_items 之前取
    added = []
    cards = 0
    stack_delta: dict = {}
    for iid in itemids:
        iid = int(iid)
        if iid <= 0 or not depot_item(iid):
            continue
        if stackable.stackable(iid):
            # 先记数量，再判断是否需要进背包列表 —— 已拥有也要继续加
            stack_delta[iid] = stack_delta.get(iid, 0) + 1
            if iid in have:
                continue
            have.add(iid)
            added.append(iid)
            continue
        if iid == LEGEND_CARD_ID:
            cards += 1
            if iid not in have:
                have.add(iid)
                added.append(iid)
            continue
        if iid in have:
            continue
        have.add(iid)
        added.append(iid)

    if stack_delta:
        stackable.add_items(target, stack_delta, world)
    if added and world is not None:
        world.merge_role_data(role.roleid, pkg_items=sorted(have))
    if cards:
        total = base_cards + cards
        if world is not None:
            world.merge_role_data(role.roleid, legend_cards=total)
        else:
            role.data = dict(role.data or {}, legend_cards=total)
        (log.info("role %s 收到传奇改装卡 x%s（共 %s 张）", role.name, cards, total) if log.isEnabledFor(20) else None)
        push_legend_cards(world, role)
    return added


def package_items_for(role) -> List[Dict[str, Any]]:
    """Full backpack contents as com.gwebtop.item.Item rows."""
    ids = set(owned_ids(role))
    if not permanent_ids(role):
        ids.update(item["id"] for item in starter_items())
    return package_reward_payload(role, sorted(ids))


def package_reward_payload(role, itemids):
    permanent = set(permanent_ids(role))
    rewards = role.data.get("pve_reward_items") or {}
    from . import premium_ammo
    payload = package_add_payload(itemids, role)
    for row in payload:
        reward = rewards.get(str(row["id"]))
        if row["id"] in premium_ammo.paid_rows():
            row["subcount"] = premium_ammo.count(role, row["id"])
        elif reward:
            row["subcount"] = reward["count"]
            row["desttime"] = 0 if row["id"] in permanent else reward["expiry"]
    return payload


def package_add_payload(itemids: List[int], role=None) -> List[Dict[str, Any]]:
    """The `itemlist` for an ScPackageSync with synctype=1 (add).

    `duration` is the item's CURRENT durability -- see item_durability().

    传了 ``role`` 时 ``subcount`` 用真实数量（``stackable.item_count``）：
    碎片、弹药这类可叠加道具才能显示「×15」而不是「×1」。背包里没有计数
    记录的道具按 1 处理，所以老存档不需要迁移。
    """
    from . import stackable
    out = []
    for iid in itemids:
        if iid in NON_BACKPACK_EQUIPMENT:
            continue
        if not depot_item(iid):
            continue
        count = 1
        if role is not None and stackable.stackable(iid):
            count = max(1, stackable.item_count(role, iid))
        out.append({"id": int(iid), "desttime": 0, "flags": 0,
                    "subcount": int(count), "duration": item_durability(iid)})
    return out


def push_stack_counts(session, role, itemids: List[int]) -> None:
    """ScPackageSync(synctype=2) —— 只更新这些道具的数量。

    客户端 ``DepotManager.Response`` 的 case 2 → ``SynPkgModify``，会覆盖
    ``subcount``。数量减少时它不会弹「获得物品」对话框，正好适合扣碎片。
    """
    if session is None or getattr(session, "closed", False):
        return
    itemids = [int(i) for i in itemids if int(i) > 0]
    if not itemids:
        return
    session.send(SC_PACKAGE_SYNC, synctype=2,
                 itemlist=package_add_payload(itemids, role))


def replace_owned_item(role, oldid: int, newid: int, world=None) -> bool:
    """把背包和所有装备方案里的 oldid 换成 newid（强化升版本用）。

    返回 False 表示背包里根本没有 oldid —— 调用方要把已经扣掉的碎片退回去。
    升版本换的是**另一条 Item**（沙鹰 101101 → 101102），不是改同一条的字段，
    所以装备槽里的 id 也必须跟着换，否则进游戏还是旧枪的数值。
    """
    target = world.role(role.roleid) if world is not None else None
    target = target or role
    ids = [int(i) for i in owned_ids(target)]
    if int(oldid) not in ids:
        return False

    seen = set()
    uniq: List[int] = []
    for iid in ids:
        iid = int(newid) if iid == int(oldid) else iid
        if iid in seen:
            continue
        seen.add(iid)
        uniq.append(iid)
    uniq.sort()
    if world is not None:
        world.merge_role_data(target.roleid, pkg_items=uniq)
    target.data = dict(target.data or {}, pkg_items=uniq)

    rows = loadouts_of(target)
    touched = False
    for row in rows:
        em = row.get("equipmap") or {}
        for slot, iid in list(em.items()):
            if int(iid) == int(oldid):
                em[int(slot)] = int(newid)
                touched = True
        row["equipmap"] = em
        row["star"] = max(
            (int(_item(i).get("star") or 0) for i in em.values()), default=0)
    if touched:
        save_loadouts(target, rows, world)
    return True
