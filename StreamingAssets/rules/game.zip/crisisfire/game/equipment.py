"""装备 / 卸下 / 修复 / 装备方案切换.

Why 仓库 was 只能看不能装备: every one of these is a request/response pair and
none of them were answered.

    DepotManager.SetActiveEquip(tab, pos, weaponid) -> CsEquip(786435)
                                                    <- ScEquipChange(786437)
    CsDeEquip(786436)          -> ScDeEquip(786438)
    CsSetActiveEquip(786434)   -> ScSetActiveEquip(786439)   switch loadout
    CsCreateNewEquipTab(786448)-> ScAddEquipTab(786440)
    CsRepairEquipGroup(786442) -> ScRepairEquipGroupRet(786444)

and why everything showed as 损坏: `com.gwebtop.item.Item.duration` is the
item's CURRENT durability (see equip.item_durability).

The loadout itself lives on the server (`EquipGroup.equips[tab].equipmap`), so
`ScEquipGroup` has to be rebuilt from the role's saved state, otherwise the
equip is forgotten on the next login.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import equip

log = logging.getLogger("crisisfire.equipment")


class ID:
    SC_EQUIP_GROUP = 786433
    CS_SET_ACTIVE_EQUIP = 786434
    CS_EQUIP = 786435
    CS_DE_EQUIP = 786436
    SC_EQUIP_CHANGE = 786437
    SC_DE_EQUIP = 786438
    SC_SET_ACTIVE_EQUIP = 786439
    SC_ADD_EQUIP_TAB = 786440
    CS_REPAIR_EQUIP_GROUP = 786442
    SC_REPAIR_EQUIP_GROUP_RET = 786444

    CS_BUY_ACTOR = 786445
    SC_BUY_ACTOR_RET = 786446
    CS_SET_DEFAULT_ACTOR = 786480
    SC_SET_DEFAULT_ACTOR = 786481
    CS_ATTACH_SUBJOIN = 786483
    SC_ATTACH_SUBJOIN = 786484
    SC_SUBJOIN_LIST = 786485
    SC_ACTOR_CHANGE = 786486

    SC_PACKAGE_SYNC = 983041

    # the client's own item rows carry the durability as `duration`
    DURABLE_POSITIONS = (11, 12, 31, 32, 33, 34, 50)


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


def _role(session: Session):
    if _world is None or not session.roleid:
        return None
    return _world.role(session.roleid)


def _sync_room_member(role) -> None:
    """Keep a room's PlayerInfo snapshot in step with the saved decorations.

    `rooms.Member.subjoins` is a snapshot taken at create/join time; without
    this an attach made while sitting in a room would only reach the client
    on the next room join.  Re-read the role from the World after the write
    (role objects passed in may be stale) and use the existing GS room sync.
    """
    try:
        from . import room_handlers
    except Exception:                     # pragma: no cover - import cycle guard
        (log.debug("room_handlers unavailable; room subjoin sync skipped",
                  exc_info=True) if log.isEnabledFor(10) else None)
        return
    room = room_handlers.MANAGER.room_of(role.roleid)
    if room is None:
        return
    member = room.members.get(role.roleid)
    if member is None:
        return
    member.subjoins = equip.subjoins_of(role)
    room_handlers._sync_room(room)


def _owns(role, weaponid: int) -> bool:
    if weaponid <= 0:
        return True                      # -1 clears the slot
    if weaponid in equip.owned_ids(role):
        return True
    # the starter loadout references weapons that may not be in `pkg_items`
    # until the backpack is first written
    return any(weaponid in l["equipmap"].values()
               for l in equip.loadouts_of(role))


# --------------------------------------------------------------------------
# 装备 / 卸下
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_EQUIP, "equip.CsEquip")
async def on_equip(session: Session, msg: dict) -> None:
    role = _role(session)
    if role is None:
        return
    tab = int(msg.get("tab") or 0)
    position = int(msg.get("position") or 0)
    weaponid = int(msg.get("weaponid") or 0)

    item = equip.item_row(weaponid) if weaponid > 0 else None
    if not _owns(role, weaponid) or (weaponid > 0 and (
        not equip.depot_item(weaponid) or item.get("equipPos") != position
    )):
        (log.info("role %s tried to equip %s which it does not own", role.name,
                 weaponid) if log.isEnabledFor(20) else None)
        # echo back the current state so the UI does not get stuck
        cur = equip.equipped_of(role, tab).get(position, -1)
        session.send(ID.SC_EQUIP_CHANGE, tab=tab, position=position,
                     weaponid=cur)
        return

    # 【v25】tab < 0：客户端「快速装备」——GetItemDialog.onEquip 对护甲/时装
    # （itemType 非 Bullet/Gun/Subjoin）发 SetActiveEquip(-1, item.equipPos, id)。
    # 语义 = 自动装到所有已解锁背包：护甲按只升不降逐个同步，其它装备装到当前
    # active 背包。原实现 tab<0 会被 set_equipped 直接拒绝 → 快速装备无效。
    if tab < 0:
        _changed: List[int] = []
        if weaponid > 0 and int(position) in equip.ARMOR_SLOTS:
            _changed = equip.equip_armor_all_tabs(role, position, weaponid, _world)
        elif weaponid > 0:
            _ai = equip.active_index(role)
            if equip.set_equipped(role, _ai, position, weaponid, _world):
                _changed = [_ai]
        for _t in _changed:
            session.send(ID.SC_EQUIP_CHANGE, tab=_t, position=position,
                         weaponid=weaponid)
        (log.info("role %s quick-equipped %s (slot %s) into tabs %s",
                 role.name,
                 equip.item_name(weaponid) if weaponid > 0 else "(empty)",
                 position, _changed) if log.isEnabledFor(20) else None)
        session.send(ID.SC_EQUIP_GROUP, equipgroup=equip.equip_group_payload(role))
        return

    # 【v24】护甲只升不降：新护甲不比当前背包该槽强时，保留现有（当前 tab
    # 也保护，避免快速装备一件更弱的护甲把好护甲顶掉）。
    if weaponid > 0 and int(position) in equip.ARMOR_SLOTS:
        _cur = int(equip.equipped_of(role, tab).get(int(position)) or 0)
        if equip.armor_ac_of(_cur) > equip.armor_ac_of(weaponid):
            session.send(ID.SC_EQUIP_CHANGE, tab=tab, position=position,
                         weaponid=_cur if _cur > 0 else -1)
            return

    if not equip.set_equipped(role, tab, position, weaponid, _world):
        return

    (log.info("role %s equipped %s into tab %s slot %s (%s)", role.name,
             equip.item_name(weaponid) if weaponid > 0 else "(empty)",
             tab, position, equip.equipped_of(role, tab)) if log.isEnabledFor(20) else None)

    session.send(ID.SC_EQUIP_CHANGE, tab=tab, position=position,
                 weaponid=weaponid)
    # 【v24】护甲：同一件护甲同步进所有已解锁背包（只升不降）。快速装备原来
    # 只改当前 tab，其它背包跟不上，用户得逐个整备页手动装。
    if weaponid > 0:
        for _t in equip.equip_armor_all_tabs(role, position, weaponid, _world):
            session.send(ID.SC_EQUIP_CHANGE, tab=_t, position=position,
                         weaponid=weaponid)
    # the score shown next to a loadout is derived from its items
    session.send(ID.SC_EQUIP_GROUP, equipgroup=equip.equip_group_payload(role))


@ROUTER.register(ID.CS_DE_EQUIP, "equip.CsDeEquip")
async def on_de_equip(session: Session, msg: dict) -> None:
    role = _role(session)
    if role is None:
        return
    tab = int(msg.get("tab") or 0)
    position = int(msg.get("position") or 0)

    if not equip.set_equipped(role, tab, position, -1, _world):
        return
    (log.info("role %s cleared tab %s slot %s", role.name, tab, position) if log.isEnabledFor(20) else None)
    session.send(ID.SC_DE_EQUIP, tab=tab, position=position)
    session.send(ID.SC_EQUIP_GROUP, equipgroup=equip.equip_group_payload(role))


@ROUTER.register(ID.CS_SET_ACTIVE_EQUIP, "equip.CsSetActiveEquip")
async def on_set_active(session: Session, msg: dict) -> None:
    role = _role(session)
    if role is None:
        return
    index = max(0, int(msg.get("activeindex") or 0))
    if _world is not None:
        _world.merge_role_data(role.roleid, active_equip=index)
    (log.info("role %s switched to loadout %s", role.name, index) if log.isEnabledFor(20) else None)
    session.send(ID.SC_SET_ACTIVE_EQUIP, activeindex=index)


@ROUTER.register(786448, "equip.CsCreateNewEquipTab")
async def on_new_tab(session: Session, msg: dict) -> None:
    """Buying an extra loadout slot (Price 1 = 50 gem)."""
    role = _role(session)
    if role is None:
        return
    rows = equip.loadouts_of(role)
    # 客户端 `GetEquipBar.NextGroupGem` = GetEquipGroupGem(EquipCount + 1)，
    # 读的是 **EquipSetPrice** 的递增价（第2个60 / 第3个180 / … / 第10个1200）。
    # 原来服务端死读 Price.id=1 的 50，两边价格对不上；而且扣完钱从不推
    # ScAcountSync，客户端顶栏钻石数纹丝不动 —— 表现就是「买栏位不扣钻石」。
    price_id = len(rows) + 1
    cost = next((int(r.get("gem") or 0) for r in gamedata.table("EquipSetPrice")
                 if int(r.get("id") or 0) == price_id), 0)
    if cost <= 0:
        cost = next((int(r.get("gem") or 0) for r in gamedata.table("Price")
                     if int(r.get("id") or 0) == 1), 50)
    if role.gold < cost:
        (log.info("role %s cannot afford a new loadout (need %s gem, has %s)",
                 role.name, cost, role.gold) if log.isEnabledFor(20) else None)
        session.send(ID.SC_EQUIP_GROUP, equipgroup=equip.equip_group_payload(role))
        return
    role.gold -= cost
    _world.update_role(role.roleid, gold=role.gold)
    # 【v24】新背包继承已解锁背包里「每槽最强」的护甲，而不是空/默认最低。
    _new_map = equip.inherit_armor_equipmap(rows)
    _new_star = max((int(equip.item_row(i).get("star") or 0)
                     for i in _new_map.values()), default=0)
    rows.append({"equipmap": _new_map, "star": _new_star})
    equip.save_loadouts(role, rows, _world)
    (log.info("role %s bought loadout slot %d for %s gem (balance %s)",
             role.name, len(rows) - 1, cost, role.gold) if log.isEnabledFor(20) else None)
    # 必须推余额，否则客户端 header 上的钻石数不会变
    session.send(983043, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    session.send(ID.SC_ADD_EQUIP_TAB,
                 equips={"equipmap": _new_map, "star": _new_star})
    session.send(ID.SC_EQUIP_GROUP, equipgroup=equip.equip_group_payload(role))


# --------------------------------------------------------------------------
# 修复
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_REPAIR_EQUIP_GROUP, "equip.CsRepairEquipGroup")
async def on_repair(session: Session, msg: dict) -> None:
    """Repair every item in one loadout.

    `Price` has no repair row, so the cost comes from the Item table's
    `repairCost`, scaled by how worn the item is.
    """
    role = _role(session)
    if role is None:
        return
    tab = int(msg.get("id") or 0)
    rows = equip.loadouts_of(role)
    if tab < 0 or tab >= len(rows):
        session.send(ID.SC_REPAIR_EQUIP_GROUP_RET, id=tab, retcode=1, cost=0)
        return

    cost = 0
    for iid in rows[tab]["equipmap"].values():
        row = equip.item_row(iid)
        cost += int(row.get("repairCost") or 0)
    cost = max(0, cost)

    if cost > role.money:
        (log.info("role %s needs %s 钞票 to repair tab %s (has %s)",
                 role.name, cost, tab, role.money) if log.isEnabledFor(20) else None)
        session.send(ID.SC_REPAIR_EQUIP_GROUP_RET, id=tab, retcode=1,
                     cost=cost)
        return

    role.money -= cost
    _world.update_role(role.roleid, money=role.money)

    # durability is carried in Item.duration, so push a full-durability row
    # for every item in the loadout
    rows[tab]["star"] = rows[tab].get("star", 0)
    equip.save_loadouts(role, rows, _world)
    payload = equip.package_add_payload(list(rows[tab]["equipmap"].values()), role)

    (log.info("role %s repaired loadout %s for %s 钞票 (%d items)",
             role.name, tab, cost, len(payload)) if log.isEnabledFor(20) else None)
    session.send(ID.SC_REPAIR_EQUIP_GROUP_RET, id=tab, retcode=0, cost=cost)
    if payload:
        from . import tasks
        tasks.record(role, task_type=tasks.REPAIR, session=session)
        # synctype=2 (modify) refreshes the durability of existing entries
        session.send(ID.SC_PACKAGE_SYNC, synctype=2, itemlist=payload)
    session.send(983043, gold=role.gold, money=role.money, diamond=role.diamond)
    from .handlers import _property_of
    session.send(1114117, roleid=role.roleid, property=_property_of(role))


# --------------------------------------------------------------------------
# 角色 (characters)
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_SET_DEFAULT_ACTOR, "equip.CsSetDefaultActor")
async def on_set_default_actor(session: Session, msg: dict) -> None:
    """Pick the character used on each side.

    `EquipManager.DoChooseActor(policeid, terristid, bioid)` sets all three at
    once, so the reply always carries the full triple.  The camp of the chosen
    id decides which slot moves -- echoing the same id into both slots would
    hand the terrist side a police actor.
    """
    role = _role(session)
    if role is None:
        return
    actorid = int(msg.get("actorid") or 0)

    camp = equip.set_default_actor(role, actorid, _world)
    if camp is None:
        (log.info("role %s cannot switch to actor %s (unknown or not owned)",
                 role.name, actorid) if log.isEnabledFor(20) else None)
    else:
        (log.info("role %s chose %s (%s) as its %s character", role.name,
                 equip.actor_name(actorid), actorid, equip.CAMP_NAME.get(camp)) if log.isEnabledFor(20) else None)

    payload = equip.equip_group_payload(role)
    session.send(ID.SC_SET_DEFAULT_ACTOR,
                 policeid=payload["curpoliceactor"],
                 terristid=payload["curterristactor"],
                 bioid=payload["curbioactor"])
    # the loadout panel shows the character portrait, so refresh it too
    session.send(ID.SC_EQUIP_GROUP, equipgroup=payload)


@ROUTER.register(ID.CS_BUY_ACTOR, "equip.CsBuyActor")
async def on_buy_actor(session: Session, msg: dict) -> None:
    """Buy a character.  Each Role row carries its own price."""
    role = _role(session)
    if role is None:
        return
    actorid = int(msg.get("id") or 0)
    code = equip.buy_actor(role, actorid, _world)

    if code == 0:
        (log.info("role %s bought character %s (%s) for %s", role.name,
                 equip.actor_name(actorid), actorid,
                 equip.actor_price(actorid)) if log.isEnabledFor(20) else None)
        session.send(ID.SC_BUY_ACTOR_RET, id=actorid, desttime=0, retcode=0)
        # EquipManager.Response(ScBuyActorRet) calls SetDefaultActor(id) on
        # success, so the owned list has to arrive as well
        session.send(ID.SC_ACTOR_CHANGE, id=actorid, desttime=0)
        session.send(ID.SC_EQUIP_GROUP,
                     equipgroup=equip.equip_group_payload(role))
        session.send(983043, gold=role.gold, money=role.money,
                     diamond=role.diamond)
        from .handlers import _property_of
        session.send(1114117, roleid=role.roleid, property=_property_of(role))
        return

    (log.info("role %s could not buy character %s (code %s)", role.name,
             actorid, code) if log.isEnabledFor(20) else None)
    session.send(ID.SC_BUY_ACTOR_RET, id=actorid, desttime=0, retcode=code)


@ROUTER.register(ID.CS_ATTACH_SUBJOIN, "equip.CsAttachSubjoin")
async def on_attach_subjoin(session: Session, msg: dict) -> None:
    """Wear/remove a decoration; the state has to outlive this connection.

    The old handler only echoed ScAttachSubjoin, so the client (and the room's
    PlayerInfo) looked right until relogin, then lost every decoration.  The
    authoritative copy now lives in role.data["subjoins"] and is replayed at
    login through ScSubjoinList(786485) -- the only writer of
    DepotManager.decorations (DepotManager.cs:132..149).
    """
    role = _role(session)
    if role is None:
        return
    pos = int(msg.get("pos") or 0)
    actor = int(msg.get("actor") or 0)
    subjoinid = int(msg.get("subjoinid") or 0)
    if subjoinid == 0:
        # -1 unloads; 0 is neither a real Subjoin id nor the unload sentinel
        (log.info("role %s sent subjoinid=0 for pos %s actor %s; ignored",
                 role.name, pos, actor) if log.isEnabledFor(20) else None)
        return

    if not equip.set_subjoin(role, actor, pos, subjoinid, _world):
        (log.info("role %s tried to attach subjoin %s at pos %s to actor %s "
                 "(rejected)", role.name, subjoinid, pos, actor) if log.isEnabledFor(20) else None)
        return

    (log.info("role %s attached subjoin %s at pos %s to actor %s",
             role.name, subjoinid, pos, actor) if log.isEnabledFor(20) else None)
    session.send(ID.SC_ATTACH_SUBJOIN, pos=pos, actor=actor,
                 subjoinid=subjoinid)
    # 落盘后的权威值从 World 回读；房间成员若已存在，立即刷新它的
    # PlayerInfo 快照并走既有的 GS ScSyncRoomInfo 广播。
    fresh = _world.role(role.roleid) if _world is not None else role
    _sync_room_member(fresh or role)
