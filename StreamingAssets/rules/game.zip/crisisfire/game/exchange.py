"""幸运积分（兑换券）与免费转盘次数.

两种「票」是不同的东西，协议也是两条：

    1048595 ScExchangeTicketSync  ticketnum   兑换券余额 -> 兑换商店用
    1048596 ScLuckyTicketSync     ticketnum   免费转盘次数 -> Normal 盘直接抵扣花费

    1048608 CsExchange            exchangeid  客户端请求兑换
    1048609 ScExchange            exchangeid  服务端确认
    1048610 ScExchangeBrd         rolename, exchangeid   全服播报

客户端侧（ActivityManager）：

    public static int exchangeTickets = 0;      // 兑换券
    public static int luckyTickets = 0;         // 免费次数

    public static void GoExchange(LotteryExchange exchange)
    {
        if (exchangeTickets < exchange.coupon) { Callboard.Show(411); return; }  // 积分不足
        GsServer.Instance.Send(new CsExchange(exchange.id));
    }

    // RoulettePanel：免费次数直接从花费里扣
    int luckyTickets = ActivityManager.luckyTickets;
    if (plateType == RoulettePlate.Type.Normal && luckyTickets > 0) { ... }
    num -= ActivityManager.luckyTickets;

    // ScExchangeTicketSync.process() -> ExchangeTicketSync(ticketnum)
    // ScLuckyTicketSync.process()    -> LuckyTicketSync(ticketnum)

`LotteryExchange` 表（14 行）: id, coupon, icon, gold, honor, exp, item, itemNum, broadcast

    id   coupon    奖励
    1    10000  -> gold 40000
    2    1000   -> gold 4000
    3    100    -> gold 400
    4    10000  -> honor 4000
    ...
    7    10000  -> item 11004
    8    1000   -> item 110101

**注意**：`GemLottery.coupon` 这个字段 14 行全是 0 —— 这个版本的转盘不直接给兑换券，
所以兑换券的来源只能由服务端决定（见 `COUPON_PER_SPIN`）。
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.exchange")


class ID:
    SC_EXCHANGE_TICKET_SYNC = 1048595
    SC_LUCKY_TICKET_SYNC = 1048596
    CS_EXCHANGE = 1048608
    SC_EXCHANGE = 1048609
    SC_EXCHANGE_BRD = 1048610

    SC_PACKAGE_SYNC = 983041
    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117


# 每次转动给多少兑换券。
# `GemLottery.coupon` 全表为 0，配置里没有依据，所以这是个可调的服务端策略。
# Text 20001 只说「转动转盘同时可获得幸运积分，积分可兑换各种奖励」。
COUPON_PER_SPIN = 20


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# 余额
# --------------------------------------------------------------------------
def tickets_of(role) -> int:
    try:
        return max(0, int((role.data or {}).get("exchange_tickets") or 0))
    except (TypeError, ValueError):
        return 0


def lucky_of(role) -> int:
    try:
        return max(0, int((role.data or {}).get("lucky_tickets") or 0))
    except (TypeError, ValueError):
        return 0


def add_tickets(role, n: int) -> int:
    if _world is None or not n:
        return tickets_of(role)
    total = max(0, tickets_of(role) + int(n))
    _world.merge_role_data(role.roleid, exchange_tickets=total)
    return total


def add_lucky(role, n: int) -> int:
    if _world is None or not n:
        return lucky_of(role)
    total = max(0, lucky_of(role) + int(n))
    _world.merge_role_data(role.roleid, lucky_tickets=total)
    return total


def send_tickets(session: Session, role) -> None:
    """两条 Sync 都要发 —— 客户端不会来要，只能服务端主动推。"""
    session.send(ID.SC_EXCHANGE_TICKET_SYNC, ticketnum=tickets_of(role))
    session.send(ID.SC_LUCKY_TICKET_SYNC, ticketnum=lucky_of(role))


def consume_lucky(role) -> bool:
    """有免费次数就消耗一次并返回 True。"""
    if lucky_of(role) <= 0:
        return False
    add_lucky(role, -1)
    return True


# --------------------------------------------------------------------------
# 兑换
# --------------------------------------------------------------------------
def exchange_rows() -> Dict[int, Dict[str, Any]]:
    out: Dict[int, Dict[str, Any]] = {}
    for r in gamedata.table("LotteryExchange"):
        try:
            out[int(r.get("id") or 0)] = r
        except (TypeError, ValueError):
            continue
    return out


def _i(row: Dict[str, Any], key: str) -> int:
    try:
        return max(0, int(row.get(key) or 0))
    except (TypeError, ValueError):
        return 0


@ROUTER.register(ID.CS_EXCHANGE, "shop.CsExchange")
async def on_exchange(session: Session, msg: dict) -> None:
    """用兑换券换奖励。

    客户端在本地就会拦「积分不足」（Callboard.Show(411)），但服务端必须自己
    再校验一遍 —— 否则改个客户端就能白拿。
    """
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    eid = int(msg.get("exchangeid") or 0)
    row = exchange_rows().get(eid)
    if row is None:
        (log.info("role %s 请求了不存在的兑换档位 %s", role.name, eid) if log.isEnabledFor(20) else None)
        send_tickets(session, role)
        return
    cost = _i(row, "coupon")
    if tickets_of(role) < cost:
        # 对齐 Callboard.Show(411)「您的幸运转盘积分不足」
        (log.info("role %s 兑换券不足: %s < %s", role.name, tickets_of(role), cost) if log.isEnabledFor(20) else None)
        send_tickets(session, role)
        return

    add_tickets(role, -cost)
    got = _grant(role, row)
    session.send(ID.SC_EXCHANGE, exchangeid=eid)
    send_tickets(session, role)
    (log.info("role %s 兑换 %s（-券%s）-> %s", role.name, eid, cost, got) if log.isEnabledFor(20) else None)

    if got.get("added"):
        from . import equip
        session.send(ID.SC_PACKAGE_SYNC, synctype=1,
                     itemlist=equip.package_add_payload(got["added"], role))
    if got.get("money"):
        session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                     diamond=role.diamond)
        from .handlers import _property_of
        session.send(ID.SC_USER_INFO, roleid=role.roleid,
                     property=_property_of(role))
    if got.get("ranked"):
        from .handlers import push_lobby_state
        push_lobby_state(session, role)

    # broadcast=1 的档位全服播报（Text 10003）
    if _i(row, "broadcast") > 0:
        info = {"id": eid, "value": cost, "rolename": role.name}
        for s in _world.sessions():
            if s.closed or not s.roleid:
                continue
            try:
                s.send(ID.SC_EXCHANGE_BRD, rolename=role.name, exchangeid=eid)
            except Exception:
                (log.debug("兑换播报失败 -> %s", s, exc_info=True) if log.isEnabledFor(10) else None)


def _grant(role, row: Dict[str, Any]) -> Dict[str, Any]:
    """发兑换奖励。字段：gold / honor / exp / item + itemNum。"""
    gold, honor, exp = _i(row, "gold"), _i(row, "honor"), _i(row, "exp")
    itemid, itemnum = _i(row, "item"), max(1, _i(row, "itemNum"))
    out: Dict[str, Any] = {"money": False, "added": [], "ranked": False}

    if gold or honor:
        from .wallet import change
        change(_world,role,coins=gold,honor=honor)
        out["money"] = True
    if exp:
        from . import leveling
        old_rank, new_rank = leveling.apply_exp(_world, role, exp)
        out["ranked"] = new_rank != old_rank
    if itemid:
        from . import equip
        out["added"] = equip.grant_items(role, [itemid] * itemnum, _world)
        out["money"] = True
        # 【v46】兑换的是**整枪**且已经拥有时，`grant_items` 会直接跳过，
        # 等于花 1000~10000 积分买了个空。按抽卡的同一口径转成碎片
        # （Part.outPutParts），让「积分兑换」永远按文本兑现。
        if not out["added"]:
            from . import gacha as _gacha
            pc = _gacha._dup_piece(itemid)
            if pc:
                out["added"] = equip.grant_items(
                    role, [int(pc[0])] * int(pc[1]), _world)
    return out


# --------------------------------------------------------------------------
# 充值页面 / 钻石兑换荣誉（离线版：点按钮直接发，不接第三方支付）
#
#   CsAddCashReq(1048580) {cashitemid}  -> ScAddCashRes(1048582) {result, cashitemid, orderid}
#       RechargeManager.Recharge(i) 发 RechargeGem.id（正数）
#       ActivityManager.GoBuyCard   发 -Card.id（负数，活动卡）
#   CsRechargeHonor(1048583) {rechargeid} -> ScRechargeHonor(1048584) {rechargeid, usegold, honor}
#       RechargeManager.ExchangeHonor(i) 发 RechargeHonor.id
#
# 原来这两个协议服务端**完全没注册**，点按钮没有任何回包，界面就一直
# 停在原处，看起来像「充值/兑换功能不存在」。
# --------------------------------------------------------------------------
CS_ADD_CASH_REQ = 1048580
SC_ADD_CASH_RES = 1048582
CS_RECHARGE_HONOR = 1048583
SC_RECHARGE_HONOR = 1048584


def _row_by_id(table: str, rid: int) -> Optional[Dict[str, Any]]:
    try:
        for r in gamedata.table(table) or []:
            if int(r.get("id") or 0) == int(rid):
                return r
    except (TypeError, ValueError):
        pass
    return None


def _push_account(session: Session, role) -> None:
    if _world is not None:
        _world.update_role(role.roleid, gold=role.gold, money=role.money,
                           diamond=role.diamond)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)


@ROUTER.register(CS_ADD_CASH_REQ, "shop.CsAddCashReq")
async def on_add_cash(session: Session, msg: dict) -> None:
    """【抖M版】充值通道关闭 —— 只回失败，不发任何钻石。

    原实现是「点一下充值档位就 +gem」（离线版不接第三方支付），
    抖M版把这个白给渠道砍掉：客户端会弹充值失败，余额不变。
    """
    cashid = int(msg.get("cashitemid") or 0)
    session.send(SC_ADD_CASH_RES, result=1, cashitemid=cashid, orderid="")
    log.info("role %s 尝试充值档位 %s —— 抖M版已关闭", session.roleid, cashid)


@ROUTER.register(CS_RECHARGE_HONOR, "shop.CsRechargeHonor")
async def on_recharge_honor(session: Session, msg: dict) -> None:
    """钻石兑换荣誉：按 RechargeHonor 表扣钻石、加荣誉。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    rid = int(msg.get("rechargeid") or 0)
    row = _row_by_id("RechargeHonor", rid) or {}
    usegold = int(row.get("gem") or 0)
    honor = int(row.get("honor") or 0) + int(row.get("giftHonor") or 0)
    if usegold <= 0 or honor <= 0:
        session.send(SC_RECHARGE_HONOR, rechargeid=rid, usegold=0, honor=0)
        return
    if role.gold < usegold:
        (log.info("role %s 钻石不足：兑换 %s 需要 %s，只有 %s",
                 role.name, rid, usegold, role.gold) if log.isEnabledFor(20) else None)
        session.send(SC_RECHARGE_HONOR, rechargeid=rid, usegold=0, honor=0)
        return
    role.gold -= usegold
    role.diamond += honor       # userInfo.diamond = GetHornor() = 荣誉
    _push_account(session, role)
    session.send(SC_RECHARGE_HONOR, rechargeid=rid, usegold=usegold,
                 honor=honor)
    (log.info("role %s 兑换档位 %s -> -%s 钻石 +%s 荣誉", role.name, rid,
             usegold, honor) if log.isEnabledFor(20) else None)
