"""好友 / 黑名单 / 请求 / 点赞.

`com.gwebtop.friend` is a push-driven protocol set -- there is no
`CsFriendList`, the server volunteers `ScFriendList` on login and after every
change:

    CS -> server                     server -> CS
    Request(917505)      targetid    ScRequestRet(917526)        errcode
    RequestByName(917516) name       ScRequest(917522)           targetid, info
    CsRequestConfirmed   targetid    ScRequestConfirmed(917507)  targetid, info,
    CsRequestRefused     targetid    ScRequestRefused(917523)    targetid, info
    AddBlackList         roleid      AddedBlackList(917513)      roleid, info
    RemoveBlackList      roleid      ScFriendList(917509)
    CsRequestDetailInfo  roleid      ScFriendInfo(917515)        roleid, property
    CsPraise             targetid    ScPraiseRet(917521)         targetid, retcode
                                     ScPraise(917518)            fromid, basicinfo
                                     ScSyncPraiseList(917519)
                                     ScFriendStatus(917524)      roleid, status

`ScRequestRet.errcode` maps straight onto TextPool:

    0 -> 114 成功发送好友请求        1 -> 143 没有检测到该信息的玩家
    2 -> 141 对方已是您的好友        3 -> 142 您在对方的黑名单中
    4 -> 140 已向对方发送请求，请等待回应   5 -> 145 您的好友数已达上限

`ScFriendStatus.status == 0` means **online** (0 = online, non-zero = offline):

    // FriendManager.OnFriendStatusChanged
    bool flag = status.status == 0;
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.friends")


class ID:
    REQUEST = 917505                  # CS 加好友（按 id）
    SC_REQUEST_CONFIRMED = 917507
    CS_REQUEST_REFUSED = 917508
    SC_FRIEND_LIST = 917509
    SC_REQUEST_LIST = 917510
    CS_REQUEST_DETAIL_INFO = 917511
    ADD_BLACKLIST = 917512
    ADDED_BLACKLIST = 917513
    REMOVE_BLACKLIST = 917514
    SC_FRIEND_INFO = 917515
    REQUEST_BY_NAME = 917516
    CS_PRAISE = 917517
    SC_PRAISE = 917518
    SC_SYNC_PRAISE_LIST = 917519
    CS_REQUEST_CONFIRMED = 917520
    SC_PRAISE_RET = 917521
    SC_REQUEST = 917522
    SC_REQUEST_REFUSED = 917523
    SC_FRIEND_STATUS = 917524
    SC_FRIEND_FIGHT_INFO = 917525
    SC_REQUEST_RET = 917526
    SC_OFFLINE_FRIEND_MESSAGE = 917527

    SC_USER_INFO = 1114117


# ScRequestRet.errcode
ERR_OK = 0
ERR_NO_PLAYER = 1
ERR_ALREADY_FRIEND = 2
ERR_BLACKLISTED = 3
ERR_DUPLICATE = 4
ERR_FRIEND_FULL = 5

MAX_FRIENDS = 50

# ScFriendStatus.status -- 0 means ONLINE
STATUS_ONLINE = 0
STATUS_OFFLINE = 1


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# Property (com.gwebtop.user.Property) -- must match handlers._property_of
# --------------------------------------------------------------------------
def _property_of(role) -> Dict[str, Any]:
    from .handlers import _property_of as inner
    return inner(role)


def _basic_of(role) -> Dict[str, Any]:
    return {"rank": int(role.level or 1), "exp": int(role.exp or 0),
            "name": role.name, "iconid": int(role.iconid or 0)}


def _fightinfo_of(role) -> Dict[str, Any]:
    """FightInfo: what a friend is doing right now."""
    from . import room_handlers
    room = room_handlers.MANAGER.room_of(role.roleid)
    if room is None:
        return {"fighttype": 0, "levelid": 0}
    return {"fighttype": 1 if room.started else 0, "levelid": int(room.levelid)}


def _online(roleid: int) -> bool:
    return _world is not None and _world.session_of_role(roleid) is not None


# --------------------------------------------------------------------------
# push helpers
# --------------------------------------------------------------------------
def send_friend_list(session: Session, role) -> None:
    """ScFriendList -- the client has no way to ask for it, so we volunteer."""
    friendlist: Dict[int, Dict[str, Any]] = {}
    online: List[int] = []
    fights: Dict[int, Dict[str, Any]] = {}
    for fid in _world.friends_of(role.roleid):
        f = _world.role(fid)
        if f is None:
            continue
        friendlist[fid] = _property_of(f)
        if _online(fid):
            online.append(fid)
            fi = _fightinfo_of(f)
            if fi["fighttype"]:
                fights[fid] = fi

    blacklist: Dict[int, Dict[str, Any]] = {}
    for bid in _world.blacklist_of(role.roleid):
        b = _world.role(bid)
        if b is not None:
            blacklist[bid] = _property_of(b)

    session.send(ID.SC_FRIEND_LIST, friendlist=friendlist, blacklist=blacklist,
                 onlinefriends=online, fightfriends=fights)
    (log.debug("ScFriendList -> %s: %d friends, %d online, %d black",
              role.name, len(friendlist), len(online), len(blacklist)) if log.isEnabledFor(10) else None)


def send_request_list(session: Session, role) -> None:
    requests: Dict[int, Dict[str, Any]] = {}
    for rid in _world.requests_to(role.roleid):
        r = _world.role(rid)
        if r is not None:
            requests[rid] = _property_of(r)
    session.send(ID.SC_REQUEST_LIST, requests=requests)


def send_praise_list(session: Session, role) -> None:
    """ScSyncPraiseList -- praise other players gave you."""
    rows = (role.data or {}).get("praises") or []
    praises = []
    for r in rows[-50:]:
        if not isinstance(r, dict):
            continue
        from_id = int(r.get("fromid") or 0)
        who = _world.role(from_id) if from_id else None
        praises.append({
            "fromid": from_id,
            "basicinfo": _basic_of(who) if who is not None else
                         {"rank": 1, "exp": 0, "name": str(r.get("name") or ""),
                          "iconid": 0},
            "time": int(r.get("time") or 0),
        })
    session.send(ID.SC_SYNC_PRAISE_LIST, priases=praises,
                 prasedcount=int((role.data or {}).get("praised_count") or 0))


def push_all(session: Session, role) -> None:
    """Everything the friend window needs, in one go (called on login)."""
    send_friend_list(session, role)
    send_request_list(session, role)
    send_praise_list(session, role)


def broadcast_status(roleid: int, online: bool) -> None:
    """Tell this role's friends that it came online / went offline."""
    if _world is None:
        return
    status = STATUS_ONLINE if online else STATUS_OFFLINE
    for fid in _world.friends_of(roleid):
        s = _world.session_of_role(fid)
        if s is not None:
            s.send(ID.SC_FRIEND_STATUS, roleid=roleid, status=status)


# --------------------------------------------------------------------------
# 加好友
# --------------------------------------------------------------------------
async def _request(session: Session, targetid: int) -> None:
    role = _world.role(session.roleid)
    if role is None:
        return
    target = _world.role(targetid)

    if target is None or targetid == role.roleid:
        session.send(ID.SC_REQUEST_RET, errcode=ERR_NO_PLAYER)
        return
    if _world.has_blacklisted(targetid, role.roleid):
        # 对方把我拉黑了
        session.send(ID.SC_REQUEST_RET, errcode=ERR_BLACKLISTED)
        return
    if _world.are_friends(role.roleid, targetid):
        session.send(ID.SC_REQUEST_RET, errcode=ERR_ALREADY_FRIEND)
        return
    if _world.has_request(role.roleid, targetid):
        session.send(ID.SC_REQUEST_RET, errcode=ERR_DUPLICATE)
        return
    # 对方已经请求过我 —— 直接互加
    if _world.has_request(targetid, role.roleid):
        _world.add_friend(role.roleid, targetid)
        _world.drop_request(targetid, role.roleid)
        session.send(ID.SC_REQUEST_RET, errcode=ERR_OK)
        _notify_confirmed(role, target)
        return
    if len(_world.friends_of(role.roleid)) >= MAX_FRIENDS:
        session.send(ID.SC_REQUEST_RET, errcode=ERR_FRIEND_FULL)
        return

    _world.add_request(role.roleid, targetid)
    session.send(ID.SC_REQUEST_RET, errcode=ERR_OK)
    (log.info("role %s(%s) -> friend request -> %s(%s)", role.name, role.roleid,
             target.name, targetid) if log.isEnabledFor(20) else None)

    ts = _world.session_of_role(targetid)
    if ts is not None:
        ts.send(ID.SC_REQUEST, targetid=role.roleid, info=_property_of(role))
        # 客户端 FriendManager.Request 会自己去重，多发一份列表更稳
        send_request_list(ts, target)


def _notify_confirmed(role, target) -> None:
    """Both sides refresh: ScRequestConfirmed + a new ScFriendList."""
    for me, other in ((role, target), (target, role)):
        s = _world.session_of_role(me.roleid)
        if s is None:
            continue
        s.send(ID.SC_REQUEST_CONFIRMED, targetid=other.roleid,
               info=_property_of(other),
               onlinestatus=STATUS_ONLINE if _online(other.roleid)
               else STATUS_OFFLINE,
               fightinfo=_fightinfo_of(other))
        send_friend_list(s, me)
        send_request_list(s, me)


@ROUTER.register(ID.REQUEST, "friend.Request")
async def on_request(session: Session, msg: dict) -> None:
    await _request(session, int(msg.get("targetid") or 0))


@ROUTER.register(ID.REQUEST_BY_NAME, "friend.RequestByName")
async def on_request_by_name(session: Session, msg: dict) -> None:
    name = str(msg.get("name") or "").strip()
    target = _world.role_named(name) if name else None
    if target is None:
        session.send(ID.SC_REQUEST_RET, errcode=ERR_NO_PLAYER)
        return
    await _request(session, target.roleid)


@ROUTER.register(ID.CS_REQUEST_CONFIRMED, "friend.CsRequestConfirmed")
async def on_confirmed(session: Session, msg: dict) -> None:
    """同意某人的好友请求."""
    role = _world.role(session.roleid)
    fromid = int(msg.get("targetid") or 0)
    other = _world.role(fromid)
    if role is None or other is None:
        session.send(ID.SC_REQUEST_RET, errcode=ERR_NO_PLAYER)
        return
    if not _world.has_request(fromid, role.roleid):
        session.send(ID.SC_REQUEST_RET, errcode=ERR_NO_PLAYER)
        return
    _world.add_friend(role.roleid, fromid)
    _world.drop_request(fromid, role.roleid)
    (log.info("role %s accepted friend request from %s", role.name, other.name) if log.isEnabledFor(20) else None)
    _notify_confirmed(role, other)


@ROUTER.register(ID.CS_REQUEST_REFUSED, "friend.CsRequestRefused")
async def on_refused(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid)
    fromid = int(msg.get("targetid") or 0)
    other = _world.role(fromid)
    if role is None or other is None:
        return
    _world.drop_request(fromid, role.roleid)
    (log.info("role %s refused friend request from %s", role.name, other.name) if log.isEnabledFor(20) else None)
    ts = _world.session_of_role(fromid)
    if ts is not None:
        ts.send(ID.SC_REQUEST_REFUSED, targetid=role.roleid,
                info=_property_of(role))
    send_request_list(session, role)


# --------------------------------------------------------------------------
# 黑名单
# --------------------------------------------------------------------------
@ROUTER.register(ID.ADD_BLACKLIST, "friend.AddBlackList")
async def on_add_blacklist(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid)
    other = _world.role(int(msg.get("roleid") or 0))
    if role is None or other is None or other.roleid == role.roleid:
        return
    _world.add_blacklist(role.roleid, other.roleid)
    (log.info("role %s blacklisted %s", role.name, other.name) if log.isEnabledFor(20) else None)
    session.send(ID.ADDED_BLACKLIST, roleid=other.roleid,
                 info=_property_of(other))
    send_friend_list(session, role)


@ROUTER.register(ID.REMOVE_BLACKLIST, "friend.RemoveBlackList")
async def on_remove_blacklist(session: Session, msg: dict) -> None:
    """把某人移出黑名单.

    `RemoveBlackList(917514)` is a **bidirectional** message -- the client sends
    it AND its process() treats an incoming copy as the server's confirmation:

        // RemoveBlackList.process()
        FriendManager.RemoveBlackList(this);
        // FriendManager
        public static void RemoveBlackList(RemoveBlackList m)
        {
            for (...) if (blackInfos[i].roleid == m.roleid)
            {
                blackInfos.RemoveAt(i);
                onBlackListChanged?.Invoke(arg, false);   // <- 界面靠这个刷新
                break;
            }
        }

    Adding works because it answers with a *different* class (`AddedBlackList`
    -> FriendManager.Response).  Removing had no answer at all: the server
    deleted the row and sent a fresh ScFriendList, but ScFriendList only
    rebuilds `blackInfos` and fires `onFriendInfoInitialized` -- the blacklist
    window listens to `onBlackListChanged`, so the entry stayed on screen and
    the player kept pressing the button (19 times in the log).

    So echo the same message back.
    """
    role = _world.role(session.roleid)
    if role is None:
        return
    target = int(msg.get("roleid") or 0)
    _world.remove_blacklist(role.roleid, target)
    (log.info("role %s removed %s from the blacklist", role.name, target) if log.isEnabledFor(20) else None)
    # 回执：客户端据此从 blackInfos 移除并刷新界面
    session.send(ID.REMOVE_BLACKLIST, roleid=target)
    send_friend_list(session, role)


@ROUTER.register(ID.CS_REQUEST_DETAIL_INFO, "friend.CsRequestDetailInfo")
async def on_detail(session: Session, msg: dict) -> None:
    """查看某人资料（好友窗口点名字）。"""
    target = _world.role(int(msg.get("roleid") or 0))
    if target is None:
        return
    session.send(ID.SC_FRIEND_INFO, roleid=target.roleid,
                 property=_property_of(target))
    session.send(ID.SC_FRIEND_FIGHT_INFO, roleid=target.roleid,
                 fightinfo=_fightinfo_of(target))


# --------------------------------------------------------------------------
# 点赞
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_PRAISE, "friend.CsPraise")
async def on_praise(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid)
    target = _world.role(int(msg.get("targetid") or 0))
    if role is None or target is None or target.roleid == role.roleid:
        session.send(ID.SC_PRAISE_RET, targetid=int(msg.get("targetid") or 0),
                     retcode=ERR_NO_PLAYER)
        return

    given = dict((role.data or {}).get("praised") or {})
    key = str(target.roleid)
    if int(given.get(key) or 0) >= 5:
        # 每人每天最多 5 次；客户端只区分 0 / 非 0
        session.send(ID.SC_PRAISE_RET, targetid=target.roleid, retcode=4)
        return
    given[key] = int(given.get(key) or 0) + 1
    _world.merge_role_data(role.roleid, praised=given)

    praises = list((target.data or {}).get("praises") or [])
    praises.append({"fromid": role.roleid, "time": int(time.time()),
                    "name": role.name})
    _world.merge_role_data(target.roleid, praises=praises[-50:],
                           praised_count=int((target.data or {}).get(
                               "praised_count") or 0) + 1)

    session.send(ID.SC_PRAISE_RET, targetid=target.roleid, retcode=0)
    (log.info("role %s praised %s (%s/%s today)", role.name, target.name,
             given[key], 5) if log.isEnabledFor(20) else None)

    ts = _world.session_of_role(target.roleid)
    if ts is not None:
        ts.send(ID.SC_PRAISE, fromid=role.roleid, basicinfo=_basic_of(role))
        send_praise_list(ts, target)
