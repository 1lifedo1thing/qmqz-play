"""抽奖 (gacha).

**Version note.** The delivered APK is built from the cracked cmge 1.7.1 base,
NOT putao 1.12 -- and the two differ here.  Reading 1.12's source first led to
a wrong conclusion, so this module follows qc/src-cracked:

    GachaWindow (1.7.1, 160 lines) has exactly two tabs:
        commonDraw            price id 14 -> ActivityManager.HonorGacha()  -> CsHonorGacha()
        superDraw1/superDraw10 price id 15 -> ActivityManager.GemGacha(n)  -> CsGemGacha(n)

    There is NO 超级军备 / big gacha in 1.7.1: no OnBigDraw*, no
    CsBigGemGacha, no `ActivityManager.BigGacha`.  That whole feature only
    exists in 1.12 (where, additionally, `GachaPriceBig1 => getPrice(18)`
    returns null because the Price table stops at id 15).

    ScHonorGachaTimes(1048651) and ScFreeGemGachaTime(1048652) are also
    1.12-only and must not be sent -- 1.7.1 has no handler for them.

Prize pools come from the client's GemGacha table (type 1 / 2 / 3), weighted by
`ratio`; `range` is the client's pity-timer hint and is ignored here.
"""
from __future__ import annotations

import logging
import random
import time
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import equip

log = logging.getLogger("crisisfire.gacha")

# Part.json 索引：重复武器 -> (碎片 id, 碎片数量)
# 原版 `Part.outPutParts` 就是「已拥有此枪械时转化几个碎片」，
# 按星级递增：4★=4、7★=18、10★=62…（Text 632 的文案就是这条）
_PART_BY_ID: Optional[Dict[int, Dict[str, Any]]] = None

# 【v6】一次性枪 —— 拥有之后就从池子里消失，和角色一样。
# 这几把（黄金沙鹰 / 黄金MP5N / 黄金AUG / 水麒麟M4A1 / 黄金蟒蛇）的升级
# `Part.parts == 0 && pieceId == 0`，只花强化点、不吃碎片，所以重复抽到
# 转出来的碎片对它们毫无用处 —— 与其让玩家抽到一堆死碎片，不如直接剔除。
EXCLUSIVE_GUNS = (101201,    # 黄金沙漠之鹰 5★ 基底
                  303051,    # 黄金MP5N 4★ 基底
                  404251,    # 黄金AUG 4★ 基底
                  404301,    # 水麒麟M4A1 4★ 基底
                  104901)    # 黄金蟒蛇 7★ 基底
EXCLUSIVE_SET = set(EXCLUSIVE_GUNS)

# 这几把也**不参与十连保底**（用户指定）：小池的「必出永久整枪」和中池的
# 「必出 7★+」都要把它们排除掉，否则保底会硬塞一把本来就该靠运气出的枪。
NO_PITY_IDS = EXCLUSIVE_SET


def _dup_piece(itemid: int):
    """已拥有这把枪时该发几个碎片，返回 (碎片 id, 数量) 或 None。"""
    global _PART_BY_ID
    if _PART_BY_ID is None:
        _PART_BY_ID = {int(p.get("id") or 0): p for p in gamedata.table("Part")}
    row = _PART_BY_ID.get(int(itemid or 0))
    if not row:
        return None
    try:
        pid = int(row.get("pieceId") or 0)
        num = int(row.get("outPutParts") or 0)
    except (TypeError, ValueError):
        return None
    if pid <= 0 or num <= 0:
        return None
    return pid, num


_ITEM_BY_ID: Optional[Dict[int, Dict[str, Any]]] = None


def _family_of(itemid: int) -> int:
    """这把枪属于哪个「枪族」（`Item.modelType`）。不是可强化枪返回 0。

    同一把枪的 4★/7★ 是不同 id 但同 modelType —— 抽卡判重要按族算，
    否则钛金AK47 抽到 7★ 会变成仓库里第二把枪，而不是转成 18 个碎片。
    必须在 `Part` 表里（可强化）才认，时装/角色/材料一律返回 0。
    """
    global _ITEM_BY_ID, _PART_BY_ID
    iid = int(itemid or 0)
    if iid <= 0:
        return 0
    if _PART_BY_ID is None:
        _PART_BY_ID = {int(p.get("id") or 0): p for p in gamedata.table("Part")}
    if iid not in _PART_BY_ID:
        return 0
    if _ITEM_BY_ID is None:
        _ITEM_BY_ID = {}
        for row in gamedata.table("Item"):
            try:
                _ITEM_BY_ID[int(row["id"])] = row
            except (KeyError, TypeError, ValueError):
                continue
    row = _ITEM_BY_ID.get(iid) or {}
    try:
        return int(row.get("modelType") or 0)
    except (TypeError, ValueError):
        return 0


class ID:
    CS_HONOR_GACHA = 1048646
    CS_GEM_GACHA = 1048647
    SC_GACHA_FAIL = 1048648
    SC_GACHA_RESULT = 1048649
    SC_GACHA_BRD = 1048650
    CS_BIG_GEM_GACHA = 1048656          # 1.12 only; registered so a stray
    CS_GET_BIG_GEM_GACHA_INFO = 1048657  # packet does not go unanswered
    SC_GET_BIG_GEM_GACHA_INFO = 1048658

    SC_PACKAGE_SYNC = 983041
    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117
    SC_RESEARCH_POINT = 2686979      # ScResearchTalentPointSync(researchpoint)
    # 强化界面（Strengthener）读的是这个 —— 和天赋点不是同一个池子
    SC_STUDY_POINT_SYNC = 786473


# 每次抽奖**固定**送的「强化点」（客户端 GachaRP 表，UI 上写死了这个数字）：
#     GachaRP 1/2 = 荣誉单抽/十连 600 / 6000
#     GachaRP 3/4 = 钻石单抽/十连 20000 / 200000
#     GachaRP 5/6 = 超级单抽/十连 55000 / 550000
# 原来完全没发（连 exp 奖励都没发），抽到「立即获得 3000 经验 / 强化点」
# 那几格等于白抽。
POOL_RP = {"honor": (1, 2), "gem": (3, 4), "big": (5, 6)}


# pool key -> (GemGacha.type, label, 单抽 Price id, 十连 Price id)
#
# **十连不是「单抽价 ×10」**，客户端用的是另一行 Price：
#     GameData.GachaPriceBig1  = getPrice(18)   单抽 328 钻石
#     GameData.GachaPriceBig10 = getPrice(19)   十连 2980 钻石（不是 3280）
# 普通/超级也一样：14/16、15/17。原来十连按单抽价乘 10 扣，比客户端显示的
# 价格多收一大截。
POOLS = {
    "honor": (1, "普通抽奖", 14, 16),
    "gem": (2, "超级抽奖", 15, 17),
    # 大池原本挂的是 GemGacha.type=3 —— 那 6 行只有 3 件饰品 + 3 个角色，
    # 零枪、零强化点，「强化点礼包（大）」抽它等于白抽。真正的大池是
    # type=5（107 行：6/8/10 万强化点、21 件 7★、距离 328/2980 那档价签
    # 也对得上）。type=3 的饰品/角色一并并进来，否则它们没有任何获取途径。
    "big": ((5, 3), "超级军备", 18, 19),
}

# ScGachaFailRes.reason
FAIL_NO_MONEY = 1
FAIL_UNKNOWN = 2
FAIL_BUSY = 3


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------
def pool_rows(pool_type) -> List[Dict[str, Any]]:
    """`pool_type` 可以是单个 type，也可以是 type 元组（大池要并两组）。"""
    if isinstance(pool_type, (tuple, list, set)):
        want = {int(t) for t in pool_type}
        return [r for r in gamedata.table("GemGacha")
                if int(r.get("type") or 0) in want]
    return [r for r in gamedata.table("GemGacha") if r.get("type") == pool_type]


def price_row(price_id: int) -> Optional[Dict[str, Any]]:
    return next((r for r in gamedata.table("Price") if r.get("id") == price_id), None)


def pool_cost(pool: str, count: int = 1) -> Dict[str, int]:
    """What this draw costs, in the client's own (confusing) currency mapping.

    `UserManager.CanBuy(Price)`: gem-priced -> `mUserInfo.gold`（钻石）,
    bloodGem-priced -> `mUserInfo.diamond`（荣誉）, gold-priced -> `mUserInfo.money`
    （金币）。

    注意 **count=10 要走十连价（Price 16/17/19），不是单抽价乘 10** ——
    客户端按钮上的数字就是十连价。
    """
    _t, _label, price1, price10 = POOLS[pool]
    price_id = price10 if int(count or 1) >= 10 else price1
    row = price_row(price_id) or {}
    return {"gold": int(row.get("gem") or 0),
            "diamond": int(row.get("bloodGem") or 0),
            "money": int(row.get("gold") or 0),
            "priceid": price_id,
            "defined": bool(row)}


def top_prize_id() -> int:
    """The daily showcase prize shown via ScGetBigGemGachaInfo."""
    rare = pool_rows(3)
    if rare:
        return int(max(rare, key=lambda r: int(r.get("carry") or 0)
                       if r.get("carry") is not None else 0)["ID"])
    rows = pool_rows(2)
    return int(rows[0]["ID"]) if rows else 0


# --------------------------------------------------------------------------
# draw
# --------------------------------------------------------------------------
def gacha_rp(pool: str, count: int) -> int:
    """这一抽固定赠送的强化点（客户端 GachaRP 表）。"""
    ids = POOL_RP.get(pool, (1, 2))
    price_id = ids[1] if int(count or 1) >= 10 else ids[0]
    for row in gamedata.table("GachaRP"):
        if int(row.get("id") or 0) == price_id:
            return int(row.get("rPoint") or 0)
    return 0


def _owned_role_ids(role) -> set:
    """已经拥有的角色 id（用于把重复角色从奖池里剔掉，别让玩家白抽）。"""
    try:
        out = set()
        for camp in equip.owned_actors(role).values():
            out.update(int(k) for k in camp)
        return out
    except Exception:
        return set()


def _exclusive_gone(role) -> set:
    """已经拥有、因此要从池子里剔除的那几把一次性枪。

    **按枪族判定**：黄金MP5N 强化到 5★ 之后 itemid 变成 303052，玩家手里
    就没有 303051 了，但这一族已经拥有，池里的 4★ 基底同样应该消失。
    """
    try:
        owned = set(equip.owned_ids(role))
    except Exception:
        return set()
    if not owned:
        return set()
    fams = {f for f in (_family_of(i) for i in owned) if f}
    out = set()
    for iid in EXCLUSIVE_SET:
        if iid in owned:
            out.add(iid)
            continue
        fam = _family_of(iid)
        if fam and fam in fams:
            out.add(iid)
    return out


def _drop_exclusive(rows, role):
    """把已拥有的一次性枪从候选里删掉；池子太薄就放弃（避免抽空气）。"""
    gone = _exclusive_gone(role)
    if not gone:
        return rows
    fresh = [r for r in rows if int(r.get("itemId") or 0) not in gone]
    return fresh if len(fresh) >= 20 else rows


def draw(pool: str, count: int, role=None) -> List[Dict[str, Any]]:
    """Pick `count` prizes from the pool, weighted by ratio.

    `role` 给了就把**已拥有的角色奖励**剔除：原来抽到重复角色时
    `buy_actor` 返回 3（已拥有），等于这次抽奖什么都没给（日志里实测
    `gacha role prize 106 -> code 3` 连着两次）。

    【v6】已拥有的一次性枪（EXCLUSIVE_GUNS）同样剔除 —— 见上面那段注释。
    """
    rows = pool_rows(POOLS[pool][0])
    if not rows:
        log.error("gacha pool %s (type %s) is empty", pool, POOLS[pool][0])
        return []
    if role is not None:
        owned = _owned_role_ids(role)
        if owned:
            fresh = [r for r in rows if int(r.get("roleId") or 0) not in owned]
            if fresh:
                rows = fresh
        rows = _drop_exclusive(rows, role)
    weights = [max(1, int(r.get("ratio") or 1)) for r in rows]
    return random.choices(rows, weights=weights, k=count)


def _dedupe_role_prizes(prizes: List[Dict[str, Any]], pool: str) -> List[Dict[str, Any]]:
    """十连里同一个角色只能出现一次（否则第二次 `buy_actor` 返回 3 = 白给）。

    重复的角色格换成同池的**非角色**奖品（权重随机），保证十连还是 10 个。
    """
    seen = set()
    out: List[Dict[str, Any]] = []
    filler = None
    for row in prizes:
        rid = int(row.get("roleId") or 0)
        if rid and rid in seen:
            if filler is None:
                cand = [r for r in pool_rows(POOLS[pool][0])
                        if not int(r.get("roleId") or 0)]
                filler = random.choice(cand) if cand else row
            out.append(filler)
            continue
        if rid:
            seen.add(rid)
        out.append(row)
    return out


def _prize_item_ids(row: Dict[str, Any]) -> List[int]:
    """这一格真正发几个道具。

    `GemGacha.ammoVal` 对**可叠加道具**（碎片 200xxx / 弹药 900xxx）就是
    数量：汤姆逊碎片格分别写着 5/4/3/2/1。原来这里只读 itemId、每格固定
    给 1 个，于是「×2」和「×4」两格一共只给 2 个（用户实测应为 6 个）。
    枪械/刀/甲 maxPile=1，ammoVal 也是 1，展开成 1 个不受影响。
    """
    iid = int(row.get("itemId") or 0)
    if not iid:
        return []
    from . import stackable as _stack
    if _stack.stackable(iid):
        try:
            n = max(1, int(row.get("ammoVal") or 1))
        except (TypeError, ValueError):
            n = 1
        return [iid] * n
    return [iid]


def _prize_role_ids(row: Dict[str, Any]) -> List[int]:
    rid = int(row.get("roleId") or 0)
    return [rid] if rid else []


# --------------------------------------------------------------------------
# 十连保底
# --------------------------------------------------------------------------
TOP_STAR = 7            # 卡池 UI 上写的是「购买十次必送 7 级枪械」

_item_by_id: Optional[Dict[int, Dict[str, Any]]] = None


def _item_row(iid: int) -> Dict[str, Any]:
    global _item_by_id
    if _item_by_id is None:
        _item_by_id = {}
        for row in gamedata.table("Item"):
            try:
                _item_by_id[int(row["id"])] = row
            except (KeyError, TypeError, ValueError):
                continue
    return _item_by_id.get(int(iid)) or {}


def _star_of(row: Dict[str, Any]) -> int:
    """这一格奖品的装备星级；点数/经验/角色格算 0。"""
    try:
        iid = int(row.get("itemId") or 0)
    except (TypeError, ValueError):
        return 0
    if iid <= 0:
        return 0
    try:
        return int(_item_row(iid).get("star") or 0)
    except (TypeError, ValueError):
        return 0


_gun_id_cache: Optional[set] = None


def _gun_ids() -> set:
    """【v46】Gun 表里的 id = **整枪**（碎片/弹药/护甲/手雷都不在里面）。

    十连保底判「永久枪」必须用它：碎片的 Item 字段同样是
    ``itemId>0 & itemDuration==0``，只判那两个字段会把碎片当成枪。
    """
    global _gun_id_cache
    if _gun_id_cache is None:
        out = set()
        for row in gamedata.table("Gun"):
            try:
                out.add(int(row["id"]))
            except (KeyError, TypeError, ValueError):
                continue
        _gun_id_cache = out
    return _gun_id_cache


def _ensure_top_prize(prizes: List[Dict[str, Any]], pool: str,
                      count: int) -> List[Dict[str, Any]]:
    """十连保底。

    分两类池处理，避免「空头承诺」：

    1) 池子里本身有 7★+ 装备（超级抽奖 / 超级军备（大））：保持原「十连必出
       7★+」保底，不破坏大池体验。
    2) 池子里没有 7★+（强化点礼包（小）/ 4★池）：原来静默跳过，等于客户端那句
       「购买十次必送永久枪」纯文案。改为【方案 C】—— 保证十连里至少有一把
       **该池自身的永久枪**（不限星级）。永久判定：奖品行 ``itemDuration==0``
       且带 ``itemId`` 的武器格；十连里已经抽到永久枪就不补。
    """
    if int(count or 1) < 10 or not prizes:
        return prizes
    # 【v6】这几把一次性枪不参与保底（用户指定），保底候选里直接排除。
    rows_all = [r for r in pool_rows(POOLS[pool][0])
                if int(r.get("itemId") or 0) not in NO_PITY_IDS]
    if not rows_all:
        return prizes

    if any(_star_of(r) >= TOP_STAR for r in rows_all):
        # —— 原 7★+ 保底（大池 / 中池），行为不变 ——
        if any(_star_of(r) >= TOP_STAR for r in prizes):
            return prizes
        rows = [r for r in rows_all if _star_of(r) >= TOP_STAR]
    else:
        # —— 方案 C：保底该池的「永久枪」（不限星） ——
        # 【v46】**必须是整枪**。原来只判 `itemId>0 且 itemDuration==0`，
        # 而池里的**碎片**（UMP45碎片 200020…）和**穿甲弹**（900xxx）
        # 也是 itemId>0 + duration=0 —— 十连里只要出了碎片，
        # `any(_is_perm)` 就成立，保底直接跳过，表现就是「永远触发不了
        # 十连必送永久枪」。现在要求这把枪真的在 Gun 表里（整枪）。
        def _is_perm(r):
            try:
                iid = int(r.get("itemId") or 0)
            except (TypeError, ValueError):
                return False
            return (iid > 0 and int(r.get("itemDuration") or 0) == 0
                    and iid in _gun_ids())

        if any(_is_perm(r) for r in prizes):
            return prizes
        rows = [r for r in rows_all if _is_perm(r)]
        if not rows:
            # 池子里连永久枪都没有（理论上不该发生），跳过避免刷屏。
            log.debug("gacha pool %s 里没有永久枪奖品，保底跳过", pool)
            return prizes

    weights = [max(1, int(r.get("ratio") or 1)) for r in rows]
    pick = random.choices(rows, weights=weights, k=1)[0]

    def _worst(i: int):
        row = prizes[i]
        # 星级越低越该被换掉；同星级时先扔装备、后扔点数/经验格
        has_payload = 1 if (row.get("rPoint") or row.get("exp")) else 0
        return (_star_of(row), -has_payload)

    idx = min(range(len(prizes)), key=_worst)
    out = list(prizes)
    out[idx] = pick
    log.info("保底生效：%s 十连补入 %s★ %s（永久=%s）", pool, _star_of(pick),
             _item_row(pick.get("itemId")).get("name"),
             int(pick.get("itemDuration") or 0) == 0)
    return out


# --------------------------------------------------------------------------
# 10★ 保底（v10，用户指定）
# --------------------------------------------------------------------------
TOP_TEN_STAR = 10
TEN_STAR_PITY = {"gem": 200, "big": 50}   # 单位是**抽数**：中池 200 抽（20 次十连）
                                          # 大池 50 抽（5 次十连），荣誉池没有


def _ensure_ten_star(prizes: List[Dict[str, Any]], pool: str, count: int,
                     st: Dict[str, Any]):
    """跨十连累计的 10★ 保底。

    计数单位是「抽数」而不是「十连次数」，这样单抽也会攒进度：
    中池 200 抽、大池 50 抽必出一把 10★（池里的 5 把等概率随机）。
    抽到任意 10★ 就把计数清零 —— 提前出了不占保底额度。

    返回 (prizes, 是否触发了保底)。
    """
    limit = TEN_STAR_PITY.get(pool)
    if not limit or not prizes:
        return prizes, False
    pulls = st.get("pity_pulls")
    if not isinstance(pulls, dict):
        pulls = st["pity_pulls"] = {}
    got = any(_star_of(r) >= TOP_TEN_STAR for r in prizes)
    n = int(pulls.get(pool) or 0) + int(count or 1)
    if got:
        pulls[pool] = 0
        return prizes, False
    if n < limit:
        pulls[pool] = n
        return prizes, False
    rows = [r for r in pool_rows(POOLS[pool][0])
            if _star_of(r) >= TOP_TEN_STAR]
    if not rows:
        pulls[pool] = 0
        return prizes, False
    pick = random.choice(rows)          # 5 把等概率
    # 换掉星级最低的一格，优先扔装备格，点数/经验格尽量留着
    def _worst(i: int):
        row = prizes[i]
        has_payload = 1 if (row.get("rPoint") or row.get("exp")) else 0
        return (_star_of(row), -has_payload)
    idx = min(range(len(prizes)), key=_worst)
    out = list(prizes)
    out[idx] = pick
    pulls[pool] = 0
    log.info("10★ 保底生效：%s 累计 %s 抽补入 %s", pool, n,
             _item_row(pick.get("itemId")).get("name"))
    return out, True


# --------------------------------------------------------------------------
# per-role state
# --------------------------------------------------------------------------
def _today() -> str:
    return time.strftime("%Y-%m-%d")


def _state(role) -> Dict[str, Any]:
    d = dict(role.data or {})
    st = d.get("gacha")
    if not isinstance(st, dict) or st.get("day") != _today():
        # 每日重置只清「今天免费抽了几次」这类字段；**保底进度必须跨天保留**，
        # 否则玩家每天抽 19 次十连、第二天归零，永远吃不到 20 次保底。
        _old_pity = st.get("pity_pulls") if isinstance(st, dict) else None
        st = {"day": _today(), "honor_used": 0, "gem_free_until": 0,
              "big_count": 0,
              "pity_pulls": dict(_old_pity) if isinstance(_old_pity, dict) else {}}
        d["gacha"] = st
    return st


def _save(role, st: Dict[str, Any]) -> None:
    if _world is not None:
        _world.merge_role_data(role.roleid, gacha=st)


FREE_HONOR_PER_DAY = 1
FREE_GEM_INTERVAL = 1800        # seconds between free gem draws


# --------------------------------------------------------------------------
# handlers
# --------------------------------------------------------------------------
def _split_duplicates(role, items: List[int]):
    """按「是否已拥有（含同枪族）」把抽到的道具拆成两部分。

    返回 `(keep, piece_pool, dup_all, dup_with_piece)`：

      * `keep`           真正要入库的道具 id
      * `piece_pool`     重复武器转化出来的碎片 id（已按数量展开）
      * `dup_all`        判定为重复的 id（含没有碎片的）
      * `dup_with_piece` 真的转成碎片的重复 id（`status=2` 用）

    判重键是 **枪族**（`Item.modelType`）：4★ 钛金AK47 与 7★ 是不同 id、
    同一把枪，抽到高星版本必须转碎片，不能再塞一把进仓库。
    """
    try:
        had = set(int(i) for i in equip.owned_ids(role))
    except (TypeError, ValueError):
        had = set()
    had_fam = {_family_of(i) for i in had} - {0}
    from . import stackable as _stack
    keep: List[int] = []
    pool: List[int] = []
    dup_all: set = set()
    dup_with_piece: set = set()
    for raw in items:
        iid = int(raw)
        if _stack.stackable(iid):
            # 碎片/弹药这类可叠加物没有「重复」概念
            keep.append(iid)
            continue
        fam = _family_of(iid)
        if iid in had or (fam and fam in had_fam):
            dup_all.add(iid)
            pc = _dup_piece(iid)
            if pc:
                pool.extend([int(pc[0])] * int(pc[1]))
                dup_with_piece.add(iid)
            continue
        keep.append(iid)
        # 同一次十连里出现两把同族：后出现的那把也要算重复
        had.add(iid)
        if fam:
            had_fam.add(fam)
    return keep, pool, dup_all, dup_with_piece


async def _do_gacha(session: Session, msg: dict, pool: str) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        log.warning("gacha %s with no role (%s)", pool, session)
        return

    # 1.7.1 sends CsGemGacha(multiple); CsHonorGacha() carries no fields at all
    multiple = int(msg.get("multiple") or 0)
    count = 10 if multiple >= 10 else 1

    # 等级门槛：强化点礼包（大）需要 50 级才开放（用户指定）。
    # 不到级直接拦下（不扣钱、不抽），返回 reason=1（ERR_CD）让客户端提示
    # 「今日已抽取」类文案——客户端没有「等级不足」的专用 reason，功能上先拦死。
    try:
        if pool == "big" and int(role.level or 0) < 50:
            log.info("role %s 等级 %s < 50，禁止抽强化点礼包（大）",
                     role.name, role.level)
            session.send(ID.SC_GACHA_FAIL, reason=FAIL_NO_MONEY)
            return
    except (TypeError, ValueError):
        pass

    cost = pool_cost(pool, count)
    paid_gold = paid_diamond = paid_money = 0

    # The client already ran UserManager.CanBuy before sending, so charge the
    # configured price rather than trusting `multiple`.
    if cost["defined"]:
        need_gold = cost["gold"]
        need_diamond = cost["diamond"]
        need_money = cost["money"]
        if (need_gold > role.gold or need_diamond > role.diamond
                or need_money > role.money):
            log.info("role %s cannot afford %s x%s (needs %s gold / %s diamond "
                     "/ %s money)", role.name, pool, count, need_gold,
                     need_diamond, need_money)
            session.send(ID.SC_GACHA_FAIL, reason=FAIL_NO_MONEY)
            return
        paid_gold, paid_diamond, paid_money = need_gold, need_diamond, need_money
    else:
        log.info("%s has no Price row in this build; drawing without charge", pool)

    prizes = _dedupe_role_prizes(draw(pool, count, role), pool)
    prizes = _ensure_top_prize(prizes, pool, count)
    # 10★ 保底（跨十连累计），必须在 7★ 保底之后：7★ 补的是「最低格」，
    # 10★ 再补的时候会把刚补进去的 7★ 当成普通格，不会互相顶掉。
    _st = _state(role)
    prizes, _pity10 = _ensure_ten_star(prizes, pool, count, _st)
    _save(role, _st)
    if not prizes:
        session.send(ID.SC_GACHA_FAIL, reason=FAIL_UNKNOWN)
        return

    role.gold -= paid_gold
    role.diamond -= paid_diamond
    role.money -= paid_money
    _world.update_role(role.roleid, gold=role.gold, diamond=role.diamond,
                       money=role.money)
    # **扣完必须把余额推给客户端。**
    # 客户端点抽奖只做 CanBuy 检查，**不会本地扣钱** —— 余额完全靠
    # ScAcountSync 刷新（UserManager.SynAccount）。原来这里只扣服务端库、
    # 不发同步，界面上钻石数字一动不动，看起来就是「抽奖不扣钻石」。
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)

    items: List[int] = []
    roles: List[int] = []
    # 奖池里有 6 格是「立即获得 3000 经验 / 强化点」（itemId=0 roleId=0），
    # 原来这些字段完全没读 —— 抽到就是白抽。
    exp_gain = 0
    rp_gain = gacha_rp(pool, count)
    for row in prizes:
        items.extend(_prize_item_ids(row))
        roles.extend(_prize_role_ids(row))
        exp_gain += int(row.get("exp") or 0)
        rp_gain += int(row.get("rPoint") or 0)

    # **发货前先拆包：重复的直接转碎片，不再进背包。**
    # 判重按枪族（Item.modelType），抽到的那把只决定给几个碎片。
    _keep, _piece_pool, _dup_all, _dup_with_piece = _split_duplicates(
        role, items)
    added = equip.grant_items(role, _keep, _world)
    _pieces_added: List[int] = []
    if _piece_pool:
        _pieces_added = equip.grant_items(role, _piece_pool, _world)
        log.info("role %s 抽到重复武器 -> +%s 片碎片", role.name,
                 len(_piece_pool))
    # 角色奖品（GemGacha.roleId，例如「猎魔人凯莉（永久）」）以前被直接丢掉，
    # 抽中了等于什么都没给 —— 1.9 的超级军备池里这类奖品占一大半。
    for rid in roles:
        code = equip.buy_actor(role, rid, _world, free=True)
        log.info("role %s gacha role prize %s -> code %s", role.name, rid, code)

    old_rank = new_rank = 0
    if exp_gain:
        from . import leveling
        from .handlers import _property_of
        old_rank, new_rank = leveling.apply_exp(_world, role, exp_gain)
        session.send(ID.SC_USER_INFO, roleid=role.roleid,
                     property=_property_of(role))
    if rp_gain:
        # **只进 Strengthener 那个池子（study_point）。**
        # 天赋页的 research_point 是另一套货币，来源是「枪械升一级」，
        # 不是抽卡。原来两池同步涨，截图里 6300000 与 6300 同源就是这个。
        from . import stackable as _stack
        total_sp = _stack.add_study_point(role, rp_gain, _world)
        session.send(ID.SC_STUDY_POINT_SYNC, studypoint=total_sp)
        log.info("role %s 抽卡 +%s 强化点（余额 %s）", role.name, rp_gain, total_sp)

    gachas = [int(r["ID"]) for r in prizes]
    # `status` 驱动客户端的角标：1 = 新获得、2 = 重复（已转碎片）、0 = 普通
    status = []
    for _row in prizes:
        _ids = [int(i) for i in _prize_item_ids(_row)]
        if not _ids:
            status.append(0)
        elif all(i in _dup_all for i in _ids):
            status.append(2 if all(i in _dup_with_piece for i in _ids) else 0)
        else:
            status.append(1)
    log.info("role %s drew %s x%s -> %s (paid %s gold / %s diamond / %s money, "
             "+%s exp +%s rp)", role.name, pool, count, gachas,
             paid_gold, paid_diamond, paid_money, exp_gain, rp_gain)

    session.send(ID.SC_GACHA_RESULT, gachas=gachas, status=status)
    equip_session_push(session, added + _pieces_added, role)
    # **碎片数量同步**：重复武器转成的碎片是「已拥有道具 +N」，
    # `grant_items` 对已拥有的可叠加道具不会放进 `added`，而 synctype=1
    # 只负责新增物品、不更新已有物品的 subcount —— 客户端就一直显示旧数量，
    # 直到玩家出售/强化让数量变动一次才刷新（用户实测「抽到 7 阶碎片没加，
    # 卖掉一张后才显示 22 张」）。这里补推 synctype=2 覆盖真实数量。
    # `_keep` 里也有直接抽中的碎片格（ammoVal 展开后），同样要刷数量。
    _stack_ids = {int(i) for i in (list(_piece_pool) + list(_keep))
                  if int(i) > 0}
    if _stack_ids:
        try:
            _fresh = _world.role(role.roleid) if _world is not None else None
            equip.push_stack_counts(session, _fresh or role, sorted(_stack_ids))
        except Exception:
            log.debug("抽卡碎片数量同步失败 role=%s", role.roleid,
                      exc_info=True)
    if new_rank > old_rank:
        try:
            from . import leveling
            leveling.push_if_ranked_up(session, role, old_rank, new_rank)
        except Exception:
            log.debug("gacha 推送升级失败", exc_info=True)

    # rare (type 3) wins are broadcast
    for row in prizes:
        info = str(row.get("info") or "")
        if row.get("type") == 3 and not info.startswith("<ref"):
            session.send(ID.SC_GACHA_BRD, gachaid=int(row["ID"]),
                         rolename=role.name)


def equip_session_push(session: Session, added: List[int], role=None) -> None:
    if not added:
        return
    session.send(ID.SC_PACKAGE_SYNC, synctype=1,
                 itemlist=equip.package_add_payload(added, role))


@ROUTER.register(ID.CS_HONOR_GACHA, "shop.CsHonorGacha")
async def on_honor_gacha(session: Session, msg: dict) -> None:
    await _do_gacha(session, msg, "honor")


@ROUTER.register(ID.CS_GEM_GACHA, "shop.CsGemGacha")
async def on_gem_gacha(session: Session, msg: dict) -> None:
    await _do_gacha(session, msg, "gem")


@ROUTER.register(ID.CS_BIG_GEM_GACHA, "shop.CsBigGemGacha")
async def on_big_gacha(session: Session, msg: dict) -> None:
    await _do_gacha(session, msg, "big")


@ROUTER.register(ID.CS_GET_BIG_GEM_GACHA_INFO, "shop.CsGetBigGemGachaInfo")
async def on_big_info(session: Session, msg: dict) -> None:
    """GachaWindow.OnEnable asks for this; it sets GameData.TopDailyGachaId."""
    session.send(ID.SC_GET_BIG_GEM_GACHA_INFO, gachaid=top_prize_id())
