"""Static scene collision queries for reconstructed BOT visibility and grid paths.

Triangle intersection is double-sided. The fallback grid is explicitly a local
reconstruction for scenes without baked navigation; it never invents a portal
across an obstacle. Moving scene objects are outside this static snapshot.
"""
from __future__ import annotations
import gzip, heapq, json, math, logging
from functools import lru_cache
from pathlib import Path
from .navigation import distance, lerp, cross

VISION_MASK = -6357253       # Robot.TouchObj
GROUND_MASK = -2162949       # Warrior.isGrounded
FORBIDDEN_GROUND = (2,20)    # Warrior hackLayerCounts -> Report/In HackLayer
BODY_HEIGHT = 1.7           # Warrior.BodyHeight
BODY_RADIUS = .35          # Warrior.Awake sets CharacterController.radius
# floor_hits accepts a surface only while normal.y^2 >= .64*|normal|^2, i.e.
# cos(slope) >= .8.  The same geometric limit fixes the maximum ground rise over
# a horizontal distance: tan(acos(.8)) == .75.  It is not a widened tolerance.
MAX_WALK_TAN = .75


def dot(a,b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def vector(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])


class Scene:
    CELL = 4.
    def __init__(self,data):
        self.tris=[];self.cells={};self.bounds=[];self.layers=[]
        layers=data.get('layers',[0]*len(data['triangles']))
        assert len(layers)==len(data['triangles'])
        for row,(a,b,c) in enumerate(data['triangles']):
            ab,ac=sub(b,a),sub(c,a)
            if dot(vector(ab,ac),vector(ab,ac)) < 1e-12: continue
            idx=len(self.tris); self.tris.append((a,b,c,ab,ac))
            self.layers.append(int(layers[row]))
            self.bounds.append(tuple((min(a[i],b[i],c[i]),max(a[i],b[i],c[i])) for i in range(3)))
            for x in range(math.floor(min(a[0],b[0],c[0])/self.CELL),math.floor(max(a[0],b[0],c[0])/self.CELL)+1):
                for z in range(math.floor(min(a[2],b[2],c[2])/self.CELL),math.floor(max(a[2],b[2],c[2])/self.CELL)+1):
                    self.cells.setdefault((x,z),[]).append(idx)

    def clear(self,a,b,mask=VISION_MASK):
        d=sub(b,a); n=max(1,int(distance(a,b)/(self.CELL/2))+1);ids=set()
        if n <= 4:
            for x in range(math.floor(min(a[0],b[0])/self.CELL),math.floor(max(a[0],b[0])/self.CELL)+1):
                for z in range(math.floor(min(a[2],b[2])/self.CELL),math.floor(max(a[2],b[2])/self.CELL)+1):
                    ids.update(self.cells.get((x,z),()))
        else:
            for i in range(n+1):
                p=lerp(a,b,i/n);x,z=math.floor(p[0]/self.CELL),math.floor(p[2]/self.CELL)
                # Supercover: no thin obstacle is lost at a grid corner.
                for dx in (-1,0,1):
                    for dz in (-1,0,1):ids.update(self.cells.get((x+dx,z+dz),()))
        bounds=tuple((min(a[i],b[i]),max(a[i],b[i])) for i in range(3))
        for idx in ids:
            if not (mask&(1<<self.layers[idx])):continue
            tb=self.bounds[idx]
            if (tb[0][1]<bounds[0][0]-1e-6 or tb[0][0]>bounds[0][1]+1e-6
                    or tb[1][1]<bounds[1][0]-1e-6 or tb[1][0]>bounds[1][1]+1e-6
                    or tb[2][1]<bounds[2][0]-1e-6 or tb[2][0]>bounds[2][1]+1e-6):continue
            p,_,_,ab,ac=self.tris[idx];h=vector(d,ac);det=dot(ab,h)
            if abs(det)<1e-9:continue
            inv=1/det;s=sub(a,p);u=inv*dot(s,h)
            if u< -1e-7 or u>1+1e-7:continue
            q=vector(s,ab);v=inv*dot(d,q)
            if v< -1e-7 or u+v>1+1e-7:continue
            t=inv*dot(ac,q)
            if 1e-5 < t < 1-1e-5:return False
        return True

    @lru_cache(maxsize=32768)
    def floor_hits(self,x,z):
        p=(x,0.,z);hits=[]
        for idx in self.cells.get((math.floor(x/self.CELL),math.floor(z/self.CELL)),()):
            a,b,c,ab,ac=self.tris[idx];normal=vector(ab,ac)
            # Upward stable surfaces only. Box undersides cannot become floors.
            # Warrior treats lastGroundNormal.y <= .8 as a sliding surface.
            if normal[1]<=0 or normal[1]**2 < .64*dot(normal,normal):continue
            den=cross(a,b,c)
            if abs(den)<1e-8:continue
            u=cross(p,b,c)/den;v=cross(a,p,c)/den;w=1-u-v
            if min(u,v,w)<-1e-6:continue
            y=u*a[1]+v*b[1]+w*c[1]
            layer=self.layers[idx]
            if not any(abs(y-old)<.02 and layer==ol for old,ol in hits):hits.append((y,layer))
        return tuple(sorted(hits))

    @lru_cache(maxsize=32768)
    def floors(self,x,z):
        ys=[]
        for y,layer in self.floor_hits(x,z):
            if layer in FORBIDDEN_GROUND or not (GROUND_MASK&(1<<layer)):continue
            if not any(abs(y-old)<.02 for old in ys):ys.append(y)
        return tuple(ys)

    def stand_clear(self,p):
        x,y,z=p
        # Simulate the native short downward ground probe: an excluded plane
        # above a candidate is still an obstruction, not permission to stand.
        hits=[(h,l) for h,l in self.floor_hits(x,z) if y-.1<=h<=y+1.]
        if not hits:return False
        # 【v55】选顶面时只认**可站立层**。
        # 地铁轨道床上方 8 cm 铺着一片 layer 2 的薄碰撞（GROUND_MASK 排除、
        # 也在 FORBIDDEN_GROUND 里，客户端 `Warrior.isGrounded` 根本不看它）。
        # 老代码把它当 top，于是整条轨道被判「站不住」——烘焙网格里一个节点
        # 都没有，BOT 只能贴着列车侧面直推。这里改成：可站立层存在时以它为
        # 准，禁止层只在**没有任何可站面**时沿用旧判定（防止钻到屋顶下方）。
        usable=[(h,l) for h,l in hits
                if l not in FORBIDDEN_GROUND and (GROUND_MASK&(1<<l))]
        top,layer=max(usable) if usable else max(hits)
        if layer in FORBIDDEN_GROUND or abs(top-y)>.12:return False
        # The authored CharacterController has stepOffset=0 and slopeLimit=90,
        # so the body follows the local ground on a slope but cannot step onto a
        # ledge.  Cast each ring probe from *that point's* walkable surface,
        # bounded by the same .75 rise limit as floor_hits.  Starting every probe
        # at p.y+.06 instead intersects the ramp itself and rejected all slopes.
        rise=BODY_RADIUS*MAX_WALK_TAN+.02
        for dx,dz in ((0,0),(BODY_RADIUS,0),(-BODY_RADIUS,0),(0,BODY_RADIUS),(0,-BODY_RADIUS)):
            ring=self.floor_hits(x+dx,z+dz)
            # 【v55】环上取地面同样只认可站立层：轨道床四周铺着 layer 2/20 的
            # 薄片（0.48 / 0.6），old 代码把它们当基准点，竖直净空射线从薄片
            # 上方打出去就被轨道护栏挡住 → 整条轨道判「站不住」。
            local=[(h,l) for h,l in ring if y-.1<=h<=y+rise
                   and l not in FORBIDDEN_GROUND and (GROUND_MASK&(1<<l))]
            # A higher horizontal surface inside body height is a ledge/ceiling,
            # not a walkable continuation (stepOffset is zero in Warrior.Awake).
            if any(y+rise<h<=y+BODY_HEIGHT for h,l in ring
                   if l not in FORBIDDEN_GROUND and (GROUND_MASK&(1<<l))):return False
            if local:
                base,layer=max(local)
                if layer in FORBIDDEN_GROUND:return False
            else:base=y
            if not self.clear((x+dx,base+.06,z+dz),(x+dx,base+BODY_HEIGHT,z+dz),mask=-1):return False
        return True

    def safe_spawn(self,p):
        return self._safe_spawn(tuple(p))

    @lru_cache(maxsize=512)
    def _safe_spawn(self,p):
        # Prefer the authored XZ. Only search a small local ring if that column
        # has no full-body clearance; these offsets are reconstruction choices.
        for radius in (0.,.5,1.,2.):
            candidates=[]
            offsets=[(0.,0.)] if radius==0 else [(radius*math.cos(i*math.pi/4),radius*math.sin(i*math.pi/4)) for i in range(8)]
            for dx,dz in offsets:
                x,z=p[0]+dx,p[2]+dz
                for y in self.floors(x,z):
                    q=(x,y,z)
                    if self.stand_clear(q):candidates.append((distance(p,q),q))
            if candidates:return min(candidates)[1]
        # A few shipped scene spawn groups are copied outside usable terrain.
        # Fall back only to an actual upward collider triangle's centroid with
        # full-body clearance. This is explicitly reconstructed placement.
        candidates=[]
        for i,(a,b,c,ab,ac) in enumerate(self.tris):
            layer=self.layers[i];normal=vector(ab,ac)
            if layer in FORBIDDEN_GROUND or not (GROUND_MASK&(1<<layer)):continue
            if normal[1]<=0 or normal[1]**2<.64*dot(normal,normal):continue
            q=tuple((a[j]+b[j]+c[j])/3 for j in range(3))
            candidates.append((distance(p,q),q))
        for _,q in sorted(candidates)[:500]:
            if self.stand_clear(q):return q
        return None

    def walk_clear(self,a,b,radius=BODY_RADIUS):
        dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz)
        sx,sz=(-dz/length*radius,dx/length*radius) if length>1e-6 else (radius,0.)
        for side in (-1,0,1):
            for h in (.4,1.4):
                if not self.clear((a[0]+side*sx,a[1]+h,a[2]+side*sz),
                                  (b[0]+side*sx,b[1]+h,b[2]+side*sz),mask=-1):return False
        return True

    def sweep_clear(self,a,b,radius=BODY_RADIUS):
        """半径 radius 的竖直圆柱沿 a→b 扫过，是否完全不碰障碍。

        `walk_clear` 的 3 条平行射线只覆盖圆柱的左右两侧，漏掉了**两端的
        半圆**。凸角处三条线可能全从角外擦过，而圆柱的前端圆弧会撞上角 ——
        这就是 BOT 贴着墙角直连、然后卡住的原因。这里给起点补后向半圆、
        终点补前向半圆，用来给「抄近路」的长距离直连做加严判定。

        只给寻路的 string pulling 用；每帧 0.2~0.4m 的正常行走仍走
        `walk_clear`，避免把移动本身卡死。
        """
        if not self.walk_clear(a,b,radius):return False
        dx,dz=b[0]-a[0],b[2]-a[2];length=math.hypot(dx,dz)
        if length<=1e-6:return True
        ux,uz=dx/length,dz/length
        for ox,oy,oz,forward in ((a[0],a[1],a[2],False),
                                 (b[0],b[1],b[2],True)):
            for i in range(9):
                ang=-math.pi/2+i*math.pi/8
                ca,sa=math.cos(ang),math.sin(ang)
                vx,vz=ux*ca-uz*sa,ux*sa+uz*ca
                if not forward:vx,vz=-vx,-vz
                for h in (.4,1.4):
                    if not self.clear((ox,oy+h,oz),
                                      (ox+vx*radius,oy+h,oz+vz*radius),mask=-1):
                        return False
        return True


class Grid:
    """Conservative 1m ground grid for scenes with no authored NavMesh.

    Geometry/clearance are derived from colliders; spacing/body size/climb are
    reconstructed controller parameters, not claimed original navigation rules.
    """
    STEP = 1.
    def __init__(self,scene):self.scene=scene;self.source_sha256='collision-grid-reconstruction'

    @lru_cache(maxsize=16384)
    def nodes(self,x,z):
        out=[]
        for y in self.scene.floors(x*self.STEP,z*self.STEP):
            p=(x*self.STEP,y,z*self.STEP)
            if not self.scene.stand_clear(p):continue
            if all(any(abs(h-y)<=.4 for h in self.scene.floors(p[0]+dx,p[2]+dz))
                   for dx,dz in ((BODY_RADIUS,0),(-BODY_RADIUS,0),(0,BODY_RADIUS),(0,-BODY_RADIUS))):out.append((x,round(y,3),z))
        return tuple(out)

    def point(self,k):return (k[0]*self.STEP,k[1],k[2]*self.STEP)

    def locate(self,p):
        return self._locate(tuple(p))

    def ground(self,p):
        floors=self.scene.floors(p[0],p[2])
        if not floors:return None
        y=min(floors,key=lambda y:abs(p[1]-y))
        return (p[0],y,p[2]) if abs(p[1]-y)<1.2 else None

    @lru_cache(maxsize=4096)
    def _locate(self,p):
        x,z=round(p[0]/self.STEP),round(p[2]/self.STEP);candidates=[]
        for dx in (-1,0,1):
            for dz in (-1,0,1):
                for k in self.nodes(x+dx,z+dz):
                    q=self.point(k)
                    if abs(q[1]-p[1])<1.2:
                        candidates.append((distance(p,q),k,q))
        for _,k,q in sorted(candidates):
            if self.scene.walk_clear(p,q):return k,q
        return None

    @lru_cache(maxsize=32768)
    def neighbours(self,k):
        a=self.point(k);out=[]
        # A 1 m grid step may climb a walkable ramp at most STEP*tan(acos(.8)).
        # Larger vertical separations additionally require the sampled ground to
        # follow the straight interpolation; a vertical ledge does not, so this
        # is not a free step-up threshold.
        rise=self.STEP*MAX_WALK_TAN+.02
        for dx,dz in ((1,0),(-1,0),(0,1),(0,-1)):
            for n in self.nodes(k[0]+dx,k[2]+dz):
                b=self.point(n);dy=abs(a[1]-b[1])
                if dy<=.4:
                    if self.scene.walk_clear(a,b):out.append(n)
                elif dy<=rise and self.slope_clear(a,b) and self.scene.walk_clear(a,b):
                    out.append(n)
        return tuple(out)

    def slope_clear(self,a,b):
        """True only when the ground height follows a-b continuously (a ramp)."""
        length=math.hypot(b[0]-a[0],b[2]-a[2])
        steps=max(1,int(length/.25))
        for i in range(steps+1):
            p=lerp(a,b,i/steps)
            fs=self.scene.floors(p[0],p[2])
            if not fs or min(abs(y-p[1]) for y in fs)>.12:return False
        return True

    @lru_cache(maxsize=512)
    def corridor(self,start,end):
        costs={start:0.};prev={};q=[(0.,start)];visited=set()
        component=getattr(self,'component',None)
        if component is not None and component[start]!=component[end]:return ()
        while q and len(visited)<50000:
            _,k=heapq.heappop(q)
            if k in visited:continue
            visited.add(k)
            if k==end:
                path=[k]
                while k in prev:k=prev[k];path.append(k)
                return tuple(reversed(path))
            for n in self.neighbours(k):
                cost=costs[k]+distance(self.point(k),self.point(n))
                if cost<costs.get(n,float('inf')):
                    costs[n]=cost;prev[n]=k
                    heapq.heappush(q,(cost+distance(self.point(n),self.point(end)),n))
        return ()

    def _corner_ok(self,a,b):
        """【v15】抄近路的加严条件：长距离直连要留出转角余量。

        只管「跨过多个网格节点」的直线；相邻节点那一步保持原判定，
        否则加严后 BOT 可能连贴墙走都不会走了。`navigation.Mesh` 和
        parkour 的包装网格没有 `scene`，那种情况直接放行（不改它们的行为）。
        """
        scene=getattr(self,'scene',None)
        if scene is None or not hasattr(scene,'sweep_clear'):return True
        if distance(a,b)<=1.2*self.STEP:return True
        try:
            from ..config import CONFIG as _C
            margin=max(0.,float(getattr(_C,'bot_corner_clearance',0.20)))
        except Exception:
            margin=0.20
        if margin<=0:return True
        return scene.sweep_clear(a,b,BODY_RADIUS+margin)

    def clear(self,a,b):
        # Body clearance alone cannot authorize crossing an unsupported hole.
        if not self.scene.walk_clear(a,b):return False
        steps=max(1,int(distance(a,b)/.25))
        return all(any(abs(y-p[1])<.6 for y in self.scene.floors(p[0],p[2]))
                   for p in (lerp(a,b,i/steps) for i in range(steps+1)))

    def path(self,a,b):
        start,end=self.locate(a),self.locate(b)
        if start is None or end is None:return ()
        keys=self.corridor(start[0],end[0])
        if not keys:return ()
        pts=[a]+[self.point(k) for k in keys]+[b];smooth=[a];i=0
        while i<len(pts)-1:
            j=min(len(pts)-1,i+12)
            while j>i+1 and not (self.clear(pts[i],pts[j])
                                 and self._corner_ok(pts[i],pts[j])):j-=1
            smooth.append(pts[j]);i=j
        return tuple(smooth)

    def advance(self,a,b,budget):
        pts=self.path(a,b)
        if not pts:return None
        current=a
        for dest in pts[1:]:
            d=distance(current,dest)
            if d>budget:return lerp(current,dest,budget/d)
            budget-=d;current=dest
        return current

    @lru_cache(maxsize=8192)
    def nearest_node(self,p,max_dy=1.2,radius=2):
        """最近的网格键（**不要求直连**）。

        BOT 站在两行网格之间（楼梯中段、台阶边缘）时 `locate()` 会因为
        `walk_clear` 不通过而返回 None —— 地铁图楼梯段实测 3.1% 的可站点
        属于这种。老逻辑拿到 None 就直接 `return here`，等于永久站桩。
        这里只做「投影到最近节点」，用于连通性与方向判断，不当成可走通行证。
        """
        x,z=round(p[0]/self.STEP),round(p[2]/self.STEP);best=None
        for dx in range(-radius,radius+1):
            for dz in range(-radius,radius+1):
                for k in self.nodes(x+dx,z+dz):
                    q=self.point(k)
                    if abs(q[1]-p[1])>max_dy:continue
                    d=distance(p,q)
                    if best is None or d<best[0]:best=(d,k)
        return best

    def nearest_joinable(self,from_key,p,max_dy=3.0,radius=4):
        """与 `from_key` 同连通分量、离 p 最近的节点。

        目标点不在网格上（车顶、楼梯中段）或落在别的分量（孤立平台）时，
        用它当替代终点，让 BOT 走到「能到的最近处」而不是原地不动。
        """
        comp=getattr(self,'component',None)
        want=comp.get(from_key) if isinstance(comp,dict) else None
        x,z=round(p[0]/self.STEP),round(p[2]/self.STEP);best=None
        for dx in range(-radius,radius+1):
            for dz in range(-radius,radius+1):
                for k in self.nodes(x+dx,z+dz):
                    q=self.point(k)
                    if abs(q[1]-p[1])>max_dy:continue
                    if want is not None and comp.get(k)!=want:continue
                    d=distance(p,q)
                    if best is None or d<best[0]:best=(d,k)
        return best[1] if best else None

    def next_waypoint(self,a,b,budget=None,route=None):
        start=self.locate(a);skey=start[0] if start else None
        if skey is None:
            # 起点也可能不在网格上（地铁轨道床那一层根本没烘焙节点）：
            # 逐级放宽找投影，找不到也不要直接放弃。
            for _dy,_r in ((1.6,2),(2.6,4)):
                hit=self.nearest_node(a,max_dy=_dy,radius=_r)
                if hit is not None:skey=hit[1];break
        end=self.locate(b);ekey=end[0] if end else None
        if ekey is None:
            # 目标常常不在网格上：玩家站在车顶 / 台阶中段 / 轨道中间。
            # 【v55】必须先按「与目标同高」找节点，再逐级放宽 —— 否则
            # nearest_node(max_dy=2.6) 会取到**自己这一层**的节点（站台上的
            # 一格），BOT 走到那儿就停住，看起来就是「贴着最近的边观望」。
            hit=None
            for _dy,_r in ((0.7,2),(1.3,3),(2.6,4)):
                hit=self.nearest_node(b,max_dy=_dy,radius=_r)
                if hit is not None:break
            ekey=hit[1] if hit else None
        keys=()
        cache=route if isinstance(route,dict) else None
        reuse=False
        # 【v58】走廊粘滞：只要目标没变（或只小幅移动），就沿用上一次 A* 的
        # **整条走廊**，只把「走到第几个节点」往前推，不再每帧重新规划。
        #
        # 根因（地铁实测）：站台外侧有 4 条对称的「外部→站台」小斜坡
        # （x8~11, z=-28..-25 / -16..-13 / 14..17 / 26..30）。BOT 站在外部
        # 空间中间时四条路几乎等长，A* 的 tie-break 会随**起点所在格**每帧
        # 翻转 → 航点在对角的斜坡之间来回换 → 表现就是「在绿斜坡那块前后
        # 反复横跳」。目标越多（人类多）重算越频繁，抖得越明显。
        if cache is not None and cache.get('keys'):
            full=cache['keys']
            i=int(cache.get('i',0) or 0)
            lo=max(0,i-1);hi=min(len(full),i+10)
            if hi>lo:
                j=min(range(lo,hi),
                      key=lambda k:distance(self.point(full[k]),a))
                # 只接受「自己确实还在这条走廊上」的校准结果。
                if j<len(full)-1 and distance(self.point(full[j]),a)<=3.0:
                    nxt=self.point(full[j+1])
                    same_goal=(cache.get('ekey') is not None
                               and cache.get('ekey')==ekey)
                    near_goal=(cache.get('bpos') is not None
                               and distance(cache['bpos'],b)<2.5)
                    # 目标换了个人，但这条走廊的第一步**仍然在朝新目标靠近**
                    # （站台左/右各站一个人、轨道上又有一人时很常见）：
                    # 继续走这条，别把整条 A* 推倒重算 —— 否则两条对称斜坡
                    # 会跟着目标切换来回翻。
                    still_useful=(
                        skey is not None and ekey is not None
                        and distance(nxt,b)<distance(a,b)-0.5)
                    # 【v58】路径承诺：目标只要还在**这条走廊终点附近**
                    # （12m 内），就先把路走完再重新规划。僵尸在站台追人时，
                    # 人在站台上来回移动 3~5m 极常见；每帧跟着重算就会导致
                    # 「大厅里往 -13 斜坡走到一半、目标挪一下又掉头去 +15」，
                    # 表现出来就是在斜坡口原地前后抽。6 秒强制刷新一次，
                    # 万一承诺错了也能自己纠正。
                    commit=(cache.get('bpos') is not None
                            and distance(full[-1],b)<12.0
                            and int(cache.get('uses',0) or 0)<60)
                    if same_goal or near_goal or still_useful or commit:
                        cache['i']=j
                        cache['uses']=int(cache.get('uses',0) or 0)+1
                        if not (same_goal or near_goal):
                            cache['ekey']=ekey;cache['bpos']=b
                        keys=full[j:]
                        reuse=True
        if not reuse:
            if cache is not None:cache.clear()
            if skey is not None and ekey is not None:
                keys=self.corridor(skey,ekey)
                if not keys:
                    ekey=self.nearest_joinable(skey,b)
                    keys=self.corridor(skey,ekey) if ekey is not None else ()
            if cache is not None and keys:
                cache['ekey']=ekey;cache['keys']=keys;cache['i']=0
                cache['bpos']=b;cache['uses']=0
        if not keys:
            # 【v55】完全连不上（例如 BOT 站在地铁轨道床上 —— 那一层根本没进
            # 网格，最近节点是车顶）。直接朝目标物理推进，交给 `_grounded_step`
            # 逐步校验（它还会挡穿墙/掉落/超速）；绝不能返回 None 让 BOT 站桩。
            return b if distance(a,b)>.05 else None
        # Steering needs the next corner, not the entire smoothed map path.
        pts=[self.point(k) for k in keys[1:13]]
        if len(keys)<=13:pts.append(b)
        if budget is not None:
            # This packet can traverse only one short straight segment. Avoid
            # repeated long-range physics scans for corners it cannot reach.
            near=[p for p in pts if distance(a,p)<=budget+2*self.STEP]
            if near:pts=near
        # 【v15】从最远往回找第一个「既能直连、又给转角留了余量」的点。
        # 加严把远处的贴角直连拒掉后，会自然落到近处的网格节点上 ——
        # 也就是宁可沿 corridor 多走一步，也不要抄近路贴着凸角过去。
        choice=None
        fallback=None
        for p in reversed(pts):
            if distance(a,p)<=.02 or not self.clear(a,p):continue
            if self._corner_ok(a,p):choice=p;break
            fallback=p
        if choice is None:choice=fallback
        if choice is None:
            # 【v54】全部候选都「直连校验不过」时，退回最近的走廊节点。
            # 老逻辑在这里返回 None，调用方就把 newpos 留在原地 —— 地铁图楼梯
            # 中段（BOT 站在两行网格之间）实测就是这样永久怼墙。最近节点可能
            # 只能走一步的一半，但那是 `_grounded_step` 会再分档校验的事，
            # 总比彻底不动好；连续几帧都没位移仍由 BOT-UNSTUCK 兜底换目标。
            cand=[p for p in pts if distance(a,p)>.02]
            choice=min(cand,key=lambda p:distance(a,p)) if cand else None
        if choice is None:
            return b if distance(a,b)>.05 else None
        # 【v55】走廊已经走到头、可真实目标还在外面 —— 典型就是地铁轨道床
        # （那一层没进烘焙网格，最近节点是车顶/站台），BOT 走到走廊最后一格
        # 就再也动不了，看起来像「贴着边缘观望」。这时直接朝目标物理推进。
        if distance(a,choice)<.6 and distance(a,b)>1.0:return b
        return choice


class BakedGrid(Grid):
    def __init__(self,scene,data):
        super().__init__(scene)
        self.source_sha256='collision-grid:'+data.get('source_collision_sha256','unrecorded')
        keys=[tuple(k) for k in data['nodes']]
        self._nodes={};self._links={}
        for i,k in enumerate(keys):
            self._nodes.setdefault((k[0],k[2]),[]).append(k)
            self._links[k]=tuple(keys[j] for j in data['edges'][i])
        self.centers = {k: self.point(k) for k in keys}
        self.component={};comp=0
        for k in keys:
            if k in self.component:continue
            stack=[k];self.component[k]=comp
            while stack:
                for n in self._links[stack.pop()]:
                    if n not in self.component:self.component[n]=comp;stack.append(n)
            comp+=1

    def nodes(self,x,z):return self._nodes.get((x,z),())
    def neighbours(self,k):return self._links.get(k,())


@lru_cache(maxsize=1)
def _data():
    p=Path(__file__).resolve().parent.parent/'gamedata/collision_181.json.gz'
    with gzip.open(p,'rt',encoding='utf-8') as f:return json.load(f)


@lru_cache(maxsize=24)
def for_scene(scene):
    data=_data().get(scene)
    return Scene(data) if data and data['triangles'] else None


@lru_cache(maxsize=8)
def grid_for_scene(scene):
    s=for_scene(scene)
    p=Path(__file__).resolve().parent.parent/'gamedata/collision_grid_181.json.gz'
    if not s or not p.exists():return None
    with gzip.open(p,'rt',encoding='utf-8') as f:data=json.load(f).get(scene)
    return BakedGrid(s,data) if data else None


@lru_cache(maxsize=512)
def spawn_ground(scene, authored):
    """Legal initial placement connected to a walkable region, when available.

    Authored points outside usable terrain need reconstructed placement. A
    collider centroid alone can choose an isolated roof with no walking exit.
    Keep a valid local placement; otherwise choose an actual connected grid
    node nearest the authored point. Never authorize a movement across the gap.
    """
    physical=for_scene(scene)
    if physical is None:return None
    safe=physical.safe_spawn(authored)
    nav=grid_for_scene(scene)
    if nav is None:return safe
    def wire(p):return tuple(round(v*100)/100 for v in p)
    if safe is not None and physical.stand_clear(wire(safe)) and nav.locate(wire(safe)) is not None:
        return safe
    candidates=sorted((distance(authored,nav.point(k)),k) for k in nav._links if nav.neighbours(k))
    for _,k in candidates:
        p=nav.point(k)
        if physical.stand_clear(wire(p)) and nav.locate(wire(p)) is not None:
            logging.getLogger(__name__).warning(
                'SPAWN-GROUND-RECONSTRUCTED scene=%s authored=%s position=%s',scene,authored,p)
            return p
    return None
