"""Projectile serials and reconstructed server-driven BOT grenade throws."""
from dataclasses import dataclass
from functools import lru_cache
import math
import time

from .. import gamedata
from . import damage, special_modes


@dataclass
class Projectile:
    roleid: int
    itemid: int
    round: int
    expires: float
    due: float = 0.0
    landing: dict | None = None


def throw(battle, roleid: int, itemid: int, pos: dict, speed: dict, *, landing=None) -> int:
    from .battle import ID
    fighter = battle.fighters.get(roleid)
    grenade = damage.grenade_row(itemid)
    if (not battle.started or battle.round_over or battle.fight_over or not grenade
            or fighter is None or not fighter.born or fighter.hp <= 0):
        return 0
    limit = getattr(battle.room, "equiplimitid", 0)
    if limit and (limit != special_modes.GRENADE or fighter.equipmap.get(41) != itemid):
        return 0
    now = time.monotonic()
    pending = battle.grenade_projectiles
    for serial, projectile in list(pending.items()):
        if projectile.expires < now or projectile.round != battle.round:
            del pending[serial]
    battle.grenade_serial += 1
    serial = battle.grenade_serial
    due = now + grenade["blastTime"] if landing is not None else 0.0
    pending[serial] = Projectile(roleid, itemid, battle.round, now + grenade["blastTime"] + 10,
                                 due, landing)
    battle.send_all(ID.SC_GRENADE_THROW, roleid=roleid, grenadeid=itemid,
                    pos=pos, speed=speed, serial=serial)
    return serial


def explode(battle, roleid: int, itemid: int, serial: int, pos: dict, *, bot=False) -> bool:
    from .battle import ID
    projectile = battle.grenade_projectiles.get(serial)
    if (not battle.started or battle.round_over or battle.fight_over or projectile is None
            or (projectile.roleid, projectile.itemid, projectile.round) != (roleid, itemid, battle.round)
            or (projectile.landing is not None) != bot or projectile.expires < time.monotonic()):
        return False
    del battle.grenade_projectiles[serial]
    targets = damage.resolve_grenade(battle, roleid, pos, itemid, is_biochem=battle.biochem is not None)
    if battle.challenge is not None:
        monster_targets, dead = battle.challenge.grenade(roleid, itemid, pos)
        targets.extend(monster_targets)
    battle.send_all(ID.SC_GRENADE_EXPLODE, roleid=roleid, pos=pos, grenadeid=itemid,
                    serial=serial, targets=targets)
    if battle.challenge is not None:
        battle.challenge.send_deaths(roleid, itemid, dead)
    for target in targets:
        victim = battle.fighters.get(target["targetid"])
        if victim is not None and victim.hp <= 0 and victim.born:
            battle.on_kill(roleid, victim.roleid, itemid)
    return True


def tick(battle) -> None:
    now = time.monotonic()
    for serial, projectile in list(battle.grenade_projectiles.items()):
        if projectile.expires < now or projectile.round != battle.round:
            del battle.grenade_projectiles[serial]
        elif projectile.landing is not None and projectile.due <= now:
            explode(battle, projectile.roleid, projectile.itemid, serial, projectile.landing, bot=True)


@lru_cache(maxsize=1)
def hand_launcher() -> dict:
    # ClientManager.WeaponChange uses launcher 711001 for slots 41 and 42.
    return next(row for row in gamedata.table("Launcher") if row["id"] == 711001)


def bot_throw(battle, fighter, target, colliders) -> bool:
    """Select a clear low lob toward the target's current ground position."""
    from .bots import _v3
    if colliders is None:
        return False
    x, y, z = fighter.syncpos
    tx, ty, tz = target.syncpos
    origin = (x, y + 1.55, z)
    landing = (tx, ty + 0.2, tz)
    flight = max(0.55, math.dist(origin, landing) / (hand_launcher()["launchSpeed"] * 0.55))
    gravity = 10.0  # Same reconstruction as parkour; Unity handles the visual flight.
    speed = ((tx - x) / flight, (landing[1] - origin[1]) / flight + gravity * flight / 2,
             (tz - z) / flight)
    prev = origin
    for segment in range(1, 9):
        t = flight * segment / 8
        point = (x + speed[0] * t, origin[1] + speed[1] * t - gravity * t * t / 2,
                 z + speed[2] * t)
        if not colliders.clear(prev, point):
            return False
        prev = point
    return bool(throw(battle, fighter.roleid, fighter.equipmap[41], _v3(*origin), _v3(*speed),
                      landing=_v3(*landing)))
