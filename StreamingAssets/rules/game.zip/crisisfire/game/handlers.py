"""Protocol handlers for the game server (GS) and room server.

Wire flow actually implemented by this client build (verified against the
decompiled sources):

    client connect
      -> CsAuanyLogin(1179651)   GsServer.DoLogin(), sent the moment the
                                 socket is up (ConnectionServer.OnConnected)
      <- ScLoginRet(1179650)     retcode 0 -> "GameLoading" (lobby)
                                 retcode 5 -> "CreateCharacter"  (JOIN_NO_ROLE)

    in CreateCharacter:
      -> CsCreateRole(1179652)
      <- ScCreateRole(1179653)   result 0 == ok; the client then re-logs in

The gnet Challenge(101)/Response(103)/OnlineAnnounce(110) handshake is
vestigial in this build: ``Challenge.process()`` and
``OnlineAnnounce.process()`` are empty bodies, so the client never reacts to
them.  Only ``KeyExchange(106)`` has a live ``process()`` (it echoes the
nonce), so we never send it either.
"""
from __future__ import annotations

import logging

from ..config import CONFIG
from ..net.server import ROUTER, Session, add_connect_hook, add_disconnect_hook
from . import (battle, biochem, chat, daily, equipment, exchange, friends,
               gacha, presents, profile, pve, pve_progress, rank_queue, relay, research,
               rewards, robot, room_fill, room_handlers, roulette, shop, talent,
               tasks, vip)
from .world import (LOGIN_BAD_NAME, LOGIN_BAD_PASSWORD, LOGIN_CREATED,
                    LOGIN_OK, World, Role)

log = logging.getLogger("crisisfire.handlers")

world: World | None = None


def bind_world(w: World) -> None:
    """Give the handlers a world and hook session bookkeeping into it."""
    global world
    world = w
    add_connect_hook(lambda s: w.attach(s))
    add_disconnect_hook(on_session_closed)
    room_fill.install()
    rank_queue.install()
    room_handlers.bind_world(w)
    biochem.bind_world(w)
    robot.bind_world(w)
    vip.bind_world(w)
    tasks.bind_world(w)
    shop.bind_world(w)
    gacha.bind_world(w)
    equipment.bind_world(w)
    roulette.bind_world(w)
    friends.bind_world(w)
    presents.bind_world(w)
    daily.bind_world(w)
    exchange.bind_world(w)
    rewards.bind_world(w)
    talent.bind_world(w)
    research.bind_world(w)


# --------------------------------------------------------------------------
# protocol ids used here
# --------------------------------------------------------------------------
class ID:
    KEEPALIVE = 100
    ERROR_INFO = 102
    KEY_EXCHANGE = 106
    CS_PING = 720899
    SC_PING = 720900
    COMMON_KEEPALIVE = 2031617

    SC_PACKAGE_SYNC = 983041          # com.gwebtop.item.ScPackageSync
    SC_ACOUNT_SYNC = 983043           # com.gwebtop.item.ScAcountSync
    SC_SERVER_ID = 8902               # openau.ServerIDResponse
    SC_INIT_USER_RET = 1114116
    SC_USER_INFO = 1114117            # com.gwebtop.user.ScUserInfo
    SC_EQUIP_GROUP = 786433
    SC_FRESHMAN_PROGRESS = 1114123   # com.gwebtop.user.ScFreshmanProgress
    SC_MY_MONEY = 1441942
    SC_MY_DIAMOND = 1441943

    CS_LOGIN = 1179649              # com.gwebtop.login.CsLogin
    SC_LOGIN_RET = 1179650
    CS_AUANY_LOGIN = 1179651
    CS_CREATE_ROLE = 1179652
    SC_CREATE_ROLE = 1179653
    SC_SERVER_DOWN = 1179654
    CS_RECONNECT_LOGIN = 1179655
    SC_ROLE_FORBID = 1179656
    SC_LOGIN_QUEUE_INFO = 1179657

# ScPackageSync.synctype
PKG_ADD = 1
PKG_MODIFY = 2
PKG_INITIALIZE = 3


# retcodes the client understands (ScLoginRet constants)
JOIN_OK = 0
JOIN_NO_ROLE = 5
# Wire retcodes for a rejected login.  Anything other than 0/5/6 makes the
# client call onLoginFailed -> back to the login screen.  5 is "no role" and
# 6 is "server full", so use 1/2 here.
#
# NOTE: these must NOT be named LOGIN_OK / LOGIN_CREATED / LOGIN_BAD_PASSWORD /
# LOGIN_BAD_NAME -- those are the *status strings* imported from .world, and a
# local int of the same name silently shadows them (`"bad_password" == 1` is
# always False, which let a wrong password through).
RET_BAD_PASSWORD = 1
RET_BAD_NAME = 2
JOIN_FULL = 6

# ScCreateRole.result
CREATE_OK = 0
CREATE_NAME_TAKEN = 1
CREATE_BAD_NAME = 5


def _octets_to_str(v) -> str:
    """Client sends Octets; tolerate bytes/str after decoding."""
    if v is None:
        return ""
    if isinstance(v, str):
        return v
    if isinstance(v, (bytes, bytearray)):
        return bytes(v).decode("utf-8", "replace")
    return str(v)


def push_lobby_state(session: Session, role: Role) -> None:
    """Send the messages the lobby UI needs to render the character.

    Traced from the client:

    * ``ServerIDResponse`` -> ``ServerIDResponse.process`` parses the ASCII
      server id, then calls ``UserManager.OnLoginLastProtocol()`` which binds
      the role to the platform SDK and fires the login/register analytics.
      ``serverid`` must be the ASCII digits of an int or ``int.Parse`` throws.
    * ``ScAcountSync`` -> ``UserManager.SynAccount`` fills
      ``userInfo.money/gold/diamond``; ``HeaderMgr.onSynAccount`` writes them
      into the header counters.
    * ``ScUserInfo`` -> ``UserManager.SynUserInfo`` sets ``mUserInfo.id`` and
      ``mUserInfo.pro`` (name, rank, exp, icon, team...), raises
      ``onUserInfoLoaded`` and flips ``isUserInfoLoaded``, which is what gates
      ``UserInfo.Render()`` behind the player card.
    * ``ScPackageSync`` with ``synctype = 3`` makes ``DepotManager`` rebuild
      the whole inventory.  An empty list means "owns nothing", which is what
      leaves the 背包 blank and the equip screen's weapon list empty.
    * ``ScEquipGroup`` -> ``EquipManager.Response`` -- this is what populates
      the loadout carousel on the 选装备 screen.  ``EquipCount`` is
      ``equips.Count``; at zero the carousel has no cells and 确定 does
      nothing, so a player with no loadouts can never start playing.

    ``GameLoading.LoadMainUI`` issues no requests, so the client reaches MainUI
    on the login exchange alone.  Panels that need more (shop, society) request
    it when opened.

    ``ScVipCashSync`` is what makes the shop usable at all: it is the only
    writer of ``RechargeData.vipLevelCurrent``, and ``UserManager.VipStatus``
    is that field.  Left at its default of -1, PackPanel refuses to sell the
    heroic weapon packs, 神秘转盘 stays shut and 超级军备 is hidden.
    """
    from . import equip

    if CONFIG.unlock_equipment and world is not None:
        role = equip.ensure_all_equipment(role, world)

    # 【v50】先撤销 v49 的龙芯片编号迁移，再按背包里龙枪的改装版本
    # 补齐 v49 少发的芯片。两者都必须早于 ScGiftSync / ScPackageSync。
    shop.migrate_legend_gift_ids(world, role)
    research.sync_legend_chips_on_login(world, role)
    # 【v59】怒龙芯片上限 1 个（老存档被 v58 的「每级发一个」刷多的裁掉）
    research.trim_angry_chip(world, role)

    # a brand-new role gets the configured starter recharge so the VIP-gated
    # content is usable out of the box; the GM panel can raise it further
    if vip.cash_of(role) == 0 and CONFIG.default_cash_all > 0:
        vip.set_cash(role, CONFIG.default_cash_all)

    session.send(ID.SC_SERVER_ID, plattype=1,
                 serverid=str(CONFIG.server_id).encode("ascii"))
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    session.send(ID.SC_USER_INFO, roleid=role.roleid, property=_property_of(role))
    session.send(ID.SC_PACKAGE_SYNC, synctype=PKG_INITIALIZE,
                 itemlist=equip.package_items_for(role))
    # 传奇改装卡张数：强化界面读 PromoteLegend.ChipNum，而它只由
    # ScLegendCardSync(1048638) 写入；客户端没有对应的请求消息，所以只能推。
    # 【v49】测试用一次性补发 100 张（marker 防重复），必须在推同步之前。
    equip.grant_login_test_cards(world, role)
    equip.send_legend_cards(session, role)
    session.send(ID.SC_EQUIP_GROUP, equipgroup=equip.equip_group_payload(role))
    # 【v17】关掉大厅「新手教官卡罗琳 → 主页 → 装备 → 主武器位」整串教程。
    # 客户端 GreenHandWizzard 用 UserManager.greenHandProgress 判断要不要弹，
    # 而 isGreenEquipCleared 只在 ScFreshmanProgress 到达时才可能为 true。
    # 私服从不下发这条协议 → 每次登录抽补给箱都重放教程。登录时推一次 14：
    # progress=14（教程走完）+ 0x200/0x400 位为 0（购买/装备教程已完成）。
    # 不置 0x800，训练关按钮和 AGreenGuider 保持原样。
    _guide_done = int(getattr(CONFIG, "lobby_guide_done_progress", 2062) or 0)
    if _guide_done:
        session.send(ID.SC_FRESHMAN_PROGRESS, progress=_guide_done)
    # 已穿戴饰品：客户端没有 CsSubjoinList 请求，DepotManager.decorations 只能由
    # ScSubjoinList(786485) 初始化（DepotManager.cs:132..149）。不推的话，
    # 重登后 Exhibition / Warrior 里的 DepotManager.GetSubjoin() 全部是 -1 ——
    # 上一局明明戴着的面罩/眼镜就没了。
    session.send(equipment.ID.SC_SUBJOIN_LIST,
                 actorsubjoinmap=equip.subjoin_list_payload(role))
    vip.push_on_login(session, role)
    shop.send_gift_sync(session, role)
    tasks.send_sync(session, role)
    from . import pve_rewards
    pve_rewards.send_times(session, role)
    robot.send_level_status(session, role)
    # 好友列表只能由服务端主动下发 —— 客户端没有「请求好友列表」的消息
    friends.push_all(session, role)
    # 签到/在线领奖的 info 也只能由服务端主动下发
    daily.push_on_login(session, role)
    # 兑换券 / 免费转盘次数的余额也只能由服务端主动推
    exchange.send_tickets(session, role)
    # 周卡/黄金周卡的到期时间（WeekCardWindow 靠 ScWeekCardSync 才显示剩余天数）
    shop.push_cards(session, role)
    # 礼盒列表（GiftManager 没有 ScPresentList 就显示空）
    presents.push_on_login(session, role)
    # 天赋面板数据（点数/已加点/强化点）也只能由服务端推
    talent.push_on_login(session, role)
    # 枪械强化：强化点余额(ScStudyPointSync) + 每把枪的进度(ScGunProgress)。
    # 客户端 Strengthener 只认这两条消息，不推的话强化界面全是 0 / 灰按钮。
    research.grant_start_points(role)
    research.push_on_login(session, role)
    # 战斗奖励领奖面板的状态（MissionBar.UpdateState 靠它决定按钮亮不亮）
    rewards.push_all(session, role)
    # 告诉我的好友：我上线了（status == 0 表示在线）
    friends.broadcast_status(role.roleid, online=True)
    (log.debug("pushed lobby state for role %s(%s) VIP%s",
              role.name, role.roleid, vip.level_of(role)) if log.isEnabledFor(10) else None)


def _property_of(role: Role) -> dict:
    """Build the com.gwebtop.user.Property struct for ScUserInfo."""
    import time
    return {
        "rank": role.level,
        "exp": role.exp,
        "createtime": int(role.data.get("createtime", time.time())),
        "name": role.name,
        "iconid": role.iconid,
        "teamid": int(role.data.get("teamid", 0)),
        "teamname": str(role.data.get("teamname", "")),
        "medals": {},
        "medalsshow": {},
        "vipstatus": int(role.data.get("vipstatus", 0)),
        "monthcard": int(pve_progress.month_active(role)),
    }


# --------------------------------------------------------------------------
# GM hooks -- called from the web panel
# --------------------------------------------------------------------------
def push_account_update(role: Role) -> bool:
    """Re-send ScAcountSync/ScUserInfo to a live session after a GM edit.

    Returns True when the role was online and got the update.  The client
    repaints the header counters and the character card on receipt.
    """
    if world is None:
        return False
    session = world.session_of_role(role.roleid)
    if session is None or session.closed:
        return False
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    session.send(ID.SC_USER_INFO, roleid=role.roleid, property=_property_of(role))
    (log.info("GM pushed account update to role %s(%s)", role.name, role.roleid) if log.isEnabledFor(20) else None)
    return True


async def kick_session(session: Session, reason: str = "GM 操作") -> None:
    """Forcibly disconnect a session (GM 'kick')."""
    (log.info("GM kicking %s (%s)", session, reason) if log.isEnabledFor(20) else None)
    await session.close()


def forbid(session: Session, reason: str, remain_seconds: int) -> None:
    """Send ScRoleForbid -> GsServer.TriggerForbiden -> client shows and quits."""
    session.send(ID.SC_ROLE_FORBID, remaintime=int(remain_seconds), reason=reason)


# --------------------------------------------------------------------------
# login
# --------------------------------------------------------------------------
def _finish_login(session: Session, acct, role: Role) -> None:
    """Bind the session to a role, answer ScLoginRet, then push lobby state."""
    session.userid = acct.userid
    session.roleid = role.roleid
    session.role_name = role.name
    world.mark_online(role.roleid, session)
    session.phase = "logged_in"
    # 【v18】原「养成测试首登清零」已删除 —— 用户要的是新号进去就有基础
    # 货币，且退出重登不抹掉额外获得的。这里只给**历史上被那段清成 0 的
    # 存量账号**做一次性补发：按 max(当前值, 基础值) 只增不减，marker 防重复。
    # 放在 push_lobby_state 之前，SC_ACOUNT_SYNC 会自然带上新余额。
    try:
        if not (role.data or {}).get("wallet_base_v18"):
            base = {"money": 10_000, "gold": 500, "diamond": 500}
            vals = {k: max(int(getattr(role, k, 0) or 0), v)
                    for k, v in base.items()}
            world.update_role(role.roleid, **vals)
            for k, v in vals.items():
                setattr(role, k, v)
            world.merge_role_data(role.roleid, wallet_base_v18=True)
            (log.info("账号基础货币补发 role=%s -> %s", role.roleid, vals) if log.isEnabledFor(20) else None)
    except Exception:
        (log.debug("账号基础货币补发失败 role=%s", role.roleid, exc_info=True) if log.isEnabledFor(10) else None)
    (log.info("login ok: %s -> role %r(%s)", session.account, role.name, role.roleid) if log.isEnabledFor(20) else None)
    session.send(ID.SC_LOGIN_RET, retcode=JOIN_OK, roleid=role.roleid, reserved=b"")
    push_lobby_state(session, role)


@ROUTER.register(ID.CS_AUANY_LOGIN, "CsAuanyLogin")
async def on_auany_login(session: Session, msg: dict) -> None:
    """First message the client sends after the socket opens.

    `username` is what the player typed plus the platform suffix
    (`AndroidDelegate.uin => username + platformSurfix`, i.e. "bob$local") and
    `password` is whatever they typed into the LoginWindow's password box.

    Any retcode other than 0/5/6 makes `GsServer.OnLoginRet` call
    `ThirdPartyDelegate.onLoginFailed`, which the patched client turns into
    "go back to the login screen" -- that is how a wrong password surfaces.
    """
    assert world is not None
    username = _octets_to_str(msg.get("username"))
    password = _octets_to_str(msg.get("password"))

    session.account = username or "guest"
    session.password = password
    session.ext = msg.get("challenge") or b""
    session.uuid = msg.get("uuid") or ""
    session.client_version = msg.get("version") or ""
    session.phase = "authed"

    acct, status = world.login(session.account, password)

    if status == LOGIN_BAD_NAME:
        (log.info("login denied (bad name): account=%r", session.account) if log.isEnabledFor(20) else None)
        session.send(ID.SC_LOGIN_RET, retcode=RET_BAD_NAME, roleid=0,
                     reserved=b"")
        await session.close()
        return

    if status == LOGIN_BAD_PASSWORD:
        (log.info("login denied (wrong password): account=%r uuid=%s",
                 session.account, session.uuid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_LOGIN_RET, retcode=RET_BAD_PASSWORD, roleid=0,
                     reserved=b"")
        await session.close()
        return

    (log.info("login %s account=%r uuid=%s ver=%s (%s)", session, username,
             session.uuid, session.client_version,
             "新账号" if status == LOGIN_CREATED else "老账号") if log.isEnabledFor(20) else None)

    banned, reason, until = world.ban_info(session.account)
    if banned:
        import time as _t
        remain = int(max(0, until - _t.time())) if until else 0
        text = reason or "账号已被封禁"
        (log.info("login denied (banned): account=%r reason=%r remain=%ss",
                 session.account, text, remain) if log.isEnabledFor(20) else None)
        forbid(session, text, remain)
        await session.close()
        return

    if not acct.roles:
        # JOIN_NO_ROLE -> client loads the CreateCharacter scene
        (log.info("account %r has no role -> retcode=%s", session.account, JOIN_NO_ROLE) if log.isEnabledFor(20) else None)
        session.send(ID.SC_LOGIN_RET, retcode=JOIN_NO_ROLE, roleid=0, reserved=b"")
        return

    _finish_login(session, acct, acct.roles[0])


@ROUTER.register(ID.CS_LOGIN, "com.gwebtop.login.CsLogin")
async def on_login(session: Session, msg: dict) -> None:
    """Re-login carrying an existing session identity."""
    assert world is not None
    username = msg.get("username") or session.account
    session.account = username
    acct, status = world.login(username, session.password)
    if status not in (LOGIN_OK, LOGIN_CREATED):
        session.send(ID.SC_LOGIN_RET, retcode=RET_BAD_PASSWORD, roleid=0,
                     reserved=b"")
        await session.close()
        return
    if not acct.roles:
        session.send(ID.SC_LOGIN_RET, retcode=JOIN_NO_ROLE, roleid=0, reserved=b"")
        return
    _finish_login(session, acct, acct.roles[0])


@ROUTER.register(ID.CS_RECONNECT_LOGIN, "CsReconnectLogin")
async def on_reconnect_login(session: Session, msg: dict) -> None:
    """Sent by GsServer.DoRejoin() after the socket was retried."""
    assert world is not None
    roleid = int(msg.get("roleid") or 0)
    role = world.role(roleid) or (world.role(session.roleid) if session.roleid else None)
    if role is None and roleid == 0 and not session.roleid:
        # 客户端清过本地状态时 roleid 传 0（run4 实测）——按最近活跃角色兜底
        role = world.most_recent_role()
        if role is not None:
            (log.info("rejoin: roleid=0, fallback to most recent role %r(%s)",
                     role.name, role.roleid) if log.isEnabledFor(20) else None)
    if role is None:
        session.send(ID.SC_LOGIN_RET, retcode=JOIN_NO_ROLE, roleid=0, reserved=b"")
        return
    if world.is_online(role.roleid) and world.session_of_role(role.roleid) is not session:
        (log.info("rejoin: kicking stale session for role %s", role.roleid) if log.isEnabledFor(20) else None)
        stale = world.session_of_role(role.roleid)
        if stale is not None:
            await stale.close()
    # A rejoin arrives on a fresh socket, so derive the account from the role
    # rather than from session.account (which is empty here).
    acct = world.account_for_role(role)
    if acct is None:
        session.send(ID.SC_LOGIN_RET, retcode=JOIN_NO_ROLE, roleid=0, reserved=b"")
        return
    session.account = acct.account
    (log.info("rejoin %s -> role %r(%s)", session, role.name, role.roleid) if log.isEnabledFor(20) else None)
    _finish_login(session, acct, role)


# --------------------------------------------------------------------------
# role creation
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_CREATE_ROLE, "CsCreateRole")
async def on_create_role(session: Session, msg: dict) -> None:
    assert world is not None
    name = (msg.get("name") or "").strip()
    iconid = int(msg.get("iconid") or 0)
    police = int(msg.get("policeactorid") or 0)
    terrist = int(msg.get("terristactorid") or 0)
    inviter = int(msg.get("inviterid") or 0)

    if not name:
        session.send(ID.SC_CREATE_ROLE, result=CREATE_BAD_NAME)
        return
    if world.role_named(name) is not None:
        session.send(ID.SC_CREATE_ROLE, result=CREATE_NAME_TAKEN)
        return

    # Re-fetch with the session's own password: the account already exists and
    # was verified at login, so this only re-reads it.
    acct, status = world.login(session.account, session.password)
    if status not in (LOGIN_OK, LOGIN_CREATED) or not acct.userid:
        log.warning("create_role with an unusable account %r (%s)",
                    session.account, status)
        session.send(ID.SC_CREATE_ROLE, result=CREATE_BAD_NAME)
        return
    role = world.create_role(
        acct, name, iconid=iconid,
        policeactorid=police, terristactorid=terrist, inviterid=inviter,
    )
    session.send(ID.SC_CREATE_ROLE, result=CREATE_OK)
    (log.info("role created: %s -> %r(%s)", session, role.name, role.roleid) if log.isEnabledFor(20) else None)

    # The client does NOT move itself on.  CharacterCreater.OnConfirm shows the
    # "waiting" spinner and OnRoleCreatedResult only reacts to *failures*
    # (result != 0); nothing hides the spinner or changes scene on success.
    # The scene change comes from GsServer.LoginSuccess -> SdkHandler.OnGsLogin,
    # which only ScLoginRet(retcode=0) fires.  So the server must log the player
    # straight in after creating the role, or the client spins forever.
    _finish_login(session, acct, role)


# --------------------------------------------------------------------------
# keepalive / liveness
# --------------------------------------------------------------------------
@ROUTER.register(ID.KEEPALIVE, "gnet.KeepAlive")
async def on_keepalive(session: Session, msg: dict) -> None:
    """**只收不回。**

    客户端的 KeepAlive 处理是「收到就回发一条」：
        public static void KeepAlive(KeepAlive alive)
        { GsServer.Instance.Send(new KeepAlive()); }
    服务端要是也回，就变成无限乒乓 —— 连接被刷爆，玩家进对局几秒就掉线
    并退回登录界面（实测）。
    收到本身就够更新 last_recv 了，不需要回应。
    """
    return


@ROUTER.register(ID.COMMON_KEEPALIVE, "com.gwebtop.common.KeepAlive")
async def on_common_keepalive(session: Session, msg: dict) -> None:
    """只收不回 —— 客户端收到这条会自己回发，再回就是死循环。
    见上面 on_keepalive 的说明。"""
    return


@ROUTER.register(ID.CS_PING, "CsPing")
async def on_ping(session: Session, msg: dict) -> None:
    import time
    session.send(ID.SC_PING, ts=int(time.time() * 1000))


@ROUTER.register(ID.KEY_EXCHANGE, "gnet.KeyExchange")
async def on_key_exchange(session: Session, msg: dict) -> None:
    """The client echoes this back if we ever send one; accept it quietly."""
    (log.debug("KeyExchange from %s: blkickuser=%s", session, msg.get("blkickuser")) if log.isEnabledFor(10) else None)


# --------------------------------------------------------------------------
# lifecycle
# --------------------------------------------------------------------------
def on_session_closed(session: Session) -> None:
    if world is not None:
        world.detach(session)
        if session.roleid:
            # 房间连接意外断开：只要 GS 还活着、房间仍在对局中，就先保留
            # 角色和 Battle 给客户端一个重连窗口；旧连接迟到的 close 也会
            # 在这里被识别（新连接已接管角色），不会把新人踢掉。
            if room_handlers.retain_room_connection(session):
                return
            # ScFightEnd closes only the room connection. A live GS connection
            # still owns the lobby slot and must be able to start another game.
            room = room_handlers.MANAGER.room_of(session.roleid)
            previous = battle.BATTLES.get(room.roomid) if room else None
            gs = world.session_of_role(session.roleid, 'gs')
            if (session.kind == 'room' and previous is not None
                    and previous.fight_over and gs is not None and not gs.closed):
                # 整场已经结束：取消重连保留，回到原来的「保留大厅房位」语义。
                room_handlers.cancel_room_reconnect_graces(room.roomid, "fight over")
                member = room.members.get(session.roleid)
                if member is not None:member.ready = False
                room_fill.fill(room)
                room_handlers._sync_room(room)
                (log.info('finished room connection closed; retained lobby role=%s room=%s',
                         session.roleid, room.roomid) if log.isEnabledFor(20) else None)
                return
            try:
                room_handlers.cleanup_role(session.roleid)
            except Exception:
                log.exception("room cleanup failed for role %s", session.roleid)
            try:
                # 好友列表里的在线状态（status != 0 = 离线）
                friends.broadcast_status(session.roleid, online=False)
            except Exception:
                log.exception("friend offline broadcast failed for role %s",
                              session.roleid)
    (log.debug("session closed: %s", session) if log.isEnabledFor(10) else None)
