"""Human BOT weapon/ammo + ground-tactics policy (reconstructed).

This module is deliberately independent from the production BOT driver so the
main coordinator can review and test it without a device or database.

Native values (read from the shipped tables / decompiled client):
    Gun.clip            magazine size
    Gun.ammo            clip + reserve; reserve == ammo - clip
    Gun.shootSpeed      seconds per trigger/shot (AGun.ShootFreq)
    Gun.reloadSpeed     reload time list (AGun.Synchs reloadTimes)
    Gun.reloadType      1 -> reloadTimes[0] is the whole reload (AGun.cs:701-707)
    Gun.effectiveRange  weapon engagement range
    Gun.speedDown       AWeapon.SpeedDown -> Warrior.SpeedDown (Warrior.cs:296)
    Gun.ammoBio         only used by BuffCounter.GainAmmoAddition with an
                        Ammobag of type 1.  PlayerData.Init/FillAmmoAll use
                        Gun.ammo - Gun.clip, never ammoBio, as reserve.
    Antiknock.Init      VelocityRun = 7f for every non-bio warrior.

The weapon catalogue verifies each item's native resources. BOT equipment
draws from its basic-variant subset, while player and form equipment are
resolved independently.

Reconstructed policy (clearly marked RECONSTRUCTED): reaction window, preferred
distance, patrol/cover scoring, strafe distance, shot catch-up cap, tactical
hold/cooldown.  They are not native rules.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

try:                                      # package import (production)
    from . import weapon_catalog as WC
except ImportError:                       # direct file import (tests)
    try:
        import weapon_catalog as WC       # type: ignore
    except ImportError:                   # fail closed
        WC = None                             # type: ignore

POS_MAIN_GUN = 11
POS_VICE_GUN = 12
POS_MELEE = 50
BIOCHEM_MODES = (8, 10)

# Reconstructed tactical hold/cooldown.  The client's WeaponChange has its own
# draw animation; these values only stop per-tick flip-flopping server-side.
MIN_HOLD_SECONDS = 0.45
SWITCH_COOLDOWN_SECONDS = 1.20
URGENT_MIN_HOLD_SECONDS = 0.15
CLOSE_RANGE_M = 8.0

# Native movement: Antiknock.Init sets VelocityRun = 7f; a non-user has
# speedAcc = 0 (Warrior.cs:726), and Warrior.SpeedDown subtracts armorSpeedDown
# (0: the BOT carries no armor item) plus AGun.speedDown while running.
HUMAN_RUN_SPEED = 7.0

# RECONSTRUCTED policy constants.
REACTION_WINDOW = 0.9         # seconds for a zombie to close one reaction window
SAFE_MARGIN = 1.5             # metres of extra separation
ZOMBIE_REACH = 2.7            # BioProperty.range (native, all rows)
ZOMBIE_MAX_SPEED = 8.2        # BioProperty.runSpeed max in shipped data
STRAFE_DISTANCE = 3.5
MIN_SAFE_DISTANCE = 6.0
PREFERRED_EXTRA = 4.0
MIN_PREFERRED = 22.0
# One claw plus half a second of ghost movement, rounded to a 7 m formation gap.
# This is a BOT positioning preference, independent of the damage radius.
FORMATION_GAP = 7.0

# Bounded shot catch-up.  The room clock now dispatches bots.tick at 10 Hz
# (0.1 s), so a normal dispatch releases ~1 due shot even for MG4 (0.1 s).
# Cap the per-dispatch catch-up at 2: a stalled tick must never replay a
# burst of 3+ fully-damaging settle_shoot calls in one frame (the "1300 HP
# deleted instantly" symptom).  Burst weapons still emit all their rays via
# needs_multi/_fire_volleys, which is a single native ScMultiShoot trigger.
MAX_SHOTS_PER_TICK = 2

# A retreat destination is validated against at most this many candidate
# corridors (each one is a cached baked-corridor query, not a full path smooth).
MAX_PATH_CANDIDATES = 3
MAX_CORRIDOR_POINTS = 16
CORRIDOR_SAMPLE_M = 2.0


# ---------------------------------------------------------------------------
# Table readers (cached indexes; production Tick must not rebuild Item/Gun)
# ---------------------------------------------------------------------------
_TABLE_INDEX: Dict[str, Dict[int, Dict[str, Any]]] = {}


def _by_id(rows: Optional[Iterable[Mapping[str, Any]]]
           ) -> Dict[int, Dict[str, Any]]:
    if rows is None:
        return {}
    if isinstance(rows, Mapping):
        return {int(k): v for k, v in rows.items() if isinstance(v, Mapping)}
    out: Dict[int, Dict[str, Any]] = {}
    for row in rows:
        try:
            out[int(row.get("id") or 0)] = row
        except (TypeError, ValueError, AttributeError):
            continue
    return out


def _table(name: str) -> List[Dict[str, Any]]:
    try:
        from .. import gamedata
        return gamedata.table(name) or []
    except ImportError:
        # Direct file import (tests).  weapon_catalog has the same fallback.
        if WC is not None:
            return list(WC._table(name))
        raise


def _table_index(name: str) -> Dict[int, Dict[str, Any]]:
    """Index one shipped table once per process (gamedata.table is cached too)."""
    hit = _TABLE_INDEX.get(name)
    if hit is not None:
        return hit
    idx = _by_id(_table(name))
    _TABLE_INDEX[name] = idx
    return idx


def clear_table_cache() -> None:
    """Tests only: drop the Item/Gun index cache."""
    _TABLE_INDEX.clear()


def _lookup(rows, name: str, iid: int) -> Optional[Mapping[str, Any]]:
    if rows is None:
        return _table_index(name).get(int(iid))
    if isinstance(rows, Mapping):
        return rows.get(int(iid))
    return _by_id(rows).get(int(iid))


def _reload_values(raw: Any) -> List[float]:
    if raw is None:
        return []
    if isinstance(raw, Mapping):
        raw = raw.get("_items") or raw.get("items") or []
    if isinstance(raw, (int, float)):
        return [float(raw)]
    out: List[float] = []
    for value in raw:
        try:
            out.append(float(value))
        except (TypeError, ValueError):
            continue
    return out


def _i(row: Mapping[str, Any], key: str, default: int = 0) -> int:
    try:
        return int(row.get(key) or default)
    except (TypeError, ValueError):
        return default


def _f(row: Mapping[str, Any], key: str, default: float = 0.0) -> float:
    try:
        return float(row.get(key) or default)
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class GunInfo:
    itemid: int
    slot: int
    clip: int
    ammo: int
    ammo_bio: int
    shoot_speed: float
    shoot_interval: float
    fire_per_shot: int
    bullet_per_shot: int
    reload_seconds: float
    reload_type: int
    effective_range: float
    basic_damage: float
    bio_damage: float
    speed_down: float
    resource: str
    tex: int
    category: str = ""
    base_id: int = 0
    display_name: str = ""
    # AGun.Synch: grapeshotdistribution / hitRange drive the multi-ray cone.
    grapeshot: int = 1
    hit_radius: float = -1.0
    reload_stages: Tuple[float, float, float] = (0.,0.,0.)
    # ---- 真实枪械参数（bot 弹道要用，原来完全没读）------------------
    # 散布：每个姿态一对「最小/最大」角度（度）。连发时从 min 往 max 涨，
    # 停火按 distributionRecovery 回落。四舍五入到 0.001 就够，表里是 float32。
    dist_min_stand: float = 0.0
    dist_max_stand: float = 0.0
    dist_min_walk: float = 0.0
    dist_max_walk: float = 0.0
    dist_min_run: float = 0.0
    dist_max_run: float = 0.0
    dist_min_crouch: float = 0.0
    dist_max_crouch: float = 0.0
    spread_grow: float = 0.0            # distributionPlusPerBulletStand
    spread_recovery: float = 0.0        # distributionRecovery
    # 距离衰减：effectiveRange 内满伤，到 maximumRange 线性降到 minDamage
    max_range: float = 0.0
    min_damage: float = 0.0
    penetration: float = 0.0
    act_type: int = 0                 # Gun.actType：6 = 狙击

    @property
    def reserve(self) -> int:
        return max(0, self.ammo - self.clip)

    @property
    def renderable(self) -> bool:
        return _texture_ok(self.resource, self.tex)

    @property
    def shot_period(self) -> float:
        """Native per-shot cadence: AGun.FireTask waits Gun.shootSpeed."""
        return max(0.02, self.shoot_speed)


def _base_id(itemid: int) -> int:
    if WC is None:
        return int(itemid)
    try:
        return WC.catalog().base_id(int(itemid))
    except Exception:
        return int(itemid)


def _texture_ok(resource: Any, tex: Any) -> bool:
    """Resource/material pair must be in the audited present set.

    ``tex`` is the client's native material index (AArsenal passes texid to
    AssetLoader); it is *not* a "skin means unusable" flag.
    """
    if WC is not None:
        return WC.texture_verified(resource, tex)
    try:
        return int(tex) == 0 and bool(str(resource or "").strip())
    except (TypeError, ValueError):
        return False


@dataclass(frozen=True)
class MeleeInfo:
    """Melee row read directly from Melee.json (AMelee.Synch)."""
    itemid: int
    name: str
    range: float
    speed: float
    damage: float
    bio_damage: float
    fan_angle: float
    resource: str
    tex: int
    base_id: int = 0

    @property
    def renderable(self) -> bool:
        return _texture_ok(self.resource, self.tex)

    @property
    def shot_period(self) -> float:
        return max(0.05, self.speed)

    @property
    def speed_down(self) -> float:
        # AMelee inherits AWeapon.SpeedDown => 0f (AWeapon.cs:161); holding a
        # knife therefore restores the full Antiknock VelocityRun.
        return 0.0


def ammobag_bonus(itemid: int, ammobags: Iterable[int] = (),
                  items=None, guns=None) -> Tuple[int, int]:
    """复刻客户端 `BuffCounter.GainAmmoAddition` 的弹匣备弹加成。

    Ammobag 表：
      * type=0 枪种弹匣（910001~910006）—— `gunSubType` 命中就 + Gun.ammoAdd，
        数值上正好是 **2 个弹匣**的备弹（AK47 30 发/匣 -> +60）。
      * type=1 生化弹匣（910007）—— `gunSubType` 覆盖 11~16 全枪种，
        + Gun.ammoBio，正好 **1 个弹匣**（AK47 +30）。

    客户端虽然定义了 GainAmmoAddition，但**全工程没有任何一处调用它**，
    所以弹匣道具买回来毫无效果。这里由服务端算出加成，直接写进 ScBorn 的
    mainbullet / minorbullet（客户端 PlayerData.Apply 会拿它当备弹上限）。
    """
    owned = {int(x) for x in (ammobags or ()) if int(x or 0) > 0}
    if not owned:
        return 0, 0
    item = _lookup(items, "Item", int(itemid))
    gun = _lookup(guns, "Gun", int(itemid))
    if not item or not gun:
        return 0, 0
    sub = _i(item, "subType")
    add = bio = 0
    for row in _table("Ammobag"):
        try:
            bid = int(row.get("id") or 0)
        except (TypeError, ValueError):
            continue
        if bid not in owned:
            continue
        raw = row.get("gunSubType")
        subs = raw.get("_items") if isinstance(raw, Mapping) else raw
        if not isinstance(subs, (list, tuple)):
            continue
        if sub not in [int(x or 0) for x in subs]:
            continue
        if _i(row, "type") == 1:
            bio += _i(gun, "ammoBio")
        else:
            add += _i(gun, "ammoAdd")
    return add, bio


def load_gun(itemid: int, items=None, guns=None,
             require_renderable: bool = True,
             ammobags: Iterable[int] = ()) -> Optional[GunInfo]:
    """Read one Gun + Item row.  Missing/skin-only items fail closed.

    With items/guns omitted (the production path) the Item/Gun indexes are
    built once and reused; only explicit test tables are indexed per call.
    """
    iid = int(itemid or 0)
    item = _lookup(items, "Item", iid)
    gun = _lookup(guns, "Gun", iid)
    if not item or not gun:
        return None
    slot = _i(item, "equipPos")
    if slot not in (POS_MAIN_GUN, POS_VICE_GUN):
        return None
    tex = _i(item, "tex")
    resource = str(item.get("resource") or "").strip()
    if require_renderable and not _texture_ok(resource, tex):
        return None
    clip = max(0, _i(gun, "clip"))
    _add, _bio = ammobag_bonus(iid, ammobags, items, guns)
    ammo = max(clip, _i(gun, "ammo")) + _add + _bio
    if clip <= 0:
        return None
    shoot_speed = _f(gun, "shootSpeed")
    if shoot_speed <= 0:
        return None
    reloads = _reload_values(gun.get("reloadSpeed"))
    reload_type = _i(gun, "reloadType")
    if reload_type == 1 and reloads:
        reload_seconds = reloads[0]
    elif reload_type == 3 and len(reloads) >= 3:
        reload_seconds = reloads[0] + clip * reloads[1] + reloads[2]
    else:
        reload_seconds = sum(reloads)
    if reload_seconds <= 0:
        reload_seconds = 2.5          # fail-safe only; selected MGs read 4.4 s
    category = WC.category_of(item) if WC is not None else ""
    base_id = _base_id(iid)
    return GunInfo(
        itemid=iid, slot=slot, clip=clip, ammo=ammo,
        ammo_bio=max(0, _i(gun, "ammoBio")),
        shoot_speed=shoot_speed,
        shoot_interval=max(0.0, _f(gun, "shootInterval")),
        fire_per_shot=max(1, _i(gun, "firePerShoot", 1)),
        bullet_per_shot=max(1, _i(gun, "bulletPerShoot", 1)),
        reload_seconds=max(0.05, reload_seconds),
        reload_type=reload_type,
        effective_range=max(1.0, _f(gun, "effectiveRange", 35.0)),
        basic_damage=_f(gun, "basicDamage"),
        bio_damage=_f(gun, "bioDamage"),
        speed_down=max(0.0, _f(gun, "speedDown")),
        resource=resource, tex=tex, category=category,
        base_id=int(base_id),
        display_name=str(item.get("name") or ""),
        grapeshot=max(0, _i(gun, "grapeshotdistribution", 1)),
        hit_radius=_f(gun, "hitRange", -1.0),
        reload_stages=tuple((reloads+[0.,0.,0.])[:3]),
        dist_min_stand=_f(gun, "minDistributionStand"),
        dist_max_stand=_f(gun, "maxDistributionStand"),
        dist_min_walk=_f(gun, "minDistributionWalk"),
        dist_max_walk=_f(gun, "maxDistributionWalk"),
        dist_min_run=_f(gun, "minDistributionRun"),
        dist_max_run=_f(gun, "maxDistributionRun"),
        dist_min_crouch=_f(gun, "minDistributionCrouch"),
        dist_max_crouch=_f(gun, "maxDistributionCrouch"),
        spread_grow=_f(gun, "distributionPlusPerBulletStand"),
        spread_recovery=_f(gun, "distributionRecovery"),
        max_range=_f(gun, "maximumRange"),
        min_damage=_f(gun, "minDamage"),
        penetration=_f(gun, "penetration"),
        act_type=_i(gun, "actType"),
    )


def load_melee(itemid: int, items=None, melees=None,
               require_renderable: bool = True) -> Optional[MeleeInfo]:
    """Read one Melee + Item row.  Unknown resources fail closed.

    Melee range/speed/damage come from Melee.json only; GunInfo is never used
    for a knife (AMelee.Synch reads Melee.range/speed, damage.resolve_shoot
    reads Melee.damag/bioDamage).
    """
    iid = int(itemid or 0)
    item = _lookup(items, "Item", iid)
    melee = _lookup(melees, "Melee", iid)
    if not item or not melee:
        return None
    if _i(item, "equipPos") != POS_MELEE:
        return None
    tex = _i(item, "tex")
    resource = str(item.get("resource") or "").strip()
    if require_renderable and not _texture_ok(resource, tex):
        return None
    rng = _f(melee, "range")
    speed = _f(melee, "speed")
    if rng <= 0 or speed <= 0:
        return None
    base_id = _base_id(iid)
    return MeleeInfo(
        itemid=iid, name=str(item.get("name") or ""), range=rng, speed=speed,
        damage=_f(melee, "damag"), bio_damage=_f(melee, "bioDamage"),
        fan_angle=_f(melee, "fanAngle"), resource=resource, tex=tex,
        base_id=int(base_id))


def trigger_rays(info: Optional[Any]) -> int:
    """AGun.Synch: harmPerFire = max(shootPerFire, bulletPerShoot).

    This is the ray count of the *first* OneShot of a trigger, independent of
    how many magazine rounds are left.  Native ``firstTrigger`` is
    ``shootSurplus == shootPerFire - 1`` and runs before the loop can notice
    that only one round remained, so a one-round-left burst still emits the
    full harmPerFire group (AGun.cs:527-554).  We reproduce that boundary
    instead of silently emitting ``min(rounds, harmPerFire)`` rays.
    """
    if info is None:
        return 1
    return max(1, int(getattr(info, "fire_per_shot", 1) or 1),
               int(getattr(info, "bullet_per_shot", 1) or 1))


def move_speed(info: Optional[Any]) -> float:
    """Native run speed minus held weapon's SpeedDown (armor is 0).

    GunInfo -> Gun.speedDown (AGun.SpeedDown); MeleeInfo -> 0 (AMelee inherits
    AWeapon.SpeedDown => 0f).  Neither jump height nor run constants change.

    【狂暴版】两条调整：
      * 拿刀 -> HUMAN_RUN_SPEED + human_melee_speed_bonus（默认 +2 = 9 m/s）
      * 手枪 -> 不计持枪降速（human_pistol_no_slow=1 时跑满 7 m/s）

    注意：真人玩家的位移由**客户端**执行（Antiknock.VelocityRun 写死 7f，
    再减 Warrior.SpeedDown），服务端这里的改动只影响服务端驱动的 BOT。
    """
    from ..config import CONFIG
    if isinstance(info, MeleeInfo):
        try:
            bonus = float(getattr(CONFIG, "human_melee_speed_bonus", 0.0) or 0.0)
        except (TypeError, ValueError):
            bonus = 0.0
        return HUMAN_RUN_SPEED + max(0.0, bonus)
    down = float(getattr(info, "speed_down", 0.0) or 0.0) if info is not None else 0.0
    try:
        _pistol_free = int(getattr(CONFIG, "human_pistol_no_slow", 0) or 0) > 0
    except (TypeError, ValueError):
        _pistol_free = False
    if _pistol_free and str(getattr(info, "category", "") or "") == "pistol":
        down = 0.0
    return max(1.0, HUMAN_RUN_SPEED - down)


def bot_loadout(index: int = 0, round_index: int = 0, *, seed: int = 0) -> Dict[int, int]:
    """Draw the biochem human BOT equipment from the basic weapon pool."""
    return WC.basic_bot_loadout(index, round_index, seed=seed) if WC is not None else {}


def resolve_loadout(loadout: Mapping[int, int], items=None, guns=None,
                    melees=None) -> Dict[int, int]:
    """Keep only slots whose ids exist and render.  Never invent a weapon."""
    out: Dict[int, int] = {}
    for slot, raw in (loadout or {}).items():
        try:
            slot, iid = int(slot), int(raw)
        except (TypeError, ValueError):
            continue
        item = _lookup(items, "Item", iid)
        if not item or _i(item, "equipPos") != slot:
            continue
        if slot in (POS_MAIN_GUN, POS_VICE_GUN):
            if load_gun(iid, items, guns) is not None:
                out[slot] = iid
        elif slot == POS_MELEE:
            if load_melee(iid, items, melees) is not None:
                out[slot] = iid
    return out


def equip_for_bot(gamemode: int, index: int = 0, *, is_bot: bool,
                  is_zombie: bool = False, is_hero: bool = False,
                  items=None, guns=None, round_index: int = 0, seed: int = 0
                  ) -> Optional[Dict[int, int]]:
    """Equipment override only for biochem 8/10 human BOTs.

    Normal modes, real players, zombies and heroes return None so the caller
    leaves their saved/hero equipment untouched.
    """
    if not is_bot or int(gamemode or 0) not in BIOCHEM_MODES:
        return None
    if is_zombie or is_hero:
        return None
    return resolve_loadout(bot_loadout(index, round_index, seed=seed), items, guns)


# ---------------------------------------------------------------------------
# Finite ammunition
# ---------------------------------------------------------------------------
@dataclass
class SlotAmmo:
    info: GunInfo
    clip: int = 0
    reserve: int = 0


class AmmoState:
    """Server-side magazine/reserve model; no implicit ammo creation."""

    def __init__(self, guns: Mapping[int, GunInfo], full: bool = True):
        self.slots: Dict[int, SlotAmmo] = {}
        # 【v61】额外弹匣数（只给 BOT 用）。`Gun.ammo` 是「总弹数」，备弹 =
        # ammo - clip，一把机枪常常只有 1~2 个备用弹匣，生化里 8 个人打一局
        # 远远不够 —— 用户要求「给生化 BOT 加多两个弹匣」。真人玩家不走这里
        # （他们有自己的客户端弹药，服务端这个模型只管 BOT）。
        self.mag_bonus = 0
        for slot, info in guns.items():
            self.slots[int(slot)] = SlotAmmo(
                info, info.clip if full else 0,
                self.full_reserve(info) if full else 0)
        self.active = POS_MAIN_GUN if POS_MAIN_GUN in self.slots else (
            POS_VICE_GUN if POS_VICE_GUN in self.slots else 0)
        self.reload_slot = 0
        self.reload_until = 0.0
        self.last_shot = -1e18
        # AGun.FireTask: one trigger event per Gun.shootSpeed, containing
        # firePerShoot rounds spaced Gun.shootInterval.  bulletPerShoot is the
        # pellet count and never consumes extra magazine rounds.
        self.last_event = -1e18
        self.burst_left = 0
        self.next_round_at = 0.0
        # AGun.OneShot emits the native ray group only on the first round of a
        # trigger (firstTrigger); the remaining firePerShoot-1 rounds only
        # spend a magazine round.  Keep that distinction across dispatches so
        # a 1+2 split of one 3-round trigger emits 3 rays, not 3+3.
        self.burst_ray_pending = False
        self.trigger_seq = 0
        self.ray_events: List[Dict[str, Any]] = []
        # 【v23】仅 BOT：狙击（actType==6）开火间隔倍率。默认 1.0，真人不变。
        self.bot_sniper_scale = 1.0

    @staticmethod
    def _overhead() -> float:
        """每发多出来的「客户端帧开销」（秒）。

        真人开火是逐帧驱动的（TouchRotator/GamePadInput 里
        `if (weapon.IsIdle()) weapon.Attack()`），一发要占掉
        「OneShot 一帧 + 输入循环下一帧才重新扣扳机」两帧，
        所以真实射速 ≈ Gun.shootSpeed + 2/fps。30fps 下 AK 实测 5~6 发/秒，
        RPD 一梭 70 发要 10 多秒 —— 和表值（8.3 发/秒、8.4 秒）差的就是这两帧。
        BOT 直接用表值会比真人快 30~50%，这里补回同样的开销。
        """
        try:
            from ..config import CONFIG
            return max(0.0, float(getattr(CONFIG, "bot_fire_overhead", 0.06) or 0.0))
        except (TypeError, ValueError):
            return 0.0

    def period_of(self, state: Optional["SlotAmmo"] = None) -> float:
        """当前槽位的真实发间隔（表值 + 客户端帧开销 + BOT 狙击倍率）。"""
        state = state if state is not None else self.slots.get(self.active)
        if state is None:
            return 0.0
        base = max(1e-3, float(state.info.shot_period) + self._overhead())
        # 【v23】BOT 拿狙击（Gun.actType==6）按倍率放慢；真人 bot_sniper_scale=1.0 不变。
        if self.bot_sniper_scale > 1.0 and int(getattr(state.info, "act_type", 0)) == 6:
            base *= self.bot_sniper_scale
        return base

    def trigger_period_of(self, state: Optional["SlotAmmo"] = None) -> float:
        """**一次扣扳机**的最小间隔。

        【v39】三连发枪（``firePerShoot>1``：M93R / FAMAS / M16A4 等 14 把）
        以前用面板 period(0.33~0.45s) 当触发间隔，而一梭 3 发只用 3×0.055s
        就打完了 -> 实际节奏 3 发/0.35s ≈ 8.6 发/秒，听感就是「三连发的射速
        打全自动」。现在**最后一发打完**再等 ``bot_burst_period``（0.6s）
        才开下一梭（梭头到梭头 ≈ 0.11+0.6 = 0.71s）；面板 period 更慢的枪
        仍按面板（不会反而加快）。
        """
        base = self.period_of(state)
        state = state if state is not None else self.slots.get(self.active)
        if state is None:
            return base
        try:
            burst = max(1, int(getattr(state.info, "fire_per_shot", 1) or 1))
        except (TypeError, ValueError):
            burst = 1
        if burst <= 1:
            return base
        from ..config import CONFIG
        try:
            floor = float(getattr(CONFIG, "bot_burst_period", 0.6) or 0.0)
        except (TypeError, ValueError):
            floor = 0.6
        return max(base, floor)

    def _reset_burst(self) -> None:
        """Forget an unfinished trigger (hold/switch/reload/long pause)."""
        self.burst_left = 0
        self.next_round_at = 0.0
        self.burst_ray_pending = False

    def drain_ray_events(self) -> List[Dict[str, Any]]:
        """Return and clear the native MultiShoot groups for this dispatch.

        Only trigger-first rounds produce an event; continuation rounds of a
        burst are consumed by ``take_shots`` but never produce a second ray
        group.  Guns with harmPerFire == 1 stay on the ordinary ScShoot path
        and therefore record no event.
        """
        out = list(self.ray_events)
        self.ray_events = []
        return out

    def _record(self, slot: int) -> None:
        """Compatibility hook; the per-id view is derived from live slots.

        Keeping ``ammo_by_id`` derived means a direct test/debug clip edit is
        visible immediately, while slot identity and the finite rounds remain
        the single source of truth.  A weapon switch never re-creates a slot.
        """
        return None

    @property
    def ammo_by_id(self) -> Dict[int, Dict[str, int]]:
        out: Dict[int, Dict[str, int]] = {}
        for slot, state in self.slots.items():
            out[int(state.info.itemid)] = {
                "slot": int(slot), "clip": int(state.clip),
                "reserve": int(state.reserve),
                "maxclip": int(state.info.clip),
            }
        return out

    def ammo_for(self, itemid: int) -> Optional[Dict[str, int]]:
        row = self.ammo_by_id.get(int(itemid))
        return dict(row) if row is not None else None

    @classmethod
    def from_loadout(cls, loadout: Mapping[int, int], items=None, guns=None,
                     full: bool = True,
                     ammobags: Iterable[int] = ()) -> "AmmoState":
        infos: Dict[int, GunInfo] = {}
        for slot in (POS_MAIN_GUN, POS_VICE_GUN):
            iid = int((loadout or {}).get(slot) or 0)
            if not iid:
                continue
            info = load_gun(iid, items, guns, ammobags=ammobags)
            if info is not None and info.slot == slot:
                infos[slot] = info
        return cls(infos, full=full)

    def full_reserve(self, info) -> int:
        """该枪的满备弹 = 表值 + `mag_bonus` 个弹匣。"""
        try:
            return int(info.reserve) + int(self.mag_bonus) * int(info.clip)
        except (TypeError, ValueError, AttributeError):
            return int(getattr(info, "reserve", 0) or 0)

    def reset_full(self) -> None:
        """Called once per new round, never from born()/respawn."""
        for slot, state in self.slots.items():
            state.clip = state.info.clip
            state.reserve = self.full_reserve(state.info)
            self._record(slot)
        self.active = POS_MAIN_GUN if POS_MAIN_GUN in self.slots else (
            POS_VICE_GUN if POS_VICE_GUN in self.slots else 0)
        self.reload_slot = 0
        self.reload_until = 0.0
        self.last_shot = -1e18
        self.last_event = -1e18
        self._reset_burst()
        self.ray_events = []

    @property
    def info(self) -> Optional[GunInfo]:
        state = self.slots.get(self.active)
        return state.info if state is not None else None

    @property
    def clip(self) -> int:
        state = self.slots.get(self.active)
        return state.clip if state is not None else 0

    @property
    def reserve(self) -> int:
        state = self.slots.get(self.active)
        return state.reserve if state is not None else 0

    def total(self, slot: Optional[int] = None) -> int:
        state = self.slots.get(int(self.active if slot is None else slot))
        return (state.clip + state.reserve) if state is not None else 0

    def reloading(self, now: float) -> bool:
        return bool(self.reload_slot) and now < self.reload_until

    def update(self, now: float) -> Optional[Tuple[int, int]]:
        """Finish a due reload.  Returns (slot, rounds_moved) once.

        ScFillBulletStop.finishtimes is a *bullet count*: the client calls
        AGun.FillBulletStop(fills) with fills = GetFillCount()
        (min(clip, reserve, clip - surplus), AGun.cs:794-806, 1199-1211).
        """
        if self.reload_slot:
            state=self.slots.get(self.reload_slot)
            if state is not None and state.info.reload_type==3:
                moved=0;slot=self.reload_slot
                while (self._shell_left>0 and now+1e-7>=self._shell_next):
                    if state.clip>=state.info.clip or state.reserve<=0:break
                    state.clip+=1;state.reserve-=1;moved+=1;self._shell_left-=1
                    self._shell_next+=max(.01,state.info.reload_stages[1])
                if now+1e-7>=self.reload_until:
                    self.reload_slot=0;self.reload_until=0.;self._shell_left=0
                    return slot,moved
                if moved:return slot,moved
                return None
        if not self.reload_slot or now < self.reload_until:
            return None
        slot, self.reload_slot, self.reload_until = self.reload_slot, 0, 0.0
        state = self.slots.get(slot)
        if state is None:
            return None
        room = max(0, state.info.clip - state.clip)
        moved = min(room, state.reserve)
        state.clip += moved
        state.reserve -= moved
        self._record(slot)
        return slot, moved

    def start_reload(self, now: float) -> Optional[GunInfo]:
        if self.reload_slot:
            return None
        state = self.slots.get(self.active)
        if state is None or state.clip >= state.info.clip or state.reserve <= 0:
            return None
        self.reload_slot = self.active
        self.reload_until = now + state.info.reload_seconds
        if state.info.reload_type==3:
            start,per,end=state.info.reload_stages
            count=min(state.info.clip-state.clip,state.reserve)
            self._shell_left=count;self._shell_next=now+start+per
            self.reload_until=now+start+count*per+end
        self._reset_burst()
        self.ray_events = []
        return state.info

    def cancel_reload(self) -> bool:
        """Cancel a reload without moving rounds (client weapon change)."""
        if not self.reload_slot:
            return False
        self.reload_slot = 0
        self.reload_until = 0.0
        self._reset_burst()
        self.ray_events = []
        return True

    def switch(self, slot: int, now: float = 0.0) -> bool:
        slot = int(slot)
        if slot == self.active or slot not in self.slots:
            return False
        # Switching away cancels a reload, like the client's weapon change.
        # It never moves rounds between clip/reserve and never refills.
        if self.reload_slot and self.reload_slot != slot:
            self.cancel_reload()
        self._reset_burst()
        self.ray_events = []
        self.active = slot
        return True

    def can_fire(self, now: float) -> bool:
        state = self.slots.get(self.active)
        if state is None or self.reloading(now) or state.clip <= 0:
            return False
        # Gun.shootSpeed is the native shot cadence (AGun.FireTask), not the
        # removed 0.9 s human constant.
        return now + 1e-6 >= self.last_shot + self.period_of(state)

    def consume(self, now: float) -> bool:
        if not self.can_fire(now):
            return False
        self.slots[self.active].clip -= 1
        self._record(self.active)
        self.last_shot = now
        self.last_event = now
        self._reset_burst()
        return True

    def take_shots(self, now: float, dt: float = 0.0, *, min_period: float = 0.0) -> int:
        """Release every shot that is already due, bounded per dispatch.

        The room clock only calls tick() every 0.25 s while MG4 fires every
        0.1 s, so one tick has to release 2-3 *due* shots.  This never sets a
        future last_shot and never replays a long stall as a burst: a gap
        larger than one second restarts the cadence with a single shot.

        Native trigger grouping survives dispatches: only the first round of
        a FireTask trigger records a MultiShoot ray group in ``ray_events``;
        the remaining firePerShoot-1 rounds (possibly released by a later
        dispatch) only spend magazine rounds.  ``hold``/``switch``/reload
        discard the unfinished trigger, so it can never emit a future ray.
        """
        self.ray_events = []
        self.update(now)
        if self.reloading(now):
            self._reset_burst()
            return 0
        state = self.slots.get(self.active)
        if state is None or state.clip <= 0:
            self._reset_burst()
            return 0
        info = state.info
        period = max(self.period_of(state), min_period)
        burst = max(1, int(info.fire_per_shot))
        interval = max(0.0, float(info.shoot_interval))
        # 【v39】触发间隔：单发枪 = 面板 period；三连发枪 = 至少 bot_burst_period。
        trigger_period = (period if burst <= 1
                          else self.trigger_period_of(state))

        # 【v21.3】慢射速单发（狙击 / 栓动，period >= 0.5s）：不追「欠账」，
        # 每 tick 最多 1 发，且必须距上次**真实开火** >= period。
        # 原实现用 last_event 累积 due 来补齐 0.25s tick 里的多发（MG4 等连发
        # 枪需要），但狙击在换弹 / 瞄准 / 短暂丢视线时仍在交战，`hold()` 不会
        # 触发，last_event 就冻结在停火前；恢复瞬间 now 已越过两个 period，
        # 于是一次 tick 补 MAX_SHOTS_PER_TICK(=2) 发 —— 听感就是 M200/AWP
        # 「瞬发两枪」，甚至比 M14EBR(0.46s) 还快。这里把慢枪改成严格单发节拍。
        # 【v26】所有单发枪「不追欠账、每 tick 最多 1 发」：tick 抖动时若一次补
        # 2 发会在同一时刻吐出（客户端同时收到两个 ScShoot）= 卡弹后打一坨。
        # 代价：高射速枪（步枪/冲锋枪/机枪）在 tick 频率不足时因量化会略掉速，
        # 换来"绝不卡弹后一坨"。firePerShoot>1 的枪仍走下面按组补发。
        if burst == 1:
            # 【v27】不丢欠账、只封顶。v26 用 last_shot = now 会把握把周期量化
            # 到 tick 的整数倍：tick≈0.05s 而加特林 0.10s，一旦 tick 抖动成
            # 0.048 就变成「3×0.048=0.144s 一发」，平均射速掉三成 -> 听感拉稀。
            # 这里改成时间轴累加（last_shot = 上一发 due），平均射速恒等于面板；
            # 同时「每 tick 最多 1 发 + 欠账封顶 1 个周期」，所以绝不会在同一次
            # dispatch 里吐出两发（不会一坨），长停火/换弹后也不会补发一大串。
            if self.last_shot <= -1e17:
                self.last_shot = now - period
            _cap = period if period < 0.5 else min(period, 0.15)
            _due = self.last_shot + period
            if now + 1e-6 < _due:
                return 0
            if now - _due > _cap:
                _due = now                      # 停火/换弹太久：不补发，重新起步
            self.last_shot = _due               # 关键：保留周期余量，不掉平均射速
            state.clip -= 1
            self.last_event = now
            self.burst_left = 0
            self.next_round_at = now
            # 【v40】霰弹枪（firePerShoot==1 但 bulletPerShoot>1）必须在这里记
            # 一条「一次扣扳机 = harmPerFire 条弹道」的事件。
            # 之前只有 firePerShoot>1 的分支会 append，单发多弹丸的枪
            # `drain_ray_events()` 返回空表，`weapon_fire.bot_fire(events=[])`
            # 就一条射线都不发 —— BOT 拿霰弹枪**永远不开枪**（无伤害、无枪口
            # 火焰、没有 ScMultiShoot），这才是「散弹枪根本不会开枪」的根因。
            _rays = trigger_rays(info)
            if _rays > 1:
                self.trigger_seq += 1
                self.ray_events.append({
                    "trigger": int(self.trigger_seq),
                    "rays": int(_rays),
                    "first_round": 1,
                    "at": float(now),
                })
            self.burst_ray_pending = False
            self._record(self.active)
            return 1

        if self.last_event <= -1e17:
            self.last_event = now - trigger_period
        if now - self.last_event > max(1.0, trigger_period * (MAX_SHOTS_PER_TICK + 2)):
            # Long pause (round start, debugger, GC): do not replay the backlog.
            self.last_event = now - trigger_period
            self._reset_burst()
        fired = 0
        limit = max(MAX_SHOTS_PER_TICK, MAX_SHOTS_PER_TICK * burst)
        while fired < limit and state.clip > 0:
            if self.burst_left <= 0:
                due = self.last_event + trigger_period
                if due > now + 1e-9:
                    break
                if min_period:
                    due = now  # Drop overdue triggers instead of firing a backlog.
                self.last_event = due
                # Native FireTask sets shootSurplus = shootPerFire.  The loop
                # below stops when the magazine is empty; the next trigger
                # starts fresh (it is never resumed after a reload/hold).
                self.burst_left = min(burst, state.clip)
                self.next_round_at = due
                self.burst_ray_pending = True
                self.trigger_seq += 1
            if self.next_round_at > now + 1e-9:
                break
            first = self.burst_ray_pending
            state.clip -= 1
            self.burst_left -= 1
            self.burst_ray_pending = False
            self.last_shot = self.next_round_at
            # 【v40】三连发的间隔从**最后一发**起算（用户口径：第三发打完之后
            # 再等 0.6s 才开下一梭），不是从扣扳机那一刻起算 —— 否则一梭本身
            # 还要占掉 3×0.055s，实际「梭头到梭头」只有 0.6s，听着还是偏快。
            # 把 last_event 挪到这一梭最后一发的时刻，下一次 due = 该时刻 + 0.6s。
            if self.burst_left <= 0:
                self.last_event = self.last_shot
            self.next_round_at += interval
            fired += 1
            rays = trigger_rays(info)
            if first and rays > 1:
                # exactly one native ScMultiShoot group per trigger, even if
                # this trigger's rounds straddle several dispatches.
                self.ray_events.append({
                    "trigger": int(self.trigger_seq),
                    "rays": int(rays),
                    "first_round": 1,
                    "at": float(self.last_shot),
                })
        if fired:
            self._record(self.active)
        return fired

    def hold(self, now: float) -> None:
        """Not shooting this tick: do not bank shots/bursts for later."""
        state = self.slots.get(self.active)
        self._reset_burst()
        self.ray_events = []
        if state is not None:
            _p = self.period_of(state)
            _tp = self.trigger_period_of(state)
            self.last_shot = max(self.last_shot, now - _p)
            self.last_event = max(self.last_event, now - _tp)

    def ready(self, now: float,
              auto_switch: bool = True) -> Tuple[str, int, Optional[GunInfo]]:
        """Return (action, slot, info) for this tick.

        action: fire | reload | reloading | empty | switch
        ``auto_switch=False`` lets the tactical selector own slot changes, so
        the BOT never sends a second, contradictory switch in the same tick.
        """
        self.update(now)
        if self.reloading(now):
            return "reloading", self.active, self.info
        state = self.slots.get(self.active)
        if state is not None and state.clip > 0:
            return "fire", self.active, state.info
        if state is not None and state.reserve > 0:
            return "reload", self.active, state.info
        if not auto_switch:
            return "empty", self.active, self.info
        for slot in (POS_VICE_GUN, POS_MAIN_GUN):
            other = self.slots.get(slot)
            if other is None or slot == self.active or self.total(slot) <= 0:
                continue
            self.switch(slot, now)
            if other.clip > 0:
                return "switch", slot, other.info
            return "reload", slot, other.info
        return "empty", self.active, self.info

    def born_reserve(self) -> Tuple[int, int]:
        """ScBorn mainbullet/minorbullet are reserve counts, not reserve+clip.

        PlayerData.Apply writes born.mainbullet into ammo_main_Reserve /
        ammo_main_Reserve_Full (PlayerData.cs:475-476) and Init->FillAmmoAll
        then always sets ammo_main_clip = gun.clip (PlayerData.cs:339).  The
        caller therefore has to re-send ScGunChange after every ScBorn so the
        finite server clip replaces that automatic full clip on screen.
        """
        main = self.slots.get(POS_MAIN_GUN)
        vice = self.slots.get(POS_VICE_GUN)
        return (main.reserve if main is not None else -1,
                vice.reserve if vice is not None else -1)

    def snapshot(self) -> Dict[int, Dict[str, int]]:
        return {slot: {"gunid": s.info.itemid, "clip": s.clip,
                       "reserve": s.reserve, "maxclip": s.info.clip}
                for slot, s in self.slots.items()}


# ---------------------------------------------------------------------------
# Tactical weapon switching (hold + cooldown, WeaponChange not ScGunChange)
# ---------------------------------------------------------------------------
@dataclass
class TacticalState:
    held_slot: int = POS_MAIN_GUN
    held_since: float = 0.0
    next_switch_at: float = 0.0
    reason: str = "born"
    switches: int = 0


@dataclass(frozen=True)
class SwitchDecision:
    from_slot: int
    to_slot: int
    reason: str
    weapon_id: int
    clip: int = 0
    reserve: int = 0
    send_sc_gun: bool = False


def _slot_ready(state: Optional[SlotAmmo], ammo: AmmoState,
                now: float) -> bool:
    if state is None:
        return False
    if ammo.reload_slot == state.info.slot and now < ammo.reload_until:
        return False
    return state.clip > 0


def choose_tactical_slot(ammo: AmmoState, melee: Optional[MeleeInfo], *,
                         now: float, threat_visible: bool,
                         nearest_dist: float, route_state=None,
                         safe: float = 0.0,
                         engage_range: float = 35.0,
                         near_threat: Optional[bool] = None,
                         route_mobility: bool = False,
                         airborne: bool = False,
                         allow_mobility_melee: bool = True,
                         forbid_melee: bool = False):
    """Return (slot, reason) for this tick, without changing state.

    Native slots only: 11 main gun, 12 vice gun, 50 melee.  Engagement always
    prefers a loaded gun; melee is a route/mobility or last-resort choice.

    ``route_mobility`` is fed by parkour_routes' ``state['route_mobility']`` /
    ``state['parkour_route']`` (see bots._tick_human_bot).  It only expresses a
    preference; the caller still applies hold/cooldown before a WeaponChange.

    ``airborne`` keeps the slot that was already planned: a jump in flight has
    a committed horizontal velocity/landing (parkour.valid_airborne), so the
    tactical layer must not churn slots mid-air.

    【v20】``forbid_melee=True`` = 竞技/普通房（非生化、非刀战、手上有枪）
    彻底禁切刀。v9 只挡了「为跑速切刀」那条路径，弹药打空时仍会从
    ``empty_melee_finish`` / ``no_gun_ammo_melee`` 切到 50 槽，而竞技 BOT
    没有生化房那套补弹/守点逻辑，于是满场端着刀跑。生化房 / 刀战房不传
    这个参数，行为完全不变（用户：「生化 bot 禁切刀已经修好了」）。
    """
    if forbid_melee:
        _gun = ammo.active if ammo.active in (POS_MAIN_GUN, POS_VICE_GUN) else None
        if _gun is None:
            _gun = POS_MAIN_GUN if POS_MAIN_GUN in ammo.slots else (
                POS_VICE_GUN if POS_VICE_GUN in ammo.slots else POS_MAIN_GUN)
        return int(_gun), "arena_melee_forbidden"
    if airborne:
        return int(ammo.active or POS_MAIN_GUN), "airborne_hold"
    # **换弹期间不要切刀。** `_slot_ready` 在 reload 中恒为 False，原来的
    # 决策会一路退到 `no_gun_ammo_melee` / `empty_melee_finish`，于是 BOT
    # 打着打着突然拔出刀、换完弹再切回来（用户反馈「不明所以地切刀」）。
    # 有备用弹药、正在换弹时保持原槽等它换完即可。
    try:
        _rs = int(getattr(ammo, "reload_slot", 0) or 0)
        if _rs in (POS_MAIN_GUN, POS_VICE_GUN) and now < float(
                getattr(ammo, "reload_until", 0) or 0):
            _slot = ammo.slots.get(_rs)
            if _slot is not None and (int(_slot.reserve or 0) > 0
                                      or int(_slot.clip or 0) > 0):
                return _rs, "reload_hold"
    except (TypeError, ValueError, AttributeError):
        pass
    main = ammo.slots.get(POS_MAIN_GUN)
    vice = ammo.slots.get(POS_VICE_GUN)
    main_ready = _slot_ready(main, ammo, now)
    vice_ready = _slot_ready(vice, ammo, now)
    main_empty = main is None or (main.clip <= 0 and main.reserve <= 0)
    vice_empty = vice is None or (vice.clip <= 0 and vice.reserve <= 0)
    engage = max(1.0, float(engage_range or 35.0))
    dist = float(nearest_dist)
    close = bool(threat_visible and dist <= max(CLOSE_RANGE_M, 1.0))
    in_engage = bool(threat_visible and dist <= engage)
    # A route knife is cancelled by a *near* threat, not by anything visible
    # at the edge of gun range.  The old code cancelled on any visible target
    # inside engage_range, which made the route knife unreachable in practice.
    if near_threat is None:
        near_threat = bool(threat_visible
                           and dist <= max(CLOSE_RANGE_M, float(safe or 0.0)))
    cancel_route = bool(near_threat)

    mobility = "gun"
    if WC is not None:
        mobility = WC.weapon_preference(
            route_state, now, threat_visible=cancel_route,
            threat_dist=dist, safe=safe, melee_ready=melee is not None)

    # Safe route/transfer: knife gives full Antiknock run speed (AMelee
    # SpeedDown=0).  A near threat cancels this; a target merely visible
    # inside gun range is handled by the engagement branch below.
    # 【v9】`allow_mobility_melee=False` = 手上还有枪有弹时**不许为了跑速切刀**。
    # 只有刀战房间（AmmoState 为空）和两把枪彻底打空才允许拿刀。
    if (allow_mobility_melee and melee is not None and not cancel_route
            and (not in_engage or route_mobility)):
        if mobility == "melee" or route_mobility:
            return POS_MELEE, "route_mobility_melee"

    if in_engage:
        # Close suppression: keep the main if it is a shotgun/SMG; otherwise
        # still use the gun that can actually reach the target.
        if close and main_ready and main is not None:
            if main.info.category in ("shotgun", "smg", "rifle", "mg"):
                return POS_MAIN_GUN, "close_suppression_main"
        if main_ready and (main.info.effective_range>=dist or not vice_ready
                           or vice.info.effective_range<dist):
            return POS_MAIN_GUN, "engage_main"
        if vice_ready:
            return POS_VICE_GUN, "engage_vice"
        if melee is not None and dist <= melee.range:
            return POS_MELEE, "empty_melee_finish"
        return (POS_MAIN_GUN if main is not None else
                POS_VICE_GUN if vice is not None else POS_MELEE), "empty"

    if main_ready and main is not None and main.info.effective_range >= dist:
        return POS_MAIN_GUN, "range_main"
    if vice_ready and vice is not None and vice.info.effective_range >= dist:
        return POS_VICE_GUN, "range_vice"
    if main_ready:
        return POS_MAIN_GUN, "default_main"
    if vice_ready:
        return POS_VICE_GUN, "main_empty_or_reload"
    if melee is not None:
        return POS_MELEE, "no_gun_ammo_melee"
    return ammo.active or POS_MAIN_GUN, "empty"


def maybe_switch(state: TacticalState, ammo: AmmoState,
                 melee: Optional[MeleeInfo], desired_slot: int, now: float,
                 reason: str, *, urgent: bool = False
                 ) -> Optional[SwitchDecision]:
    """Apply hold/cooldown and return one legal switch, or None.

    A gun slot must exist in AmmoState.  Melee (50) is legal only when a real
    MeleeInfo was loaded.  The returned decision never asks for ScGunChange:
    tactical switching reuses the already-equipped slot via WeaponChange.
    """
    desired = int(desired_slot or 0)
    state.held_slot = int(state.held_slot or ammo.active or POS_MAIN_GUN)
    if desired == state.held_slot:
        return None
    if now < float(state.next_switch_at or 0.0):
        return None
    held_for = float(now) - float(state.held_since or 0.0)
    if held_for < (URGENT_MIN_HOLD_SECONDS if urgent else MIN_HOLD_SECONDS):
        return None
    if desired in (POS_MAIN_GUN, POS_VICE_GUN):
        target = ammo.slots.get(desired)
        if target is None:
            return None
        # Switching gun->gun cancels an in-flight reload without adding ammo.
        ammo.switch(desired, now)
        weapon_id = target.info.itemid
        clip, reserve = target.clip, target.reserve
    elif desired == POS_MELEE and melee is not None:
        # Leaving a reloading gun cancels it; no rounds are moved.
        ammo.cancel_reload()
        weapon_id = melee.itemid
        clip, reserve = 0, 0
    else:
        return None
    decision = SwitchDecision(
        from_slot=int(state.held_slot), to_slot=desired, reason=str(reason),
        weapon_id=int(weapon_id), clip=int(clip), reserve=int(reserve),
        send_sc_gun=False)
    state.held_slot = desired
    state.held_since = float(now)
    state.next_switch_at = float(now) + SWITCH_COOLDOWN_SECONDS
    state.reason = str(reason)
    state.switches += 1
    return decision


def can_melee(melee: Optional[MeleeInfo], dist: float,
              *, friendly: bool = False) -> bool:
    """True only inside Melee.range and never against a friendly target."""
    if melee is None or friendly:
        return False
    return 0.0 <= float(dist) <= float(melee.range)


def notify_route_state(target: Any, **kwargs) -> Any:
    """Re-export of the main-coordinator preference hook (no movement)."""
    if WC is None:
        return kwargs
    return WC.notify_route_state(target, **kwargs)


def request_mobility_weapon(target: Any, now: float, **kwargs) -> Dict[str, Any]:
    """Re-export of the mobility preference hook (no switch, no jump)."""
    if WC is None:
        return {"slot": POS_MELEE, "reason": "route", "until": now}
    return WC.request_mobility_weapon(target, now, **kwargs)


# ---------------------------------------------------------------------------
# Threat assessment / decision
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Threat:
    roleid: int
    pos: Tuple[float, float, float]
    dist: float
    visible: bool
    speed: float = 0.0
    reachable: bool = True


@dataclass(frozen=True)
class Decision:
    mode: str
    fire: bool
    target_id: int
    reason: str
    threat_ids: Tuple[int, ...] = ()


def _xz(a, b) -> float:
    return math.hypot(a[0] - b[0], a[2] - b[2])


def max_threat_speed(threats: Sequence[Threat]) -> float:
    speeds = [t.speed for t in threats if t.speed and t.speed > 0]
    return max(speeds) if speeds else ZOMBIE_MAX_SPEED


def safe_distance(threats: Sequence[Threat],
                  reaction: float = REACTION_WINDOW,
                  margin: float = SAFE_MARGIN) -> float:
    """Stay outside one zombie reaction window before its claw range.

    reach + runSpeed * reaction + margin.  At the shipped 8.2 m/s this is
    2.7 + 7.38 + 1.5 = 11.58 m, i.e. beyond a full claw window.
    """
    return max(MIN_SAFE_DISTANCE,
               ZOMBIE_REACH + max_threat_speed(threats) * reaction + margin)


def preferred_distance(safe: float) -> float:
    return max(MIN_PREFERRED, safe + PREFERRED_EXTRA)


def perch_safe(here, threats: Sequence[Threat], safe: float) -> bool:
    """Leave a perch for claw danger or a ghost reaching its elevation.

    低处幽灵够不到的高点本身是安全的狙击位，但有两类情况必须下来：

    1. 幽灵贴近 / 幽灵到达同高度且可见可达 —— 原来的判断。
    2. 有幽灵威胁却**一个都看不见**（幽灵全在低处、被平台/栏杆挡死）：
       高点的狙击价值归零，BOT 只会钉在上面当雕像（用户反馈「人类 BOT
       站在高处只瞄准母体不下来」）。此时视为不安全，下去追击/换位。
    """
    if any(t.dist <= ZOMBIE_REACH + .5 or
           (t.dist <= safe and t.pos[1] >= here[1] - .8
            and (t.reachable or t.visible)) for t in threats):
        return False
    if threats and not any(t.visible for t in threats):
        return False
    return True


def is_pincer(here, threats: Sequence[Threat], safe: float) -> bool:
    near = [t for t in threats if t.dist <= safe * 1.7]
    if len(near) < 2:
        return False
    vecs = []
    for t in near:
        dx, dz = t.pos[0] - here[0], t.pos[2] - here[2]
        n = math.hypot(dx, dz)
        if n > 1e-6:
            vecs.append((dx / n, dz / n))
    if len(vecs) < 2:
        return False
    widest = 0.0
    for i in range(len(vecs)):
        for j in range(i + 1, len(vecs)):
            dot = max(-1.0, min(1.0, vecs[i][0] * vecs[j][0]
                                + vecs[i][1] * vecs[j][1]))
            widest = max(widest, math.acos(dot))
    sx = sum(v[0] for v in vecs)
    sz = sum(v[1] for v in vecs)
    return widest >= math.radians(105.0) or math.hypot(sx, sz) <= 0.55


def pick_target(threats: Sequence[Threat]) -> Optional[Threat]:
    """选目标：最近的可见敌人（没有可见的就取最近的）。

    【v39】v36 的「目标粘滞」随锁定延迟一起撤销 —— 那是为了配合
    「连续可见 N 秒」不被打断才加的，锁定回退后不再需要。
    """
    if not threats:
        return None
    visible = [t for t in threats if t.visible]
    pool = visible or list(threats)
    return min(pool, key=lambda t: t.dist)


def decide(here, threats: Sequence[Threat], *, engage_range: float,
           safe: float, preferred: float, reloading: bool = False,
           weapon_empty: bool = False) -> Decision:
    """Ground decision.  Fire is independent from movement, so a retreating or
    strafing human can still shoot when the target is visible and in range."""
    target = pick_target(threats)
    ids = tuple(t.roleid for t in threats)
    if not threats:
        return Decision("patrol", False, 0, "no_threat", ids)
    nearest = min(threats, key=lambda t: t.dist)
    can_shoot = bool(target is not None and target.visible
                     and target.dist <= engage_range)
    if weapon_empty:
        mode = "empty_retreat" if nearest.dist <= preferred else "empty"
        return Decision(mode, False, target.roleid if target else 0,
                        "no_ammo", ids)
    if reloading:
        mode = "reload_retreat" if nearest.dist <= preferred else "reload_hold"
        return Decision(mode, False, target.roleid if target else 0,
                        "reloading", ids)
    pincer = is_pincer(here, threats, safe)
    if pincer or nearest.dist <= safe:
        return Decision("retreat", can_shoot,
                        target.roleid if target else 0,
                        "pincer" if pincer else "inside_safe", ids)
    if target is None or not target.visible:
        return Decision("chase", False, target.roleid if target else 0,
                        "no_line_of_sight", ids)
    if target.dist > preferred:
        return Decision("chase", can_shoot, target.roleid,
                        "target_far", ids)
    return Decision("hold", can_shoot, target.roleid, "keep_distance", ids)


# ---------------------------------------------------------------------------
# Reachable destination selection
# ---------------------------------------------------------------------------
def _validate(p) -> Optional[Tuple[float, float, float]]:
    try:
        return (float(p[0]), float(p[1]), float(p[2]))
    except (TypeError, ValueError, IndexError):
        return None


def _locate(nav, p):
    if nav is None or not hasattr(nav, "locate"):
        return None
    try:
        return nav.locate(tuple(p))
    except Exception:
        return None


def _same_component(nav, a, b) -> bool:
    if nav is None:
        return True
    la, lb = _locate(nav, a), _locate(nav, b)
    if la is None or lb is None:
        return False
    comp = getattr(nav, "component", None)
    if comp is None:
        return True
    return comp[la[0]] == comp[lb[0]]


def _reachable(nav, here, cand) -> bool:
    """Cheap reachability: same baked component.  Corridor existence is then
    checked once on the chosen candidate, never for every sample point."""
    if nav is None:
        return True
    return _same_component(nav, here, cand)


# Per-nav spatial bucket over baked centres.  Rebuilt only when the nav object
# changes; keeps candidate generation O(local cells) instead of O(all polys).
_CENTER_INDEX: Dict[int, Tuple[Any, Dict[Tuple[int, int],
                                        List[Tuple[Any, Tuple[float, float, float]]]]]] = {}
_BUCKET_M = 4.0


def _center_index(nav):
    hit = _CENTER_INDEX.get(id(nav))
    if hit is not None and hit[0] is nav:
        return hit[1]
    bucket: Dict[Tuple[int, int], List[Tuple[Any, Tuple[float, float, float]]]] = {}
    for key, p in getattr(nav, "centers", {}).items():
        q = (float(p[0]), float(p[1]), float(p[2]))
        bucket.setdefault((int(q[0] // _BUCKET_M), int(q[2] // _BUCKET_M)),
                          []).append((key, q))
    if len(_CENTER_INDEX) > 16:
        _CENTER_INDEX.clear()
    _CENTER_INDEX[id(nav)] = (nav, bucket)
    return bucket


def _local_candidates(here, max_distance: float):
    out = []
    for dx, dz in ((3, 0), (-3, 0), (0, 3), (0, -3),
                   (3, 3), (-3, 3), (3, -3), (-3, -3),
                   (5, 0), (-5, 0), (0, 5), (0, -5),
                   (7, 0), (-7, 0), (0, 7), (0, -7)):
        if math.hypot(dx, dz) <= max_distance:
            out.append((here[0] + dx, here[1], here[2] + dz))
    return out


def nav_candidates(nav, here, min_distance: float = 2.0,
                   max_distance: float = 16.0):
    """Only points on the same baked component; never a raw Euclidean point.

    Candidate generation uses a cached 4 m bucket index, so a call touches the
    local cells instead of every polygon on the map.
    """
    if nav is None:
        return _local_candidates(here, max_distance)
    centers = getattr(nav, "centers", None)
    comp = getattr(nav, "component", None)
    loc = _locate(nav, here)
    if not centers or comp is None or loc is None:
        return [p for p in _local_candidates(here, max_distance)
                if _reachable(nav, here, p)]
    want = comp[loc[0]]
    bucket = _center_index(nav)
    radius = int(math.ceil((max_distance + _BUCKET_M) / _BUCKET_M))
    hx, hz = int(here[0] // _BUCKET_M), int(here[2] // _BUCKET_M)
    out = []
    for bx in range(hx - radius, hx + radius + 1):
        for bz in range(hz - radius, hz + radius + 1):
            for key, p in bucket.get((bx, bz), ()):
                if comp.get(key) != want:
                    continue
                d = _xz(here, p)
                if min_distance < d <= max_distance:
                    out.append(p)
    out.sort(key=lambda p: _xz(here, p))
    if len(out) > 48:
        out = [out[i * len(out) // 48] for i in range(48)]
    # Keep a few close local escapes for tight rooms.
    out.extend(p for p in _local_candidates(here, min(max_distance, 7.0))
               if _reachable(nav, here, p))
    unique = {}
    for p in out:
        unique[(round(p[0], 2), round(p[1], 2), round(p[2], 2))] = p
    return list(unique.values())


def _corridor_points(nav, here, cand) -> List[Tuple[float, float, float]]:
    """Baked corridor centre segment between two points, evenly capped.

    This replaces the old full-map nav.path() smoothing: no per-candidate
    physics raycasts, only the already-baked polygon/grid corridor.
    """
    here, cand = tuple(here), tuple(cand)
    if nav is not None and hasattr(nav, "corridor"):
        la, lb = _locate(nav, here), _locate(nav, cand)
        if la is not None and lb is not None:
            try:
                keys = nav.corridor(la[0], lb[0]) or ()
            except Exception:
                keys = ()
            centers = getattr(nav, "centers", {}) or {}
            if keys and centers:
                if len(keys) > MAX_CORRIDOR_POINTS:
                    step = len(keys) / MAX_CORRIDOR_POINTS
                    keys = [keys[int(i * step)] for i in range(MAX_CORRIDOR_POINTS)]
                pts = [here] + [tuple(centers[k]) for k in keys
                                if k in centers] + [cand]
                return pts
    return [here, cand]


def _path_min_points(pts, threats: Sequence[Threat]) -> float:
    if not threats:
        return float("inf")
    best = float("inf")
    for a, b in zip(pts, pts[1:]):
        length = math.dist(a, b)
        steps = max(1, min(6, int(math.ceil(length / CORRIDOR_SAMPLE_M))))
        for i in range(steps + 1):
            p = tuple(a[j] + (b[j] - a[j]) * (i / steps) for j in range(3))
            for t in threats:
                d = math.dist(p, t.pos)
                if d < best:
                    best = d
    return best


def path_min_threat(nav, here, cand, threats: Sequence[Threat]) -> float:
    return _path_min_points(_corridor_points(nav, here, cand), threats)


def _crowd(point, occupied, gap: float = FORMATION_GAP) -> float:
    if gap <= 0:
        return 0.0
    return sum(max(0.0, gap - _xz(point, q)) ** 2 / gap
               for q in occupied if q is not None and abs(point[1] - q[1]) < 1.5)


def _recent(point, recent) -> float:
    return sum(max(0.0, 2.5 - _xz(point, q)) for q in recent if q is not None)


def _escape_threshold(safe: float, here_min: float) -> float:
    """Path envelope.  When the BOT is already inside the safe ring, any escape
    path literally starts inside it; in that case only require the path not to
    get closer to a threat than the current position (with a small tolerance)."""
    return min(safe * 0.75, max(0.0, here_min - 0.25))


def _ranked(here, threats, cands, occupied, recent, require_clearance):
    here_min = min((t.dist for t in threats), default=float("inf"))
    ranked = []
    for cand in cands:
        cand_min = min((_xz(cand, t.pos) for t in threats),
                       default=float("inf"))
        if require_clearance and cand_min + 0.25 < here_min:
            continue
        score = (cand_min if threats else 0.0) + 0.25 * _xz(here, cand)
        score -= 1.5 * _crowd(cand, occupied) + 2.0 * _recent(cand, recent)
        ranked.append((score, cand))
    ranked.sort(key=lambda item: -item[0])
    return ranked


def _first_safe_path(nav, here, ranked, threats, threshold, limit, occupied=(),
                     crowd_gap: float = FORMATION_GAP):
    """Validate only the top few candidates; the corridor query is cached and
    is reused by next_waypoint in the same tick."""
    best, best_score = None, -float('inf')
    for score, cand in ranked[:limit]:
        points = _corridor_points(nav, here, cand)
        if _path_min_points(points, threats) < threshold:
            continue
        if not occupied:
            return cand
        # Compare real corridors and exclude the shared starting area.
        traffic = max((_crowd(p, occupied, crowd_gap) for p in points[1:-1]
                       if _xz(p, here) >= 4.75), default=0.)
        score -= .6 * traffic
        if score > best_score:
            best, best_score = cand, score
    return best


def _toward_filter(cands, here, toward):
    """v57：落单人类 BOT 被追时，撤退候选只留「确实朝汇合点靠近」的那些。

    被包在死角 / 汇合方向全被僵尸堵住时一个都留不下，就退回全量候选 ——
    先活下来，下一 tick 再谈汇合，绝不能因为「找不到队伍方向」站着不动。
    """
    if toward is None:
        return cands
    base = _xz(here, toward)
    closer = [c for c in cands if _xz(c, toward) <= base - 1.5]
    return closer or cands


def pick_retreat(here, nav, threats: Sequence[Threat], *, safe: float,
                 occupied=(), recent=(), max_distance: float = 16.0,
                 toward=None):
    """Pick a reachable point that increases clearance from *all* threats.

    A candidate is rejected when its baked corridor passes through the threat
    envelope; a detour that merely ends far away but walks past a zombie is
    not safe.  At most MAX_PATH_CANDIDATES corridors are evaluated.

    `toward`（v57）：额外要求候选比当前位置更靠近该点，用来把「撤退」
    变成「撤向最近的小队」；安全过滤的优先级仍然最高。
    """
    if not threats:
        return pick_patrol(here, nav, threats, occupied=occupied,
                           recent=recent, max_distance=max_distance)
    here_min = min(t.dist for t in threats)
    threshold = _escape_threshold(safe, here_min)
    cands = _toward_filter(nav_candidates(nav, here, 2.0, max_distance),
                           here, toward)
    ranked = _ranked(here, threats, cands, occupied, recent, True)
    best = _first_safe_path(nav, here, ranked, threats, threshold,
                            MAX_PATH_CANDIDATES, occupied)
    if best is not None:
        return best
    # Surrounded / no clearing candidate: maximise minimum clearance without
    # crossing a threat, but never choose an unreachable point.
    ranked = _ranked(here, threats,
                     _toward_filter(nav_candidates(nav, here, 1.0, max_distance),
                                    here, toward),
                     occupied, recent, False)
    best = _first_safe_path(nav, here, ranked, threats, threshold,
                            MAX_PATH_CANDIDATES, occupied)
    if best is not None:
        return best
    # Last resort: no path clears the full envelope.  Still move, but never
    # through a zombie's body: require >= 1 m from every threat along the
    # baked corridor.  Standing still with a zombie inside the safe ring is
    # strictly worse than a short sidestep.
    near_first = sorted(ranked, key=lambda item: -min(
        (_xz(item[1], t.pos) for t in threats), default=float("inf")))
    return _first_safe_path(nav, here, near_first, threats, 1.0, 3, occupied)


def pick_hold(here, nav, threats: Sequence[Threat], *, preferred: float,
              safe: float, occupied=(), seed: int = 0):
    """Short strafe/step that keeps the preferred band without closing in."""
    target = pick_target(threats)
    if target is None:
        return None
    dx, dz = target.pos[0] - here[0], target.pos[2] - here[2]
    n = math.hypot(dx, dz) or 1.0
    px, pz = -dz / n, dx / n
    sign = 1 if (int(seed) & 1) == 0 else -1
    cands = []
    for mix in (sign, -sign):
        cands.append((here[0] + px * STRAFE_DISTANCE * mix, here[1],
                      here[2] + pz * STRAFE_DISTANCE * mix))
    cands.append((here[0] - dx / n * 2.5, here[1], here[2] - dz / n * 2.5))
    here_min = min(t.dist for t in threats)
    threshold = _escape_threshold(safe, here_min) * 0.95
    ranked = []
    for cand in cands:
        if not _reachable(nav, here, cand):
            continue
        cand_min = min(_xz(cand, t.pos) for t in threats)
        if cand_min < here_min - 0.75 or cand_min < safe * 0.8:
            continue
        score = -abs(cand_min - preferred) - 1.2 * _crowd(cand, occupied)
        ranked.append((score, cand))
    ranked.sort(key=lambda item: -item[0])
    return _first_safe_path(nav, here, ranked, threats, threshold, 2, occupied)


def pick_patrol(here, nav, threats: Sequence[Threat] = (), *, occupied=(),
                recent=(), seed: int = 0, max_distance: float = 12.0,
                prefer_high: bool = False, support=(), anchor=None, anchor_radius: float = 0.0,
                crowd_gap: float = FORMATION_GAP):
    """Distributed reachable patrol/prepare destination.

    `anchor` / `anchor_radius`（v49）：只在「锚点附近」的候选里挑，
    给生化房人类 BOT 做「围绕出生点小范围主动游走」用。锚点没候选时
    退回原来的整圈候选，避免把人卡死。

    `crowd_gap`（v57）：队友之间希望保持的距离。默认 FORMATION_GAP(7m)
    是「散兵线」口径；生化小队要抱到 5m 以内、在队心 4.5m 里坚守，
    必须把这个排斥半径压到 2.5~3m，否则 `_crowd` 的惩罚会把队伍推开，
    组队判定（<=5m）刚成立就散伙。
    """
    cands = nav_candidates(nav, here, 2.0, max_distance)
    if anchor is not None and anchor_radius > 0:
        near = [cand for cand in cands if _xz(anchor, cand) <= anchor_radius]
        if not near:
            # 半径内一个节点都没有（navmesh 多边形中心很稀疏，队心又贴墙）：
            # 取**离锚点最近**的那几个候选，绝不放宽半径 —— 放宽到 2 倍等于
            # 把队员派到 9m 外，两个人的距离一过散伙阈值，队伍当场解散。
            cands = sorted(cands, key=lambda cand: _xz(anchor, cand))[:3]
        else:
            cands = near
    ranked = []
    for cand in cands:
        clearance = (min(_xz(cand, t.pos) for t in threats)
                     if threats else max_distance)
        score = 0.35 * clearance + 0.15 * _xz(here, cand)
        if support:
            # Stay one short sprint from a companion while leaving space to retreat.
            gap = min((abs(math.dist(cand, ally) - 6.5) for ally in support
                       if abs(cand[1] - ally[1]) < 1.5), default=6.5)
            score += max(0.0, 2.8 - 0.6 * gap)
        crowd = _crowd(cand, occupied, crowd_gap)
        if prefer_high and not threats and crowd < .25:
            score += 1.2 * max(0., min(2., cand[1] - here[1]))
        score -= 2.0 * crowd + 2.5 * _recent(cand, recent)
        ranked.append((score, cand))
    ranked.sort(key=lambda item: -item[0])
    if threats or occupied:
        return _first_safe_path(nav, here, ranked, threats, 1.0 if threats else 0.,
                                MAX_PATH_CANDIDATES, occupied, crowd_gap)
    return ranked[0][1] if ranked else None


def pick_approach(here, nav, threats, target, *, safe, preferred, occupied=(), recent=()):
    """Take a different firing position from allies pursuing the same ghost."""
    band = preferred if target.visible else max(safe, preferred * .7)
    ranked = []
    for candidate in nav_candidates(nav, here, 1.0, 16.0):
        distance_to_target = math.dist(candidate, target.pos)
        if distance_to_target < safe or distance_to_target >= target.dist - .5:
            continue
        score = -abs(distance_to_target - band) - 2.0 * _crowd(candidate, occupied)
        score -= _recent(candidate, recent)
        ranked.append((score, candidate))
    ranked.sort(key=lambda item: -item[0])
    threshold = _escape_threshold(safe, min(t.dist for t in threats))
    return _first_safe_path(nav, here, ranked, threats, threshold, MAX_PATH_CANDIDATES, occupied)


def choose_destination(decision: Decision, here, nav, threats: Sequence[Threat],
                       *, safe: float, preferred: float, occupied=(), recent=(),
                       seed: int = 0):
    """Movement destination for non-chase modes.  Chase uses the target pos."""
    if decision.mode in ("retreat", "reload_retreat", "empty_retreat"):
        return pick_retreat(here, nav, threats, safe=safe,
                            occupied=occupied, recent=recent)
    if decision.mode in ("empty", "reload_hold"):
        nearest = min((t.dist for t in threats), default=float("inf"))
        if nearest <= safe * 1.25:
            return pick_retreat(here, nav, threats, safe=safe,
                                occupied=occupied, recent=recent)
        return None
    if decision.mode == "hold":
        return pick_hold(here, nav, threats, preferred=preferred,
                         safe=safe, occupied=occupied, seed=seed)
    if decision.mode == "patrol":
        return pick_patrol(here, nav, threats, occupied=occupied,
                           recent=recent, seed=seed)
    return None
