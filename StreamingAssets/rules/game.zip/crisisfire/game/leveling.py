"""Experience and rank (等级).

The client never derives the rank from exp -- it just takes whatever
`ScUserInfo.property.rank` says:

    UserManager.GetRank()      => mUserInfo.pro.rank
    Deblocker.UserLevel        => UserManager.userInfo.pro?.rank ?? 0

and it detects a level-up by comparing the new rank with the previous one:

    bool flag = mUserInfo.pro != null && info.roleid == mUserInfo.id
                && mUserInfo.pro.rank < info.property.rank;
    ...
    if (!flag) return;
    LevelUpDialog d = DialogMgr.queueDialog("LevelUp");   // 升级弹窗 + 解锁物品弹窗

So the server has to compute the rank and push ScUserInfo whenever it rises.

The thresholds come from the client's Rank table (100 ranks):

    id 1   新兵1       exp 0
    id 2   新兵2       exp 90
    id 3   新兵3       exp 360
    id 5   三等兵1     exp 540
    id 100 三星元帅5   exp 258208

This matters beyond cosmetics: `RankUnlock` gates whole features on the rank
(Deblocker.CheckOpen), and staying at rank 1 locks them forever:

    DailyTask 1   Shop 2   Enhance 2   SlotMachine 2   Talent 5   CreateClan 10
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from .. import gamedata

log = logging.getLogger("crisisfire.leveling")

_ranks: Optional[List[Tuple[int, int]]] = None      # sorted (exp, id)


def _table() -> List[Tuple[int, int]]:
    global _ranks
    if _ranks is None:
        rows = []
        for r in gamedata.table("Rank"):
            try:
                rows.append((int(r.get("exp") or 0), int(r["id"])))
            except (KeyError, TypeError, ValueError):
                continue
        rows.sort()
        _ranks = rows
        if not rows:
            log.error("Rank table is empty -- ranks will stay at 1")
    return _ranks


def max_rank() -> int:
    return max((i for _e, i in _table()), default=1)


def rank_for_exp(exp: int) -> int:
    """Highest rank whose exp threshold the player has reached."""
    best = 1
    for threshold, rid in _table():
        if exp >= threshold:
            best = rid
        else:
            break
    return best


def exp_for_rank(rank: int) -> int:
    for threshold, rid in _table():
        if rid == rank:
            return threshold
    return 0


def next_rank_exp(rank: int) -> int:
    """Total exp needed for the next rank, or 0 at the cap."""
    nxt = rank + 1
    for threshold, rid in _table():
        if rid == nxt:
            return threshold
    return 0


def rank_name(rank: int) -> str:
    for row in gamedata.table("Rank"):
        if row.get("id") == rank:
            return row.get("rankName") or ""
    return ""


def progress(role) -> Dict[str, Any]:
    """What the exp bar needs: current rank, its floor, and the next floor."""
    cur = max(1, int(role.level or 1))
    floor = exp_for_rank(cur)
    nxt = next_rank_exp(cur)
    return {
        "rank": cur,
        "rankName": rank_name(cur),
        "exp": int(role.exp or 0),
        "expFloor": floor,
        "expNext": nxt,
        "into": max(0, int(role.exp or 0) - floor),
        "need": (nxt - floor) if nxt else 0,
    }


def apply_exp(world, role, delta: int) -> Tuple[int, int]:
    """Add exp, recompute the rank, persist both.  Returns (old, new) rank."""
    old_rank = max(1, int(role.level or 1))
    role.exp = max(0, int(role.exp or 0) + int(delta))
    new_rank = rank_for_exp(role.exp)

    fields: Dict[str, Any] = {"exp": role.exp}
    if new_rank != old_rank:
        role.level = new_rank
        fields["level"] = new_rank
        (log.info("role %s ranked up %s -> %s (%s), exp=%s",
                 role.name, old_rank, new_rank, rank_name(new_rank), role.exp) if log.isEnabledFor(20) else None)

    world.update_role(role.roleid, **fields)
    if new_rank != old_rank:
        # 可用天赋点 = 军衔等级 - 1，等级一变就得立刻推。
        # 只在登录时推 ScTalentSync 的话，打完一局升了级、天赋面板还是旧点数，
        # 要重进游戏才刷新 —— 和之前「碎片数量不刷新」是同一类问题（服务端没推）。
        push_talent_point(world, role)
    return old_rank, new_rank


def push_talent_point(world, role) -> None:
    """把当前可用天赋点推给在线客户端（ScTalentPointSync）。"""
    try:
        from . import talent
    except Exception:
        return
    try:
        sessions = world.sessions_of_role(role.roleid) if world is not None else []
    except Exception:
        sessions = []
    if not sessions:
        return
    try:
        for sess in sessions:
            if getattr(sess, "closed", False):
                continue
            sess.send(talent.ID.SC_TALENT_POINT, point=talent.point_of(role))
        (log.info("role %s 推送天赋点 %s", role.roleid,
                 talent.point_of(role)) if log.isEnabledFor(20) else None)
    except Exception:
        log.warning("role %s 推天赋点失败", getattr(role, "roleid", "?"),
                    exc_info=True)


def push_if_ranked_up(session, role, old_rank: int, new_rank: int) -> None:
    """ScUserInfo with a higher rank makes the client show the level-up dialog."""
    if new_rank <= old_rank:
        return
    from .handlers import _property_of
    session.send(1114117, roleid=role.roleid, property=_property_of(role))


def unlocked_features(rank: int) -> List[str]:
    """Deblocker features that this rank opens (used to log / test)."""
    out = []
    for row in gamedata.table("RankUnlock"):
        try:
            if int(row.get("level") or 0) <= rank:
                out.append(str(row.get("title") or row.get("name")))
        except (TypeError, ValueError):
            continue
    return out
