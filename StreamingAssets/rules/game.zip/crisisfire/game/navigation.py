"""1.8.1 baked polygon navigation, consumed by the reconstructed BOT controller.

No guessed links or direct-line fallback. Internal edges use serialized neighbour
IDs; tile links must share an overlapping portal with opposite baked side flags.
This reader is a local implementation, not Unity's own pathfinder. Missing data,
unreachable islands and unbaked jumps fail closed and are reported by the caller.
"""
from __future__ import annotations
import gzip, heapq, json, math
from functools import lru_cache
from pathlib import Path

EPS = 1e-5


def distance(a, b):
    return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))


def lerp(a, b, t):
    return tuple(x+(y-x)*t for x,y in zip(a,b))


def cross(a,b,c):
    return (b[0]-a[0])*(c[2]-a[2])-(b[2]-a[2])*(c[0]-a[0])


class Mesh:
    def __init__(self, data):
        self.polys = {}; self.links = {}; self.cells = {}; external = []
        self.source_sha256 = data.get('sha256','')
        for ti,t in enumerate(data['tiles']):
            for pi,p in enumerate(t['polys']):
                if p['type'] or not p['flags']: continue
                k = (ti,pi); vs = [tuple(t['verts'][i]) for i in p['v']]
                assert len(vs) >= 3
                self.polys[k] = vs; self.links[k] = {}
                for x in range(math.floor(min(v[0] for v in vs)/8),math.floor(max(v[0] for v in vs)/8)+1):
                    for z in range(math.floor(min(v[2] for v in vs)/8),math.floor(max(v[2] for v in vs)/8)+1):
                        self.cells.setdefault((x,z),[]).append(k)
        for ti,t in enumerate(data['tiles']):
            for pi,p in enumerate(t['polys']):
                k = ti,pi
                if k not in self.polys: continue
                vs = self.polys[k]
                for ei,n in enumerate(p['n']):
                    a,b = vs[ei],vs[(ei+1)%len(vs)]
                    if 0 < n < 0x8000:
                        dest = ti,n-1
                        assert dest in self.polys, (k,dest)
                        # Validate layout and edge direction against the neighbour.
                        ov = self.polys[dest]
                        assert any(distance(a,ov[(j+1)%len(ov)]) < .002 and distance(b,v) < .002
                                   for j,v in enumerate(ov)), (k,dest,'unshared edge')
                        self.links[k][dest] = (a,b)
                    elif n & 0x8000:
                        external.append((k,n&255,a,b,t))
        for i,(k,side,a,b,t) in enumerate(external):
            for other,os,c,d,ot in external[i+1:]:
                if other[0] == k[0] or os != (side+4)%8: continue
                dx,dz = {0:(1,0),2:(0,1),4:(-1,0),6:(0,-1)}.get(side,(0,0))
                if (ot['x']-t['x'],ot['z']-t['z']) != (dx,dz): continue
                axis = 2 if side in (0,4) else 0
                fixed = 0 if axis == 2 else 2
                if max(abs(a[fixed]-c[fixed]),abs(b[fixed]-d[fixed])) > .002: continue
                lo = max(min(a[axis],b[axis]),min(c[axis],d[axis]))
                hi = min(max(a[axis],b[axis]),max(c[axis],d[axis]))
                if hi-lo <= EPS: continue
                def point(u,v,s): return lerp(u,v,(s-u[axis])/(v[axis]-u[axis]))
                pa,pb = point(a,b,lo),point(a,b,hi)
                pc,pd = point(c,d,lo),point(c,d,hi)
                if max(abs(pa[1]-pc[1]),abs(pb[1]-pd[1])) > min(t['climb'],ot['climb'])+.002: continue
                self.links[k][other] = (pa,pb)
                self.links[other][k] = (pc,pd)
        self.centers = {k:tuple(sum(v[i] for v in vs)/len(vs) for i in range(3))
                        for k,vs in self.polys.items()}
        self.component = {}; comp = 0
        for k in self.polys:
            if k in self.component: continue
            stack = [k]; self.component[k] = comp
            while stack:
                for n in self.links[stack.pop()]:
                    if n not in self.component: self.component[n] = comp; stack.append(n)
            comp += 1

    def height(self, k, p):
        vs = self.polys[k]
        for j in range(1,len(vs)-1):
            a,b,c = vs[0],vs[j],vs[j+1]; den = cross(a,b,c)
            if abs(den)<EPS: continue
            u,v = cross(p,b,c)/den,cross(a,p,c)/den; w = 1-u-v
            if min(u,v,w) >= -EPS: return u*a[1]+v*b[1]+w*c[1]
        return None

    def locate(self, p, max_height=1.5):
        """Only a surface under the actual XZ, never snap through a wall."""
        best = None; delta = max_height
        for k in self.cells.get((math.floor(p[0]/8),math.floor(p[2]/8)),()):
            y = self.height(k,p)
            if y is not None and abs(p[1]-y) <= delta:
                best,delta = (k,(p[0],y,p[2])),abs(p[1]-y)
        return best

    def ground(self,p):
        loc=self.locate(p)
        return loc[1] if loc is not None else None

    def clear(self, a, b):
        """Floor-corridor raycast; each transition must use a real shared portal.

        This is deliberately NOT a replacement for a 3D physics visibility test.
        It prevents firing/movement across holes and walls absent from the floor
        mesh, and rejects different floors and disconnected navigation islands.
        """
        start,end = self.locate(a),self.locate(b)
        if start is None or end is None: return False
        if self.component[start[0]] != self.component[end[0]]: return False
        k = start[0]; t0 = 0.; seen = set()
        for _ in range(len(self.polys)+1):
            if k == end[0]: return True
            vs = self.polys[k]; exits = []
            for j,u in enumerate(vs):
                v = vs[(j+1)%len(vs)]
                # Solve A+t(B-A) == U+s(V-U) in XZ.
                rx,rz = b[0]-a[0],b[2]-a[2]
                sx,sz = v[0]-u[0],v[2]-u[2]
                den = rx*sz-rz*sx
                if abs(den)<EPS: continue
                qx,qz = u[0]-a[0],u[2]-a[2]
                t = (qx*sz-qz*sx)/den; s = (qx*rz-qz*rx)/den
                if t >= t0-EPS and -EPS <= s <= 1+EPS and t < 1+EPS:
                    exits.append((t,j))
            advanced = False
            for t,j in sorted(exits):
                # Sample just beyond a portal; corner-touching alone is not a link.
                probe = lerp(a,b,min(1.,t+1e-4))
                u,v = vs[j],vs[(j+1)%len(vs)]
                for n,(pa,pb) in self.links[k].items():
                    if n in seen: continue
                    hit = lerp(a,b,t)
                    if abs(cross(pa,pb,hit)) > .003: continue
                    if not (min(pa[0],pb[0])-.002 <= hit[0] <= max(pa[0],pb[0])+.002 and
                            min(pa[2],pb[2])-.002 <= hit[2] <= max(pa[2],pb[2])+.002): continue
                    h = self.height(n,probe)
                    offset=a[1]-start[1][1]
                    if h is None or abs(h+offset-probe[1]) > .12: continue
                    seen.add(k); k,t0 = n,t; advanced = True; break
                if advanced: break
            if not advanced: return False
        return False

    @lru_cache(maxsize=2048)
    def corridor(self, start, end):
        if self.component[start] != self.component[end]: return ()
        costs = {start:0.}; prev = {}; q = [(0.,start)]
        while q:
            _,k = heapq.heappop(q)
            if k == end:
                path = [k]
                while k in prev: k=prev[k]; path.append(k)
                return tuple(reversed(path))
            for n in self.links[k]:
                cost = costs[k]+distance(self.centers[k],self.centers[n])
                if cost < costs.get(n,float('inf')):
                    costs[n] = cost; prev[n] = k
                    heapq.heappush(q,(cost+distance(self.centers[n],self.centers[end]),n))
        return ()

    def path(self, a, b):
        start,end = self.locate(a),self.locate(b)
        if start is None or end is None: return ()
        corridor = self.corridor(start[0],end[0])
        if not corridor: return ()
        pts = [a]
        for k,n in zip(corridor,corridor[1:]):
            u,v = self.links[k][n]; mid = lerp(u,v,.5)
            # Keep the original foot offset while following ramps/stairs.
            pts.append((mid[0],mid[1]+a[1]-start[1][1],mid[2]))
        pts.append((b[0],end[1][1]+a[1]-start[1][1],b[2]))
        # Greedy string pulling, checked by the polygon raycast, never raw shortcuts.
        smooth = [pts[0]]; i = 0
        while i < len(pts)-1:
            j = len(pts)-1
            while j > i+1 and not self.clear(pts[i],pts[j]): j -= 1
            smooth.append(pts[j]); i=j
        return tuple(smooth)

    def advance(self, a, b, budget):
        pts = self.path(a,b)
        if not pts: return None
        current = a
        for dest in pts[1:]:
            d = distance(current,dest)
            if d > budget: return lerp(current,dest,budget/d)
            budget -= d; current=dest
        return current


@lru_cache(maxsize=1)
def _data():
    path = Path(__file__).resolve().parent.parent/'gamedata/navigation_181.json.gz'
    with gzip.open(path,'rt',encoding='utf-8') as f: return json.load(f)


@lru_cache(maxsize=32)
def for_scene(scene):
    data = _data().get(scene)
    return Mesh(data) if data else None


def for_battle(battle):
    from .. import gamedata
    scene = str((gamedata.map_row(battle.room.mapid) or {}).get('scene') or '')
    return for_scene(scene)
