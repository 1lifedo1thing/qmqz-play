"""Short, collision-checked human BOT jumps (local reconstructed policy).

Antiknock.Init/Consts: JumpHeight=1, Gravity=10, VelocityJump=sqrt(2*g*h).
ScJump only starts remote animation (Warrior.OnJump); position packets must
therefore carry the actual airborne trajectory. No teleports or guessed links.
"""
from __future__ import annotations
import math
from .navigation import distance, lerp
from .geometry import BODY_HEIGHT, BODY_RADIUS

HEIGHT = 1.0
GRAVITY = 10.0
UP = math.sqrt(2 * GRAVITY * HEIGHT)


def point(jump, t):
    t = min(max(t, 0.), jump['duration'])
    a = jump['start'];vx,vz = jump['horizontal']
    return (a[0]+vx*t, a[1]+jump.get('up',UP)*t-.5*GRAVITY*t*t, a[2]+vz*t)


def _body_clear(scene, a, b):
    # Five radial lines at three body heights bound the static body sweep.
    for dx,dz in ((0,0),(BODY_RADIUS,0),(-BODY_RADIUS,0),(0,BODY_RADIUS),(0,-BODY_RADIUS)):
        for h in (.08,.85,BODY_HEIGHT):
            if not scene.clear((a[0]+dx,a[1]+h,a[2]+dz),
                               (b[0]+dx,b[1]+h,b[2]+dz),mask=-1):
                return False
    return True


def arc_to(scene, start, landing, speed, foot=0., jump_height=HEIGHT):
    """Exact-endpoint jump for a baked route; no navigation links are invented.

    Symmetric .85m height changes land below native fall-damage velocity 8.
    The original 1m jump and horizontal weapon-dependent speed still apply.
    """
    start=tuple(start);landing=tuple(round(v*100)/100 for v in landing)
    start_ground=(start[0],start[1]-foot,start[2])
    end_ground=(landing[0],landing[1]-foot,landing[2])
    if not scene.stand_clear(start_ground) or not scene.stand_clear(end_ground):return None
    rise=landing[1]-start[1]
    if not -.85<=rise<=.85 or speed<=0 or jump_height<rise or jump_height<=0:return None
    up=math.sqrt(2*GRAVITY*jump_height)
    duration=(up+math.sqrt(max(0.,up*up-2*GRAVITY*rise)))/GRAVITY
    length=math.hypot(landing[0]-start[0],landing[2]-start[2])
    if length<.6 or length/duration>speed+.001:return None
    jump={'start':start,'end':landing,'duration':duration,'elapsed':0.,'up':up,
          'horizontal':((landing[0]-start[0])/duration,(landing[2]-start[2])/duration)}
    count=max(12,math.ceil(duration/.06));previous=start
    for i in range(1,count+1):
        p=point(jump,duration*i/count)
        if not _body_clear(scene,previous,p):return None
        previous=p
    return jump


def plan(nav, scene, here, toward, speed, foot=0.):
    """Choose one short ballistic hop with an actual supported landing.

    The .85m climb/.6m drop limits are conservative route policy within the
    original 1m jump. They never increase native jump/run parameters.
    """
    if nav is None or scene is None or toward is None or speed<=0:return None
    ground=nav.ground(here)
    if ground is None or abs(here[1]-ground[1]-foot)>.12:return None
    if not scene.stand_clear(ground):return None
    dx,dz=toward[0]-here[0],toward[2]-here[2];n=math.hypot(dx,dz)
    if n<.5:return None
    ux,uz=dx/n,dz/n
    # Try useful short crossings before tiny hops. Avoid unbounded map scans.
    for length in (min(4.,speed*.8),3.,2.):
        if length<1.5:continue
        for angle in (0.,.45,-.45):
            c,s=math.cos(angle),math.sin(angle)
            x=here[0]+length*(ux*c-uz*s);z=here[2]+length*(ux*s+uz*c)
            floors=scene.floors(x,z)
            for y in sorted(floors,key=lambda h:abs(h-ground[1])):
                rise=y-ground[1]
                if not -.6<=rise<=.85:continue
                landing_ground=(x,y,z)
                if not scene.stand_clear(landing_ground):continue
                end=tuple(round(v*100)/100 for v in (x,y+foot,z))
                x,z=end[0],end[2]
                loc=nav.locate(end)
                if loc is None or abs(loc[1][1]-y)>.15:continue
                duration=(UP+math.sqrt(UP*UP-2*GRAVITY*rise))/GRAVITY
                if length/duration>speed+.001:continue
                jump={'start':tuple(here),'end':end,'duration':duration,'elapsed':0.,
                      'horizontal':((x-here[0])/duration,(z-here[2])/duration)}
                count=max(12,math.ceil(duration/.06));previous=here;valid=True
                for i in range(1,count+1):
                    p=point(jump,duration*i/count)
                    if not _body_clear(scene,previous,p):valid=False;break
                    previous=p
                if valid:return jump
    return None


def valid_airborne(state, position, nav, scene):
    """An airborne sample must match its prevalidated arc, with a legal landing."""
    jump=state.get('jump')
    if not jump:return False
    expected=point(jump,jump['elapsed'])
    if distance(position,expected)>.015:return False
    if nav.locate(jump['end']) is None:return False
    return _body_clear(scene,position,position)


def advance(state, dt):
    jump=state.get('jump')
    if jump is None:return None
    jump['elapsed']=min(jump['duration'],jump['elapsed']+dt)
    p=point(jump,jump['elapsed'])
    if jump['elapsed']>=jump['duration']-1e-8:
        p=jump['end'];state.pop('jump',None)
        if jump.get('shelter'):
            state['perch']=p
        if state.pop('route_airborne',False):state['route_air_finished']=True
    return tuple(round(v*100)/100 for v in p)


def step(battle, fighter, state, nav, scene, here, desired, destination, speed, dt, now, evade=False, occupied=()):
    """Advance an active jump or start an eligible moving/escape hop."""
    active=advance(state,dt)
    if active is not None:return active
    from . import parkour_routes
    routed=parkour_routes.steer(battle,fighter,state,nav,scene,here,desired,destination,
                               speed,dt,now,evade=evade,occupied=occupied)
    if routed is not None:return routed
    state.setdefault('jump_after',now+.25*(fighter.roleid%7))
    if now<state.get('jump_after',0.) or dt>.3:return desired
    if destination is None or distance(here,destination)<1.5:return desired
    # Only grounded human BOTs call this; no jump during remote zombie changes.
    moving=math.hypot(desired[0]-here[0],desired[2]-here[2])>.1
    if not (evade or moving):return desired
    # 【v49】跳跃失败黑名单（用户：生化沙漠反复跳箱顶）。BOT 跳上高台
    # 发现是死路、又跳下来，会无限重复 —— 把那个起跳点记 20 秒坏点，
    # 期间不在它附近起跳、也不把落点选在它附近。`CF_BOT_JUMP_BAD_SEC=0` 可关。
    bad = [b for b in (state.get('jump_bad') or ()) if b[2] > now]
    state['jump_bad'] = bad
    try:
        from ..config import CONFIG as _C
        _bad_sec = float(getattr(_C, 'bot_jump_bad_sec', 20.0) or 0.0)
    except Exception:
        _bad_sec = 20.0
    if bad and any((here[0]-b[0])**2 + (here[2]-b[1])**2 <= 4.0 for b in bad):
        # 站在刚被判定为死路的点上：这一轮不跳，交给寻路绕开
        state['jump_after'] = now + .8
        return desired
    jump=plan(nav,scene,here,destination,speed,state.get('foot',0.))
    if jump is not None and bad:
        ex, ez = jump['end'][0], jump['end'][2]
        if any((ex-b[0])**2 + (ez-b[1])**2 <= 4.0 for b in bad):
            state['jump_after'] = now + .8
            return desired
    if now<state.get('client_jump_after',0.):return desired
    state['jump_after']=now+(2.0+(fighter.roleid%5)*.3 if jump else .8)
    if jump is None:return desired
    # 记录「刚爬上去」的起跳点；若 3 秒内又从上面往下跳，判定该点是死路
    if _bad_sec > 0:
        if jump['end'][1] - here[1] >= .45:
            state['last_ascent'] = (here, now)
        else:
            asc = state.get('last_ascent')
            if asc is not None and now - asc[1] <= 3.0:
                _pts = list(state.get('jump_bad') or ())
                _pts.append((asc[0][0], asc[0][2], now + _bad_sec))
                del _pts[:-6]
                state['jump_bad'] = _pts
                state.pop('last_ascent', None)
                state['jump_after'] = now + 1.0
    if occupied:
        from .human import _crowd
        if _crowd(jump['end'], occupied) > _crowd(desired, occupied) + .75:
            return desired
        if not evade and jump['end'][1] - here[1] < .45 and nav.clear(here, jump['end']):
            return desired
    if jump['end'][1] - here[1] >= .45:
        jump['shelter'] = True
    state['jump']=jump
    from . import bot_airlife
    state['client_jump_after']=now+jump['duration']+bot_airlife.landing_tail()
    from . import battle as B
    def wire(p):return {k:int(round(v*100)) for k,v in zip('xyz',p)}
    vx,vz=jump['horizontal']
    battle.send_all(B.ID.SC_JUMP,roleid=fighter.roleid,pos=wire(here),speed=wire((vx,UP,vz)))
    B.log.info('BOT-JUMP role=%s from=%s to=%s duration=%.3f',fighter.roleid,here,jump['end'],jump['duration'])
    return advance(state,dt)
