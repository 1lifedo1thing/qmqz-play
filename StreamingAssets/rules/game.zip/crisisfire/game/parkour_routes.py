"""Route-level walking/jumping over baked, collision-validated platforms.

Walking components remain separate: jump edges never become walking shortcuts.
Route selection is local reconstructed BOT policy, not an original server rule.
"""
import gzip,json,math
from collections import defaultdict,deque
from functools import lru_cache
from pathlib import Path
from . import geometry as G
from .human import _crowd
from .navigation import distance,lerp


class Routes:
    def __init__(self,physical,data):
        self.physical=physical;self.nav=G.BakedGrid(physical,data)
        self.nav.parkour_routes=self
        self.nav.source_sha256='parkour-grid:'+data['graph_sha256']
        self.sizes=defaultdict(int)
        for component in self.nav.component.values():self.sizes[component]+=1
        keys=[tuple(k) for k in data['nodes']];self.by_component=defaultdict(list)
        self.incoming=defaultdict(set)
        for edge in data['jumps']:
            a,b=keys[edge['from']],keys[edge['to']]
            row={'start':self.nav.point(a),'end':self.nav.point(b),
                 'speed':edge['speed'],'from_component':self.nav.component[a],
                 'to_component':self.nav.component[b]}
            self.by_component[row['from_component']].append(row)
            self.incoming[row['to_component']].add(row['from_component'])

    @lru_cache(maxsize=512)
    def transfer_distances(self,goal):
        distances={goal:0};pending=deque([goal])
        while pending:
            current=pending.popleft()
            for previous in self.incoming.get(current,()):
                if previous not in distances:
                    distances[previous]=distances[current]+1
                    pending.append(previous)
        return distances

    def can_reach(self,first,second):
        return first in self.transfer_distances(second)

    def pursuit_edge(self,here,component,goal,speed,recent):
        """Choose an existing crossing that gets closer to the target's floor."""
        remaining=self.transfer_distances(goal)
        hops=remaining.get(component)
        if not hops:return None
        candidates=[edge for edge in self.by_component.get(component,())
                    if remaining.get(edge['to_component'])==hops-1 and edge['speed']<=speed+.05]
        return min(candidates,default=None,key=lambda edge:distance(here,edge['start'])+
                   10.*sum(distance(edge['end'],point)<1. for point in recent))

    def choose(self,here,toward,threats=(),recent=(),occupied=(),seed=0,evade=False):
        loc=self.nav.locate(here)
        if loc is None:return None
        component=self.nav.component[loc[0]]
        goal=self.nav.locate(toward) if toward is not None else None
        goal_component=self.nav.component[goal[0]] if goal is not None else None
        queue=deque([(component,here,[],0.,[here])]);options=[];expanded=0
        initial=min((math.dist(here,t) for t in threats),default=0.)
        while queue and expanded<40:
            comp,at,legs,cost,visited=queue.popleft();expanded+=1
            edges=sorted(self.by_component.get(comp,()),key=lambda e:distance(at,e['start']))[:8]
            for edge in edges:
                other=edge['to_component']
                if any(distance(edge['end'],old)<1.5 for old in visited):continue
                if legs and distance(edge['end'],legs[-1]['start'])<2.:continue
                if any(edge is old for old in legs):continue
                approach=distance(at,edge['start'])
                if approach>12:continue
                a,b=self.nav.locate(at),self.nav.locate(edge['start'])
                if a is None or b is None:continue
                corridor=self.nav.corridor(a[0],b[0])
                if not corridor:continue
                # A distant-looking destination is not safe if the approach
                # walks past an immediately threatening ghost.
                pts=[at]+[self.nav.point(k) for k in corridor]+[edge['start']]
                if threats:
                    envelope=max(.8,min(initial-.3,3.))
                    if min(math.dist(p,t) for p in pts for t in threats)<envelope:continue
                total=cost+approach+distance(edge['start'],edge['end'])
                if total>28:continue
                route=legs+[edge];end=edge['end']
                clearance=min((math.dist(end,t) for t in threats),default=0.)
                gain=clearance-initial if threats else 0.
                height=end[1]-here[1]
                progress=distance(here,toward)-distance(end,toward) if toward else 0.
                revisits=sum(max(0.,3.-distance(end,p)) for p in recent)
                score=(2.0*gain if evade else .8*progress)+1.5*height+.6*len(route)-.1*total-3.*revisits
                if threats and not evade:score-=4.*max(0.,8.-clearance)
                if goal_component is not None and other==goal_component:score+=2.
                score-=2.*_crowd(end,occupied)+_crowd(route[0]['end'],occupied)
                if not threats or clearance>=min(initial,8.)-.3:
                    options.append((score,route))
                if len(route)<3:queue.append((other,end,route,total,visited+[edge['start'],end]))
        if not options:return None
        options.sort(key=lambda row:row[0],reverse=True)
        close=[row for row in options[:4] if row[0]>=options[0][0]-1.5]
        return close[int(seed)%len(close)][1]


@lru_cache(maxsize=1)
def _data():
    p=Path(__file__).resolve().parent.parent/'gamedata/parkour_routes_181.json.gz'
    if not p.exists():return {}
    with gzip.open(p,'rt',encoding='utf-8') as f:return json.load(f)


@lru_cache(maxsize=8)
def for_scene(scene):
    data=_data().get(scene);physical=G.for_scene(scene)
    return Routes(physical,data) if data and physical else None


def steer(battle,fighter,state,nav,scene,here,desired,toward,speed,dt,now,evade=False,occupied=(),pursuit=False):
    """Return a controlled route step, or None to retain ordinary steering."""
    graph=getattr(nav,'parkour_routes',None)
    if graph is None:return None
    from . import parkour as P
    route=state.get('parkour_route')
    loc=nav.locate(here)
    component=nav.component[loc[0]] if loc is not None else None
    goal=nav.locate(toward) if pursuit and toward is not None else None
    goal_component=nav.component[goal[0]] if goal is not None else None
    stranded=(component is not None and graph.sizes[component]<32
              and any(e['to_component']!=component for e in graph.by_component.get(component,())))
    if state.pop('route_air_finished',False):
        state['route_index']=state.get('route_index',0)+1
    if route and state.get('route_index',0)>=len(route):
        from .battle import log
        (log.info('BOT-ROUTE-DONE role=%s hops=%s pos=%s',fighter.roleid,len(route),here) if log.isEnabledFor(20) else None)
        state.setdefault('route_recent',[]).append(route[-1]['end'])
        del state['route_recent'][:-6]
        state['parkour_route']=None;state['route_mobility']=False
        state['route_after']=now+1.
        route=None
    if pursuit and (goal_component is None or goal_component==component
                    or (route and state.get('pursuit_goal')!=goal_component)):
        state['parkour_route']=None;state['route_mobility']=False
        return None
    if route is None:
        if now<state.get('route_after',0.):return None
        bio=battle.biochem
        hero=fighter.roleid in getattr(bio,'heroes',set())
        if hero:
            from .bots import _profile,_visible
            reach=_profile(battle,fighter)[0]
            if any(g.born and g.hp>0 and bio.is_zombie(g.roleid) and g.syncpos is not None
                   and distance(here,g.syncpos)<=reach and _visible(scene,here,g.syncpos)
                   for g in battle.fighters.values()):
                return None  # Arrived in sword reach: fight, do not leave again.
        state['route_after']=now+2.+(fighter.roleid%7)*.15
        # Do not add a hop every two seconds while stationary at a gun position.
        if not pursuit and not stranded and (toward is None or (not evade and distance(here,desired)<.08)):return None
        if toward is None:toward=graph.by_component[component][0]['end']
        bio=battle.biochem
        hero=fighter.roleid in getattr(bio,'heroes',set())
        threats=[] if hero or pursuit else [g.syncpos for g in battle.fighters.values() if g.born and g.hp>0
                                  and bio.is_zombie(g.roleid) and g.syncpos is not None]
        if not occupied:
            occupied=[g.syncpos for g in battle.fighters.values() if g.roleid!=fighter.roleid
                      and g.born and g.hp>0 and not bio.is_zombie(g.roleid) and g.syncpos is not None]
        recent=state.get('route_recent',())
        if pursuit:
            edge=graph.pursuit_edge(here,component,goal_component,speed,recent)
            route=[edge] if edge is not None else None
        else:
            route=graph.choose(here,toward,threats,recent,occupied,fighter.roleid,evade)
        if not route:return None
        if not pursuit and not hero and not stranded and toward is not None:
            if _crowd(route[-1]['end'], occupied) > _crowd(toward, occupied) + .75:
                return None
        state['parkour_route']=route;state['route_index']=0
        if pursuit:state['pursuit_goal']=goal_component
        state['route_until']=now+14.;state['route_mobility']=True
        from .battle import log
        (log.info('BOT-ROUTE role=%s hops=%s start=%s end=%s',fighter.roleid,len(route),here,route[-1]['end']) if log.isEnabledFor(20) else None)
    if now>state.get('route_until',0.):
        state['parkour_route']=None;state['route_mobility']=False;return None
    leg=route[state['route_index']];foot=state.get('foot',0.)
    launch=(leg['start'][0],leg['start'][1]+foot,leg['start'][2])
    landing=(leg['end'][0],leg['end'][1]+foot,leg['end'][2])
    hero=fighter.roleid in getattr(battle.biochem,'heroes',set())
    threats=[] if hero or pursuit else [g.syncpos for g in battle.fighters.values() if g.born and g.hp>0
                             and battle.biochem.is_zombie(g.roleid) and g.syncpos is not None]
    clearance=min((distance(here,p) for p in threats),default=float('inf'))
    landing_clearance=min((distance(landing,p) for p in threats),default=float('inf'))
    if landing_clearance<min(3.2,clearance+.5):
        state['parkour_route']=None;state['route_mobility']=False;return None
    if distance(here,launch)>.18:
        waypoint=nav.next_waypoint(here,launch,budget=speed*dt)
        if waypoint is None:
            state['parkour_route']=None;state['route_mobility']=False;return None
        if threats and min(distance(waypoint,p) for p in threats)<min(3.,clearance-.25):
            state['parkour_route']=None;state['route_mobility']=False;return None
        dist=distance(here,waypoint)
        from .bots import _grounded_step
        target=lerp(here,waypoint,min(1.,speed*dt/dist)) if dist>.001 else here
        return _grounded_step(nav,scene,here,target,foot,speed*dt)
    # Revalidate the exact current launch/landing with the current held-weapon
    # speed and body offset. Baked maximum speed is never used as permission.
    if now<state.get('client_jump_after',0.):return here
    height=P.HEIGHT
    if pursuit:
        from .bots import _zombie_prop
        height=float(_zombie_prop(fighter.actorid).get('jumpHeight') or height)
    jump=P.arc_to(scene,here,landing,speed,foot,jump_height=height)
    if jump is None:
        if leg['speed']>speed+.05:
            state['route_mobility']=True
            state['route_speed_wait']=state.get('route_speed_wait',0)+1
            if state['route_speed_wait']<4:return here
        if pursuit:
            recent=state.setdefault('route_recent',[])
            recent.append(leg['end']);del recent[:-6]
        state['parkour_route']=None;state['route_mobility']=False;return None
    state['route_speed_wait']=0;state['jump']=jump;state['route_airborne']=True
    if not pursuit and not hero and state['route_index'] == len(route)-1:
        if route[0]['from_component'] != leg['to_component'] or leg['end'][1]-route[0]['start'][1] >= .45:
            jump['shelter'] = True
    from . import bot_airlife
    state['client_jump_after']=now+jump['duration']+bot_airlife.landing_tail(height)
    from . import battle as B
    def wire(p):return {k:int(round(v*100)) for k,v in zip('xyz',p)}
    vx,vz=jump['horizontal']
    battle.send_all(B.ID.SC_JUMP,roleid=fighter.roleid,pos=wire(here),speed=wire((vx,jump['up'],vz)))
    B.log.info('BOT-ROUTE-JUMP role=%s hop=%s/%s from=%s to=%s',fighter.roleid,
               state['route_index']+1,len(route),here,landing)
    return P.advance(state,dt)
