"""真人玩家的服务端弹药记录 —— 只用来填 `WeaponChange` 回包里的 total。

为什么需要它
------------
客户端切枪时发 `WeaponChange(roleid, weaponpos, -1)`：在线模式下子弹由
本地 `AArsenal` / `PlayerData` 维护，客户端**不把真值发给服务端**。
服务端原来把 -1 原样回传，客户端 `ClientManager.WeaponChange`：

    int ammoInClip = playerData.GetAmmoInClip(weaponpos);
    ChangeWeapon(roleid, weaponid, playerData.AmmoID, bulletnum - ammoInClip, ammoInClip);

于是 `reserve = -1 - ammoInClip` 是负数，`AGun.SetAmmo` 里：

    if (ammoReserve < 0) { ammoReserve = ammoTotalReserve; }

—— **每切一次枪，备弹就被补满一次**（用户反复报的「切枪就回满备弹」）。

做法
----
服务端按 `Gun` 表自己记一份 clip / reserve：

* 出生（第一次切枪 / 第一次开火）时按 `f.equipmap` 的 11 / 12 建；
* 每次 `CsShoot` 扣 `firePerShoot` 发；
* `CsFillBullet` 把弹匣补满（从 reserve 里扣）。

只用于回包那一个数字，不参与伤害裁决。误差来自「客户端射速 vs 服务端
收到的 CsShoot 次数」，但方向是**只会少发、不会凭空变多** —— 至少不再
「切一次满一次」。
"""
from __future__ import annotations

import logging
from typing import Dict, Optional

log = logging.getLogger("crisisfire.player_ammo")

_POS_GUNS = (11, 12)      # 主武器 / 副武器（近战 50 没有弹药）


def held_slot(battle, f) -> int:
    """当前手上的武器槽。

    ★ 不能只看 `f.weaponpos`：服务端在回合开始会把它清 0，而客户端**开局
    持枪时并不发 `WeaponChange`**（`FPSOnlineBehaviour.ChangeWeapon` 只在
    玩家主动换枪时调用）。所以「本局第一次切枪之前」的所有射击，`weaponpos`
    都是 0 —— 记账全被跳过，账本一直到第一次切枪才用 Gun 表的**满弹**值
    建起来，回包 `bulletnum = clip + reserve` 恰好是满的，客户端就表现为
    「每局第一次切枪回满备弹」。

    这里复用伤害裁决那条同样的推断（`damage.active_weapon`），保证记账
    和「这一枪算谁的伤害」用的是同一把枪。
    """
    try:
        from . import damage
        slot, _iid = damage.active_weapon(f)
        return int(slot or 0)
    except Exception:
        return int(getattr(f, "weaponpos", 0) or 0)


def _book(battle) -> Dict[int, Dict[int, list]]:
    book = getattr(battle, "_player_ammo", None)
    if book is None:
        book = battle._player_ammo = {}
    return book


def _load(info, slot: int, itemid: int = 0) -> Optional[list]:
    """[clip, reserve, max_clip, max_reserve, itemid]；非枪械返回 None。"""
    try:
        clip = int(getattr(info, "clip", 0) or 0)
        reserve = int(getattr(info, "reserve", 0) or 0)
        if int(getattr(info, "slot", 0) or 0) != slot or clip <= 0:
            return None
    except (TypeError, ValueError):
        return None
    return [clip, reserve, clip, reserve, int(itemid or 0)]


def snapshot(battle, f) -> Dict[int, list]:
    """取（必要时建）该玩家的弹药表。

    每次调用都核对一次槽位上的枪 id：中途捡枪（`CsPickupGun`）会改
    `equipmap`，旧模型必须丢掉重建，否则切枪会回一个不属于这把枪的数字。
    """
    book = _book(battle)
    rows = book.get(int(f.roleid))
    if rows is None:
        rows = book[int(f.roleid)] = {}
    from . import human
    eq = getattr(f, "equipmap", {}) or {}
    # 弹匣道具加成必须和 ScBorn 下发的 mainbullet / minorbullet 用同一套，
    # 否则服务端账本比客户端少一两个弹匣，切枪时备弹会**变少**。
    bags = ()
    try:
        getter = getattr(battle, "_ammobags_for", None)
        if getter is not None:
            bags = tuple(getter(f.roleid) or ())
    except Exception:
        bags = ()
    for slot in _POS_GUNS:
        iid = int(eq.get(slot) or 0)
        if not iid:
            rows.pop(slot, None)
            continue
        row = rows.get(slot)
        if row is not None and int(row[4]) == iid:
            continue
        try:
            # 弹药和模型无关：皮肤/贴图不合格的枪同样要能记账，否则
            # `total()` 返回 None -> 回包 -1 -> 又是一次「切枪回满」。
            info = human.load_gun(iid, require_renderable=False, ammobags=bags)
        except Exception:          # 数据缺失时不要影响切枪
            info = None
        fresh = _load(info, slot, iid) if info is not None else None
        if fresh is None:
            rows.pop(slot, None)
        else:
            rows[slot] = fresh
    return rows


def total(battle, f, slot: int) -> Optional[int]:
    """该槽的 (clip + reserve)；没有模型（近战/未知）返回 None。"""
    if int(slot) not in _POS_GUNS:
        return None
    rows = snapshot(battle, f)
    row = rows.get(int(slot))
    if row is None:
        return None
    return int(row[0]) + int(row[1])


def on_shot(battle, f, rounds: int = 1) -> None:
    """一次扣扳机：从当前槽位的弹匣里扣 `rounds` 发（不会扣成负数）。"""
    slot = held_slot(battle, f)
    if slot not in _POS_GUNS:
        return
    row = snapshot(battle, f).get(slot)
    if row is None:
        return
    row[0] = max(0, int(row[0]) - max(0, int(rounds)))


def on_reload(battle, f, slot: Optional[int] = None) -> None:
    """换弹完成：弹匣补满，差额从 reserve 扣。"""
    slot = int(slot) if slot is not None else held_slot(battle, f)
    if slot not in _POS_GUNS:
        return
    row = snapshot(battle, f).get(slot)
    if row is None:
        return
    clip, reserve, max_clip = int(row[0]), int(row[1]), int(row[2])
    need = max(0, max_clip - clip)
    if need <= 0 or reserve <= 0:
        return
    take = min(need, reserve)
    row[0] = clip + take
    row[1] = reserve - take


def reset(battle, f) -> None:
    """满弹重置（新回合 / 出生点补弹用）。"""
    book = _book(battle)
    book.pop(int(f.roleid), None)
    snapshot(battle, f)


def forget(battle, roleid: int) -> None:
    _book(battle).pop(int(roleid), None)
