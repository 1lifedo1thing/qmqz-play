"""UC 1.9 paid ammo selection and local inventory accounting."""
from collections import Counter
from functools import lru_cache

from .. import gamedata

STOCK_ID = 900000
COUNTS = "paid_ammo_counts"
STOCK_TYPE = {11: 1, 12: 3}
TYPE_SLOT = {1: 11, 2: 11, 3: 12, 4: 12}


@lru_cache(maxsize=1)
def paid_rows():
    return {row["id"]: row for row in gamedata.table("Ammo") if row["id"] != STOCK_ID}


def count(role, itemid):
    saved = (role.data.get(COUNTS) or {}).get(str(itemid))
    if saved is not None:
        return int(saved)
    # Older builds advertised one round per owned ammo item.
    return int(itemid in (role.data.get("pkg_items") or ()))


def stock_change(role, deltas):
    before = {item: count(role, item) for item in deltas}
    saved = dict(role.data.get(COUNTS) or {})
    for item, delta in deltas.items():
        saved[str(item)] = min(999999, before[item] + delta)
        if saved[str(item)] < 0:
            raise ValueError("insufficient paid ammo")
    return ({COUNTS: saved} if deltas else {}), before


def gift_deltas(row):
    from .shop import _as_ids
    deltas = Counter()
    for item, quantity in zip(_as_ids(row["ammo"]), _as_ids(row["ammoNum"]), strict=True):
        deltas[item] += quantity
    return deltas


def sync_stock(session, role, before):
    from . import equip
    for item, previous in before.items():
        total = count(role, item)
        if total == 0:
            if previous:
                session.send(983042, itemlist=[item])
        elif total != previous:
            session.send(983041, synctype=2 if previous else 1,
                         itemlist=equip.package_reward_payload(role, [item]))


def _for_weapon(weapon):
    from . import damage
    gun = damage._table("Gun").get(weapon)
    return paid_rows().get(gun["vipAmmo"]) if gun else None


def switch(battle, session, requested):
    from . import damage, handlers
    from .relay import ID
    fighter = battle.fighters.get(session.roleid)
    slot = TYPE_SLOT.get(requested)
    if slot is None or fighter is None or not fighter.born or fighter.hp <= 0:
        return
    if battle.round_over or battle.fight_over or damage.uses_melee(battle, fighter):
        return
    if damage.active_weapon(fighter)[0] != slot:
        return
    stock = STOCK_TYPE[slot]
    profile = _for_weapon(fighter.equipmap.get(slot))
    role = handlers.world.role(fighter.roleid) if handlers.world else None
    if requested != stock and profile and role and count(role, profile["id"]):
        fighter.paid_ammo_slots.add(slot)
        actual = requested
    else:
        fighter.paid_ammo_slots.discard(slot)
        actual = stock
    session.send(ID.BULLET_CHANGE, roleid=fighter.roleid, bullettype=actual)
    battle.send_others(fighter.roleid, ID.BULLET_CHANGE, roleid=fighter.roleid, bullettype=actual)


def spend(battle, fighter, *, rays=1, multi=False):
    """Return the profile and number of rays that use it for one client trigger."""
    if not getattr(fighter, "paid_ammo_slots", None) or not battle.started:
        return {}, 0
    from . import damage, handlers
    from .relay import ID
    if damage.uses_melee(battle, fighter):
        return {}, 0
    slot, weapon = damage.active_weapon(fighter)
    if slot not in fighter.paid_ammo_slots:
        return {}, 0
    profile = _for_weapon(weapon)
    world = handlers.world
    role = world.role(fighter.roleid) if world else None
    if profile is None or role is None:
        return {}, 0
    item = profile["id"]
    gun = damage._table("Gun")[weapon]
    rounds = min(max(1, gun["firePerShoot"]), rays) if multi else 1
    used = min(count(role, item), rounds)
    if used:
        changes, before = stock_change(role, {item: -used})
        world.award_local(role.roleid, changes)
        lobby = world.session_of_role(role.roleid, "gs")
        if lobby is not None and not lobby.closed:
            sync_stock(lobby, role, before)
    if not count(role, item):
        for selected in tuple(fighter.paid_ammo_slots):
            if _for_weapon(fighter.equipmap.get(selected)) == profile:
                fighter.paid_ammo_slots.discard(selected)
                battle.send_all(ID.BULLET_CHANGE, roleid=fighter.roleid, bullettype=STOCK_TYPE[selected])
    # Native shotgun groups spend one round, even with eight hit rays.
    paid_rays = rays if used == rounds else used
    return profile, paid_rays
