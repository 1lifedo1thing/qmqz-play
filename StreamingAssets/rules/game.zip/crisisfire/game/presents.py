"""赠送 / 收礼（CsGiveItem / CsReceivePresent）。

客户端流程（1.7.1 `GiftPersonDialog`）：

* `ConfirmBuyDialog.OnOtherBuy`：商品/角色点「赠送」→ `GiftPersonData.Set(type,id)`
* `GiftPersonDialog.OnPresent` → `CsGiveItem(presenttype, itemid, 目标 roleid)`
* `GiftBoxDetail` 点领取 → `CsReceivePresent(presentid)`
* 登录后 `GiftManager` 需要 `ScPresentList(presents)` 才能显示礼盒

presenttype 的真实含义（不是随便定的）：

===== ========================== ==========================================
  0   商店商品（itemid=Shop.id）   只有 gem>0 的商品允许赠送；发放 Shop.itemId
  1   角色（itemid=Role.id）      发放角色
  3   礼包（itemid=Gift.giftLevel） 发放礼包内容，并标记该礼包已拥有
===== ========================== ==========================================

币种照 `UserManager.CanBuy`：gem→role.gold（钻石）、bloodGem→role.diamond
（荣誉）、gold→role.money（金币）。
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from ..net.server import ROUTER, Session
from . import equip, shop

log = logging.getLogger("crisisfire.presents")


class ID:
    CS_GIVE = 1048631
    SC_GIVE = 1048632
    SC_GET_ITEM = 1048633
    SC_LIST = 1048634
    CS_RECEIVE = 1048635
    SC_RECEIVE = 1048636

    SC_ACOUNT_SYNC = 983043


MAX_PRESENTS = 50

_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# 存取
# --------------------------------------------------------------------------
def presents_of(role) -> List[Dict[str, Any]]:
    raw = (role.data or {}).get("presents") or []
    out: List[Dict[str, Any]] = []
    for item in raw:
        if isinstance(item, dict):
            try:
                out.append({
                    "presenttype": int(item.get("presenttype") or 0),
                    "givername": str(item.get("givername") or ""),
                    "itemid": int(item.get("itemid") or 0),
                    "count": max(1, int(item.get("count") or 1)),
                    "givetime": int(item.get("givetime") or 0),
                    "presentid": int(item.get("presentid") or 0),
                })
            except (TypeError, ValueError):
                continue
    return out


def _save(role, items: List[Dict[str, Any]]) -> None:
    if _world is None:
        return
    _world.merge_role_data(role.roleid, presents=items[-MAX_PRESENTS:])


def push_on_login(session: Session, role) -> None:
    session.send(ID.SC_LIST, presents=presents_of(role))


# --------------------------------------------------------------------------
# 价格 / 内容
# --------------------------------------------------------------------------
def _price_of_shop(shopid: int):
    row = shop.shop_row(shopid)
    if row is None:
        return None
    gem = int(row.get("gem") or 0)
    blood = int(row.get("bloodGem") or 0)
    money = int(row.get("gold") or 0)
    itemid = int(row.get("itemId") or 0)
    count = max(1, int(row.get("subCount") or 1))
    return {"gold": gem, "diamond": blood, "money": money,
            "itemid": itemid, "count": count, "row": row}


def _charge(role, price: Dict[str, int]) -> bool:
    if price["gold"] > role.gold or price["diamond"] > role.diamond or \
            price["money"] > role.money:
        return False
    role.gold -= price["gold"]
    role.diamond -= price["diamond"]
    role.money -= price["money"]
    if _world is not None:
        _world.update_role(role.roleid, gold=role.gold,
                           diamond=role.diamond, money=role.money)
    return True


def _push_money(session: Session, role) -> None:
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)


def _gift_items(giftid: int) -> List[int]:
    row = shop.gift_row(giftid)
    return shop.gift_items(row) if row else []


# --------------------------------------------------------------------------
# 赠送
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_GIVE, "presents.CsGiveItem")
async def on_give(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    presenttype = int(msg.get("presenttype") or 0)
    itemid = int(msg.get("itemid") or 0)
    targetid = int(msg.get("roleid") or 0)

    def fail(code: int) -> None:
        session.send(ID.SC_GIVE, result=code, presenttype=presenttype,
                     itemid=itemid, rolename="")

    target = _world.role(targetid) if _world else None
    if target is None or targetid == role.roleid:
        (log.info("role %s 赠送失败：目标 %s 不存在/是自己", role.name, targetid) if log.isEnabledFor(20) else None)
        fail(1)
        return

    items = presents_of(target)
    if len(items) >= MAX_PRESENTS:
        (log.info("role %s 的礼盒已满（%s）", target.name, len(items)) if log.isEnabledFor(20) else None)
        fail(2)
        return

    price = {"gold": 0, "diamond": 0, "money": 0}
    count = 1
    if presenttype == 0:
        info = _price_of_shop(itemid)
        if info is None or info["itemid"] <= 0:
            fail(1)
            return
        price = {"gold": info["gold"], "diamond": info["diamond"],
                 "money": info["money"]}
        count = info["count"]
    elif presenttype == 1:
        p = equip.actor_price(itemid)
        price = {"gold": p.get("gold", 0), "diamond": p.get("diamond", 0),
                 "money": p.get("money", 0)}
    elif presenttype == 3:
        row = shop.gift_row(itemid)
        if row is None:
            fail(1)
            return
        price = {"gold": int(row.get("price") or 0), "diamond": 0, "money": 0}
    else:
        log.warning("未知 presenttype=%s (role %s)", presenttype, role.name)
        fail(1)
        return

    if not _charge(role, price):
        (log.info("role %s 赠送 %s 余额不足", role.name, itemid) if log.isEnabledFor(20) else None)
        fail(1)
        _push_money(session, role)
        return

    nextid = max((p["presentid"] for p in items), default=0) + 1
    present = {
        "presenttype": presenttype,
        "givername": role.name,
        "itemid": itemid,
        "count": count,
        "givetime": int(time.time()),
        "presentid": nextid,
    }
    items.append(present)
    _save(target, items)

    # 收礼人在线就立刻推过去（离线则等下次登录的 ScPresentList）
    sess = _world.session_of_role(target.roleid) if _world else None
    if sess is not None and not sess.closed:
        sess.send(ID.SC_GET_ITEM, present=present)

    session.send(ID.SC_GIVE, result=0, presenttype=presenttype,
                 itemid=itemid, rolename=target.name)
    _push_money(session, role)
    (log.info("role %s 送给 %s type=%s item=%s (present %s)",
             role.name, target.name, presenttype, itemid, nextid) if log.isEnabledFor(20) else None)


# --------------------------------------------------------------------------
# 领取
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_RECEIVE, "presents.CsReceivePresent")
async def on_receive(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    presentid = int(msg.get("presentid") or 0)
    items = presents_of(role)
    present = next((p for p in items if p["presentid"] == presentid), None)
    if present is None:
        session.send(ID.SC_RECEIVE, result=1, presentid=presentid)
        return

    items = [p for p in items if p["presentid"] != presentid]
    from . import premium_ammo
    ptype = present["presenttype"]
    itemid = present["itemid"]
    info = _price_of_shop(itemid) if ptype == 0 else None
    gift = shop.gift_row(itemid) if ptype == 3 else None
    deltas = premium_ammo.gift_deltas(gift) if gift else {}
    if info and info["itemid"] in premium_ammo.paid_rows():
        deltas[info["itemid"]] = info["count"]
    changes, before = premium_ammo.stock_change(role, deltas)
    _world.award_local(role.roleid, {**changes, "presents": items[-MAX_PRESENTS:]})
    added: List[int] = []
    _gift_row = None
    if ptype == 0:
        if info and info["itemid"] and info["itemid"] not in deltas:
            added = equip.grant_items(role, [info["itemid"]], _world)
    elif ptype == 1:
        code = equip.buy_actor(role, itemid, _world, free=True)
        if code != 0:
            (log.info("领取角色 %s 返回 %s（可能已拥有）", itemid, code) if log.isEnabledFor(20) else None)
    elif ptype == 3:
        ids = _gift_items(itemid)
        added = equip.grant_items(role, ids, _world)
        # 【v20】礼盒里的穿甲弹等按 Gift.ammoNum 补足真实数量
        _gift_row = shop.gift_row(itemid)
        if _gift_row is not None:
            shop.grant_gift_ammo(role, _gift_row, _world)
        owned = shop.owned_gifts(role)
        if itemid not in owned:
            owned.append(itemid)
            if _world is not None:
                _world.merge_role_data(role.roleid, gifts=owned)
        # 标记已拥有，客户端 Response 里再调 BuyGift 就不会重复扣钱
        session.send(shop.ID.SC_GIFT_SYNC, gifts=owned)

    session.send(ID.SC_RECEIVE, result=0, presentid=presentid)
    premium_ammo.sync_stock(session, role, before)
    if added:
        session.send(shop.ID.SC_PACKAGE_SYNC, synctype=1,
                     itemlist=equip.package_add_payload(added, role))
    # 【v20】领取礼盒后也把弹药真实数量推给客户端
    if ptype == 3 and _gift_row is not None:
        shop.gift_ammo_sync(session, _gift_row, role)
    _push_money(session, role)
    (log.info("role %s 领取礼盒 %s (type=%s item=%s) -> %s",
             role.name, presentid, ptype, itemid, added) if log.isEnabledFor(20) else None)
