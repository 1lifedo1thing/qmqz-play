"""玩家资料：改名（CsChangeName）与查看他人资料（CsGetRoleInfo）。

这两条客户端一直在发，服务端原来都没有 handler：

    RenameDialog.OnConfirm -> CsChangeName(rolename)       1114145
        <- ScChangeName(result, rolename)                  1114146
           result 0 成功 / 1 名字被占用(Callboard 413) /
                  2 名字非法(395) / 3 钱不够(30)

    ViewManager.View(roleid) -> CsGetRoleInfo(roleid)      1114158
        <- ScGetRoleInfo(...)                              1114159

没有 handler 的表现：改名框点确定没反应；点别人头像「查看资料」没反应。
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from ..net.server import ROUTER, Session
from . import pve_progress

log = logging.getLogger("crisisfire.profile")


class ID:
    CS_CHANGE_NAME = 1114145
    SC_CHANGE_NAME = 1114146
    CS_GET_ROLE_INFO = 1114158
    SC_GET_ROLE_INFO = 1114159
    CS_SET_SEX = 1114156
    SC_SET_SEX = 1114157
    SC_USER_INFO = 1114117
    CHANGE_ICON = 1114128          # com.gwebtop.user.ChangeIcon（收发同一个类）


# ScChangeName.result
NAME_OK = 0
NAME_TAKEN = 1
NAME_INVALID = 2
NAME_NO_MONEY = 3

MAX_NAME_LEN = 16          # 客户端自己限 8 个字，服务端放宽一点（防绕过）


def _world():
    from . import handlers
    return handlers.world


def _role_of(session: Session):
    world = _world()
    if world is None or not session.roleid:
        return None
    return world.role(session.roleid)


def _valid_name(name: str) -> bool:
    if not name or len(name) > MAX_NAME_LEN:
        return False
    # 换行/制表符会把客户端聊天/房间列表排版搞乱
    return not any(ch in name for ch in "\r\n\t")


@ROUTER.register(ID.CS_CHANGE_NAME, "user.CsChangeName")
async def on_change_name(session: Session, msg: dict) -> None:
    role = _role_of(session)
    if role is None:
        return
    world = _world()
    name = str(msg.get("rolename") or "").strip()
    if not _valid_name(name):
        session.send(ID.SC_CHANGE_NAME, result=NAME_INVALID, rolename=name)
        return
    if name == role.name:
        session.send(ID.SC_CHANGE_NAME, result=NAME_OK, rolename=name)
        return
    other = world.role_named(name) if world is not None else None
    if other is not None and other.roleid != role.roleid:
        session.send(ID.SC_CHANGE_NAME, result=NAME_TAKEN, rolename=name)
        return
    old = role.name
    try:
        world.update_role(role.roleid, name=name)
    except ValueError:
        session.send(ID.SC_CHANGE_NAME, result=NAME_TAKEN, rolename=name)
        return
    session.role_name = name
    (log.info("role %s 改名 %r -> %r", role.roleid, old, name) if log.isEnabledFor(20) else None)

    # 房间成员表里缓存的是旧名字，改完要同步，否则房间里还是旧名
    try:
        from . import room_handlers as rh
        room = rh.MANAGER.room_of(role.roleid)
        if room is not None:
            member = room.members.get(role.roleid)
            if member is not None:
                member.name = name
            rh._sync_room(room)
    except Exception:
        (log.debug("改名后同步房间失败 role=%s", role.roleid, exc_info=True) if log.isEnabledFor(10) else None)

    session.send(ID.SC_CHANGE_NAME, result=NAME_OK, rolename=name)
    # 大厅顶部的名字来自 ScUserInfo.property.name
    try:
        from . import handlers
        session.send(ID.SC_USER_INFO, roleid=role.roleid,
                     property=handlers._property_of(role))
    except Exception:
        (log.debug("改名后推送 ScUserInfo 失败", exc_info=True) if log.isEnabledFor(10) else None)


def _head_ids() -> set:
    """Head 表里存在的头像 id（1..N + 1001~1004 那批 VIP 头像）。"""
    from .. import gamedata
    out = set()
    for row in gamedata.table("Head"):
        try:
            out.add(int(row.get("id") or 0))
        except (TypeError, ValueError):
            continue
    out.discard(0)
    return out


@ROUTER.register(ID.CHANGE_ICON, "user.ChangeIcon")
async def on_change_icon(session: Session, msg: dict) -> None:
    """更换头像。

    `HeadIconSelectDialog.onConfirm` 只做两件事：发 `ChangeIcon(iconid)`、
    关掉对话框 —— **本地不改头像，也不等回包**。真正把头像换掉的是
    `com.gwebtop.user.ChangeIcon.process` → `UserManager.SwitchIcon(iconid)`，
    而 process 只会在**收到服务端下发的同一个 ChangeIcon** 时执行。
    所以服务端必须：存 iconid + 原样回一条 ChangeIcon。
    以前没有 handler（消息被丢弃），表现就是「点确定头像不变」。
    """
    role = _role_of(session)
    if role is None:
        return
    iconid = int(msg.get("iconid") or 0)
    heads = _head_ids()
    if heads and iconid not in heads:
        (log.info("role %s 换头像被拒：%s 不在 Head 表", role.name, iconid)
         if log.isEnabledFor(20) else None)
        session.send(ID.CHANGE_ICON, iconid=int(role.iconid or 0))
        return
    world = _world()
    try:
        if world is not None:
            world.update_role(role.roleid, iconid=iconid)
        else:
            role.iconid = iconid
    except Exception:
        log.exception("更换头像写库失败 role=%s iconid=%s", role.roleid, iconid)
        session.send(ID.CHANGE_ICON, iconid=int(role.iconid or 0))
        return
    role.iconid = iconid
    (log.info("role %s 更换头像 -> %s", role.roleid, iconid)
     if log.isEnabledFor(20) else None)

    # 房间成员表也缓存了 iconid，不同步的话队友看到的还是旧头像
    try:
        from . import room_handlers as rh
        room = rh.MANAGER.room_of(role.roleid)
        if room is not None:
            member = room.members.get(role.roleid)
            if member is not None:
                member.iconid = iconid
            rh._sync_room(room)
    except Exception:
        (log.debug("换头像后同步房间失败 role=%s", role.roleid, exc_info=True)
         if log.isEnabledFor(10) else None)

    # ★ 回一条，客户端 process → SwitchIcon 才会更新 UI（头像 + userIconChanged 回调）
    session.send(ID.CHANGE_ICON, iconid=iconid)


def _equip_ids(role) -> List[int]:
    """展示用的装备（当前方案里的武器 id）—— 查不到就返回空列表。"""
    try:
        from . import equip
        rows = equip.loadouts_of(role)
        if not rows:
            return []
        eq = rows[0].get("equipmap") or {}
        return [int(v) for v in eq.values() if int(v or 0) > 0]
    except Exception:
        return []


def _rank_stats(role) -> Dict[str, Any]:
    """军衔/排位相关字段。服务端没有排位系统，先给 0（客户端会照常显示）。"""
    return {"ranknum": 0, "rankwin": 0, "rankpoint": 0}


@ROUTER.register(ID.CS_SET_SEX, "user.CsSetSex")
async def on_set_sex(session: Session, msg: dict) -> None:
    """性别切换（GenderModal -> CsSetSex(0=男 / 1=女)）。

    `ScSetSex(roleid, sex)` 只触发客户端 `UserManager.SetSex` 事件刷新界面；
    服务端把 `roles.sex` 存下来即可（角色创建/换装界面读它）。
    """
    role = _role_of(session)
    world = _world()
    if role is None or world is None:
        return
    sex = int(msg.get("sex") or 0)
    if sex not in (0, 1):
        return
    world.update_role(role.roleid, sex=sex)
    session.send(ID.SC_SET_SEX, roleid=role.roleid, sex=sex)
    (log.info("role %s 性别 -> %s", role.roleid, "女" if sex else "男") if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_GET_ROLE_INFO, "user.CsGetRoleInfo")
async def on_get_role_info(session: Session, msg: dict) -> None:
    world = _world()
    target = int(msg.get("roleid") or 0)
    if world is None or not target:
        return
    role = world.role(target)
    if role is None:
        return
    data = role.data or {}
    session.send(
        ID.SC_GET_ROLE_INFO,
        roleid=role.roleid,
        rank=int(role.level or 1),
        name=role.name or "",
        iconid=int(role.iconid or 0),
        teamname=str(data.get("teamname") or ""),
        medals={},
        vipstatus=int(data.get("vipstatus") or 0),
        monthcard=int(pve_progress.month_active(role)),
        killnum=int(data.get("killnum") or 0),
        headshots=int(data.get("headshots") or 0),
        killrate=float(data.get("killrate") or 0.0),
        equip=_equip_ids(role),
        **_rank_stats(role),
    )
    (log.info("role %s 查看 %s 的资料", session.roleid, target) if log.isEnabledFor(20) else None)
