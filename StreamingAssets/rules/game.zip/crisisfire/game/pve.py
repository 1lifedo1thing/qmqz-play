"""1.9 challenge local response, using its own tables and MonsterState."""
import asyncio
import logging
import math
from collections import defaultdict
from functools import lru_cache

from .. import gamedata
from ..net.server import ROUTER
from . import bot_balance, damage

log = logging.getLogger("crisisfire.pve")
PVE_MODE = 12
MONSTER_ID_BASE = 1_000_000
SC_MONSTER_BORN, SC_MONSTER_TARGET, SC_MONSTER_ATTACK = 1441971, 1441972, 1441974
SC_ROUND_START, SC_ROUND_CLEAR = 1441976, 1442007
SC_RESULT, SC_DETAIL, SC_SCORE = 1245277, 1245278, 1442006
# Local balance for the reconstructed challenge. The 1.9 tables supply the
# weapon, range, body-part and monster values, but no online damage formula.
GUN_DAMAGE_SCALE = 3


def is_pve(gamemode):
    return gamemode == PVE_MODE


@lru_cache(maxsize=None)
def rows(name):
    return {int(row.get("id", row.get("Id"))): row for row in gamedata.table(name)}


def values(value):
    return value["_items"][:value["_size"]] if isinstance(value, dict) else value


def xyz(pos):
    return {key: int(value) for key, value in zip("xyz", pos)}


def metres(pos):
    return tuple(float(pos.get(axis, 0)) / 100 for axis in "xyz")


def armor_profile(equipmap):
    # UC 1.9 Numeric.ArmorAC uses the largest maxAc in slots 31–34.
    armor = rows("Armor")
    equipped = (armor[equipmap[slot]] for slot in (31, 32, 33, 34)
                if equipmap.get(slot) in armor)
    return max(equipped, key=lambda row: row["maxAc"], default={})


@lru_cache(maxsize=None)
def challenge_coefficient(part):
    return next((row["challengeCoefficient"] for row in gamedata.table("DamageCoefficient")
                 if row["hitPartId"] == part), 1.0)


def shot_damage(weapon, part, distance, ammo=None):
    if not math.isfinite(distance) or distance < 0:
        return 0
    coefficient = challenge_coefficient(part)
    gun = rows("Gun").get(weapon)
    if gun is None:
        melee = rows("Melee").get(weapon)
        return int((melee["damag"] + melee["heroDamage"]) * coefficient) if melee else 0
    ammo = ammo or {}
    effective = gun["effectiveRange"] + ammo.get("effectiveRangePlus", 0)
    maximum = gun["maximumRange"] + ammo.get("maxRangePlus", 0)
    if distance >= maximum:
        return 0
    # Tip 1078 and the depot's PvEDMG panel put Hero Strike in Challenge.
    # Reconstructed as a separate bonus, without applying the local 3x
    # ordinary gun scale to it. The equipped upgrade's own row supplies it.
    strike = gun["heroBasicDamage"]
    bonus = ammo.get("basicDamagePlus", 0)
    if distance <= effective:
        base = gun["basicDamage"]
    else:
        # AttackProperty.SetGun interpolates the base and ammo values together.
        fraction = (distance - effective) / (maximum - effective)
        base = gun["basicDamage"] + fraction * (gun["minDamage"] - gun["basicDamage"])
        bonus += fraction * (ammo.get("minDamagePlus", 0) - bonus)
        strike *= 1 - fraction
    return int((base * GUN_DAMAGE_SCALE + strike + bonus) * coefficient)


def wave_plan(round_id):
    row = rows("ChallengeRound")[round_id]
    groups = values(row["monsterGroupId"])
    coordinates = [values(row[key]) for key in ("x", "y", "z", "kx", "ky", "kz")]
    if any(len(column) != len(groups) for column in coordinates):
        raise ValueError(f"Incomplete spawn columns for ChallengeRound {round_id}")
    schedules = []
    available_at = {}
    for group, *point in zip(groups, *coordinates):
        config = rows("MonsterGroup")[group]
        model = rows("ChallengeMonster")[config["monsterId"]]
        for _ in range(config["num"]):
            schedules.append((float(config["delayTime"]), tuple(point[:3]), tuple(point[3:]), model))
    result = []
    # The later client sample shows a short separation between monsters using
    # the same point. The spacing is a local reconstruction. Positions and
    # group start delays are the 1.9 values.
    for due, pos, rotation, model in sorted(schedules, key=lambda row: row[0]):
        due = max(due, available_at.get(pos, 0))
        available_at[pos] = due + 0.55
        result.append((due, pos, rotation, model))
    return sorted(result, key=lambda row: row[0])


class Challenge:
    def __init__(self, battle):
        from . import pve_allies, pve_progress, pve_revive, pve_support

        self.battle = battle
        self.mode = rows("ChallengeMode")[battle.room.levelid]
        self.rounds = values(self.mode["round"])
        self.times = values(self.mode["maxTime"])
        self.index = -1
        self.monsters = {}
        self.next_id = MONSTER_ID_BASE
        self.started = False
        self.finished = False
        self.pending = []
        self.advance = None
        self.timeout = None
        self.damage = defaultdict(int)
        self.kills = defaultdict(int)
        self.started_at = None
        self.settled_at = None
        self.wave_deadline = None
        self.next_retarget_at = 0
        self.time_bonus = defaultdict(int)
        self.participants = set()
        self.loop = None
        self.medals = pve_progress.ChallengeMedals(self)
        self.revives = pve_revive.Revives(self)
        self.support = pve_support.BattleSupport(self)
        self.allies = pve_allies.Allies(self)

    def player_born(self, fighter):
        from . import bots, handlers, pve_rewards
        if bots.is_bot(fighter.roleid):
            self.allies.born(fighter)
            return
        first = fighter.roleid not in self.participants
        if first:
            self.participants.add(fighter.roleid)
            world = handlers.world
            role = world.role(fighter.roleid) if world else None
            if role is not None:
                pve_rewards.close_result(world, role)
            if self.started:
                self.support.sync_props(fighter.roleid)
        self.revives.born(fighter.roleid, first)

    def spawn_armor(self, fighter):
        fighter.fullac = armor_profile(fighter.equipmap).get("maxAc", 0)
        fighter.ac = fighter.fullac
        (log.info("PVE armor spawn role=%s ac=%s", fighter.roleid, fighter.ac) if log.isEnabledFor(20) else None)

    def active(self):
        return self.started and not self.finished and not self.battle.fight_over

    def begin(self):
        if self.started:
            return
        self.started = True
        self.loop = asyncio.get_running_loop()
        self.next_round()
        self.support.start()

    def next_round(self):
        self.index += 1
        if self.index == len(self.rounds):
            self.finish(True)
            return
        plan = wave_plan(self.rounds[self.index])
        self.wave_total = len(plan)
        remain = self.times[self.index]
        if not plan or remain <= plan[-1][0]:
            raise ValueError(f"Invalid wave {self.rounds[self.index]} duration/spawns")
        now = self.loop.time()
        if self.started_at is None:
            self.started_at = now
        self.battle.send_all(SC_ROUND_START, curr=self.index + 1,
                             round=len(self.rounds), remaintime=remain)
        self.wave_deadline = now + remain
        self.pending = [self.loop.call_later(due, self.spawn, pos, rotation, model)
                        for due, pos, rotation, model in plan]
        self.timeout = self.loop.call_later(remain, self.finish, False)

    def stop(self):
        for timer in (*self.pending, self.timeout, self.advance):
            if timer is not None:
                timer.cancel()
        self.pending.clear()
        self.timeout = self.advance = None

    def pick_target(self, pos, current=0):
        origin = metres(pos)
        distances = {f.roleid: math.dist(origin, f.syncpos) for f in self.battle.fighters.values()
                     if f.born and f.hp > 0 and f.syncpos is not None}
        nearest = min(distances, key=distances.get, default=0)
        # Keep chasing a live target until a different fighter is clearly closer.
        if current in distances and distances[current] <= distances[nearest] + 3.0:
            return current
        return nearest

    def controller(self, target):
        from . import bots

        # For a BOT target the room owner runs native monster AI on its behalf.
        return self.battle.room.owner if bots.is_bot(target) else target

    def spawn(self, pos, rotation, model):
        if not self.active():
            return
        self.pending.pop(0)
        self.next_id += 1
        mid = self.next_id
        hp = float(model["hpBase"])
        target = self.pick_target(xyz(pos))
        mob = {"pos": xyz(pos), "quat": {**xyz(rotation), "w": 0}, "model": model,
               "hp": hp, "target": target, "controller": self.controller(target), "attackindex": -1}
        self.monsters[mid] = mob
        self.battle.send_all(SC_MONSTER_BORN, monsterid=mid, pos=mob["pos"], quat=mob["quat"],
                             modelid=model["id"], hp=hp, ac=0, targetid=target, fullhp=hp, fullac=0)

    def retarget(self):
        for mid, mob in self.monsters.items():
            target = self.pick_target(mob["pos"], mob["target"])
            controller = self.controller(target)
            if mob["target"] == target and mob["controller"] == controller:
                continue
            mob["target"] = target
            if mob["controller"] != controller:
                mob["controller"], mob["attackindex"] = controller, -1
            self.battle.send_all(SC_MONSTER_TARGET, monsterid=mid, pos=mob["pos"],
                                 quat=mob["quat"], targetid=target)

    def tick(self):
        if not self.active():
            return
        self.allies.tick()
        now = self.loop.time()
        if now >= self.next_retarget_at:
            self.next_retarget_at = now + 1.0
            self.retarget()

    def maybe_clear(self):
        if self.active() and not self.pending and not self.monsters and self.advance is None:
            # Send the last hit before releasing this wave's client resources.
            self.advance = self.loop.call_soon(self.clear)

    def clear(self):
        if not self.active():
            return
        # No original service-side formula was recovered. Use the time left
        # on successfully cleared waves for the local time bonus.
        left = max(0, min(self.times[self.index], int(self.wave_deadline - self.loop.time())))
        self.medals.clear(self.wave_total)
        for fighter in self.battle.fighters.values():
            if fighter.born or fighter.roleid in self.participants:
                roleid = fighter.roleid
                self.time_bonus[roleid] += left
                self.battle.send_all(SC_SCORE, roleid=roleid, score=self.score(roleid))
        self.stop()
        self.battle.send_all(SC_ROUND_CLEAR, round=self.index + 1)
        self.next_round()

    def hurt(self, roleid, mid, mob, amount, part):
        dealt = min(int(math.ceil(mob["hp"])), amount)
        mob["hp"] = max(0.0, mob["hp"] - amount)
        self.damage[roleid] += dealt
        died = mob["hp"] == 0
        if died:
            del self.monsters[mid]
            self.kills[roleid] += 1
            self.medals.kill(roleid, mob["model"])
            from . import handlers, tasks
            if handlers.world is not None:
                tasks.record(handlers.world.role(roleid), task_type=tasks.CHALLENGE_KILL)
        self.battle.send_all(SC_SCORE, roleid=roleid, score=self.score(roleid))
        self.maybe_clear()
        return damage.HitResult(mid, dealt, part, died, mob["hp"])

    def send_deaths(self, killerid, weaponid, victims):
        from .battle import ID

        for victim in victims:
            self.battle.send_all(ID.SC_KILL, roleid=victim, killerid=killerid,
                                 weaponid=weaponid, killtype=0, combokill=0)
            (log.info("PVE-KILL role=%s victim=%s weapon=%s", killerid, victim, weaponid) if log.isEnabledFor(20) else None)

    def score_breakdown(self, roleid):
        table = rows("ChallengeScore")
        duration = 0
        if self.settled_at is not None and self.started_at is not None:
            duration = int(max(0, self.settled_at - self.started_at))
        counts = {1: self.damage[roleid], 2: self.kills[roleid], 3: duration,
                  4: self.support.pickups[roleid]}
        points = {1: counts[1] * table[1]["num"], 2: counts[2] * table[2]["num"],
                  3: self.time_bonus[roleid] * table[3]["num"], 4: counts[4] * table[4]["num"]}
        for medal, count in self.medals.counts.get(roleid, {}).items():
            counts[medal] = count
            points[medal] = count * table[medal]["num"]
        return counts, points

    def score(self, roleid):
        return sum(self.score_breakdown(roleid)[1].values())

    def on_shoot(self, roleid, shot, *, ammo=None):
        from .bots import is_bot

        fighter = self.battle.fighters.get(roleid)
        if not self.active() or fighter is None or not fighter.born or fighter.hp <= 0:
            return []
        slot, weapon = damage.active_weapon(fighter)
        reach = damage.melee_range(slot, weapon)
        if reach is None and not shot.get("targets") and not is_bot(roleid):
            fallback = self.gun_fallback(fighter, weapon, shot, ammo)
            if fallback is not None:
                shot["targets"] = [fallback]
        hits = []
        for target in shot.get("targets", ()):
            mid = target["targetid"]
            mob = self.monsters.get(mid)
            if mob is None:
                continue
            if reach is not None and (
                fighter.syncpos is None or not 0 <= target["sd"] <= reach
                or math.dist(fighter.syncpos, metres(mob["pos"])) > reach + damage.MELEE_SYNC_TOLERANCE
            ):
                continue
            part = target["hitpart"]
            amount = self.support.attack_bonus(roleid, shot_damage(weapon, part, target["sd"], ammo))
            amount = bot_balance.damage(self.battle, roleid, amount)
            if amount > 0:
                hits.append(self.hurt(roleid, mid, mob, amount, part))
        return hits

    def gun_fallback(self, fighter, weapon, shot, ammo=None):
        from . import geometry
        gun = rows("Gun").get(weapon)
        if not gun or not self.monsters:
            return None
        scene = gamedata.map_row(self.battle.room.mapid)["scene"]
        collider = geometry.for_scene(scene)
        if collider is None:
            return None
        reach = gun["maximumRange"] + (ammo or {}).get("maxRangePlus", 0)
        origin = metres(shot.get("position") or {})
        ray = metres(shot.get("dir") or {})
        length = math.hypot(*ray)
        if not length or reach <= 0:
            return None
        direction = tuple(value / length for value in ray)
        best = None
        for mid, mob in self.monsters.items():
            x, y, z = metres(mob["pos"])
            size = mob["model"]["actor_scale"]
            center = (x, y + 1.0 * size, z)
            distance = sum((b - a) * d for a, b, d in zip(origin, center, direction))
            if not 0 < distance <= reach or (best and distance >= best["sd"]):
                continue
            impact = tuple(a + d * distance for a, d in zip(origin, direction))
            height = impact[1] - y
            nearest = (x, y + min(max(height, 0), 1.75 * size), z)
            if math.dist(impact, nearest) > 0.45 * size or not collider.clear(origin, impact):
                continue
            part = 1 if height > 1.45 * size else 2 if height > 1.0 * size else 3 if height > 0.6 * size else 4
            best = {"targetid": mid, "sd": distance, "hitpart": part,
                    "hitpos": xyz((a - b) * 100 for a, b in zip(impact, (x, y, z))),
                    "targetpos": mob["pos"]}
        return best

    def grenade(self, roleid, itemid, pos):
        from . import pve_progress

        origin = metres(pos)
        radius = damage.grenade_row(itemid).get("blastRange", 0)
        targets = []
        dead = []
        if not self.active() or radius <= 0:
            return targets, dead
        for mid, mob in list(self.monsters.items()):
            distance = math.dist(origin, metres(mob["pos"]))
            if distance > radius:
                continue
            amount = self.support.attack_bonus(roleid, damage.calc_grenade_damage(itemid, distance))
            amount = bot_balance.damage(self.battle, roleid, amount)
            if amount > 0:
                hit = self.hurt(roleid, mid, mob, amount, damage.GRENADE_PART)
                if hit.died:
                    dead.append(mid)
                targetpos = mob["pos"]
                targets.append(dict(targetid=mid, hpdamage=float(hit.hpdamage), acdamage=0,
                                    sapihpdamage=0, hitpart=hit.hitpart, sd=distance,
                                    hitpos={}, targetpos=targetpos))
        if len(dead) >= 5 and self.medals.award(roleid, pve_progress.EXPLOSIVE):
            self.battle.send_all(SC_SCORE, roleid=roleid, score=self.score(roleid))
        return targets, dead

    def managed_monster(self, session, message):
        mid = message["monsterid"]
        mob = self.monsters.get(mid) if self.active() else None
        return mob if mob and mob["controller"] == session.roleid else None

    def sync(self, session, msg, message_id):
        mob = self.managed_monster(session, msg)
        if mob is None:
            return
        mob["pos"], mob["quat"] = msg["pos"], msg["quat"]
        self.battle.send_others(session.roleid, message_id, **msg)

    def on_attack(self, session, msg):
        mob = self.managed_monster(session, msg)
        if mob is None:
            return
        index, skill_id = msg["attackindex"], msg["skillid"]
        if skill_id <= 0:
            if index <= mob["attackindex"]:
                return
            mob["attackindex"] = index
        # TPSMonsterBehaviour.SkillFire writes -1 for every skill event.
        mob["pos"], mob["quat"] = msg["pos"], msg["quat"]
        model = mob["model"]
        attack = float(model["damage"])
        reach = float(model["range"])
        if skill_id > 0:
            if skill_id not in values(model["skillId"]):
                return
            skill = rows("MonsterSkill")[skill_id]
            reach = float(skill["range"])
            if skill["type"] in (2, 4):
                grenade = damage.grenade_row(skill["damage"])
                reach = float(grenade["blastRange"])
            elif skill["damage"] > 0:
                attack = float(skill["damage"])

        targets = list(dict.fromkeys(msg["targetid"]))
        hpdamage, acdamage = [], []
        dead = []
        for roleid in targets:
            fighter = self.battle.fighters.get(roleid)
            amount = 0.0
            armor_damage = 0
            if (fighter is not None and fighter.born and fighter.hp > 0 and fighter.syncpos is not None
                and not self.battle.is_invincible(roleid) and not self.support.pickup_shield(roleid)):
                center = msg["targetpos"] if skill_id > 0 and skill["type"] in (2, 4) else mob["pos"]
                distance = math.dist(metres(center), fighter.syncpos)
                if distance <= reach + 0.4:
                    amount = attack
                    if skill_id > 0 and skill["type"] in (2, 4):
                        amount = float(damage.calc_grenade_damage(skill["damage"], distance))
                    if amount > 0 and fighter.ac > 0:
                        # Monster attacks have no hit part. Use the armor that
                        # supplies the AC pool and spend at least one AC per hit.
                        # The original server-side reduction formula is unavailable.
                        armor = armor_profile(fighter.equipmap)
                        armor_cost = max(1, math.ceil(amount - armor["monsterDAc"]))
                        armor_damage = min(fighter.ac, armor_cost)
                        amount -= min(amount, armor["monsterDHp"]) * armor_damage / armor_cost
                        fighter.ac -= armor_damage
                    fighter.hp = max(0.0, fighter.hp - amount)
                    if fighter.hp == 0:
                        dead.append(roleid)
            hpdamage.append(amount)
            acdamage.append(armor_damage)
        self.battle.send_all(SC_MONSTER_ATTACK, **{**msg, "targetid": targets,
                                                  "hpdamage": hpdamage, "acdamage": acdamage})
        self.send_deaths(msg["monsterid"], 0, dead)
        for roleid in dead:
            self.support.player_died(roleid)
            self.battle.on_kill(0, roleid)
        if dead:
            self.retarget()

    def finish(self, won):
        if not self.active():
            return
        from . import handlers, leveling, pve_progress, pve_rewards, pve_support, tasks

        if won:
            for roleid, fighter in self.battle.fighters.items():
                if (roleid in self.participants or fighter.born) and fighter.deaths == 0:
                    self.medals.award(roleid, pve_progress.SURVIVAL)
        self.settled_at = self.loop.time()
        self.finished = True
        self.stop()
        self.support.stop()
        self.battle.fight_over = True
        self.battle.room.started = False
        for roleid in self.battle.fighters:
            self.battle._cancel_relive(roleid)
        pve_support.clear_buffs(self.battle.room)
        scores = {roleid: self.score(roleid) for roleid in self.battle.fighters}
        self.battle.send_all(SC_RESULT, roomid=self.battle.room.roomid, win=int(won),
                             round=min(self.index + 1, len(self.rounds)), scores=scores)
        world = handlers.world
        if world is None:
            return
        for roleid, score in scores.items():
            role = world.role(roleid)
            if role is None:
                continue
            old_rank = role.level
            result = pve_rewards.new_result(self.mode, score)
            played = roleid in self.participants or self.battle.fighters[roleid].born
            changes = {pve_rewards.RESULT_KEY: result if played and result["grade"] else None}
            vipexp = vipmoney = first = 0
            if won and played:
                vipexp, vipmoney, first = pve_progress.win_bonuses(role, self.mode, changes)
                world.award_local(roleid, changes, exp=self.mode["expReward"] + vipexp,
                                  coins=self.mode["goldReward"] + vipmoney,
                                  honor=self.mode["honoReward"] + first)
                tasks.record(role, task_type=tasks.CHALLENGE_WIN)
            else:
                world.merge_role_data(roleid, **changes)
            session = world.session_of_role(roleid, "gs")
            if session is not None and not session.closed:
                pve_rewards.send_times(session, role)
                counts, breakdown = self.score_breakdown(roleid)
                session.send(SC_DETAIL, vipexp=vipexp, vipmoney=vipmoney, firstwinbloodgem=first, sumscore=score,
                             medals=counts, scores=breakdown)
                pve_rewards.send_balance(session, role)
                if won and played:
                    session.send(2686979, researchpoint=changes["research_point"])
                leveling.push_if_ranked_up(session, role, old_rank, role.level)


def challenge_of(session):
    from . import battle, room_handlers
    room = room_handlers.MANAGER.room_of(session.roleid)
    fight = battle.battle_for(room, create=False) if room is not None else None
    return fight.challenge if fight is not None else None


@ROUTER.register(1441973, "gclient.CsMonsterAttack")
async def monster_attack(session, msg):
    challenge = challenge_of(session)
    if challenge is not None:
        challenge.on_attack(session, msg)


@ROUTER.register(1441975, "gclient.MonsterPosSync")
async def monster_pos(session, msg):
    challenge = challenge_of(session)
    if challenge is not None:
        challenge.sync(session, msg, 1441975)


@ROUTER.register(1441981, "gclient.MonsterSkillStart")
async def monster_skill(session, msg):
    challenge = challenge_of(session)
    if challenge is not None:
        challenge.sync(session, msg, 1441981)
