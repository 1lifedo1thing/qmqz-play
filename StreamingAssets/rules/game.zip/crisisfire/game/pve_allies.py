"""Local challenge teammates using the native roster, movement and combat messages."""
import logging
import math
from collections import deque
from dataclasses import dataclass, field
from types import SimpleNamespace

from . import bot_balance, pve_bot_compat as bots, human, navigation, weapon_fire
from .pve import metres

log = logging.getLogger("crisisfire.pve.allies")
FORMATION = ((-4.5, -2.5), (4.5, -2.5), (0.0, 5.0))
SYNC_INTERVAL = 0.1  # UC Config.syncInterval, consumed by PosSyncClient.


@dataclass
class Motion:
    foot: float = 0.0
    anchor: tuple | None = None
    formation: tuple | None = None
    goal: tuple | None = None
    path: deque = field(default_factory=deque)
    yaw: float | None = None
    speed: float = 0.0
    aim: int = 0
    fire: dict = field(default_factory=dict)


class Allies:
    def __init__(self, challenge):
        self.challenge = challenge
        self.battle = challenge.battle
        self.ammo = {}
        self.motion = {}
        self.supply_due = {}
        self.supply_goals = {}
        self.last_tick = None

    def born(self, fighter):
        roleid = fighter.roleid
        self.ammo[roleid] = human.AmmoState.from_loadout(fighter.equipmap)
        self.motion.pop(roleid, None)
        self.supply_due.pop(roleid, None)
        self.supply_goals.pop(roleid, None)

    def tick(self):
        if not self.challenge.active() or not self.ammo:
            return
        now = self.challenge.loop.time()
        dt = SYNC_INTERVAL if self.last_tick is None else min(0.25, now - self.last_tick)
        self.last_tick = now
        if dt <= 0:
            return
        nav, colliders = bots._world(self.battle)
        if nav is None or colliders is None:
            return
        neighbours = {rid: f.syncpos for rid, f in self.battle.fighters.items()
                      if f.born and f.hp > 0 and f.syncpos is not None}
        entries = {}
        for roleid, ammo in self.ammo.items():
            if roleid not in neighbours or ammo.active not in ammo.slots:
                continue
            fighter = self.battle.fighters[roleid]
            entry = self.step(fighter, ammo, nav, colliders, neighbours, now, dt)
            if entry is not None:
                entries[roleid] = entry
                neighbours[roleid] = fighter.syncpos
        if entries:
            self.battle.broadcast_positions(entries)

    def step(self, fighter, ammo, nav, colliders, neighbours, now, dt):
        rid, here = fighter.roleid, fighter.syncpos
        motion = self.motion.get(rid)
        if motion is None:
            ground = nav.ground(here)
            foot = max(0, min(0.5, here[1] - ground[1])) if ground else 0
            motion = self.motion[rid] = Motion(foot=foot)
        slot = ammo.slots[ammo.active]
        if (loaded := ammo.update(now)) is not None:
            bots._send_reload_stop(self.battle, fighter, *loaded)

        destination = None
        target = None
        needs_supply = not slot.clip and not slot.reserve
        if needs_supply:
            destination = self.supply_destination(rid, here, ammo, nav, now)
        else:
            enemies = sorted((math.dist(here, metres(mob["pos"])), mid, metres(mob["pos"]))
                             for mid, mob in self.challenge.monsters.items())
            candidates = sorted(enemies, key=lambda enemy: enemy[1] != motion.aim)
            visible = next((enemy for enemy in candidates if enemy[0] <= slot.info.effective_range
                            and bots._visible(colliders, here, enemy[2])), None)
            if visible is not None:
                _, mid, pos = visible
                target = SimpleNamespace(roleid=mid, syncpos=pos)
                motion.aim = mid

            teammate = min((pos for other, pos in neighbours.items() if other not in self.ammo),
                           key=lambda pos: math.dist(here, pos), default=None)
            if teammate is not None:
                destination = self.formation_goal(rid, motion, nav, here, teammate)
            elif target is None:
                destination = next((point for _, _, pos in enemies
                                    if (point := self.reachable_point(nav, here, pos)) is not None), None)

        speed = human.move_speed(slot.info)
        budget = min(speed, motion.speed + 9 * dt) * dt
        position = self.advance(nav, colliders, here, destination, motion, budget)
        if destination is not None or target is not None:
            if needs_supply:
                # Teammates already inside the ring can wait in the approach
                # lane. Keep avoiding players and moving allies on the way in.
                neighbours = {other: pos for other, pos in neighbours.items()
                              if other not in self.ammo or not self.challenge.support.at_ammo(other)}
            position = bots._separate(nav, colliders, here, position, rid, neighbours, motion.foot, budget)
        motion.speed = math.dist(here, position) / dt
        entry = self.position_entry(fighter, target, here, position, motion, speed, dt)

        if not slot.clip and ammo.start_reload(now) is not None:
            bots._send_reload_start(self.battle, fighter, ammo.active)
        visible = target is not None and bots._visible(colliders, position, target.syncpos)
        if not bot_balance.ready(self.battle, fighter, target, visible, now, motion.fire):
            ammo.hold(now)
            return entry
        dist = math.dist(position, target.syncpos)
        moving = motion.speed > 0.25
        motion.fire["moving"] = moving
        fired = ammo.take_shots(now, dt, min_period=bot_balance.profile(self.battle).shot_gap)
        if weapon_fire.needs_multi(slot.info):
            weapon_fire.bot_fire(self.battle, fighter, target, dist, slot.info,
                                 seq=int(now * 1000) + rid, events=ammo.drain_ray_events(),
                                 ray_clear=colliders.clear, log_tag="PVE-BOTMULTI", moving=moving)
        else:
            for _ in range(fired):
                if target.roleid not in self.challenge.monsters:
                    break
                bots._fire(self.battle, fighter, target, dist, colliders=colliders, state=motion.fire)
        return entry

    @staticmethod
    def advance(nav, colliders, here, goal, motion, budget):
        if goal is None:
            motion.goal = None
            motion.path.clear()
            return here
        if motion.goal is None or math.dist(motion.goal, goal) > 1.0:
            motion.goal = tuple(goal)
            motion.path = deque(nav.path(here, goal)[1:])
        while motion.path:
            point = motion.path[0]
            # Path corners are at floor level. Project to the fighter's foot
            # height before checking arrival or calculating the stride.
            point = (point[0], point[1] + motion.foot, point[2])
            length = math.dist(here, point)
            if length > 0.14:
                candidate = navigation.lerp(here, point, min(1.0, budget / length))
                position = bots._grounded_step(nav, colliders, here, candidate, motion.foot, budget)
                if position == here:
                    motion.goal = None  # Rebuild from the actual floor on the next tick.
                return position
            motion.path.popleft()
        return here

    @staticmethod
    def position_entry(fighter, target, here, position, motion, speed, dt):
        entry = bots._step(fighter, target or fighter, 0, speed, dt, destination=position)
        facing = target.syncpos if target is not None else position
        dx, dz = facing[0] - here[0], facing[2] - here[2]
        if math.hypot(dx, dz) > 0.02:
            yaw = math.atan2(dx, dz)
            if motion.yaw is None:
                motion.yaw = yaw
            else:
                delta = (yaw - motion.yaw + math.pi) % math.tau - math.pi
                cap = math.radians(270) * dt
                motion.yaw += max(-cap, min(cap, delta))
        if entry is not None and motion.yaw is not None:
            half = motion.yaw * 0.5
            entry["state"]["quat"] = {"x": 0, "y": round(math.sin(half) * 20000),
                                      "z": 0, "w": round(math.cos(half) * 20000)}
        return entry

    def formation_goal(self, roleid, motion, nav, here, anchor):
        if motion.anchor is None or math.dist(motion.anchor, anchor) >= 2.0:
            index = tuple(self.ammo).index(roleid) % len(FORMATION)
            dx, dz = FORMATION[index]
            goal = (anchor[0] + dx, anchor[1], anchor[2] + dz)
            motion.anchor = anchor
            motion.formation = self.reachable_point(nav, here, goal)
            if motion.formation is None and (start := nav.locate(here)) is not None:
                points = (pos for node, pos in nav.centers.items()
                          if nav.component[node] == nav.component[start[0]]
                          and abs(pos[1] - anchor[1]) < 1.2 and 3 <= math.dist(pos, anchor) <= 8)
                occupied = [other.formation for rid, other in self.motion.items()
                            if rid != roleid and other.formation is not None]
                motion.formation = min(points, key=lambda pos: (sum(math.dist(pos, p) < 2 for p in occupied),
                                                                math.dist(pos, goal)), default=None)
        return motion.formation

    @staticmethod
    def reachable_point(nav, here, pos):
        start, end = nav.locate(here), nav.locate(pos)
        if start is not None and end is not None and nav.component[start[0]] == nav.component[end[0]]:
            return end[1]
        return None

    def supply_destination(self, roleid, here, ammo, nav, now):
        support = self.challenge.support
        if support.at_ammo(roleid):
            due = self.supply_due.setdefault(roleid, now + support.ammo_time)
            if now >= due:
                self.supply_due.pop(roleid)
                self.supply_goals.pop(roleid, None)
                ammo.reset_full()
                support.complete_refill(roleid)
            return None

        self.supply_due.pop(roleid, None)
        if roleid not in self.supply_goals:
            start = nav.locate(here)
            if start is None:
                return None
            center = support.layout["ammo_pos"]
            # Ammo's transform can be inside solid geometry. Navigate to a
            # reachable floor point inside the original trigger sphere.
            radius = support.layout["ammo_radius"]
            foot = self.motion[roleid].foot
            points = (pos for node, pos in nav.centers.items()
                      if nav.component[node] == nav.component[start[0]]
                      and math.dist((pos[0], pos[1] + foot, pos[2]), center) < radius - 0.2)
            claimed = tuple(self.supply_goals.values())
            goal = min(points, key=lambda pos: (sum(math.dist(pos, other) < 1.25 for other in claimed),
                                                math.dist(here, pos)), default=None)
            if goal is not None:
                self.supply_goals[roleid] = goal
                (log.info("PVE-BOT-AMMO role=%s from=%s goal=%s", roleid, here, goal) if log.isEnabledFor(20) else None)
        return self.supply_goals.get(roleid)
