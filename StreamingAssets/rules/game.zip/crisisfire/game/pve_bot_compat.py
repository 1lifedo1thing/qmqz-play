"""PvP 房间人机：按1.8.1客户端数据重建的服务端控制器。

默认 bots_drive 通过 ScBorn / ScRoleStatusSync / ScShoot 驱动远程角色，
攻击复用玩家共用结算链；巡游、避让与路径算法为重建实现。
移动读取本包导航及静态碰撞，不给未知地图添加穿墙直线兜底。

另有独立实验开关 bots_ai：ScManageAI(1441905) 将 roleid 写入客户端
robots 字典，RobotDesc 必须取真实表内 id，且必须先于 ScBorn 下发。
它与 bots_drive 互斥：ClientManager.RoleStatusSync 跳过 IsRelated 角色。
旧设备记录已证明单独下发 ManageAI 未能启动本包的完整 AI，不能称它已可用。
僵尸还受 AArsenal 的非僵尸 TPS 上枪条件限制，默认走服务端控制器。

客户端依据：ClientManager、PosSyncClient、BeanConverter、ABiochemHand、
AArsenal、Robot、TPSOnlineBehaviour；服务一侧始终是本地重建实现。
"""
from __future__ import annotations

import logging
import math
import time
from typing import Any, Dict, List, Optional, Tuple

from .. import gamedata
from ..config import CONFIG
from . import rooms as R
from . import damage, special_modes
from . import human
from . import bio_sense, bot_balance, room_ai, weapon_fire

log = logging.getLogger("crisisfire.bots")


class ID:
    SC_MANAGE_AI = 1441905

# 机器人 roleid 段：和真实角色（十万级）、PVE 怪物（1000001+）都错开
BOT_ID_BASE = 900_000
BOT_NAMES = ["机器人·阿尔法", "机器人·贝塔", "机器人·伽马", "机器人·德尔塔"]


_actors_cache: Dict[int, List[int]] = {}


def actors_of_camp(camp: int) -> List[int]:
    """Role.json 里属于某个阵营的角色 id（camp 1=警、2=匪、3=僵尸）。

    机器人**必须**拿一个真实存在的 actorid。客户端 `PlayerData.Init()` 是：

        Role roleById = CsRoleMgr.instance.GetRoleById(actorid);
        IsZombie = roleById.camp == 3;        // roles 查不到 -> null -> NRE

    而 `GetRoleById` 未命中直接回 null，所以此前 `f.actorid = 1`（Role 表里
    最小的 id 是 101）会让整条 ScBorn 在客户端**抛空引用后什么也不画** ——
    这就是名单里有人、场上却是「幽灵」的原因。
    """
    if camp not in _actors_cache:
        try:
            rows = gamedata.table("Role") or []
        except Exception:
            log.exception("读 Role 表失败")
            rows = []
        _actors_cache[camp] = sorted({int(r.get("id") or 0) for r in rows
                                      if int(r.get("camp") or 0) == camp
                                      and int(r.get("id") or 0) > 0})
    return _actors_cache[camp]


def pick_actor(side: int, index: int = 0) -> int:
    ids = actors_of_camp(2 if side == 2 else 1)
    if not ids:
        return 0
    return ids[index % len(ids)]


_rows: Optional[List[Dict[str, Any]]] = None


def _desc_rows() -> List[Dict[str, Any]]:
    """RobotDesc 表（id 0 是客户端 levelRobots 排除掉的样板，一并跳过）。"""
    global _rows
    if _rows is None:
        try:
            _rows = [r for r in gamedata.table("RobotDesc") or []
                     if int(r.get("id") or -1) > 0]
        except Exception:
            log.exception("读 RobotDesc 表失败")
            _rows = []
    return _rows


def pick_robotid(level: int, actorid: int = 0) -> Optional[Dict[str, Any]]:
    """挑一个**客户端查得到**的 RobotDesc 行。

    `RobotConfigs.GetRobotDesc(id)` 未命中回 null，而 `ManageAI` 紧接着就
    `robotDesc.level` —— 越界 id = 客户端空引用。所以这里只从表里真实存在的
    id 里选，并且优先挑 actorId 和机器人当前模型一致的那一行（和客户端单机
    侧 `RandomPrototype(level, camp)` 的思路一致）。档位没有则就近借档。
    """
    rows = _desc_rows()
    if not rows:
        return None
    exact = [r for r in rows if int(r.get("level") or 0) == int(level)]
    cand = exact or rows
    match = [r for r in cand if int(r.get("actorId") or 0) == int(actorid)]
    pool = match or cand
    pool.sort(key=lambda r: int(r.get("id") or 0))
    return pool[0]


def manage_ai(battle, fighter) -> int:
    """给机器人下发 ScManageAI —— 让客户端自己跑它的 AI。

    证据见模块 docstring（`TPSOnlineBehaviour` 只在 `DataPool.IsRobot(roleid)`
    时才替这台机器人发 `CsShoot`，而 `IsRobot` 就是 `ManageAI` 填进去的字典）。

    **必须发在 ScBorn 之前** —— 这不是保险，是硬要求，链条是：

        AArsenal.cs:204   if (DataPool.IsRobot(warrior.roleid))
                              warrior.GetComponent<Robot>().EquipWeapon(id);
        Robot.cs:164      EquipWeapon -> Startup()
        Robot.cs:178      Startup -> StartCoroutine(Ranging())   // AI 的心跳

    出生时的 TPS 枪械加载协程只跑**一次**。ManageAI 若晚于 ScBorn，那一刻
    IsRobot 还是 false ⇒ `Robot.EquipWeapon` 永远不会被调 ⇒ `Startup` 没跑过
    ⇒ 组件挂上了也没有心跳，机器人照样立正。（真机实测正是这个顺序：44 条
    ScManageAI 都发了、客户端 logcat 一条 Unity 异常都没有，但服务端收到的
    CsShoot 仍然全是玩家一个人的。）
    反过来先发 ManageAI：`OnRoleCreated`（ClientManager.cs:1331）会在出生时按
    `robots` 字典补挂 `Robot`，随后枪械加载时 IsRobot 已为真，AI 才起步。

    返回用到的 robotid（没发则 0）。
    """
    if not CONFIG.bots_ai or not is_bot(fighter.roleid):
        return 0
    desc = pick_robotid(CONFIG.bots_ai_level, int(fighter.actorid or 0))
    if desc is None:
        log.warning("RobotDesc 表没有可用行，%s 保持站桩", fighter.roleid)
        return 0
    robotid = int(desc.get("id") or 0)
    battle.send_all(ID.SC_MANAGE_AI, roleid=int(fighter.roleid),
                    robotid=robotid)
    (log.info("人机接管 AI role=%s robotid=%s level=%s actor=%s",
             fighter.roleid, robotid, desc.get("level"), desc.get("actorId")) if log.isEnabledFor(20) else None)
    return robotid


def _bot_seed(battle) -> int:
    return int.from_bytes(getattr(battle.room, "token", b""), "big")


def _bot_equipmap(battle, roleid: int) -> Dict[int, int]:
    """Base equipment chosen independently of every player's inventory."""
    from . import equip, weapon_catalog
    rule = special_modes.rule(getattr(battle.room, "equiplimitid", 0)) or {}
    category = weapon_catalog.CATEGORY_BY_SUBTYPE.get(rule.get("mainEquipType"), "")
    weapons = weapon_catalog.basic_bot_loadout(
        _bot_index(roleid), seed=_bot_seed(battle), main_category=category, include_grenade=True)
    return {**equip.COMMON, **weapons}


def install(battle, count: int = 2) -> int:
    """确保机器人进入战斗。只装一次。

    两个来源：
    * room_fill 预填的成员（房间满员 → 客户端才肯开始）——补建 fighter；
    * 房间没满时按 count 再补。
    """
    if getattr(battle, "_bots_installed", False):
        return 0
    battle._bots_installed = True

    added = 0
    # 预填成员已有 bot roleid：只补 fighter，不动成员表
    for roleid, member in list(battle.room.members.items()):
        if is_bot(roleid) and roleid not in battle.fighters:
            f = battle.add(member)
            f.equipmap = _bot_equipmap(battle, roleid)
            f.equipindex = 0
            f.actorid = pick_actor(int(getattr(member, "side", 1) or 1), added)
            _ensure_human_loadout(battle, f, reset_ammo=True)
            added += 1
            (log.info("预填机器人入战斗 roleid=%s name=%s side=%s actor=%s 装备=%s",
                     roleid, member.name, member.side, f.actorid, f.equipmap) if log.isEnabledFor(20) else None)

    for i in range(count):
        limit = int(getattr(battle.room, 'playerlimits', 0) or 0)
        if limit > 0 and len(battle.room.members) >= limit:
            break
        roleid = BOT_ID_BASE + i + 1
        if roleid in battle.room.members:
            continue
        side = 1 if i % 2 == 0 else 2
        name = BOT_NAMES[i % len(BOT_NAMES)]
        member = R.Member(roleid=roleid, name=name, level=30, iconid=1,
                          side=side, ready=True)
        battle.room.members[roleid] = member
        f = battle.add(member)
        f.equipmap = _bot_equipmap(battle, roleid)
        f.equipindex = 0
        f.actorid = pick_actor(side, i)
        _ensure_human_loadout(battle, f, reset_ammo=True)
        added += 1
        (log.info("加入机器人 roleid=%s name=%s side=%s 装备=%s",
                 roleid, name, side, f.equipmap) if log.isEnabledFor(20) else None)

    if added:
        (log.info("房间 %s 共加入 %d 个机器人", battle.room.roomid, added) if log.isEnabledFor(20) else None)
    # Pre-filled room members may already have a Fighter; install must still
    # apply the biochem loadout before their first ScBorn.
    for f in getattr(battle, "fighters", {}).values():
        if is_bot(f.roleid):
            _ensure_human_loadout(battle, f, reset_ammo=True)
    return added


def is_bot(roleid: int) -> bool:
    return BOT_ID_BASE < int(roleid or 0) < BOT_ID_BASE + 10_000


# ==========================================================================
# 生化人类 BOT：装备 / 弹量 / 协议
# ==========================================================================
#
# 所有数值来自 Item/Gun/Melee 表与 equipment_audit 的资源清单，策略值是重建
# 实现（见 human.py / weapon_catalog.py）。普通模式、真人装备、英雄 {50: 8001}
# 和僵尸形态都不进入这里。
#
# 战术切换：主/副/近战都来自真实 equipmap 槽位。切换只发 WeaponChange（复用
# 已装备槽位），ScGunChange 仅用于初始装备/ScBorn 后的有限弹量同步；切枪不会
# 重建枪械、不会回满弹。持握/冷却值见 human.MIN_HOLD_SECONDS 等。
def _is_bio_room(battle) -> bool:
    try:
        return int(getattr(battle.room, "gamemode", 0) or 0) in human.BIOCHEM_MODES
    except (TypeError, ValueError):
        return False


def _bot_index(roleid: int) -> int:
    return max(0, int(roleid or 0) - BOT_ID_BASE - 1)


def _is_human_bot(battle, f) -> bool:
    if not is_bot(getattr(f, "roleid", 0)) or not _is_bio_room(battle):
        return False
    bio = getattr(battle, "biochem", None)
    if bio is None:
        # install() runs before Battle.begin() creates Biochem.  At that point
        # every bot is still a human; infection only happens later.
        return True
    return (not bio.is_zombie(f.roleid)
            and f.roleid not in getattr(bio, "heroes", set()))


def _ammo_states(battle) -> Dict[int, human.AmmoState]:
    states = getattr(battle, "_bot_ammo", None)
    if states is None:
        states = battle._bot_ammo = {}
    return states


def _tactical_states(battle) -> Dict[int, human.TacticalState]:
    states = getattr(battle, "_bot_tactical", None)
    if states is None:
        states = battle._bot_tactical = {}
    return states


def _route_state(battle, roleid: int):
    """Route preference store keyed by roleid (Fighter is __slots__).

    The main coordinator can call ``human.notify_route_state`` on this object
    (or hand its own RouteState to ``human.weapon_preference``).  It only
    records a preference; it never moves or jumps.
    """
    if human.WC is None:
        return None
    table = getattr(battle, "_bot_route", None)
    if table is None:
        table = battle._bot_route = {}
    state = table.get(int(roleid))
    if state is None:
        state = table[int(roleid)] = human.WC.RouteState()
    return state


def route_state(battle, roleid: int):
    """Public main-coordinator hook: get the persistent per-BOT RouteState.

    Usage:
        st = bots.route_state(battle, roleid)
        human.notify_route_state(st, route="parkour", safe=True)
        human.request_mobility_weapon(st, now, duration=1.5)
    This only records a preference; the BOT tactical layer decides when a
    legal WeaponChange may happen.  No movement or jump is performed here.
    """
    return _route_state(battle, roleid)


def _melee_for(f, state) -> Optional[human.MeleeInfo]:
    iid = int((getattr(f, "equipmap", {}) or {}).get(human.POS_MELEE) or 0)
    cached = state.get("melee")
    if cached is not None and int(cached[0]) == iid:
        return cached[1]
    info = human.load_melee(iid) if iid else None
    state["melee"] = (iid, info)
    return info


def _send_weapon_change(battle, f, slot: int) -> None:
    """WeaponChange reuses an already-equipped slot; it never rebuilds a gun.

    `ClientManager.WeaponChange(roleid, weaponpos, bulletnum)` (ClientManager.cs
    :200-221) calls `PlayerData.PullWeapon(weaponpos)` and then
    `ChangeWeapon(roleid, weaponid, AmmoID, bulletnum - ammoInClip, ammoInClip)`
    where `ammoInClip = playerData.GetAmmoInClip(weaponpos)` is the client's
    current magazine.  So the wire field `bulletnum` is the **total** held
    rounds (clip + reserve), not a clip and not a reserve: the client subtracts
    its own clip to obtain reserve (AWeapon.Attach: ammoReserve = reserve,
    ammoInClip = inClip).  Sending only clip or only reserve would rotate the
    displayed reserve to the wrong number.

    ScGunChange (ClientManager.GunChange -> PlayerData.PickWeapon) replaces the
    gun row and is reserved for initial equip/after ScBorn.  A tactical switch
    must use WeaponChange so clip/reserve stay exactly what the server holds.
    """
    from . import battle as B
    st = _ammo_state(battle, f)
    total = 0
    if st is not None and int(slot) in st.slots:
        total = st.total(int(slot))
    battle.send_all(B.ID.WEAPON_CHANGE, roleid=int(f.roleid),
                    weaponpos=int(slot), bulletnum=int(total))


def _ensure_human_loadout(battle, f, reset_ammo: bool = False) -> bool:
    """Apply the biochem human loadout before ScBorn, and on every round reset.

    The same dict is stored in human_equipmap so _next_bio_round restores the
    machine gun instead of an empty/generic loadout.  Ammo is only refilled by
    reset_ammo=True (new round), never by a respawn inside the round.
    """
    if not _is_human_bot(battle, f):
        return False
    gamemode = int(getattr(battle.room, "gamemode", 0) or 0)
    index = _bot_index(f.roleid)
    round_index = int(getattr(battle, "_bot_round_seq", 0) or 0)
    states = _ammo_states(battle)
    # Fast path for the per-tick call: compare against the already-resolved
    # loadout, so no Item/Gun lookup or AmmoState rebuild happens every tick.
    applied = dict(getattr(f, "human_equipmap", {}) or {})
    if (not reset_ammo and int(f.roleid) in states and applied
            and dict(getattr(f, "equipmap", {}) or {}) == applied):
        return True
    loadout = human.equip_for_bot(
        gamemode, index, is_bot=True, is_zombie=False, is_hero=False,
        round_index=round_index, seed=_bot_seed(battle))
    if not loadout:
        log.warning("HUMAN-BOT no renderable loadout role=%s", f.roleid)
        return False
    changed = dict(getattr(f, "equipmap", {}) or {}) != loadout
    f.equipmap = dict(loadout)
    f.human_equipmap = dict(loadout)
    new_state = int(f.roleid) not in states
    if changed or reset_ammo or new_state:
        states[int(f.roleid)] = human.AmmoState.from_loadout(loadout)
    if changed or reset_ammo or new_state:
        (log.info("HUMAN-BOT EQUIP role=%s items=%s ammo_reset=%s",
                 f.roleid, sorted(loadout.items()),
                 bool(reset_ammo or changed or new_state)) if log.isEnabledFor(20) else None)
    return True


def _ammo_state(battle, f) -> Optional[human.AmmoState]:
    states = _ammo_states(battle)
    st = states.get(int(f.roleid))
    if st is None:
        if not _ensure_human_loadout(battle, f):
            return None
        st = states.get(int(f.roleid))
    return st


def refill_reserves(battle, f) -> None:
    st = _ammo_state(battle, f)
    if st is None:
        return
    # ClientManager.PickupItem calls FillAmmoAll(false) and ReFull(false).
    st.cancel_reload()
    for state in st.slots.values():
        state.reserve = state.info.reserve


def prepare_born(battle, f) -> Tuple[int, int]:
    """battle.born() hook: equip before ScBorn and return reserve counts.

    ScBorn.mainbullet/minorbullet feed PlayerData.Apply -> FillAmmoAll; they are
    reserve counts, not clip+reserve.  Returning -1 lets native FillAmmoAll use
    Gun.ammo-clip for non-BOT players (unchanged).
    """
    if not is_bot(getattr(f, "roleid", 0)) or not _is_bio_room(battle):
        return -1, -1
    if not _ensure_human_loadout(battle, f):
        return -1, -1
    st = _ammo_state(battle, f)
    if st is None:
        return -1, -1
    done = st.update(time.monotonic())
    if done is not None:
        _send_reload_stop(battle, f, done[0], done[1])
    return st.born_reserve()


def current_born_reserve(battle, f) -> Tuple[int, int]:
    """Read-only reserve for snapshot ScBorn of an already spawned BOT."""
    if not is_bot(getattr(f, "roleid", 0)) or not _is_bio_room(battle):
        return -1, -1
    st = _ammo_states(battle).get(int(f.roleid))
    return st.born_reserve() if st is not None else (-1, -1)


def on_round(battle) -> None:
    """battle._next_bio_round() hook: restore every human BOT's loadout.

    This runs before _spawn_prepared_bots(), so the following ScBorn carries
    the machine gun in equipmap; equipment is never changed only server-side.
    """
    if not _is_bio_room(battle):
        return
    # Advance the deterministic round seed BEFORE re-equipping, so a new round
    # gets the next catalog category/variant.  Ammo is reset only here.
    battle._bot_round_seq = int(getattr(battle, "_bot_round_seq", 0) or 0) + 1
    for f in list(getattr(battle, "fighters", {}).values()):
        if is_bot(f.roleid) and _is_human_bot(battle, f):
            _ensure_human_loadout(battle, f, reset_ammo=True)
    battle._bot_tactical = {}
    battle._bot_route = {}
    battle._bot_state = {}


def _send_reload_start(battle, f, slot: int) -> None:
    from . import battle as B
    battle.send_all(B.ID.SC_FILL_BULLET,
                    roleid=int(f.roleid), weaponpos=int(slot))


def _send_reload_stop(battle, f, slot: int, rounds: int) -> None:
    from . import battle as B
    type_id = getattr(B.ID, "SC_FILL_BULLET_STOP", 1441946)
    battle.send_all(type_id, roleid=int(f.roleid),
                    weaponpos=int(slot), finishtimes=int(rounds))


def _send_gun_state(battle, f, slot: int, viewerid: int = 0) -> None:
    """ScGunChange(roleid, weaponpos, gunid, inclip, reserve, reservefull).

    ClientManager.GunChange (ClientManager.cs:1221-1235) calls
    PlayerData.PickWeapon + Warrior.PickWeapon, so it both replaces the gun in
    that slot *and* activates it as the held weapon (AArsenal.Pick ->
    AGun.Initialize).  WeaponChange is not needed; sending both would rebuild
    the gun model twice.  For a non-active slot it still updates that slot's
    PlayerData clip/reserve via AGun.Equipped -> DataPool.AmmoChanged.
    """
    from . import battle as B
    st = _ammo_state(battle, f)
    if st is None or slot not in st.slots:
        return
    s = st.slots[slot]
    fields = dict(roleid=int(f.roleid), weaponpos=int(slot),
                  gunid=int(s.info.itemid), bulletnum=int(s.clip),
                  sumbulletnum=int(s.reserve),
                  maxbulletnum=int(s.info.reserve))
    if viewerid and hasattr(battle, "send_to_role"):
        battle.send_to_role(int(viewerid), B.ID.SC_GUN_CHANGE, **fields)
    else:
        battle.send_all(B.ID.SC_GUN_CHANGE, **fields)


def _send_gun_snapshot(battle, f, viewerid: int = 0) -> None:
    """Re-sync both slots after a ScBorn.

    PlayerData.Apply -> Init -> FillAmmoAll(all:true) always sets
    ammo_main_clip/ammo_minor_clip = Gun.clip (PlayerData.cs:332-359), so the
    client would show a full magazine even when the server has fewer rounds.
    Send the non-active slot first (it also stores its clip/reserve) and the
    active slot last so the held weapon ends up correct.
    """
    st = _ammo_state(battle, f)
    if st is None:
        return
    order = [s for s in (human.POS_VICE_GUN, human.POS_MAIN_GUN)
             if s != st.active and s in st.slots]
    order.append(st.active)
    for slot in order:
        _send_gun_state(battle, f, slot, viewerid=viewerid)


def after_born(battle, f, viewerid: int = 0) -> None:
    """battle.born()/_snapshot_born_to() hook: correct the auto-full clip."""
    if not is_bot(getattr(f, "roleid", 0)) or not _is_bio_room(battle):
        return
    if not _is_human_bot(battle, f):
        return
    if int(f.roleid) not in _ammo_states(battle):
        return
    _send_gun_snapshot(battle, f, viewerid=viewerid)


_PROP_CACHE: Dict[int, Dict[str, Any]] = {}


def _zombie_prop(actorid: int) -> Dict[str, Any]:
    key = int(actorid or 0)
    prop = _PROP_CACHE.get(key)
    if prop is None:
        from .biochem import bio_property_of
        prop = bio_property_of(key) or {}
        _PROP_CACHE[key] = prop
    return prop


# ==========================================================================
# 服务端驱动的人机大脑（CF_BOTS_DRIVE=1，默认开）
# ==========================================================================
#
# 为什么要在服务端做：客户端自带的 `Robot` 心跳只有一个入口
# （`AArsenal` 的 TPS 上枪分支 -> `Robot.EquipWeapon` -> `Startup`），
# 真机实测服务端把 `ScManageAI` 按正确顺序发过去也不会起步（HANDOFF 第九轮）。
# 而客户端本来就有一套**处理远程真人**的机制，服务端完全可以照它来驱动：
#
#     ClientManager.RoleStatusSync(ScRoleStatusSync)   // 位置：>8m 直接 teleport
#     ClientManager.Shoot(ScShoot)                     // 弹道 + 掉血 + 死亡表现
#
# 所以本模块做的事只有一件：**把机器人当成一个"由服务端操控的远程玩家"** ——
# 每 tick 推位置、按交战距离开一枪，枪走 `battle.settle_shoot`，
# 和玩家上报的 CsShoot 共用同一条伤害/击杀/感染裁决链。
#
# 数值来源（不靠猜）：
#   僵尸 runSpeed / range / atkSpeed / damage  <- BioProperty.json（runSpeed 7.5~8.2、
#     range 2.7、atkSpeed 0.45）；`sd` 超过 range 会被 damage.resolve_shoot 忽略，
#     所以爪击必须真的贴脸。
#   人类的 6.0 m/s、35m 交战距离、0.9s 节奏 = **重建值**（包内没有"玩家移动速度"
#     这类可直接引用的表），只影响观感，不参与任何官方数值。
#   生化 8/10 人类 BOT 已改走 human.py：Gun.shootSpeed 作为射击间隔、Gun.clip/
#     ammo 作为有限弹量。下面的 0.9s 只保留给普通模式的旧路径。

HUMAN_SPEED = 6.0        # 米/秒（重建值）
HUMAN_RANGE = 35.0       # 米：枪械有效交战距离（重建值）
HUMAN_KEEP = 9.0        # 米：压到这个距离就停下开火（重建值）
HUMAN_INTERVAL = 0.9     # 秒：普通模式旧路径（生化走 Gun.shootSpeed）
# Reconstructed practice BOT tuning. Player weapons use the original tables.
PISTOL_REACTION = 0.7
PISTOL_INTERVAL = 0.95
PISTOL_KEEP = 6.0
ZOMBIE_KEEP_RATIO = 0.6  # 僵尸要贴到 range 的 60% 以内才爪击
ZOMBIE_FALLBACK = (2.7, 7.5, 0.6)   # range / speed / interval 兜底


def _v3(x: float, y: float, z: float) -> Dict[str, int]:
    """世界坐标 -> 线上 Vec3（short，×100）。"""
    return {"x": int(round(x * 100)), "y": int(round(y * 100)),
            "z": int(round(z * 100))}


def _pos(f) -> Optional[Tuple[float, float, float]]:
    p = getattr(f, "syncpos", None)
    if not p:
        return None
    return (float(p[0]), float(p[1]), float(p[2]))


def _side_of(battle, f) -> int:
    """敌我划分：生化看"是不是僵尸"，其它模式看 side。"""
    bio = getattr(battle, "biochem", None)
    if bio is not None:
        return 3 if bio.is_zombie(f.roleid) else 1
    return 1 if int(f.side or 1) == 1 else 2


def _profile(battle, f) -> Tuple[float, float, float, float]:
    """(交战距离, 移动速度, 开火间隔, 压近距离)。"""
    bio = getattr(battle, "biochem", None)
    if bio is not None and bio.is_zombie(f.roleid):
        from .biochem import bio_property_of
        prop = bio_property_of(f.actorid) or {}
        rng = float(prop.get("range") or ZOMBIE_FALLBACK[0])
        spd = float(prop.get("runSpeed") or ZOMBIE_FALLBACK[1])
        # ABiochemHand.FireTask holds Firing for atkRate + atkSpeed;
        # ShootFreq additionally gates requests at atkRate + .1 seconds.
        rate = float(prop.get("atkRate") or .15)
        itv = max(rate + float(prop.get("atkSpeed") or .45), rate + .1)
        return rng, spd, max(0.2, itv), rng * ZOMBIE_KEEP_RATIO
    if bio is not None and f.roleid in getattr(bio,'heroes',set()):
        # Hero conversion replaces the gun with 8001. The old 12m gun keep
        # distance made sword heroes retreat forever outside their 2.7m reach.
        melee=damage._table('Melee').get(int(f.equipmap.get(50) or 0)) or {}
        if melee:
            rng=float(melee['range']);interval=float(melee['speed'])
            return rng,7.0,interval,rng*.6
    slot, itemid = damage.active_weapon(f)
    reach = damage.melee_range(slot, itemid)
    if reach is not None:
        melee = damage._table("Melee").get(itemid) or {}
        return reach, HUMAN_SPEED, float(melee.get("speed") or HUMAN_INTERVAL), reach * 0.65
    limit = getattr(battle.room, "equiplimitid", 0)
    if limit == special_modes.PISTOL and slot == human.POS_VICE_GUN:
        gun = damage._table("Gun").get(itemid) or {}
        return float(gun.get("effectiveRange") or 0), HUMAN_SPEED, PISTOL_INTERVAL, PISTOL_KEEP
    if limit:
        from . import grenades
        if f.weaponpos == 41:
            reach = float(damage.grenade_row(itemid)["blastRange"])
            return reach, HUMAN_SPEED, float(grenades.hand_launcher()["shootFreq"]), reach * 0.7
    return HUMAN_RANGE, HUMAN_SPEED, HUMAN_INTERVAL, HUMAN_KEEP


def _pick_target(battle, f, nav=None, colliders=None):
    """同阵营不算，死人不算，没位置的不算；取最近的一个。

    返回 (target, dist)；没有可打的目标时返回 (None, None)。
    """
    me = _side_of(battle, f)
    here = _pos(f)
    if here is None:
        return None, None
    origin=nav.locate(here) if nav is not None else None
    bio = getattr(battle, 'biochem', None)
    zombie = bio is not None and bio.is_zombie(f.roleid)
    hero = bio is not None and f.roleid in getattr(bio,'heroes',())
    best, bd = None, None
    for g in battle.fighters.values():
        if g.roleid == f.roleid or not g.born or g.hp <= 0:
            continue
        if _side_of(battle, g) == me:
            continue
        gp = _pos(g)
        if gp is None:
            continue
        d = math.sqrt(sum((a - b) ** 2 for a, b in zip(here, gp)))
        if nav is not None:
            dest=nav.locate(gp)
            connected=(origin is not None and dest is not None
                       and nav.component[origin[0]]==nav.component[dest[0]])
            graph=getattr(nav,'parkour_routes',None)
            if (not connected and graph is not None and origin is not None and dest is not None
                    and (hero or (zombie and gp[1] - here[1] > .35))):
                connected=graph.can_reach(nav.component[origin[0]],nav.component[dest[0]])
            if not connected:
                # A visible target across a gap can still be shot. Otherwise
                # choose a reachable enemy instead of chasing an isolated roof.
                if d>_profile(battle,f)[0] or not _visible(colliders,here,gp):continue
        if bd is None or d < bd:
            best, bd = g, d
    return best, bd


def _step(f, target, dist, speed, dt, destination=None) -> Optional[dict]:
    """朝目标走一步，返回要广播的那一条 `SRoleSync`（没动则 None）。

    面向目标用绕 Y 的 quat（线上 ×20000 的 short）。客户端对非本人的角色是按
    pos 插值走位，朝向只影响模型脸朝哪。
    """
    fp, tp = _pos(f), _pos(target)
    if fp is None or tp is None or dt <= 0:
        return None
    if destination is None:
        if dist <= .0001: destination = fp
        else:
            k = min(1.0, (speed * dt) / dist)
            destination = tuple(a+(b-a)*k for a,b in zip(fp,tp))
    nx,ny,nz = destination
    f.syncpos = (nx, ny, nz)
    # Patrol has no enemy to face. Use its actual movement direction.
    heading = (nx-fp[0], nz-fp[2]) if target is f else (tp[0]-fp[0], tp[2]-fp[2])
    half = math.atan2(*heading) * 0.5
    return {
        "state": {
            "quat": {"w": int(round(math.cos(half) * 20000)), "x": 0,
                     "y": int(round(math.sin(half) * 20000)), "z": 0},
            "pos": _v3(nx, ny, nz),
            "speed": _v3((nx - fp[0]) / dt, (ny - fp[1]) / dt, (nz - fp[2]) / dt),
        },
        "timestamp": int(time.time() * 1000),
    }


def _fire(battle, f, target, dist, *, colliders=None, state=None) -> None:
    """替机器人开一枪：走的是和玩家 CsShoot 完全相同的结算出口。"""
    from . import battle as B
    fp, tp = _pos(f), _pos(target)
    if fp is None or tp is None:
        return
    dx, dy, dz = tp[0] - fp[0], (tp[1] + 1.2) - (fp[1] + 1.5), tp[2] - fp[2]
    n = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
    shoot = {
        "position": _v3(fp[0], fp[1] + 1.5, fp[2]),
        "dir": {"x": int(round(dx / n * 20000)), "y": int(round(dy / n * 20000)),
                "z": int(round(dz / n * 20000))},
        "targets": [{
            "targetid": int(target.roleid),
            "sd": float(dist),
            "hitpart": 2,
            "hitpos": _v3(tp[0], tp[1] + 1.2, tp[2]),
            "targetpos": _v3(tp[0], tp[1], tp[2]),
        }],
    }
    _, weapon = damage.active_weapon(f)
    if not damage.uses_melee(battle, f) and damage._table("Gun").get(weapon):
        state = state if state is not None else {}
        sequence = state.get("shot_sequence", 0) + 1
        state["shot_sequence"] = sequence
        shoot, = weapon_fire.aim_shoots(
            f.roleid, weapon, sequence, (fp[0], fp[1] + 1.5, fp[2]), (dx, dy, dz),
            target.roleid, tp, dist, {}, count=1, aim_spread_deg=0.0,
            ray_clear=colliders.clear if colliders else None,
            aim_error=bot_balance.aim_offset(battle, f.roleid, sequence, state.get("moving", False),
                                               weaponid=weapon))
    B.settle_shoot(battle, int(f.roleid), shoot, battle.biochem is not None, log_tag="BOTSHOOT")


def _fire_volleys(battle, f, target, dist, info, rounds, seq=0, events=None,
                  colliders=None, moving=False) -> int:
    """Native trigger-first ray groups -> ScMultiShoot.

    ``events`` is the exact list recorded by AmmoState: one entry per trigger
    first round, even when the trigger's remaining rounds arrive in a later
    dispatch.  The magazine was already charged by take_shots; this function
    never touches ammo.  Single-shot guns stay on _fire above.  Each pellet
    ray is checked against its own static corridor through ``colliders``.
    """
    from . import weapon_fire
    clear = None
    if colliders is not None:
        clear = colliders.clear
    return weapon_fire.bot_fire(battle, f, target, dist, info, int(rounds),
                                seq=seq, log_tag="BOTSHOOT", events=events,
                                ray_clear=clear, moving=moving)



def _world(battle):
    from . import navigation, geometry
    scene = str((gamedata.map_row(battle.room.mapid) or {}).get('scene') or '')
    nav = geometry.grid_for_scene(scene) or navigation.for_scene(scene)
    colliders = geometry.for_scene(scene)
    if int(battle.room.gamemode or 0) in (8,10):
        from . import parkour_routes
        routes=parkour_routes.for_scene(scene)
        if routes is not None:nav=routes.nav
    if getattr(battle,'_bot_world_logged',None) != scene:
        battle._bot_world_logged = scene
        (log.info('BOT-WORLD scene=%s navigation=%s triangles=%s',scene,
                 nav.source_sha256 if nav else 'missing',len(colliders.tris) if colliders else 0) if log.isEnabledFor(20) else None)
    return nav,colliders


def _visible(colliders, a, b):
    if colliders is None:return False
    return colliders.clear((a[0],a[1]+1.5,a[2]),(b[0],b[1]+1.2,b[2]))


def _anchor(nav, here, seed, away=None, occupied=(), recent=()):
    """Local patrol/retreat choice; all candidates must lie on actual ground."""
    from .navigation import distance
    if hasattr(nav,'centers'):
        loc=nav.locate(here)
        if loc is None:return None
        candidates=[p for k,p in nav.centers.items()
                    if nav.component[k]==nav.component[loc[0]] and 2<distance(here,p)<12]
    else:
        candidates=[]
        for dx,dz in ((5,0),(-5,0),(0,5),(0,-5),(4,4),(-4,4),(4,-4),(-4,-4)):
            loc=nav.locate((here[0]+dx,here[1],here[2]+dz))
            if loc:candidates.append(loc[1])
    if not candidates:return None
    if away is not None:
        candidates.sort(key=lambda p:distance(p,away)-.25*distance(here,p),reverse=True)
        candidates=candidates[:8]
    else:
        candidates.sort();offset=seed%len(candidates)
        candidates=candidates[offset:]+candidates[:offset]
        # Score a distributed bounded sample rather than every map cell for
        # every actor. Patrol selection must not stall the shared room clock.
        if len(candidates)>32:
            candidates=[candidates[i*len(candidates)//32] for i in range(32)]
        # Equal seeds used to send neighbours back to the same few offsets.
        # Spread destinations across the connected legal region and prefer
        # places not just visited. This is reconstructed patrol policy.
        def penalty(p):
            crowd=sum(max(0.,3.-math.hypot(p[0]-q[0],p[2]-q[2]))
                      for q in occupied if abs(p[1]-q[1])<1.2)
            revisit=sum(max(0.,2.-distance(p,q)) for q in recent)
            return crowd+2.*revisit
        candidates.sort(key=penalty)
    for p in candidates[:12]:
        if hasattr(nav,'corridor'):
            a,b=nav.locate(here),nav.locate(p)
            if a is not None and b is not None and nav.corridor(a[0],b[0]):return p
        elif nav.path(here,p):return p
    return None


def _grounded_step(nav, colliders, here, desired, foot, budget):
    """Validate the exact transmitted segment, including support and speed."""
    from .navigation import distance, lerp
    origin=nav.locate(here)
    if origin is None:return here
    for attempt in range(4):
        candidate=lerp(here,desired,.5**attempt)
        ground=nav.ground(candidate)
        if ground is None:continue
        candidate=(candidate[0],ground[1]+foot,candidate[2])
        if distance(here,candidate)>budget+.005:continue
        # Physics support alone does not imply membership in this baked graph.
        # Infection/ScBorn round positions to centimetres, so validate that
        # exact representation too before allowing the movement.
        candidate=tuple(round(v*100)/100 for v in candidate)
        if distance(here,candidate)>budget+.005:continue
        loc=nav.locate(candidate)
        if loc is None or nav.component[loc[0]]!=nav.component[origin[0]]:continue
        if not nav.clear(here,candidate):continue
        # A collision Grid.clear already performs this same physical query.
        if getattr(nav,'scene',None) is colliders or colliders.walk_clear(here,candidate):
            return candidate
    return here


def _separate(nav, colliders, here, desired, rid, neighbours, foot, budget):
    """Local crowd steering; never push/teleport another role or bypass a wall.

    Positions come from one tick-start snapshot so roster iteration order cannot
    bias avoidance. Other floors and dead/unborn actors do not repel. The .9m
    comfort distance is reconstructed policy; the native body radius is .35m.
    """
    from .navigation import distance
    nearby=[(other,p) for other,p in neighbours.items() if other!=rid
            and abs(p[1]-here[1])<1.2
            and math.hypot(p[0]-here[0],p[2]-here[2])<budget+1.2]
    if not nearby:return desired
    def crowd(point):
        return sum(max(0.,.9-math.hypot(point[0]-p[0],point[2]-p[2]))**2
                   for _,p in nearby)
    if crowd(desired)<1e-6:return desired
    rx=rz=0.
    for other,p in nearby:
        dx,dz=here[0]-p[0],here[2]-p[2];d=math.hypot(dx,dz)
        if d>=1.2:continue
        if d<1e-5:
            # A role pair receives opposite deterministic directions at overlap.
            angle=((min(rid,other)*31+max(rid,other)*17)%360)*math.pi/180
            sign=1 if rid<other else -1
            dx,dz,d=math.cos(angle)*sign,math.sin(angle)*sign,1.
            weight=1.2
        else:weight=1.2-d
        rx+=dx/d*weight;rz+=dz/d*weight
    length=math.hypot(rx,rz)
    if length<1e-6:return desired
    ux,uz=rx/length,rz/length
    stride=min(budget,.6)
    candidates=[desired,here]
    dx,dz=desired[0]-here[0],desired[2]-here[2]
    for mix in (0.,.5,1.):
        vx,vz=dx*mix+ux*stride,dz*mix+uz*stride
        n=math.hypot(vx,vz)
        if n>budget:vx*=budget/n;vz*=budget/n
        point=_grounded_step(nav,colliders,here,(here[0]+vx,here[1],here[2]+vz),foot,budget)
        candidates.append(point)
    # Progress matters when clearance is equal; separation wins at overlap.
    return min(candidates,key=lambda p:4.*crowd(p)+.08*distance(p,desired))


def _tick_human_bot(battle, f, nav, colliders, now, dt, motion, neighbours,
                    shots) -> Tuple[int, Optional[dict]]:
    """Biochem human BOT: ammo + all-threat ground tactics.

    Movement and firing are independent: retreat/strafe still shoots when the
    target is visible and in range.  Every destination is a baked-grid point
    with corridor validation, not a Euclidean detour.  ``dt`` is the real
    dispatch interval measured by tick(), never a hard-coded 0.25.
    """
    from .navigation import distance, lerp
    rid = int(f.roleid)
    here = _pos(f)
    if here is None:
        return 0, None
    if not _ensure_human_loadout(battle, f):
        return 0, None
    st = _ammo_state(battle, f)
    if st is None:
        return 0, None
    state = motion.setdefault(rid, {})
    dt = max(0.0, min(float(dt), 1.0))

    done = st.update(now)
    if done is not None:
        slot, rounds = done
        _send_reload_stop(battle, f, slot, rounds)
        if not st.reloading(now):
            _send_gun_state(battle, f, slot)
        (log.info("HUMAN-BOT %s role=%s slot=%s rounds=%s ammo=%s/%s",
                 'RELOAD-SHELL' if st.reloading(now) else 'RELOAD-DONE',
                 rid, slot, rounds, st.slots[slot].clip, st.slots[slot].reserve) if log.isEnabledFor(20) else None)

    threats = bio_sense.threats(battle, f, nav, colliders, here, state, now)
    safe = human.safe_distance(threats)
    preferred = human.preferred_distance(safe)
    perch = state.get('perch')
    hold_perch = (perch is not None and distance(here, perch) < .5
                  and bio_sense.post_safe(here, threats, safe))
    if perch is not None and not hold_perch:
        state.pop('perch')
    melee = _melee_for(f, state)
    gun_infos = [s.info for s in st.slots.values()]
    engage = max((i.effective_range for i in gun_infos), default=HUMAN_RANGE)
    visible = [t for t in threats if t.visible]
    nearest_vis = min((t.dist for t in visible), default=float("inf"))

    # parkour_routes keeps its plan in the same per-role motion dict:
    #   state['parkour_route']  = baked hops (start/end/speed)
    #   state['route_index']    = next hop
    #   state['route_mobility'] = route needs a faster/held-light weapon
    #   state['jump']           = committed ballistic arc in flight
    # A jump already in flight must not change its planned horizontal
    # velocity/landing, so the tactical layer freezes the held slot mid-air.
    route_hops = state.get("parkour_route") or ()
    route_index = int(state.get("route_index", 0) or 0)
    route_mobility = bool(state.get("route_mobility"))
    on_route = not hold_perch and bool(route_mobility or (route_hops
                                       and route_index < len(route_hops)))
    airborne = state.get("jump") is not None
    near_cancel = bool(visible) and nearest_vis <= max(human.CLOSE_RANGE_M,
                                                       float(safe or 0.0))

    route = _route_state(battle, rid)
    if route is not None:
        if airborne:
            human.notify_route_state(route, route="parkour", safe=True,
                                     airborne=True, reason="route_airborne")
        elif on_route and not hold_perch:
            if near_cancel:
                # A close threat cancels route mobility (but only grounded:
                # an in-flight jump keeps its committed slot above).
                human.notify_route_state(route, route="engage", safe=False,
                                         reason="route_cancel")
            else:
                human.notify_route_state(route, route="parkour",
                                         safe=True, reason="parkour_route")
                # Preference only: no movement, no jump, no switch here.
                human.request_mobility_weapon(route, now,
                                              reason="parkour_route",
                                              duration=0.6)
        elif not visible and not hold_perch:
            human.notify_route_state(route, route="transfer", safe=True,
                                     reason="transfer")
            human.request_mobility_weapon(route, now, reason="transfer",
                                          duration=0.6)
        else:
            human.notify_route_state(route, route="engage", safe=False,
                                     reason="engage")

    tactical = _tactical_states(battle).get(rid)
    if tactical is None:
        tactical = _tactical_states(battle)[rid] = human.TacticalState(
            held_slot=st.active, held_since=now - 10.0, reason="born")
    if tactical.held_slot in (human.POS_MAIN_GUN, human.POS_VICE_GUN):
        if tactical.held_slot != st.active and tactical.held_slot in st.slots:
            st.switch(tactical.held_slot, now)
    desired, why = human.choose_tactical_slot(
        st, melee, now=now, threat_visible=bool(visible),
        nearest_dist=nearest_vis, route_state=route, safe=safe,
        engage_range=engage, near_threat=near_cancel,
        route_mobility=on_route, airborne=airborne)
    urgent = (desired in (human.POS_MAIN_GUN, human.POS_VICE_GUN)
              and tactical.held_slot == human.POS_MELEE
              and bool(visible) and nearest_vis <= safe * 1.5)
    switch = None if airborne else human.maybe_switch(
        tactical, st, melee, desired, now, why, urgent=urgent)
    if switch is not None:
        f.weaponpos = int(switch.to_slot)
        _send_weapon_change(battle, f, switch.to_slot)
        state["empty_logged"] = False
        (log.info("HUMAN-BOT SWITCH role=%s %s->%s reason=%s gun=%s ammo=%s/%s",
                 rid, switch.from_slot, switch.to_slot, switch.reason,
                 switch.weapon_id, switch.clip, switch.reserve) if log.isEnabledFor(20) else None)

    held_melee = tactical.held_slot == human.POS_MELEE
    if held_melee:
        action, slot, info = "melee", human.POS_MELEE, None
        reloading = False
        weapon_empty = all(st.total(s) <= 0 for s in st.slots)
        f.weaponpos = human.POS_MELEE
    else:
        if tactical.held_slot in st.slots and st.active != tactical.held_slot:
            st.switch(tactical.held_slot, now)
        action, slot, info = st.ready(now, auto_switch=False)
        f.weaponpos = int(tactical.held_slot)
        if action in ("reload", "reloading"):
            if action == "reload":
                started = st.start_reload(now)
                if started is not None:
                    _send_reload_start(battle, f, slot)
                    (log.info("HUMAN-BOT RELOAD role=%s slot=%s %.2fs ammo=%s/%s",
                             rid, slot, started.reload_seconds,
                             st.slots[slot].clip, st.slots[slot].reserve) if log.isEnabledFor(20) else None)
            reloading = True
            weapon_empty = False
        elif action == "switch":
            _send_weapon_change(battle, f, slot)
            reloading = False
            weapon_empty = False
        elif action == "empty":
            reloading = False
            weapon_empty = True
            if not state.get("empty_logged"):
                state["empty_logged"] = True
                (log.info("HUMAN-BOT EMPTY role=%s slots=%s (explicit no-ammo, "
                         "no ammo invented)", rid, st.snapshot()) if log.isEnabledFor(20) else None)
        else:
            reloading = False
            weapon_empty = False

    if not weapon_empty:
        state["empty_logged"] = False

    speed = human.move_speed(melee if held_melee else info)
    # The longest carried gun is useful for choosing a slot; firing/chasing
    # must use the currently held gun, not an empty long-range primary.
    engage=(melee.range if held_melee and melee is not None else
            float(info.effective_range) if info is not None else HUMAN_RANGE)
    # A held knife is a real weapon: "all guns empty" must not suppress the
    # melee swing through the gun-empty retreat branch.
    combat_empty = bool(weapon_empty and not (held_melee and melee is not None))
    visible_target = (min(visible, key=lambda t: t.dist)
                      if visible else None)
    melee_stick = bool(held_melee and melee is not None and weapon_empty
                       and visible_target is not None
                       and visible_target.dist <= melee.range)
    if melee_stick:
        # No gun ammo and a zombie already inside Melee.range: stay on the
        # spot and swing.  This does not alter run/jump/damage constants.
        decision = human.Decision(
            "melee_hold", True, visible_target.roleid, "melee_range",
            tuple(t.roleid for t in threats))
    else:
        decision = human.decide(
            here, threats, engage_range=engage, safe=safe,
            preferred=preferred, reloading=reloading,
            weapon_empty=combat_empty)
    if combat_empty and hold_perch:
        state.pop('perch', None)
        hold_perch = False
    if decision.mode == 'chase':
        decision = human.Decision('hold' if decision.fire else 'watch', decision.fire,
                                  decision.target_id, 'defend_lane', decision.threat_ids)
    if hold_perch:
        decision = human.Decision('perch_hold', decision.fire, decision.target_id,
                                  'safe_landing', decision.threat_ids)
    target = next((t for t in threats if t.roleid == decision.target_id), None)
    target_f = battle.fighters.get(target.roleid) if target is not None else None

    allies = {other: pos for other, pos in neighbours.items()
              if other != rid and not battle.biochem.is_zombie(other)}
    occupied = list(allies.values())
    for other in allies:
        teammate = motion.get(other, {})
        planned = (teammate.get('jump') or {}).get('end')
        if planned is None:
            hops = teammate.get('parkour_route') or ()
            index = teammate.get('route_index', 0)
            planned = hops[index]['end'] if index < len(hops) else None
        planned = planned or teammate.get('patrol') or teammate.get('move_dest')
        if planned is not None and distance(planned, allies[other]) > 1.0:
            occupied.append(planned)
    recent = state.setdefault("visited", [])
    preparing = not getattr(battle.biochem, 'infection_started', True)
    dest = None
    if melee_stick or hold_perch:
        state["patrol"] = None
        state["move_dest"] = None
        state['patrol_ascent'] = False
        if hold_perch:
            state['parkour_route'] = None
            state['route_mobility'] = False
            state.pop('route_air_finished', None)
    elif decision.mode == "patrol":
        state["move_dest"] = None
        dest = state.get("patrol")
        arrived = dest is not None and distance(here, dest) < 0.5
        crowded = arrived and human._crowd(here, occupied) > 1.0
        heading = None
        if arrived and not crowded and not combat_empty and bio_sense.post_safe(here, threats, safe):
            high = here[1] - state.get('patrol_start_y', here[1]) >= .7
            heading = bio_sense.hold_heading(here, nav, colliders, state.get('bot_facing', 0.0), high)
        if heading is not None:
            state['guard_yaw'] = heading
            state['perch'] = here
            state['patrol'] = None
            state['patrol_ascent'] = False
            hold_perch = True
            dest = None
        elif dest is None or arrived:
            if dest is not None:
                recent.append(dest)
                del recent[:-4]
            # Keep the opening spread before sending a BOT to an upper perch.
            # Each room can reserve one voluntary uphill approach at a time.
            prefer_high = (not any(distance(here, p) < human.FORMATION_GAP for p in allies.values())
                           and not any(motion.get(other, {}).get('patrol_ascent') for other in allies))
            dest = human.pick_patrol(
                here, nav, threats, occupied=occupied, recent=recent,
                seed=rid + int(state.get("patrol_index", 0)),
                max_distance=16.0 if preparing else 12.0, prefer_high=prefer_high,
                support=tuple(allies.values()))
            state["patrol_index"] = int(state.get("patrol_index", 0)) + 1
            state["patrol"] = dest
            state['patrol_start_y'] = here[1]
            state['patrol_ascent'] = bool(prefer_high and dest is not None and dest[1]-here[1]>=.7)
    else:
        state["patrol"] = None
        state['patrol_ascent'] = False
        key = (decision.mode, decision.target_id)
        if (state.get("move_mode") != key or state.get("move_dest") is None
                or now >= float(state.get("move_until", 0.0))
                or distance(here, state.get("move_dest")) < 0.5):
            if decision.mode == 'chase' and target is not None:
                dest = human.pick_approach(
                    here, nav, threats, target, safe=safe, preferred=preferred,
                    occupied=occupied, recent=recent) or target.pos
            else:
                dest = human.choose_destination(
                    decision, here, nav, threats, safe=safe, preferred=preferred,
                    occupied=occupied, recent=recent, seed=rid)
            if dest is None and 'retreat' in decision.mode:
                dest = bio_sense.break_contact(here, nav, colliders, threats)
            # Stagger re-picks so twelve BOTs never run their corridor queries
            # in the same room-clock tick.
            state.update(move_mode=key, move_dest=dest,
                         move_until=now + 1.0 + (rid % 8) * 0.05)
        else:
            # Keep walking to the cached destination between re-picks.
            dest = state.get("move_dest")

    surface = nav.ground(here) if nav is not None else None
    foot = (state.setdefault("foot", max(0.0, min(0.5, here[1] - surface[1])))
            if surface is not None else 0.0)
    budget = speed * dt
    newpos = here
    if dest is not None and nav is not None and colliders is not None:
        if hasattr(nav, "next_waypoint"):
            waypoint = nav.next_waypoint(here, dest, budget=budget)
        else:
            path = nav.path(here, dest)
            waypoint = next((p for p in path[1:]
                             if distance(here, p) > 0.02), None) if path else None
        if waypoint is not None:
            length = distance(here, waypoint)
            if length > 1e-6:
                newpos = lerp(here, waypoint, min(1.0, budget / length))
                newpos = _grounded_step(nav, colliders, here, newpos, foot,
                                        budget)
    if nav is not None and colliders is not None and not hold_perch:
        newpos = _separate(nav, colliders, here, newpos, rid, allies, foot,
                           budget)
        # A valid uphill walking corridor is already a route to the perch.
        # An optional jump may otherwise pull the BOT back down the stairs.
        walking_upstairs = (decision.mode == 'patrol' and state.get('patrol_ascent')
                            and dest is not None and distance(here,newpos) > .08 and not airborne)
        if walking_upstairs:
            state['parkour_route'] = None
            state['route_mobility'] = False
            state.pop('route_air_finished', None)
        elif hasattr(colliders,'floors'):
            from . import parkour
            newpos=parkour.step(battle,f,state,nav,colliders,here,newpos,dest,
                               speed,dt,now,evade='retreat' in decision.mode,
                               occupied=occupied)
    walking = distance(here, newpos) > 0.001
    if decision.mode == 'patrol' and dest is not None and distance(here, dest) >= .5 and not walking:
        stalled = state.get('patrol_stalled', 0.) + dt
        if stalled >= 1.0:
            recent.append(dest)
            del recent[:-4]
            state['patrol'] = None
            state['patrol_ascent'] = False
            stalled = 0.
        state['patrol_stalled'] = stalled
    else:
        state['patrol_stalled'] = 0.
    facing = bio_sense.facing(f, target, state, hold_perch, now)
    entry = _step(f, facing, target.dist if target is not None else 0.0,
                  speed, dt, destination=newpos)
    # Leave supply for other players until this BOT is low on both carried guns.
    # An inscribed circle fits the pickup trigger at any of its random rotations.
    if (state.get("jump") is None and st.slots
            and all(s.reserve < s.info.clip for s in st.slots.values())):
        x, y, z = f.syncpos
        for box in battle.biochem.boxes:
            pos = box["pos"]
            if (box["kind"] == "ammo" and abs(y - pos["y"] / 100) <= .5
                    and (x - pos["x"] / 100) ** 2 + (z - pos["z"] / 100) ** 2 <= 1.5 ** 2):
                battle.biochem.take_box(box["dropid"], rid)
                break
    if entry is not None:
        state["quat"] = entry["state"]["quat"]
    if dest is not None and walking:
        state["last_move_mode"] = decision.mode

    if decision.mode != state.get("mode") or decision.target_id != state.get("target"):
        (log.info("HUMAN-BOT %s role=%s target=%s dist=%s threats=%s reason=%s "
                 "ammo=%d/%d safe=%.1f preferred=%.1f speed=%.2f",
                 decision.mode.upper(), rid, decision.target_id,
                 round(target.dist, 1) if target is not None else "-",
                 list(decision.threat_ids),
                 decision.reason, st.clip, st.reserve, safe, preferred, speed) if log.isEnabledFor(20) else None)
        state["mode"], state["target"] = decision.mode, decision.target_id

    fired = 0
    firing = False
    acquired = False
    if (decision.fire and target is not None and target_f is not None
            and target_f.born and target_f.hp > 0):
        fp = _pos(f)
        if fp is not None:
            dist = distance(fp, target.pos)
            visible = _visible(colliders, fp, target.pos)
            if held_melee:
                # Knife uses Melee.range/speed, never GunInfo.  damage.py
                # rejects sd > Melee.range and same_team() protects friendlies.
                if (visible and melee is not None
                        and human.can_melee(melee, dist)):
                    last = float(state.get("melee_last", -1e18))
                    acquired = True
                    if (now + 1e-9 >= last + melee.shot_period
                            and bot_balance.ready(battle, f, target_f, True, now, state)):
                        _fire(battle, f, target_f, dist, colliders=colliders, state=state)
                        state["melee_last"] = now
                        fired = 1
                        (log.info("HUMAN-BOT MELEE role=%s target=%s dist=%.2f "
                                 "knife=%s range=%.2f speed=%.2f dmg=%.1f",
                                 rid, target.roleid, dist, melee.itemid,
                                 melee.range, melee.speed, melee.damage) if log.isEnabledFor(20) else None)
            elif visible and dist <= engage:
                # Bounded catch-up: only shots already due by Gun.shootSpeed,
                # never a future timestamp and never a long-stall burst.
                # A zero here can simply mean the next round of an unfinished
                # burst is not due yet, so do not call hold() in that case.
                acquired = True
                firing = bot_balance.ready(battle, f, target_f, True, now, state)
                state["moving"] = walking
                fired = st.take_shots(now, dt, min_period=bot_balance.profile(battle).shot_gap) if firing else 0
                gun_info = st.slots[st.active].info if st.active in st.slots else info
                if fired and gun_info is not None and weapon_fire.needs_multi(gun_info):
                    # Shotgun/burst: one trigger carries max(firePerShoot,
                    # bulletPerShoot) rays via ScMultiShoot.  The single-shot
                    # path below is untouched for ordinary rifles/pistols.
                    _fire_volleys(battle, f, target_f, dist, gun_info, fired,
                                  seq=int(now * 1000) + rid,
                                  events=st.drain_ray_events(),
                                  colliders=colliders, moving=walking)
                else:
                    for _ in range(fired):
                        _fire(battle, f, target_f, dist, colliders=colliders, state=state)
                if fired and (now - float(state.get("fire_log_at", -1e9)) >= 1.0
                              or state.get("fire_target") != target.roleid):
                    state["fire_log_at"] = now
                    state["fire_target"] = target.roleid
                    (log.info("HUMAN-BOT FIRE role=%s target=%s dist=%.1f "
                             "gun=%s ammo=%d/%d interval=%.3f shots=%d",
                             rid, target.roleid, dist,
                             info.itemid if info else 0, st.clip, st.reserve,
                             info.shot_period if info else 0.0, fired) if log.isEnabledFor(20) else None)
    if not acquired:
        state.pop("acquisition", None)
    if not firing and not held_melee:
        # Holding fire (no LOS / out of range / target disappeared) must not
        # bank rounds or keep an unfinished burst for when the target returns.
        st.hold(now)

    if walking:
        return 1, entry
    return 0, entry


def tick(battle, dt: float = 0.25) -> int:
    """每个回合 tick 驱动一遍所有机器人。返回动了的个数。

    与 `ScManageAI` 那条路**互斥**：客户端 `RoleStatusSync` 会跳过
    `DataPool.IsRelated` 的角色，而 IsRobot 正是 ManageAI 写进去的。
    两条同时开的话服务端推的位置会被静默丢弃，所以这里直接拒。
    """
    if not CONFIG.bots_drive or CONFIG.bots_ai or not math.isfinite(dt) or dt <= 0:
        return 0
    from . import bot_recoil, parkour, parkour_routes
    from .navigation import distance, lerp
    nav,colliders = _world(battle)
    now = time.monotonic()
    # Real dispatch interval: the room clock requests 0.25 s but a delayed or
    # coalesced callback must not be replayed as a 0.25 s step (and a faster
    # one must not move/shoot at the old cadence).  Clamp pathological gaps.
    prev = getattr(battle, "_bot_tick_at", None)
    try:
        battle._bot_tick_at = now
    except Exception:
        pass
    if prev is not None:
        measured = now - float(prev)
        if math.isfinite(measured) and 0.0 < measured <= 2.0:
            dt = measured
    dt = max(1e-3, min(float(dt), 1.0))
    # Fighter 是 __slots__ 类，不能往上挂临时字段，开火时刻记在 battle 上。
    shots: Dict[int, float] = getattr(battle, "_bot_shot_at", None)
    if shots is None:
        shots = battle._bot_shot_at = {}
    motion = getattr(battle,'_bot_motion',None)
    if motion is None:motion=battle._bot_motion={}
    moved = 0
    entries: Dict[int, dict] = {}
    neighbours={int(f.roleid):_pos(f) for f in battle.fighters.values()
                if f.born and f.hp>0 and _pos(f) is not None}
    bio = getattr(battle, 'biochem', None)
    native_room = room_ai.enabled(battle)
    bio_sensing = bio is not None
    for f in list(battle.fighters.values()):
        if not is_bot(f.roleid) or not f.born or f.hp <= 0:
            continue
        rid=int(f.roleid);state=motion.setdefault(rid,{})
        state['updated_at']=now
        zombie = bio is not None and bio.is_zombie(rid)
        if state.get('jump') is not None and (state.get('form_airborne') or zombie):
            # born() already advanced this arc up to the actual model-change
            # time. A later fighter in this same tick must not advance the
            # whole room interval a second time.
            air_dt = dt
            if state.get('form_airborne'):
                air_dt=max(0.,now-state.get('form_air_at',now-dt))
                state['form_air_at']=now
            here=_pos(f);newpos=parkour.advance(state,air_dt)
            if bio_sensing:
                target, dist, _ = room_ai.scan(battle, f, colliders, state, now, level=2)
            else:
                target,dist=_pick_target(battle,f,nav,colliders)
            entry=_step(f,target or f,dist or 0.,_profile(battle,f)[1],dt,destination=newpos)
            if entry is not None:entries[rid]=entry
            if distance(here,newpos)>.001:moved+=1
            if target is not None and target.born and target.hp>0:
                rng,_,interval,_=_profile(battle,f)
                reach=distance(newpos,_pos(target))
                visible = reach <= rng and _visible(colliders, newpos, _pos(target))
                if (bot_balance.ready(battle, f, target, visible, now, state)
                        and now - shots.get(rid, -math.inf) >= interval):
                    shots[rid] = now
                    _fire(battle, f, target, reach, colliders=colliders, state=state)
            else:
                state.pop("acquisition", None)
            if state.get('jump') is None:state.pop('form_airborne',None)
            continue
        if battle.biochem is not None and _is_human_bot(battle, f):
            m, entry = _tick_human_bot(battle, f, nav, colliders, now, dt,
                                       motion, neighbours, shots)
            moved += m
            if entry is not None:
                entries[rid] = entry
            continue
        target, dist = (None, None) if native_room or bio_sensing else _pick_target(battle, f, nav, colliders)
        rng, speed, itv, keep = _profile(battle, f)
        if native_room:
            rng = room_ai.reach(battle, f, rng)
        here=_pos(f)
        if here is None:continue
        surface=nav.ground(here) if nav is not None else None
        foot=state.setdefault('foot',max(0.,min(.5,here[1]-surface[1]))) if surface is not None else 0.
        dest=None;visible=False
        if (native_room or bio_sensing) and nav is not None and colliders is not None:
            # Bio movement keeps its own reach, parkour and retreat rules.
            stop = keep if bio_sensing else rng
            target, dist, dest = room_ai.plan(battle, f, nav, colliders, state, neighbours, now, stop,
                                              level=2 if bio_sensing else 1)
        elif nav is not None and colliders is not None:
            if target is not None:
                visible=_visible(colliders,here,_pos(target))
                if (not zombie and battle.biochem is not None and dist<8
                        and f.roleid not in getattr(battle.biochem,'heroes',set())):
                    dest=state.get('retreat')
                    if (state.get('retreat_enemy')!=target.roleid or dest is None
                            or now>=state.get('retreat_until',0.) or distance(here,dest)<.5):
                        dest=_anchor(nav,here,rid,away=_pos(target))
                        state.update(retreat=dest,retreat_enemy=target.roleid,retreat_until=now+1.)
                elif dist>keep or not visible:dest=_pos(target)
            else:
                dest=state.get('patrol')
                if dest is None or distance(here,dest)<.5:
                    recent=state.setdefault('visited',[])
                    if dest is not None:recent.append(dest);del recent[:-4]
                    occupied=[p for other,p in neighbours.items() if other!=rid]
                    occupied += [s['patrol'] for other,s in motion.items()
                                 if other!=rid and other in neighbours and s.get('patrol') is not None]
                    dest=_anchor(nav,here,rid+state.get('patrol_index',0),
                                 occupied=occupied,recent=recent)
                    state['patrol']=dest;state['patrol_index']=state.get('patrol_index',0)+1
        newpos=here
        recoil = bot_recoil.displacement(state,dt) if zombie and nav is not None and colliders is not None else None
        if recoil is not None:
            dx, dz = recoil
            pushed = (here[0] + dx, here[1], here[2] + dz)
            newpos = _grounded_step(nav,colliders,here,pushed,foot,max(speed*dt,math.hypot(dx,dz)))
            (log.debug('BOT-RECOIL role=%s from=%s to=%s', rid, here, newpos) if log.isEnabledFor(10) else None)
        elif dest is not None:
            if hasattr(nav,'next_waypoint'):
                waypoint=nav.next_waypoint(here,dest,budget=speed*dt)
            else:
                path=nav.path(here,dest)
                waypoint=next((p for p in path[1:] if distance(here,p)>.02),None) if path else None
            if (native_room or bio_sensing) and waypoint is None:
                located = nav.locate(here)
                if located is not None and distance(here, located[1]) > .05:
                    waypoint = located[1]
            # One straight path segment per packet: interpolating a multi-corner
            # displacement would cut back through the obstacle on the client.
            if waypoint is not None:
                length=distance(here,waypoint)
                newpos=lerp(here,waypoint,min(1.,speed*dt/length))
                # Keep a stable foot offset. Treating a shortcut's interpolated
                # Y as a new foot offset each tick accumulates drift on ramps.
                newpos=_grounded_step(nav,colliders,here,newpos,foot,speed*dt)
        if recoil is None and nav is not None and colliders is not None:
            newpos=_separate(nav,colliders,here,newpos,rid,neighbours,foot,speed*dt)
            if zombie and hasattr(colliders,'floors'):
                uphill = dest if dest is not None and dest[1] - here[1] > .35 else None
                routed = parkour_routes.steer(battle,f,state,nav,colliders,here,newpos,
                                              uphill,
                                              speed,dt,now,pursuit=True)
                if routed is not None:
                    newpos = routed
            elif (battle.biochem is not None and f.roleid in getattr(battle.biochem,'heroes',set())
                    and hasattr(colliders,'floors')):
                newpos=parkour.step(battle,f,state,nav,colliders,here,newpos,dest,speed,dt,now)
        walking=distance(here,newpos)>.001
        if dest is not None and not walking and target is None:
            # An obsolete/blocked patrol must not pin this actor forever.
            if native_room or bio_sensing:
                state.pop('island', None)
                state['last_island'] = dest
            else:
                state['patrol']=None
                recent=state.setdefault('visited',[]);recent.append(dest);del recent[:-4]
        # Send an explicit zero velocity when a moving actor stops/loses a target.
        # Keep periodic position samples while idle so timestamps stay current.
        facing=target or f
        e=_step(f,facing,dist or 0.,speed,dt,destination=newpos)
        if e is not None:
            if not walking and target is None and state.get('quat') is not None:
                e['state']['quat']=state['quat']
            if (native_room or bio_sensing) and not walking and target is None:
                if (yaw := state.get('scan_yaw')) is not None:
                    e['state']['quat'] = dict(x=0, y=round(math.sin(yaw / 2) * 20000),
                                             z=0, w=round(math.cos(yaw / 2) * 20000))
            if native_room:
                bot_balance.smooth_facing(state, e, dt)
            state['quat']=e['state']['quat']
            entries[rid]=e
        state['moving']=walking
        if walking:moved+=1
        engaged = target is not None and target.born and target.hp > 0
        if engaged:
            dist = distance(newpos, _pos(target))
        can_see = engaged and dist <= rng and _visible(colliders, newpos, _pos(target))
        aligned = not native_room or (can_see and room_ai.aligned(f, target, dist, state))
        slot, _ = damage.active_weapon(f)
        if slot in (11, 12) and not zombie:
            bot_balance.gun_tick(battle, f, target, dist, can_see, colliders, state, now, aligned=aligned)
        elif (bot_balance.ready(battle, f, target, can_see, now, state) and aligned
              and now - shots.get(rid, -math.inf) >= itv):
            shots[rid] = now
            if getattr(battle.room, "equiplimitid", 0) and slot == 41:
                from . import grenades
                grenades.bot_throw(battle, f, target, colliders)
            else:
                _fire(battle, f, target, dist, colliders=colliders, state=state)
    if not native_room:
        for roleid, entry in entries.items():
            bot_balance.smooth_facing(motion[roleid], entry, dt)
    # 一个 tick 一帧位置：全场机器人合进同一条 ScRoleStatusSync。
    # 客户端每收到一条就把 lastSyncServerTime 推到它的 servertime，
    # 拆成多条同毫秒的消息并不会更顺，只会多一倍包。
    if entries:
        battle.broadcast_positions(entries)
    return moved
