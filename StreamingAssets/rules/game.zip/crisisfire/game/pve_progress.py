"""UC challenge honors and local monthly-card entitlements."""
import logging
import time
from collections import Counter, defaultdict

from ..net.server import ROUTER
from . import pve

log = logging.getLogger("crisisfire.pve.progress")
MONTH_UNTIL = "card_1_until"
MONTH_DAILY = "pve_month_reward_day"
FIRST_WIN_DAY = "pve_first_win_day"
SERVER_EPOCH = 1_356_998_400  # CalendarUtil uses 2013-01-01 00:00:00 UTC.
FIRST_WIN_HONOR = 20  # The stock WinRewardModal's base win honor.
SURVIVAL, SUPPLY, KILLING, EXPLOSIVE, BOSS, REBORN = range(5, 11)


def month_expiry(role):
    return int(role.data.get(MONTH_UNTIL) or 0) if role else 0


def month_active(role):
    return month_expiry(role) > int(time.time())


def sync_month(session, role, *, activate=False):
    from . import handlers, pve_rewards

    now = int(time.time())
    until = month_expiry(role)
    card = pve.rows("Card")[1]
    opened = activate and until <= now
    changes = {}
    if opened:
        until = now + card["duration"]
        changes[MONTH_UNTIL] = until
    day = time.strftime("%Y-%m-%d")
    daily = until > now and role.data.get(MONTH_DAILY) != day
    if daily:
        changes[MONTH_DAILY] = day
        changes["research_point"] = role.data.get("research_point", 0) + card["dailyRP"]
    if changes:
        handlers.world.award_local(role.roleid, changes, gems=card["dailyGem"] if daily else 0,
                                   honor=card["dailyHonor"] if daily else 0)
    session.send(1048598, desttime=until - SERVER_EPOCH if until > now else 0)
    if opened:
        session.send(1048594, cardid=1)
    if daily:
        pve_rewards.send_balance(session, role)
        session.send(2686979, researchpoint=role.data["research_point"])
        session.send(1048605, addgem=card["dailyGem"], addhonor=card["dailyHonor"],
                     researchpoint=card["dailyRP"])


@ROUTER.register(1048580, "shop.CsAddCashReq")
async def request_card(session, message):
    # ActivityManager.GoBuyCard uses -1 for the month card on both original
    # entry points. It activates the local card without a checkout order.
    from . import pve_rewards

    if message.get("cashitemid") == -1:
        _, role = pve_rewards.current_role(session)
        if role is not None:
            sync_month(session, role, activate=True)


def win_bonuses(role, mode, changes):
    day = time.strftime("%Y-%m-%d")
    first = 0
    if role.data.get(FIRST_WIN_DAY) != day:
        first = FIRST_WIN_HONOR
        changes[FIRST_WIN_DAY] = day
    exp, coins, points = 0, 0, mode["rPointAward"]
    if month_active(role):
        card = pve.rows("Card")[1]
        exp = mode["expReward"] * card["addExp"] // 100
        coins = mode["goldReward"] * card["addGold"] // 100
        points += mode["rPointMonth"]
    changes["research_point"] = role.data.get("research_point", 0) + points
    return exp, coins, first


class ChallengeMedals:
    """Local trigger rules for the stock ChallengeScore medal rows."""

    def __init__(self, challenge):
        self.challenge = challenge
        self.counts = defaultdict(Counter)
        self.wave_kills = Counter()
        self.refilled = set()
        self.ammo_picked = set()
        self.revived = set()

    def award(self, roleid, medal):
        row = pve.rows("ChallengeScore")[medal]
        counts = self.counts[roleid]
        if counts[medal] and not row["isMetering"]:
            return False
        counts[medal] += 1
        from . import handlers, tasks

        if handlers.world is not None:
            tasks.record(handlers.world.role(roleid), task_type=tasks.CHALLENGE_MEDAL)
        (log.info("PVE-MEDAL role=%s id=%s count=%s", roleid, medal, counts[medal]) if log.isEnabledFor(20) else None)
        return True

    def kill(self, roleid, model):
        self.wave_kills[roleid] += 1
        if self.challenge.index + 1 == len(self.challenge.rounds) and model["finalBoss"]:
            self.award(roleid, BOSS)

    def clear(self, wave_total):
        for roleid, kills in self.wave_kills.items():
            if kills == wave_total:
                self.award(roleid, KILLING)
        self.wave_kills.clear()
        for roleid in tuple(self.revived):
            fighter = self.challenge.battle.fighters.get(roleid)
            if fighter is not None and fighter.born and fighter.hp > 0:
                self.award(roleid, REBORN)
                self.revived.remove(roleid)

    def supply(self, roleid, *, pickup):
        (self.ammo_picked if pickup else self.refilled).add(roleid)
        if roleid in self.ammo_picked and roleid in self.refilled:
            return self.award(roleid, SUPPLY)
        return False
