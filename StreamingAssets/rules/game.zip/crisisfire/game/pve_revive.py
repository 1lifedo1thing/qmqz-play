"""Challenge immediate revive, with the stock signed count and price table."""
import logging
from collections import Counter

from . import pve

log = logging.getLogger("crisisfire.pve.revive")
FREE_IMMEDIATE = 1  # The original server's starting count is unavailable.
SC_TIMES, SC_FREE, SC_WAIT = 1441977, 1441978, 1441920


def revive_price(times):
    if times > 0:
        return 0
    row = pve.rows("CostRelive")[1]
    costs = pve.values(row["cost"])
    return next((cost for limit, cost in zip(pve.values(row["num"]), costs)
                 if abs(times) <= limit), costs[-1])


class Revives:
    def __init__(self, challenge):
        self.challenge = challenge
        self.battle = challenge.battle
        self.used = Counter()
        self.fallen = set()

    def remaining(self, roleid):
        return FREE_IMMEDIATE - self.used[roleid]

    def born(self, roleid, first):
        if first:
            self.battle.send_to_role(roleid, SC_FREE, times=FREE_IMMEDIATE)
        if roleid in self.fallen:
            self.fallen.remove(roleid)
            self.challenge.medals.revived.add(roleid)

    def death(self, roleid, waittime):
        self.fallen.add(roleid)
        times = self.remaining(roleid)
        self.battle.send_all(SC_TIMES, roleid=roleid, times=times, remaintime=waittime)
        # The stock ScPVEReliveTimes reader calls WaitRelive only for <= 0.
        if times > 0:
            self.battle.send_to_role(roleid, SC_WAIT, waittime=waittime)

    def authorize(self, payer, target):
        from . import handlers

        buyer = self.battle.fighters.get(payer)
        victim = self.battle.fighters.get(target)
        if (not self.challenge.active() or buyer is None or victim is None
                or buyer.side != victim.side or target not in self.fallen
                or victim.born or victim.hp > 0):
            return False
        world = handlers.world
        role = world.role(payer) if world is not None else None
        price = revive_price(self.remaining(target))
        if role is None or role.gold < price:
            return False
        if price:
            # The client tracks pending spend in ExpenseData until battle
            # teardown. Commit immediately, sync the wallet at settlement.
            world.award_local(payer, {}, gems=-price)
        self.used[target] += 1
        self.fallen.remove(target)
        self.challenge.medals.revived.add(target)
        (log.info("PVE-RELIVE payer=%s target=%s price=%s remaining=%s", payer, target,
                 price, self.remaining(target)) if log.isEnabledFor(20) else None)
        return True
