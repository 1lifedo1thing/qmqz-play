"""Local reconstruction of the UC 1.9 challenge-card response."""
import random
import time
from functools import lru_cache

from .. import gamedata
from ..net.server import ROUTER
from . import equip

SC_CARD = 1245269
SC_BUY = 1245271
SC_TIMES = 1245280
DAILY_LIMIT = 3
NORMAL_LIMIT = 2
DAILY_KEY = "pve_daily_cards"
RESULT_KEY = "pve_card_result"
ITEMS_KEY = "pve_reward_items"


def grade_for(mode, score):
    from .pve import values
    return sum(score >= limit for limit in values(mode["gradeScore"]))


def new_result(mode, score):
    return {"levelid": mode["id"], "grade": grade_for(mode, score),
            "normal": 0, "special": False}


def daily_state(role):
    day = time.strftime("%Y-%m-%d")
    stored = role.data.get(DAILY_KEY) or {}
    left = stored.get("left", DAILY_LIMIT) if stored.get("day") == day else DAILY_LIMIT
    return {"day": day, "left": left}


def send_times(session, role):
    session.send(SC_TIMES, num=daily_state(role)["left"])


def close_result(world, role):
    if role.data.get(RESULT_KEY) is not None:
        world.merge_role_data(role.roleid, **{RESULT_KEY: None})


@lru_cache(maxsize=12)
def reward_pool(group):
    pool = [row for row in gamedata.table("LotteryReward")
            if row["type"] == group and row["ratio"] > 0]
    if not pool or any(row["roleId"] or row["exp"]
                       or (row["itemId"] and not equip.depot_item(row["itemId"]))
                       or (not row["itemId"] and not row["rPoint"])
                       for row in pool):
        raise ValueError(f"Unsupported 1.9 challenge card group {group}")
    return pool


def price(row_id):
    return next(row["gem"] for row in gamedata.table("Price") if row["id"] == row_id)


def item_grant(role, row):
    item = row["itemId"]
    now = int(time.time())
    permanent = set(equip.permanent_ids(role)) or {item["id"] for item in equip.starter_items()}
    items = dict(role.data.get(ITEMS_KEY) or {})
    old = items.get(str(item)) or {}
    expiry = old.get("expiry", 0)
    owned = item in permanent or expiry > now
    if not row["itemDuration"]:
        permanent.add(item)
    if item in permanent:
        expiry = 0
    else:
        expiry = max(now, expiry) + row["itemDuration"]
    count = (old.get("count", 1) if owned else 0) + row["num"]
    if equip.item_row(item)["equipPos"]:
        count = 1
    items[str(item)] = {"count": count, "expiry": expiry}
    return {"pkg_items": sorted(permanent), ITEMS_KEY: items}, owned


def current_role(session):
    from . import handlers
    world = handlers.world
    return world, world.role(session.roleid) if world and session.kind == "gs" else None


def send_balance(session, role):
    session.send(983043, gold=role.gold, money=role.money, diamond=role.diamond)


@ROUTER.register(1245268, "fight.CsPveLotteryReward")
async def flip(session, message):
    from .pve import rows, values
    world, role = current_role(session)
    if role is None:
        return
    state = daily_state(role)
    stored = role.data.get(RESULT_KEY)
    kind = message.get("boxtype")
    if not stored or not state["left"] or kind not in (1, 3):
        session.send(SC_CARD, res=-1)
        return
    result = dict(stored)
    grade = result["grade"]
    normal = kind == 1
    if (normal and (grade < 1 or result["normal"] >= NORMAL_LIMIT)
            or not normal and (grade < 4 or result["special"])):
        session.send(SC_CARD, res=-1)
        return
    cost = price(20) if normal and result["normal"] else 0
    if role.gold < cost:
        session.send(SC_CARD, res=-2)
        return

    mode = rows("ChallengeMode")[result["levelid"]]
    # Native SS special cards have a distinct request type but no pool/price
    # in that request. Use the same difficulty's SS group once at no fee.
    pool = reward_pool(values(mode["boxConfig"])[grade - 1])
    prize = random.choices(pool, weights=[row["ratio"] for row in pool], k=1)[0]
    if normal:
        state["left"] -= 1
        result["normal"] += 1
    else:
        result["special"] = True
    changes = {DAILY_KEY: state, RESULT_KEY: result}
    item = prize["itemId"]
    if item:
        inventory, owned = item_grant(role, prize)
        changes.update(inventory)
    else:
        points = role.data.get("research_point", 0) + prize["rPoint"]
        changes["research_point"] = points

    # Commit the charge, quota and reward together before acknowledging.
    world.award_local(role.roleid, changes, gems=-cost)
    session.send(SC_CARD, res=prize["id"])
    send_times(session, role)  # the client decrements its counter on SC_CARD
    if item:
        payload = equip.package_reward_payload(role, [item])
        session.send(983041, synctype=2 if owned else 1, itemlist=payload)
    else:
        session.send(2686979, researchpoint=points)
    if cost:
        send_balance(session, role)


@ROUTER.register(1245270, "fight.CsBuyPveRewardTimes")
async def buy_times(session, _message):
    world, role = current_role(session)
    if role is None:
        return
    state = daily_state(role)
    cost = price(21)
    if not state["left"] and role.gold >= cost:
        state["left"] = DAILY_LIMIT
        world.award_local(role.roleid, {DAILY_KEY: state}, gems=-cost)
        send_balance(session, role)
        session.send(SC_BUY, res=0)
    else:
        session.send(SC_BUY, res=1)
    send_times(session, role)


@ROUTER.register(1245279, "fight.CsGetPveReward")
async def collect(session, _message):
    world, role = current_role(session)
    if role is not None:
        close_result(world, role)
        send_times(session, role)
