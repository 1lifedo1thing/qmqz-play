"""UC 1.9 challenge preparation, props and resupply."""
import logging
import math
import random
from collections import Counter

from .. import gamedata
from . import pve

log = logging.getLogger("crisisfire.pve.support")
SC_ADD_BUFF, SC_REMOVE_BUFF, SC_BUFF_LIST = 1245273, 1245275, 1245276
SC_PROP_DROP, SC_PICKUP, SC_ADD_HP, SC_FILL_AMMO = 1441982, 1441938, 1441952, 1442005
HP, ATTACK, INVINCIBLE, TEAM_ATTACK, AMMO = 1, 2, 5, 6, 7
PICKUP_HALF_WIDTH = 1.5  # Both stock challenge box prefabs are 3m wide.
PICKUP_CONTACT_PAD = 0.4
PICKUP_RECHECK = 0.25


def costs(buffs):
    return tuple(sum(row[key] for row in buffs) for key in ("gold", "gem", "bloodGem"))


def can_afford(role, buffs):
    coins, gems, honor = costs(buffs)
    return role.money >= coins and role.gold >= gems and role.diamond >= honor


def buff_rows(member):
    rows = pve.rows("InitialProp")
    return [rows[buffid] for buffid in member.pve_buffs]


def sync_buffs(session, room):
    if pve.is_pve(room.gamemode):
        for member in room.members.values():
            session.send(SC_BUFF_LIST, roleid=member.roleid, buffs=sorted(member.pve_buffs))


def select_buff(session, message, remove):
    from . import handlers, room_handlers

    room = room_handlers.MANAGER.room_of(session.roleid)
    if (session.kind != "gs" or room is None or room.started or not pve.is_pve(room.gamemode)
            or message.get("roomid") != room.roomid):
        return
    role = handlers.world.role(session.roleid) if handlers.world is not None else None
    buffid = message.get("buffid")
    row = pve.rows("InitialProp").get(buffid)
    if row is None or role is None:
        return
    member = room.members[session.roleid]
    if remove:
        if buffid not in member.pve_buffs:
            return
        member.pve_buffs.remove(buffid)
        response = SC_REMOVE_BUFF
    else:
        selected = buff_rows(member)
        personal = sum(not choice["isTeam"] for choice in selected)
        cap = 4 if int(role.data.get("vipstatus", 0)) >= 1 else 3
        if (buffid in member.pve_buffs
                or (row["isTeam"] and any(choice["isTeam"] for choice in selected))
                or (not row["isTeam"] and personal >= cap)
                or not can_afford(role, [*selected, row])):
            return
        member.pve_buffs.add(buffid)
        response = SC_ADD_BUFF
    room_handlers._broadcast(room, response, roleid=member.roleid, buffid=buffid)
    (log.info("PVE-BUFF room=%s role=%s buff=%s selected=%s", room.roomid, member.roleid,
             buffid, not remove) if log.isEnabledFor(20) else None)


def clear_buffs(room):
    from . import room_handlers

    for member in room.members.values():
        for buffid in sorted(member.pve_buffs):
            room_handlers._broadcast(room, SC_REMOVE_BUFF, roleid=member.roleid, buffid=buffid)
        member.pve_buffs.clear()


class BattleSupport:
    def __init__(self, challenge):
        self.challenge = challenge
        self.battle = challenge.battle
        rule = self.battle.room.levelid
        self.layout = pve.rows("LocalChallengePoints")[rule]
        self.map_config = pve.rows("PropMap")[rule]
        game_rule = gamedata.rule(rule)
        self.ammo_time = game_rule["pveAmmoTime"]
        self.invincible_time = game_rule["rebornInvincibleTime"]
        self.active_buffs = {}
        self.team_attack = 0
        self.props = {}
        self.next_dropid = 2_000_000  # Local round-scoped identifier range.
        self.timers = {}
        self.refills = {}
        self.pickup_timers = {}
        self.passive = {}
        self.pickups = Counter()

    def activate(self, roleid):
        """Charge each participant once, at their first successful spawn."""
        from . import handlers, pve_rewards, room_handlers

        if roleid in self.active_buffs:
            return
        room = self.battle.room
        member = room.members.get(roleid)
        if member is None or not member.pve_buffs:
            self.active_buffs[roleid] = {}
            return
        world = handlers.world
        role = world.role(roleid) if world is not None else None
        selected = buff_rows(member)
        if role is None or not can_afford(role, selected):
            for buffid in sorted(member.pve_buffs):
                room_handlers._broadcast(room, SC_REMOVE_BUFF, roleid=roleid, buffid=buffid)
            member.pve_buffs.clear()
            self.active_buffs[roleid] = {}
            return
        coins, gems, honor = costs(selected)
        world.award_local(roleid, {}, coins=-coins, gems=-gems, honor=-honor)
        stats = Counter()
        for row in selected:
            stats[row["type"]] += row["num"]
        self.active_buffs[roleid] = stats
        self.team_attack += stats[TEAM_ATTACK]
        session = world.session_of_role(roleid, "gs")
        if session is not None and not session.closed:
            pve_rewards.send_balance(session, role)
        (log.info("PVE-BUFF-START room=%s role=%s buffs=%s", room.roomid, roleid,
                 sorted(member.pve_buffs)) if log.isEnabledFor(20) else None)

    def bonus(self, roleid, kind):
        return self.active_buffs.get(roleid, {}).get(kind, 0)

    def full_hp(self, roleid):
        return 100.0 + self.bonus(roleid, HP)

    def spawn_invincible(self, roleid):
        return self.invincible_time + self.bonus(roleid, INVINCIBLE)

    def attack_bonus(self, roleid, amount):
        # The online damage formula is unavailable. Apply the table value as a
        # percent multiplier, keeping individual ray and explosive damage in scale.
        percent = self.team_attack + self.bonus(roleid, ATTACK)
        return amount * (100 + percent) // 100

    def reserve(self, fighter, slot, base):
        count = self.bonus(fighter.roleid, AMMO)
        gun = pve.rows("Gun").get(fighter.equipmap.get(slot))
        if not count or gun is None:
            return base
        return max(0, gun["ammo"] - gun["clip"]) + count * gun["clip"]

    def start(self):
        self.schedule(0, self.map_config["propTime"])
        for slot in range(1, 4):
            if self.map_config[f"specialTime{slot}"]:
                self.schedule(slot, self.map_config[f"specialTime{slot}"])

    def schedule(self, slot, seconds):
        self.timers[slot] = self.challenge.loop.call_later(seconds, self.refresh, slot, seconds)

    def stop(self):
        for timer in (*self.timers.values(), *self.refills.values(), *self.pickup_timers.values()):
            timer.cancel()
        self.timers.clear()
        self.refills.clear()
        self.pickup_timers.clear()
        self.props.clear()
        self.passive.clear()

    def refresh(self, slot, seconds):
        self.timers.pop(slot, None)
        if not self.challenge.active():
            return
        occupied = {tuple(item["pos"].values()) for source, item in self.props.values() if source == slot}
        if slot:
            points = [pve.values(self.map_config[f"specialPoint{slot}"])]
            pool = pve.values(self.map_config[f"specialList{slot}"])
            weights = pve.values(self.map_config[f"specialRate{slot}"])
            limit = 1
        else:
            points = self.layout["prop_points"]
            pool = pve.values(self.map_config["propList"])
            weights = pve.values(self.map_config["propRate"])
            limit = self.map_config["propCount"]
        open_points = [point for point in points if tuple(point) not in occupied]
        for point in random.sample(open_points, min(len(open_points), max(0, limit - len(occupied)))):
            self.next_dropid += 1
            fields = {"dropid": self.next_dropid, "timeout": 2_147_483_647,
                      "propid": random.choices(pool, weights=weights, k=1)[0], "pos": pve.xyz(point)}
            self.props[self.next_dropid] = (slot, fields)
            self.battle.send_all(SC_PROP_DROP, **fields)
            (log.info("PVE-PROP room=%s drop=%s prop=%s pos=%s", self.battle.room.roomid,
                     fields["dropid"], fields["propid"], fields["pos"]) if log.isEnabledFor(20) else None)
        self.schedule(slot, seconds)

    def sync_props(self, roleid):
        for _, fields in self.props.values():
            self.battle.send_to_role(roleid, SC_PROP_DROP, **fields)

    def fighter(self, roleid):
        fighter = self.battle.fighters.get(roleid)
        if self.challenge.active() and fighter and fighter.born and fighter.hp > 0:
            return fighter
        return None

    def pickup(self, roleid, dropid, recheck=False):
        request = roleid, dropid
        if recheck:
            self.pickup_timers.pop(request, None)
        fighter = self.fighter(roleid)
        entry = self.props.get(dropid)
        if fighter is None or fighter.syncpos is None or entry is None:
            return
        dx, dy, dz = (a - b for a, b in zip(fighter.syncpos, pve.metres(entry[1]["pos"])))
        width = PICKUP_HALF_WIDTH + PICKUP_CONTACT_PAD
        # The original trigger is a box at floor level. The role's reported
        # position is its feet, so accept overlap with its standing body.
        if max(abs(dx), abs(dz)) > width or not -1.8 <= dy <= 0.9:
            if recheck:
                (log.info("PVE-PICKUP-REJECT role=%s drop=%s offset=%s", roleid, dropid,
                         (round(dx, 2), round(dy, 2), round(dz, 2))) if log.isEnabledFor(20) else None)
            elif request not in self.pickup_timers:
                # OnTriggerEnter only reports once. TCP pickup can precede
                # the fresh UDP position report from the same movement.
                self.pickup_timers[request] = self.challenge.loop.call_later(
                    PICKUP_RECHECK, self.pickup, roleid, dropid, True)
                (log.info("PVE-PICKUP-WAIT role=%s drop=%s offset=%s", roleid, dropid,
                         (round(dx, 2), round(dy, 2), round(dz, 2))) if log.isEnabledFor(20) else None)
            return
        timer = self.pickup_timers.pop(request, None)
        if timer is not None:
            timer.cancel()
        _, fields = self.props.pop(dropid)
        prop = pve.rows("Prop")[fields["propid"]]
        self.battle.send_all(SC_PICKUP, roleid=roleid, dropid=dropid)
        if prop["type"] < 5:
            self.passive[roleid] = (prop["type"], self.challenge.loop.time() + prop["time"])
        elif prop["type"] == 15:
            healed = min(float(prop["val"]), self.full_hp(roleid) - fighter.hp)
            if healed > 0:
                fighter.hp += healed
                self.battle.send_all(SC_ADD_HP, roleid=roleid, addhp=healed)
        elif prop["type"] == 5:
            self.challenge.medals.supply(roleid, pickup=True)
        self.pickups[roleid] += 1
        self.battle.send_all(pve.SC_SCORE, roleid=roleid, score=self.challenge.score(roleid))
        from . import handlers, tasks
        if handlers.world is not None:
            tasks.record(handlers.world.role(roleid), task_type=tasks.CHALLENGE_PICKUP)
        (log.info("PVE-PICKUP role=%s drop=%s prop=%s", roleid, dropid, prop["id"]) if log.isEnabledFor(20) else None)

    def player_died(self, roleid):
        self.cancel_refill(roleid)
        self.passive.pop(roleid, None)
        for request in tuple(self.pickup_timers):
            if request[0] == roleid:
                self.pickup_timers.pop(request).cancel()

    def pickup_shield(self, roleid):
        kind, until = self.passive.get(roleid, (0, 0))
        return kind == 1 and self.challenge.loop.time() < until

    def at_ammo(self, roleid):
        fighter = self.fighter(roleid)
        return (fighter is not None and fighter.syncpos is not None
                and math.dist(fighter.syncpos, self.layout["ammo_pos"]) <= self.layout["ammo_radius"])

    def fill_ammo(self, roleid, operation):
        if operation == 2:
            self.cancel_refill(roleid)
        elif operation == 0 and roleid not in self.refills:
            if not self.at_ammo(roleid):
                self.battle.send_all(SC_FILL_AMMO, roleid=roleid, result=2)
                return
            self.refills[roleid] = self.challenge.loop.call_later(self.ammo_time, self.complete_refill, roleid)

    def cancel_refill(self, roleid):
        timer = self.refills.pop(roleid, None)
        if timer is not None:
            timer.cancel()
            self.battle.send_all(SC_FILL_AMMO, roleid=roleid, result=2)

    def complete_refill(self, roleid):
        self.refills.pop(roleid, None)
        success = self.at_ammo(roleid)
        self.battle.send_all(SC_FILL_AMMO, roleid=roleid, result=1 if success else 2)
        if success and self.challenge.medals.supply(roleid, pickup=False):
            self.battle.send_all(pve.SC_SCORE, roleid=roleid, score=self.challenge.score(roleid))
        (log.info("PVE-SUPPLY role=%s success=%s", roleid, success) if log.isEnabledFor(20) else None)
