"""高难匹配（排位战 / 英雄联赛）的房间级规则、经济与 BOT 配置。

★ 设计红线：所有覆盖**只读房间属性**，绝不临时修改全局 CONFIG —— 否则
  普通房 / 生化房会串味。`rank_type()` 拿不到值的房间一律走原来的全局值。

两个入口在客户端共用 `QualifyingWindow`，只靠 `CsRankReady.ranktype` 区分：
    0 = 排位战（双倍奖励贴图）  1 = 英雄联赛
玩法由服务端下发的 `roominfo.gamemode` / `equiplimitid` 决定，客户端没有
模式选择菜单，所以「不改 UI」是可行的。
"""
from __future__ import annotations

import random
from typing import Any, Dict, Optional, Tuple

QUALIFYING = 0
LEAGUE = 1

# ---- 经济：钻石 = role.gold -------------------------------------------
TICKET = 500              # 联赛门票，点击匹配时预扣
# 【抖M版】数值整体收紧：
KILL_REWARD = 1200        # 联赛每杀 1 人（正式版 1000；替代普通的 kills*1）
DEATH_PENALTY = 5500      # 联赛每死 1 次（正式版 3000）
WIN_REWARD = 1680         # 排位本局胜利，只发真人且不叠加击杀钻
LOSE_PENALTY = 1680       # 【抖M版】排位本局失败扣款，clamp 到余额不为负

# 【抖M版】联赛按子模式加发胜利奖励（用户口径）：
#   团队竞技胜利 5000 钻 / SOLO 拿到第一（判定条件 = 本局击杀满 20）20000 钻 /
#   黑暗模式胜利 100000 钻；手枪对决（mode1 + equiplimitid=2）不发。
# 正式版（rt19）整段不存在 —— 只有抖M版结算才读。
LEAGUE_WIN_REWARD = {1: 5000, 4: 20000, 9: 100000}
LEAGUE_SOLO_KILLS = 20

# 联赛模式池：团队作战 : SOLO战 : 手枪对决 : 黑暗模式 = 10 : 4 : 2 : 1
LEAGUE_POOL: Tuple[Tuple[str, int], ...] = (
    ("team", 10), ("solo", 4), ("pistol", 2), ("dark", 1))

# ---- 房间级 BOT 覆盖 ---------------------------------------------------
BOT_FOV = {QUALIFYING: 280.0, LEAGUE: 280.0}   # 外面非高难 = CONFIG 的 135
# 【v20】联赛池由 7-9 扩到 6-9（用户嫌太少）；排位仍是 4-7。含端点。
GUN_STARS = {QUALIFYING: (4, 7), LEAGUE: (6, 9)}

# 【v20】复活无敌：排位歼灭(mode3) / 联赛 SOLO(mode4) 太长，统一 1.5 秒。
# 其它模式、外面自建房全部沿用 GameRule.rebornInvincibleTime，不动。
RANK_INVINCIBLE = {QUALIFYING: {3: 1.5}, LEAGUE: {4: 1.5}}

# 【v20】SOLO 全图复活点：每张图一套固定 8 点，整个游戏不随对局/回合变化。
# 用固定种子的确定性生成 + 模块级缓存，进程重启后仍是同一套。
SOLO_SPAWN_SEED = 0x5A10C0DE

# 【v20】骑士 / 龙系列 4-9★ 里「确认没问题」、允许进高难 BOT 枪池的主武器。
# 判据（逐把实测）：4<=star<=9、equipPos=11、在 cat.pool(11) 里、
# Gun.json 有对应行（真实射速/弹匣/伤害数据）、APK 里有对应 FPS 模型 bundle。
# 之前一律按 tex=99/levelTag 排除是过度保守：实测这 38 把全都有
# `{resource}_fps` 与 `{resource}_tex_99` 模型。10★ 以上（10-13 级）不放行。
SAFE_KNIGHT_IDS = frozenset((
    309121, 309122, 309123, 309124, 309125, 309126,
    403021, 403081, 403121, 403122, 403123, 403124, 403125, 403126,
    404021, 404081, 404121, 404122, 404123, 404124, 404125, 404126,
    507011, 507012, 507013, 507014, 507015, 507016,
    606011, 606031, 606131, 606132, 606133, 606134, 606135, 606136,
    1403081, 1606011,
))


def spawn_invincible(room: Any, gamemode: int) -> Optional[float]:
    """高难房的复活无敌秒数；None = 用规则表原值。"""
    rt = rank_type(room)
    if rt is None:
        return None
    return RANK_INVINCIBLE.get(rt, {}).get(int(gamemode))


def rank_type(obj: Any) -> Optional[int]:
    """room / battle / None -> 0 / 1 / None。

    只认 `local_rank_match` 标记（由 rank_queue 建房时打），不依赖
    `roominfo` 之类的方法是否存在 —— 结算 / 视野锥 / 枪池都可能传进来
    轻量对象，靠方法名判断会静默退化成「普通房」。
    """
    if obj is None:
        return None
    room = obj
    if not hasattr(room, "local_rank_match") and hasattr(obj, "room"):
        room = obj.room
    if room is None or not getattr(room, "local_rank_match", False):
        return None
    v = getattr(room, "local_rank_type", None)
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def bot_fov(room: Any) -> float:
    """高难房 280°，其余房间用 CONFIG 默认（v19 起 = 135°）。"""
    rt = rank_type(room)
    if rt in BOT_FOV:
        return float(BOT_FOV[rt])
    from ..config import CONFIG
    try:
        return float(getattr(CONFIG, "bot_fov_deg", 135.0))
    except (TypeError, ValueError):
        return 135.0


def gun_stars(room: Any) -> Optional[Tuple[int, int]]:
    """高难房的 BOT 枪池星级区间；None = 用原来的全局池。"""
    return GUN_STARS.get(rank_type(room))


def league_win_reward(room: Any) -> int:
    """【抖M版】联赛胜利额外奖励（钻石）；不在联赛 / 手枪对决返回 0。

    子模式靠服务端下发的房间属性区分，客户端没有选择菜单：
        gameMode 1 + equiplimitid 0 -> 团队竞技      5000
        gameMode 1 + equiplimitid 2 -> 手枪对决      0（不发）
        gameMode 4                  -> SOLO         20000（另需 20 杀，见调用方）
        gameMode 9                  -> 黑暗模式     100000
    """
    if rank_type(room) != LEAGUE:
        return 0
    if int(getattr(room, "equiplimitid", 0) or 0):
        return 0
    gm = int(getattr(room, "gamemode", 0) or 0)
    return int(LEAGUE_WIN_REWARD.get(gm, 0))


def _playable(mode: int):
    """该 gameMode 下 id<1000 且地图可用的规则行。"""
    from .. import gamedata
    return [r for r in gamedata.game_rules()
            if int(r.get("gameMode") or 0) == mode
            and int(r.get("id") or 0) < 1000
            and (gamedata.map_row(r.get("mapId")) or {}).get("status") in (0, 1)]


def pick_rule(rt: Optional[int]) -> Tuple[Optional[dict], int]:
    """按入口挑一条规则，返回 (GameRule 行, equiplimitid)。

    排位：只出 GameMode.json 里明确叫「歼灭战」的 mode3，11 条随机地图。
    联赛：10:4:2:1 加权抽 团队 / SOLO / 手枪对决 / 黑暗，地图随机；
          黑暗只有 id=999 一条，按用户口径不随机。
          手枪对决不是 gameMode，是 mode1 + equiplimitid=2(PISTOL)。
    """
    from .special_modes import PISTOL
    if rt == QUALIFYING:
        rows = _playable(3)
        return (random.choice(rows) if rows else None), 0
    if rt == LEAGUE:
        kinds = [name for name, weight in LEAGUE_POOL for _ in range(weight)]
        kind = random.choice(kinds)
        if kind == "solo":
            rows = _playable(4)
        elif kind == "pistol":
            rows = _playable(1)
            return (random.choice(rows) if rows else None), PISTOL
        elif kind == "dark":
            rows = _playable(9)
            return (rows[0] if rows else None), 0
        else:
            rows = _playable(1)
        return (random.choice(rows) if rows else None), 0
    # 非高难（理论不会走到）：保持原来的团队竞技
    rows = _playable(1)
    return (random.choice(rows) if rows else None), 0
