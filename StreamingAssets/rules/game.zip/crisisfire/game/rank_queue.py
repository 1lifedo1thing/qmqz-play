"""排位入口本地匹配（重建实现）。

1.8.1 客户端的排位请求（CsRankReady/CsRankInfo/CsRankQuit）在服务端没有业务
handler（route coverage 证据），入口点了没反应。这里重建一条**本地练习匹配**：
排队 3 秒 → 按入口随机一条规则建房（room_fill 自动填满 BOT）→ 直接开打。
不声称还原官方排位调度/评级/赛季算法；战斗本身是原生客户端 + 服务端房间。

【v19】两个入口分流（口径见 rank_profiles.py）：
  · ranktype 0 排位战：只出「歼灭战」(mode3) 随机地图；胜利发 1680 钻。
  · ranktype 1 英雄联赛：团队:SOLO:手枪对决:黑暗 = 10:4:2:1 加权随机；
    点匹配预扣 500 钻门票，正常结算退票 + 每杀 1000 / 每死 3000，
    中途退出 / 掉线吞票。钻石不足发 ScGachaFailRes(reason=3) 弹官方提示。

【v20】门票改成**单一账本**：每笔票有唯一 id，只能被消费一次。
  v19 的「TICKETS 临时字典 + 复制到 room.rank_ticket + room 上退款标记」
  是三份状态，结算与退出路径各写各的，实测出现「退了 500 又补 500」。
  现在扣款只记一笔，退款统一走 `consume_ticket()`，全局唯一入口。

协议形状按 1.8.1 客户端 marshal（evidence/client_protocols.json）：
    CsRankReady 1245230 {ready:int, ranktype:int}
    ScRankReady 1245231 {ranktype:int, ready:int, waittime:int}
    CsRankInfo  1245244 {}   ScRankInfo 1245245 {readynum,fightnum,waittime}
    CsRankQuit  1245227 {}   ScRankQuit 1245228 {roleid}
    ScSyncRankRoomInfo 1245243 {id, roominfo, players}（根尾可被帧长跳过）
"""
import asyncio, itertools, logging, random

from ..net.server import ROUTER
from . import room_handlers as RH
from . import rank_profiles as RP

log = logging.getLogger("crisisfire.rank_queue")
WAITING = {}

SC_GACHA_FAIL = 1048648        # com.gwebtop.shop.ScGachaFailRes
SC_ACOUNT_SYNC = 983043        # com.gwebtop.item.ScAcountSync

# 唯一账本：ticket_id -> {roleid, amount, roomid(None=仍在排队), refunded}
LEDGER = {}
_TICKET_SEQ = itertools.count(1)


def cancel(rid):
    task = WAITING.pop(rid, None)
    if task:
        task.cancel()


def _world():
    from . import handlers
    return handlers.world


def _sync_wallet(session, role):
    try:
        session.send(SC_ACOUNT_SYNC, gold=int(role.gold),
                     money=int(role.money), diamond=int(role.diamond))
    except Exception:
        (log.debug("RANK-TICKET 余额同步失败", exc_info=True) if log.isEnabledFor(10) else None)


def _find_pending(roleid: int, roomid=None):
    """找该玩家一笔**未退过**的票；roomid=None 时只要排队态的。"""
    for tid, rec in list(LEDGER.items()):
        if rec["roleid"] != int(roleid) or rec["refunded"]:
            continue
        if roomid is None:
            if rec["roomid"] is None:
                return tid, rec
        elif rec["roomid"] == int(roomid):
            return tid, rec
    return None, None


def consume_ticket(room, world, role) -> int:
    """【v20】唯一退款入口：正常结算退房票，一笔票全局只可能成功一次。

    由 `Battle.reward_players()` 调用；账本里没有未消费的票就返回 0，
    因此重复结算、结算后再发 CsRankQuit 都不会多退。
    """
    rid = int(role.roleid)
    roomid = int(getattr(room, "roomid", 0) or 0)
    tid, rec = _find_pending(rid, roomid)
    if tid is None:
        return 0
    amt = int(rec["amount"])
    rec["refunded"] = True
    LEDGER.pop(tid, None)
    from .wallet import change
    change(world, role, gems=amt)
    (log.info("RANK-TICKET 退票 ticket=%s role=%s +%d 余额=%d",
             tid, rid, amt, int(role.gold)) if log.isEnabledFor(20) else None)
    return amt


def _refund_pending(session):
    """只退**还在排队、没进房**的票（玩家主动取消 / 匹配失败）。

    进房后的票由 `consume_ticket()` 处理；这里绝不碰，避免两条退款路径。
    """
    tid, rec = _find_pending(session.roleid, roomid=None)
    if tid is None:
        return
    w = _world()
    role = w.role(session.roleid) if w is not None else None
    if role is None:
        return
    amt = int(rec["amount"])
    rec["refunded"] = True
    LEDGER.pop(tid, None)
    from .wallet import change
    change(w, role, gems=amt)
    _sync_wallet(session, role)
    (log.info("RANK-TICKET 排队取消退票 ticket=%s role=%s +%d 余额=%d",
             tid, session.roleid, amt, int(role.gold)) if log.isEnabledFor(20) else None)


def _charge_ticket(session) -> bool:
    """每次点匹配校验并预扣 500 钻。不足直接弹官方「钻石不足」通知。

    上一局若中途退出，旧票按惩罚沉没（不做退款，只从账本清掉）。
    """
    w = _world()
    role = w.role(session.roleid) if w is not None else None
    if role is None:
        return False
    if int(role.gold) < RP.TICKET:
        # ★ 服务端 FAIL_NO_MONEY=1 在客户端弹的是 Callboard(601)；
        #   只有 reason=3 才走 Callboard.Show(30)「抱歉，您的钻石不足」。
        session.send(SC_GACHA_FAIL, reason=3)
        (log.info("RANK-TICKET 余额不足 role=%s gold=%s（已弹钻石不足）",
                 session.roleid, int(role.gold)) if log.isEnabledFor(20) else None)
        return False
    # 清掉本玩家所有旧票（中途退出的沉没票 / 上一局残留）
    for tid, rec in list(LEDGER.items()):
        if rec["roleid"] == int(session.roleid):
            LEDGER.pop(tid, None)
    from .wallet import change
    change(w, role, gems=-RP.TICKET)
    tid = next(_TICKET_SEQ)
    LEDGER[tid] = {"roleid": int(session.roleid), "amount": RP.TICKET,
                   "roomid": None, "refunded": False}
    _sync_wallet(session, role)
    (log.info("RANK-TICKET 扣票 ticket=%s role=%s -%d 余额=%d",
             tid, session.roleid, RP.TICKET, int(role.gold)) if log.isEnabledFor(20) else None)
    return True


def attach_ticket(room, roleid: int) -> None:
    """建房成功后把该玩家的排队票绑定到房间；之后只由结算消费。"""
    tid, rec = _find_pending(roleid, roomid=None)
    if tid is not None:
        rec["roomid"] = int(room.roomid)


def install():
    original_sync = RH._sync_room

    def sync(room):
        if not getattr(room, "local_rank_match", False):
            return original_sync(room)
        RH._broadcast(room, 1245243, id=room.roomid,
                      roominfo=room.roominfo(), players=room.player_map())

    RH._sync_room = sync

    async def found(session, ranktype):
        try:
            await asyncio.sleep(3)
            if session.closed:
                _refund_pending(session)      # 排队期掉线：没进房，退票
                return
            old = RH.MANAGER.room_of(session.roleid)
            if old and old.started:
                _refund_pending(session)
                return
            member = RH._member_of(session)
            if member is None:
                _refund_pending(session)
                return
            from .. import gamedata
            rule, limit = RP.pick_rule(ranktype)
            if rule is None:
                # 「匹配一定成功」：池子异常也不能让玩家卡在排队里。
                rule, limit = RP.pick_rule(None)
            if rule is None:
                rows = [r for r in gamedata.game_rules()
                        if int(r.get("gameMode") or 0) == 1
                        and int(r.get("id") or 0) < 1000]
                rule, limit = (rows[0] if rows else None), 0
            if rule is None:
                _refund_pending(session)
                log.error("rank queue: no playable rule at all")
                return
            if old:
                RH.MANAGER.leave(old.roomid, session.roleid)
            room = RH.MANAGER.create(member, levelid=int(rule["id"]))
            # 【v1.0.1】真人在排位/联赛里**随机**落阵营。
            # 根因：`RH._member_of()` 不给 side（`rooms.Member` 默认 1），
            # 而 `RoomManager.create()` 只把 owner 塞进 members、**不走
            # `assign_side()`** → 匹配出来的房永远是 police(1)，对面清一色
            # BOT，玩家体感「只会分到联盟军」。
            # `room_fill.fill()` 的 BOT 是「按现有真人数平衡」补位的，所以
            # 这里把真人挪到 2 之后，BOT 会自动少填一个进 2、多填一个进 1，
            # 两边人数仍然相等。SOLO(mode4) 没有阵营概念（`bots._side_of`
            # 给每人唯一 roleid），保持原样。
            if int(room.gamemode) != 4:
                member.side = 1 if random.random() < 0.5 else 2
                (log.info("RANK-SIDE role=%s room=%s -> side=%s",
                         member.roleid, room.roomid, member.side) if log.isEnabledFor(20) else None)
            room.local_rank_match = True
            room.local_rank_type = int(ranktype)
            room.equiplimitid = int(limit)
            # 【v49】排位/联赛禁用辅助瞄准：建房默认带 bit 8，这里显式清掉。
            # Room.roominfo() 还有第二道裁决（防止房间被复用后又带上 8）。
            from . import rooms as _R
            room.flags = int(room.flags or 0) & ~_R.FLAG_AUTOAIM
            attach_ticket(room, session.roleid)
            member.ready = True
            session.send(1245231, ranktype=ranktype, ready=1, waittime=0)
            sync(room)
            (log.info("MATCH_FOUND role=%s room=%s ranktype=%s rule=%s map=%s "
                     "mode=%s limit=%s", session.roleid, room.roomid,
                     ranktype, rule["id"], room.mapid,
                     room.gamemode, room.equiplimitid) if log.isEnabledFor(20) else None)
            await asyncio.sleep(0.5)
            if not session.closed and session.roleid in room.members:
                await RH._start_battle(room)
        except asyncio.CancelledError:
            pass
        except Exception:
            log.exception("rank queue found failed role=%s", session.roleid)
            _refund_pending(session)
        finally:
            if WAITING.get(session.roleid) is asyncio.current_task():
                WAITING.pop(session.roleid, None)

    @ROUTER.register(1245230, "fight.CsRankReady")
    async def on_rank_ready(session, msg):
        if not session.roleid:
            return
        ranktype = int(msg.get("ranktype") or 0)
        if int(msg.get("ready") or 0) == 1:
            cancel(session.roleid)
            _refund_pending(session)
            session.send(1245231, ranktype=ranktype, ready=1, waittime=0)
            (log.info("MATCH_CANCEL role=%s", session.roleid) if log.isEnabledFor(20) else None)
            return
        room = RH.MANAGER.room_of(session.roleid)
        if room and room.started:
            return
        if session.roleid in WAITING:
            session.send(1245231, ranktype=ranktype, ready=0, waittime=3)
            return
        if ranktype == RP.LEAGUE and not _charge_ticket(session):
            return
        WAITING[session.roleid] = asyncio.create_task(found(session, ranktype))
        session.send(1245231, ranktype=ranktype, ready=0, waittime=3)
        (log.info("MATCH_QUEUED role=%s ranktype=%s", session.roleid, ranktype) if log.isEnabledFor(20) else None)

    @ROUTER.register(1245244, "fight.CsRankInfo")
    async def on_rank_info(session, msg):
        session.send(1245245, readynum=len(WAITING),
                     fightnum=sum(bool(getattr(r, "local_rank_match", False)
                                       and r.started)
                                  for r in RH.MANAGER.rooms.values()),
                     waittime=3)

    @ROUTER.register(1245227, "fight.CsRankQuit")
    async def on_rank_quit(session, msg):
        cancel(session.roleid)
        _refund_pending(session)     # 只退排队态；进房后的票不碰
        session.send(1245228, roleid=session.roleid or 0)
        (log.info("MATCH_QUIT role=%s", session.roleid) if log.isEnabledFor(20) else None)

    # 原生 Commander.Quit 先发 GS CsQuit 再发房内 RoleQuit；GS 清房先到时
    # 房内 RoleQuit 会对着不存在的房间 —— 幂等回一条让客户端退出干净。
    original_quit = ROUTER.handler_for(1441901)

    @ROUTER.register(1441901, "gclient.RoleQuit (idempotent own exit)")
    async def quit_battle(session, msg):
        rid = int(msg.get("roleid") or session.roleid or 0)
        if rid == session.roleid and rid > 0 and RH.MANAGER.room_of(rid) is None:
            session.send(1441901, roleid=rid)
            (log.info("QUIT_ACK after GS cleanup role=%s", rid) if log.isEnabledFor(20) else None)
            return
        await original_quit(session, msg)

    (log.info("rank_queue installed (高难分流 + 门票单一账本)") if log.isEnabledFor(20) else None)
