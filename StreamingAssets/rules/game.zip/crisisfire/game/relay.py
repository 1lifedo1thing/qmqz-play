"""战斗内的动作转发 —— 让其他玩家看到你在做什么.

服务端对 `CsAction` / `CsJump` 一直是转发的，但同类消息漏了一批。缺了它们，
别人看你就是「站着不动」：连发、换弹、手雷、拾取、下包全都没有表现。

这批是 `tools/audit_requests.py` 找出来的（客户端会发、服务端没有路由）。

字段差异要一个个对，不能照抄：

    CsMultiShoot(1441899)      roleid, shoots
    ScMultiShoot(1441900)      shoots, shooterid        <- 名字不同：roleid -> shooterid

    CsGrenadeExplode(1441909)  roleid, pos, grenadeid, serial
    ScGrenadeExplode(1441910)  roleid, pos, grenadeid, serial, targets   <- 多 targets

    CsFillBullet(1441934)      roleid
    ScFillBullet(1441935)      roleid, weaponpos        <- 多 weaponpos（靠 WeaponChange 追踪）

    CsFillBulletStop(1441945)  roleid, finishtimes
    ScFillBulletStop(1441946)  roleid, weaponpos, finishtimes

    CsPickupItem(1441932)      roleid, dropid           -> ScPickupItem(1441938) 字段一致
    BulletChange(1441944)      roleid, bullettype       -> **双向同名**，要回执
    CsBombOper(1441925)        roleid, operate          -> ScBombOper(1441926) 字段一致

    CsPickupGun(1441947)       roleid, dropid, pos      -> **没有 Sc 对应**，只转发给其他人

    CsFall(1441953)            roleid, speed
    ScFall(1441954)            damage                   <- 只回给坠落者，服务端算伤害

`ScFall` 只有 damage 没有 roleid —— 它是发给**坠落的那个人**的，告诉他摔了多少血。
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.relay")


class ID:
    CS_MULTI_SHOOT = 1441899
    SC_MULTI_SHOOT = 1441900
    CS_GRENADE_EXPLODE = 1441909
    SC_GRENADE_EXPLODE = 1441910
    CS_PICKUP_ITEM = 1441932
    SC_PICKUP_ITEM = 1441938
    CS_FILL_BULLET = 1441934
    SC_FILL_BULLET = 1441935
    CS_FILL_BULLET_STOP = 1441945
    SC_FILL_BULLET_STOP = 1441946
    BULLET_CHANGE = 1441944
    CS_BOMB_OPER = 1441925
    SC_BOMB_OPER = 1441926
    CS_PICKUP_GUN = 1441947
    CS_FALL = 1441953
    SC_FALL = 1441954

    SC_PING = 720900


# 坠落伤害：`VirtualServer.GetFallDamage(roleid, velocity)` 是客户端本地算的，
# 服务端这边按速度线性折算。数值没有配置依据（客户端那个函数读的是玩家状态），
# 所以给一个保守的系数，要调改这里。
FALL_DAMAGE_PER_UNIT = 10.0
FALL_DAMAGE_FREE_SPEED = 12.0      # 这个速度以下不摔伤


def _battle_of(session: Session):
    """这个会话所在的战场（不在战斗里就返回 None）。"""
    from .battle import battle_for, _room_of
    room = _room_of(session.roleid) if session.roleid else None
    if room is None:
        return None, None
    return room, battle_for(room, create=False)


def _weaponpos(b, roleid: int) -> int:
    f = b.fighters.get(roleid) if b is not None else None
    return int(getattr(f, "weaponpos", 0) or 0) if f is not None else 0


def fall_damage(speed: float) -> int:
    """坠落伤害。速度低于阈值不摔伤。"""
    try:
        v = max(0.0, float(speed))
    except (TypeError, ValueError):
        return 0
    if v <= FALL_DAMAGE_FREE_SPEED:
        return 0
    return int((v - FALL_DAMAGE_FREE_SPEED) * FALL_DAMAGE_PER_UNIT)


def _i(msg: Dict[str, Any], key: str, default: int = 0) -> int:
    try:
        return int(msg.get(key) or default)
    except (TypeError, ValueError):
        return default


def _multi_shot_payload(b, shooterid: int, s: dict, is_bio: bool):
    """兼容包装：返回 (ShootDamage payload, hits)，实际结算在 weapon_fire。

    **绝对不能把客户端原始 ShootHit 原样塞进 ScMultiShoot**：
    `ShootHit.targets` 的元素是 `TargetHit`（targetid/sd/hitpart/hitpos/
    targetpos），而 `ShootDamage.targets` 要的是 `TargetDamage`
    （多出 hpdamage/acdamage/sapihpdamage）。原样转发时客户端按错误结构解码，
    打出来的伤害数字就是 0（用户反馈「有伤害显示但伤害是 0」）。
    """
    from . import damage
    hits = damage.resolve_shoot(b, shooterid, s, is_biochem=is_bio) or []
    ch = getattr(b, "challenge", None)
    if ch is not None:
        monster_hits = ch.on_shoot(shooterid, s) or []
        if monster_hits:
            hits = list(hits) + list(monster_hits)
    return damage.shoot_damage_payload(s, hits), hits


# --------------------------------------------------------------------------
# 纯转发（别人看得到你的动作）
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_MULTI_SHOOT, "gclient.CsMultiShoot")
async def on_multi_shoot(session: Session, msg: dict) -> None:
    """连发/霰弹枪。`ScMultiShoot` 用 shooterid，不是 roleid。

    真人这条分支原来直接 `damage.resolve_shoot` 然后自己发 ScMultiShoot，
    绕过了 `battle.settle_shoot` 的射手活体/回合守卫、生化后坐力登记和统一
    的击杀结算。现在和 BOT 的多弹丸发射共用 `weapon_fire.settle_multi`：

    * 射手必须存在、已出生、hp>0，且回合未结束；否则**不结算也不下发**；
    * 每条射线都走 `damage.resolve_shoot`，友方/出生保护/死亡目标检查一致；
    * 击杀按目标去重后调用 `battle.on_kill`；
    * 挑战模式命中的怪物仍然并入 payload（由 damage 层生成 TargetDamage）。
    """
    room, b = _battle_of(session)
    if b is None:
        return
    from . import weapon_fire
    shoots = msg.get("shoots") or []
    if not shoots:
        return
    # PVE monster hits are not Fighters; keep the same merge point as before.
    weapon_fire.settle_multi(b, session.roleid, shoots, b.biochem is not None,
                             log_tag="MULTISHOOT", player_reported=True)


@ROUTER.register(ID.CS_GRENADE_EXPLODE, "gclient.CsGrenadeExplode")
async def on_grenade_explode(session: Session, msg: dict) -> None:
    """Apply a grenade explosion once, for the owner of its issued serial."""
    _, battle = _battle_of(session)
    if battle is not None:
        from . import grenades
        grenades.explode(battle, session.roleid, _i(msg, "grenadeid"),
                         _i(msg, "serial"), msg.get("pos") or {})


@ROUTER.register(ID.CS_PICKUP_ITEM, "gclient.CsPickupItem")
async def on_pickup_item(session: Session, msg: dict) -> None:
    """Route supply boxes through the round that owns them."""
    _, b = _battle_of(session)
    if b is None:
        return
    dropid = _i(msg, "dropid")
    if b.challenge is not None:
        b.challenge.support.pickup(session.roleid, dropid)
        return
    bio = getattr(b, "biochem", None)
    if bio is not None and bio.owns_box_id(dropid):
        bio.take_box(dropid, session.roleid)
        return
    if bio is not None:
        # 生化房里捡到「不归本回合管」的道具：只转发会让客户端自己把箱子
        # 吃掉、本地回血，服务端血量却不动 —— 正是「箱子不生效」的假象。
        (log.info("BIO-PICKUP 未知 dropid=%s role=%s（不属于本回合的箱子）",
                 dropid, session.roleid) if log.isEnabledFor(20) else None)
    b.send_all(ID.SC_PICKUP_ITEM, roleid=session.roleid, dropid=dropid)


@ROUTER.register(ID.CS_PICKUP_GUN, "gclient.CsPickupGun")
async def on_pickup_gun(session: Session, msg: dict) -> None:
    """捡枪。**没有 Sc 对应消息**，只能把原消息转给别人。"""
    room, b = _battle_of(session)
    if b is None:
        return
    b.send_all(ID.CS_PICKUP_GUN,
                  roleid=session.roleid, dropid=_i(msg, "dropid"),
                  pos=msg.get("pos") or {})


@ROUTER.register(ID.CS_FILL_BULLET, "gclient.CsFillBullet")
async def on_fill_bullet(session: Session, msg: dict) -> None:
    """开始补弹。`ScFillBullet` 多一个 weaponpos。"""
    room, b = _battle_of(session)
    if b is None:
        return
    # 【v61】换弹完成时把服务端弹药记账的弹匣补满（切枪回包要用）。
    try:
        from . import player_ammo
        _f = b.fighters.get(session.roleid)
        if _f is not None:
            player_ammo.on_reload(b, _f)
    except Exception:
        pass
    b.send_all(ID.SC_FILL_BULLET,
                  roleid=session.roleid,
                  weaponpos=_weaponpos(b, session.roleid))


@ROUTER.register(ID.CS_FILL_BULLET_STOP, "gclient.CsFillBulletStop")
async def on_fill_bullet_stop(session: Session, msg: dict) -> None:
    """补弹结束。"""
    room, b = _battle_of(session)
    if b is None:
        return
    b.send_all(ID.SC_FILL_BULLET_STOP,
                  roleid=session.roleid,
                  weaponpos=_weaponpos(b, session.roleid),
                  finishtimes=_i(msg, "finishtimes"))


@ROUTER.register(ID.BULLET_CHANGE, "gclient.BulletChange")
async def on_bullet_change(session: Session, msg: dict) -> None:
    """换弹夹类型。

    `BulletChange` 是**双向同名**消息（和 RemoveBlackList 一样），客户端发它，
    同时它自己的 process() 也把它当作回执。所以要**回执给自己** + 转给别人。
    """
    room, b = _battle_of(session)
    if b is None:
        return
    from . import premium_ammo
    premium_ammo.switch(b, session, _i(msg, "bullettype"))


@ROUTER.register(ID.CS_BOMB_OPER, "gclient.CsBombOper")
async def on_bomb_oper(session: Session, msg: dict) -> None:
    """爆破模式的安包 / 拆包请求，转给 `bomb.Bomb` 状态机。

    客户端在线时 `Commander.BombOper` **只发不等**：它自己只会发 1/3（安放按下/松开）
    和 4/6（拆除按下/松开）、以及取包 7；`operate=2`（已安放）和 `5`（已拆除）
    客户端从不产生，只能由服务端按 GameRule 的时长裁决后广播回来。
    所以这里既要**原样转发**客户端报的那些值，也要让状态机在计时到点后
    自己补发 2 / 5 / ScBombPos / ScBombExplode —— 少一半都进不了「已安放」。
    """
    room, b = _battle_of(session)
    if b is None:
        return
    operate = _i(msg, "operate")
    (log.info("room %s role %s 爆破操作 operate=%s", room.roomid,
             session.roleid, operate) if log.isEnabledFor(20) else None)
    b.bomb.request(session.roleid, operate)
    b.send_all(ID.SC_BOMB_OPER, roleid=session.roleid, operate=operate)


@ROUTER.register(ID.CS_FALL, "gclient.CsFall")
async def on_fall(session: Session, msg: dict) -> None:
    """坠落。客户端报速度，**服务端算伤害**（对齐 CsShoot 的分工）。

    `ScFall` 只有 damage 字段、没有 roleid —— 它是回给**坠落者本人**的。
    """
    room, b = _battle_of(session)
    if b is None:
        return
    f = b.fighters.get(session.roleid)
    if f is None or not f.born:
        return
    dmg = fall_damage(msg.get("speed"))
    if dmg <= 0:
        return
    f.hp = max(0.0, float(f.hp) - dmg)
    session.send(ID.SC_FALL, damage=dmg)
    (log.info("room %s role %s 坠落 -%s 血 (剩 %s)", room.roomid,
             session.roleid, dmg, f.hp) if log.isEnabledFor(20) else None)
    if f.hp <= 0:
        b.on_kill(0, session.roleid)
