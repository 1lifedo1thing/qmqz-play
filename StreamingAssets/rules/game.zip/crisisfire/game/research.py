"""枪械强化 / 升版本 / 碎片合成 / 碎片回收.

客户端这套 UI 是**完整实现**的（``Strengthener.cs`` 625 行），但服务端一条
协议都没注册，所以点「强化」按钮没有任何反应。这里把整条链接上：

    强化   CsGunResearch(786477, gunid)      → ScGunResearch(786478, gunid, progress)
    升版本 CsTransform(786459, gunid, newid) → ScTransform(786460, newgunid)
    合成   CsPartsHecheng(786487, partsid)   → ScPartsHecheng(786488, partsid, number, gunid)
    卖碎片 CsSellParts(786489, partsid, num) → ScSellParts(786490, partsid, number)
    同步   ScGunProgress(786476, {gunid: progress})
           ScStudyPointSync(786473, studypoint)

数据全在 ``gamedata/Part.json``（359 行）与 ``Fusion.json``（26 行）：

    Part    id(=枪的 Item id) / modelType(系列) / version(第几版) /
            maxHolding(强化进度上限，0 = 已是最高版) / price(每次强化消耗强化点) /
            parts(升版本消耗的碎片数) / pieceId(碎片道具 id)

强化**本身不加伤害** —— 它是「攒进度」；攒满 ``maxHolding`` 之后花碎片升版本，
换成同一个 ``modelType`` 下一版的 Item，而版本化 Item 的 ``basicDamage`` 才是
递增的（沙鹰 101101=38 → 101102=40 → 101103=42 → 101104=44）。所以升版本时
必须把背包和装备方案里的 itemid 一起换掉，否则只改了显示。
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import equip, stackable

log = logging.getLogger("crisisfire.research")


class ID:
    SC_STUDY_POINT_SYNC = 786473
    CS_SALE_STUDY_POINT = 786474
    SC_SALE_STUDY_POINT = 786475
    SC_GUN_PROGRESS = 786476
    CS_GUN_RESEARCH = 786477
    SC_GUN_RESEARCH = 786478
    CS_TRANSFORM = 786459
    SC_TRANSFORM = 786460
    CS_PARTS_HECHENG = 786487
    SC_PARTS_HECHENG = 786488
    CS_SELL_PARTS = 786489
    SC_SELL_PARTS = 786490
    CS_EXCHANGE_PARTS = 786491
    SC_EXCHANGE_PARTS = 786492
    SC_PACKAGE_SYNC = 983041


_world = None

_part_index: Optional[Dict[int, Dict[str, Any]]] = None
_by_model: Optional[Dict[int, List[Dict[str, Any]]]] = None
_fusion_by_parts: Optional[Dict[int, Dict[str, Any]]] = None


def bind_world(world) -> None:
    global _world
    _world = world


def _parts() -> Dict[int, Dict[str, Any]]:
    global _part_index, _by_model
    if _part_index is None:
        _part_index = {}
        _by_model = {}
        for row in gamedata.table("Part"):
            try:
                pid = int(row["id"])
            except (KeyError, TypeError, ValueError):
                continue
            _part_index[pid] = row
            try:
                mid = int(row.get("modelType") or 0)
            except (TypeError, ValueError):
                mid = 0
            _by_model.setdefault(mid, []).append(row)
        for rows in _by_model.values():
            rows.sort(key=lambda r: int(r.get("version") or 0))
    return _part_index


def part_row(partid: int) -> Optional[Dict[str, Any]]:
    return _parts().get(int(partid))


def max_version(modelType: int) -> int:
    _parts()
    rows = (_by_model or {}).get(int(modelType)) or []
    return int(rows[-1].get("version") or 0) if rows else 0


def part_by_version(modelType: int, version: int) -> Optional[Dict[str, Any]]:
    _parts()
    for row in (_by_model or {}).get(int(modelType)) or []:
        if int(row.get("version") or 0) == int(version):
            return row
    return None


def next_part(part: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """同一系列里的下一版本。"""
    return part_by_version(int(part.get("modelType") or 0),
                           int(part.get("version") or 0) + 1)


def _fusion_index() -> Dict[int, Dict[str, Any]]:
    global _fusion_by_parts
    if _fusion_by_parts is None:
        _fusion_by_parts = {}
        for row in gamedata.table("Fusion"):
            try:
                _fusion_by_parts[int(row["partsId"])] = row
            except (KeyError, TypeError, ValueError):
                continue
    return _fusion_by_parts


def fusion_for(pieceid: int) -> Optional[Dict[str, Any]]:
    return _fusion_index().get(int(pieceid))


_piece_ids: Optional[set] = None


def _is_piece(itemid: int) -> bool:
    """这个道具 id 是不是「碎片」（Part.pieceId 集合里的）。

    兑换兜底时只允许拿碎片去补，绝不能把弹药 / 强化材料当材料扣掉。
    """
    global _piece_ids
    if _piece_ids is None:
        _piece_ids = set()
        for row in gamedata.table("Part"):
            try:
                pid = int(row.get("pieceId") or 0)
            except (TypeError, ValueError):
                continue
            if pid > 0:
                _piece_ids.add(pid)
    return int(itemid) in _piece_ids


# --------------------------------------------------------------------------
# 同步
# --------------------------------------------------------------------------
def push_study_point(session: Session, role) -> None:
    if session is None or getattr(session, "closed", False):
        return
    session.send(ID.SC_STUDY_POINT_SYNC, studypoint=stackable.study_point(role))


def push_progress(session: Session, role) -> None:
    """登录时的批量进度。客户端 Strengthener.gunProgress 靠它填满所有进度条。"""
    if session is None or getattr(session, "closed", False):
        return
    mapping = stackable.research_map(role)
    session.send(ID.SC_GUN_PROGRESS,
                 guns={int(k): int(v) for k, v in mapping.items()})


def push_on_login(session: Session, role) -> None:
    push_study_point(session, role)
    push_progress(session, role)


def _push_package_all(session: Session, role) -> None:
    """全量背包：升版本要换 itemid，而 ScPackageSync 只有 add/modify/all 三种，
    add 不会删掉旧 id，所以这里必须整包重发（客户端 case 3 会 Clear 后重建）。"""
    if session is None or getattr(session, "closed", False):
        return
    session.send(ID.SC_PACKAGE_SYNC, synctype=3,
                 itemlist=equip.package_items_for(role))


# --------------------------------------------------------------------------
# 强化
# --------------------------------------------------------------------------
def grant_start_points(role) -> None:
    """首次登录发一笔启动强化点（`CF_RESEARCH_POINTS`，默认 20000）。

    原版强化点只从转盘和月卡来，本地私服没有稳定的获取途径，
    界面会一直显示 0（用户实测「强化点无法获取」）。

    **只发一次**：早期版本是「不足就补到 20000」，结果玩家花光后重登又
    变成 20000，养成完全没有意义。现在用 ``study_point_granted`` 标记，
    补贴过一次之后就不再补，后续靠抽卡（强化点礼包）赚。
    """
    from ..config import CONFIG
    if role is None:
        return
    if (role.data or {}).get("study_point_granted"):
        return
    try:
        want = max(0, int(getattr(CONFIG, "research_start_points", 0) or 0))
    except (TypeError, ValueError):
        want = 0
    if want > 0 and stackable.study_point(role) < want:
        stackable.set_study_point(role, want, _world)
        (log.info("role %s 首发强化点 %s", getattr(role, "roleid", "?"), want) if log.isEnabledFor(20) else None)
    if _world is not None:
        _world.merge_role_data(role.roleid, study_point_granted=True)


_LEGEND_CHIP_CACHE: Dict[int, int] = {}

# 【v49】每条龙的芯片总数上限（礼包 1 + 改 2 + 改36 3 + 改37 4 + 改38 5 = 15）
_LEGEND_CHIP_LIMIT = 15
# 【v49】生命芯片载体：Gift.giftLevel=5（1880 钻礼包行，addHp 保持原版 5）。
# 客户端 Gift 表只有 10 行、且是 BinaryFormatter 流，插行会打乱对象引用，
# 且用户明确「不改变这个礼包的内容」→ 用 2 个 +5 凑 +10，不改表值。
# ★ 龙芯片 giftLevel 沿用官方编号（两端一致，不要再改）：
#   8 炎龙 / 6 狂龙 / 7 魔龙 / 9 血龙 / 10 屠龙。
_LIFE_CHIP_GIFT = 5
# 每把龙「改·38」发 2 个「生命+5」芯片（用户口径：不改 1880 钻礼包内容）
_LIFE_CHIPS_PER_DRAGON = 2


def _legend_chip_for(model_type: int) -> int:
    """按 Item.modelType 找对应的传奇龙武器芯片礼包（Gift.giftLevel）。

    五把龙枪（炎龙AK47 / 狂龙AWP / 魔龙M4A1 / 血龙左轮 / 屠龙尼泊尔）
    各有 4 次传奇改装（v0→v4）。用户要求：礼包买来给 1 个芯片，
    之后**每改装升一级再给 1 个**，最终每种龙最多 5 个（可叠加）。
    """
    mt = int(model_type or 0)
    if not mt:
        return 0
    if mt in _LEGEND_CHIP_CACHE:
        return _LEGEND_CHIP_CACHE[mt]
    items = {int(r['id']): r for r in gamedata.table('Item')}
    found = 0
    for row in gamedata.table('Gift'):
        if int(row.get('isLegend') or 0) != 1:
            continue
        raw = row.get('item')
        ids = raw.get('_items') if isinstance(raw, dict) else raw
        if not isinstance(ids, (list, tuple)):
            continue
        for x in ids:
            iid = int(x or 0)
            if iid and int((items.get(iid) or {}).get('modelType') or 0) == mt:
                found = int(row.get('giftLevel') or 0)
                break
        if found:
            break
    _LEGEND_CHIP_CACHE[mt] = found
    return found


def _grant_legend_chip(session: Session, role, model_type: int, count: int = 1) -> None:
    """改装龙武器升一级 -> 按**该级档位**发对应数量的武器芯片。

    【v49 用户新口径】每把龙总共 15 个芯片：
        购买礼包        -> 1 个（礼包本身进 gifts，天然满足）
        「改」   star10 -> 2 个
        「改·36」star11 -> 3 个
        「改·37」star12 -> 4 个
        「改·38」star13 -> 5 个
        1+2+3+4+5 = 15，效果叠加 15 次（GiftBuff.Sync 按 gifts 列表累加，
        重复 id 就会重复叠加，客户端不需要改）。
    上限 15 是硬保护：手改数据/重复回调也不会超过。
    """
    gift = _legend_chip_for(model_type)
    if not gift or int(count or 0) <= 0:
        return
    from . import shop as _shop
    gifts = list(_shop.owned_gifts(role))
    have = gifts.count(gift)
    take = max(0, min(int(count), _LEGEND_CHIP_LIMIT - have))
    if take <= 0:
        (log.info("role %s 龙芯片 %s 已达上限 %s 个", role.name, gift,
                 _LEGEND_CHIP_LIMIT) if log.isEnabledFor(20) else None)
        return
    gifts.extend([gift] * take)
    if _world is not None:
        _world.merge_role_data(role.roleid, gifts=gifts)
    role.data = dict(role.data or {}, gifts=gifts)
    session.send(_shop.ID.SC_GIFT_SYNC, gifts=gifts)
    (log.info("role %s 改装龙武器 -> 芯片 %s +%d (共 %d 个)", role.name, gift,
             take, gifts.count(gift)) if log.isEnabledFor(20) else None)


def _grant_life_chip(session: Session, role, model_type: int) -> None:
    """「改·38」额外给 2 个「生命+5」芯片（每把龙只给一次）。

    【v49 用户口径】**不改 1880 钻礼包（giftLevel=5）的内容**：它的
    `addHp` 保持原版 5，所以直接买礼包仍是 +5。要凑「生命+10」就发
    **两个** 同款芯片，客户端 `GiftBuff.Sync` 本就按拥有个数累加，
    2×5 = 10。5 把龙 × 2 = 10 个芯片 = +50 生命，与改之前的 +10×5 等价。
    文案 `TextPool.Get(396, gift.addHp)` 显示「生命永久+5」是**单个**
    芯片的值，属性面板的合计由 ChipAddition 那边算。
    """
    mt = int(model_type or 0)
    if not mt:
        return
    from . import shop as _shop
    done = [int(x) for x in ((role.data or {}).get("legend_life_chips") or [])]
    if mt in done:
        (log.info("role %s 龙的 %s 生命芯片已发过", role.name, mt) if log.isEnabledFor(20) else None)
        return
    gifts = list(_shop.owned_gifts(role))
    gifts.extend([_LIFE_CHIP_GIFT] * _LIFE_CHIPS_PER_DRAGON)
    done.append(mt)
    if _world is not None:
        _world.merge_role_data(role.roleid, gifts=gifts,
                               legend_life_chips=done)
    role.data = dict(role.data or {}, gifts=gifts, legend_life_chips=done)
    session.send(_shop.ID.SC_GIFT_SYNC, gifts=gifts)
    (log.info("role %s 改·38 -> 生命+5 芯片 x%d (第 %d 把龙, 累计 %d 个)",
             role.name, _LIFE_CHIPS_PER_DRAGON, len(done),
             gifts.count(_LIFE_CHIP_GIFT)) if log.isEnabledFor(20) else None)


# 每条龙累计应有的芯片数（礼包 1 + 改2 + 改36 3 + 改37 4 + 改38 5）
_CHIPS_BY_STAR = {9: 1, 10: 3, 11: 6, 12: 10, 13: 15}
# 【v58】加上怒龙（modelType 310，怒龙-打击者 9★）。用户口径：
# 「怒龙改·38」同样发 2 个「生命+5」芯片，6 把龙满改 = 12 个 = 生命 +60。
_LEGEND_MODEL_TYPES = (492, 608, 495, 113, 851, 310)

# 【v59 用户新口径】怒龙芯片（Gift.giftLevel=11）改成「改·38 专属」：
#   * 买 4980 钻怒龙礼包 **不再** 送芯片（只给枪）
#   * 只有把怒龙做到「怒龙改·38」(Item 203105 / star13) 才给 **1 个**
#   * 全账号上限 1 个
# 其余 5 把龙的「每级发芯片」逻辑不变。
_ANGRY_MODEL_TYPE = 310
_ANGRY_CHIP_GIFT = 11
_ANGRY_CHIP_LIMIT = 1


def _grant_angry_chip(session: Session, role) -> None:
    """怒龙改·38 → 1 个怒龙芯片（上限 1 个，重复调用幂等）。"""
    from . import shop as _shop
    gifts = list(_shop.owned_gifts(role))
    if gifts.count(_ANGRY_CHIP_GIFT) >= _ANGRY_CHIP_LIMIT:
        (log.info("role %s 怒龙芯片已满 %s 个", role.name,
                 _ANGRY_CHIP_LIMIT) if log.isEnabledFor(20) else None)
        return
    gifts.append(_ANGRY_CHIP_GIFT)
    if _world is not None:
        _world.merge_role_data(role.roleid, gifts=gifts)
    role.data = dict(role.data or {}, gifts=gifts)
    session.send(_shop.ID.SC_GIFT_SYNC, gifts=gifts)
    (log.info("role %s 怒龙改·38 -> 怒龙芯片 x1（共 %d 个）",
             role.name, gifts.count(_ANGRY_CHIP_GIFT)) if log.isEnabledFor(20) else None)


def trim_angry_chip(world, role):
    """【v59】怒龙芯片上限 1 个：老存档裁到 1 个（只做一次）。

    v58 之前怒龙跟其它龙一样「每改装一级发一个」，改满会有 15 个；
    现在芯片改为「改·38 只给 1 个、上限 1 个」，所以登录时把多余的裁掉。
    """
    if world is None or role is None:
        return role
    fresh = world.role(role.roleid) or role
    data = dict(fresh.data or {})
    if data.get("angry_chip_v59_trim"):
        return fresh
    gifts = [int(g) for g in (data.get("gifts") or [])]
    out: List[int] = []
    seen = 0
    dropped = 0
    for g in gifts:
        if g == _ANGRY_CHIP_GIFT:
            seen += 1
            if seen > _ANGRY_CHIP_LIMIT:
                dropped += 1
                continue
        out.append(g)
    data["gifts"] = out
    data["angry_chip_v59_trim"] = 1
    world.merge_role_data(role.roleid, **data)
    role.data = dict(fresh.data or {})
    if dropped:
        (log.info("role %s 怒龙芯片裁到 %d 个（去掉 %d 个）",
                 role.name, _ANGRY_CHIP_LIMIT, dropped) if log.isEnabledFor(20) else None)
    return fresh


def sync_legend_chips_on_login(world, role) -> None:
    """【v50】按背包里每条龙的最高改装版本，一次性补齐历史少发的芯片。

    v49 用 `nxt.get("star")` 取 Part 表（没有 star，恒 0），每次改装只发
    1 个芯片，改满的龙只有 5 个（应 15 个），改·38 也没发生命芯片。
    只修发放逻辑不会补回用户已经改满的那些武器，所以登录时按
    Item.star(9~13) 反推应有累计数量补差额。marker 保证只补一次，
    之后的改装走 `on_transform` 的正常发放。
    **必须在 shop.migrate_legend_gift_ids（编号回滚）之后调用。**
    """
    if world is None or role is None:
        return
    fresh = world.role(role.roleid) or role
    data = dict(fresh.data or {})
    if data.get("legend_chips_v50_sync"):
        return
    from . import equip as _eq
    owned = set(_eq.owned_ids(fresh))
    best: Dict[int, int] = {}
    for row in gamedata.table("Item"):
        mt = int(row.get("modelType") or 0)
        if mt not in _LEGEND_MODEL_TYPES or int(row["id"]) not in owned:
            continue
        star = int(row.get("star") or 0)
        if star > best.get(mt, 0):
            best[mt] = star
    gifts = list(data.get("gifts") or [])
    added = 0
    for mt, star in best.items():
        # 【v59】怒龙不再按星级发芯片（只有改·38 给 1 个），见下面单独一段
        if mt == _ANGRY_MODEL_TYPE:
            continue
        gift = _legend_chip_for(mt)
        if not gift:
            continue
        want = _CHIPS_BY_STAR.get(star, 1)
        lack = max(0, min(want, _LEGEND_CHIP_LIMIT) - gifts.count(gift))
        if lack:
            gifts.extend([gift] * lack)
            added += lack
    # 【v59】怒龙：只有做到「改·38」(star13) 才有 1 个芯片，且上限 1 个
    if best.get(_ANGRY_MODEL_TYPE, 0) >= 13:
        lack_angry = max(0, _ANGRY_CHIP_LIMIT - gifts.count(_ANGRY_CHIP_GIFT))
        if lack_angry:
            gifts.extend([_ANGRY_CHIP_GIFT] * lack_angry)
            added += lack_angry
    # 「改·38」的每条龙应额外有 2 个「生命+5」芯片
    full = sum(1 for s in best.values() if s >= 13)
    want_life = full * _LIFE_CHIPS_PER_DRAGON
    lack_life = max(0, want_life - gifts.count(_LIFE_CHIP_GIFT))
    if lack_life:
        gifts.extend([_LIFE_CHIP_GIFT] * lack_life)
        added += lack_life
    data["gifts"] = gifts
    data["legend_chips_v50_sync"] = 1
    world.merge_role_data(role.roleid, **data)
    role.data = dict(fresh.data or {})
    if added:
        (log.info("LEGEND-CHIP-SYNC role=%s 按改装版本补发 %d 个芯片 "
                 "( versions=%s, 生命芯片应 %d 个 )",
                 role.name, added, best, want_life) if log.isEnabledFor(20) else None)


def _grant_talent_point(session: Session, role, n: int = 1) -> None:
    """枪械「升一级」给 1 点强化天赋点。

    官方：强化枪械并完成一次改装（枪械等级 +1）才能获得一点，
    这就是 `ResearchTalent.unlockPoints`（5/10/20/30…）那套点数的来源。
    抽卡给的是**强化点**（study_point），两者不是同一种货币。
    """
    if int(n) <= 0:
        return
    try:
        from . import talent
    except Exception:
        return
    total = int(talent.research_point_of(role)) + int(n)
    try:
        if _world is not None:
            _world.merge_role_data(role.roleid, research_point=total)
    except Exception:
        (log.debug("写 research_point 失败", exc_info=True) if log.isEnabledFor(10) else None)
    try:
        session.send(talent.ID.SC_RESEARCH_POINT, researchpoint=total)
    except Exception:
        (log.debug("推 research_point 失败", exc_info=True) if log.isEnabledFor(10) else None)
    (log.info("role %s 强化天赋点 +%s -> %s", role.name, n, total) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_GUN_RESEARCH, "equip.CsGunResearch")
async def on_gun_research(session: Session, msg: dict) -> None:
    """点一次「强化」：扣强化点、进度 +1。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    gunid = int(msg.get("gunid") or 0)
    part = part_row(gunid)
    if part is None:
        (log.info("CsGunResearch: %s 不在 Part 表里（不可强化的枪种）", gunid) if log.isEnabledFor(20) else None)
        return

    progress = stackable.progress_of(role, gunid)
    cap = int(part.get("maxHolding") or 0)
    if cap <= 0 or progress >= cap:
        # 已经满了：把当前状态回一遍，客户端好把按钮置灰
        session.send(ID.SC_GUN_RESEARCH, gunid=gunid, progress=progress)
        return

    price = max(0, int(part.get("price") or 0))
    if price > 0 and not stackable.take_study_point(role, price, _world):
        (log.info("role %s 强化点不足（%s < %s）gun=%s", role.name,
                 stackable.study_point(role), price, gunid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_GUN_RESEARCH, gunid=gunid, progress=progress)
        push_study_point(session, role)
        return

    progress = stackable.set_progress(role, gunid, progress + 1, _world)
    (log.info("role %s 强化 %s -> %s/%s（-点 %s）", role.name, gunid,
             progress, cap, price) if log.isEnabledFor(20) else None)
    session.send(ID.SC_GUN_RESEARCH, gunid=gunid, progress=progress)
    push_study_point(session, role)
    # **小级强化不再给强化天赋点。**
    # 原来每点一次「强化」就 +1，玩家把 AK 从小级 1 一路点到 11，天赋页
    # 就显示 11 点，而实际上只改装进阶过 1 次。官方口径是「完成一次改装
    # （版本进阶）才给点」，统一在 on_transform 里结算。


@ROUTER.register(ID.CS_TRANSFORM, "equip.CsTransform")
async def on_transform(session: Session, msg: dict) -> None:
    """进度满 + 碎片够 → 升版本，换掉背包与装备里的 itemid。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    gunid = int(msg.get("gunid") or 0)
    newgunid = int(msg.get("newgunid") or 0)
    cur = part_row(gunid)
    nxt = part_row(newgunid)
    if cur is None or nxt is None:
        (log.info("CsTransform: %s / %s 不在 Part 表", gunid, newgunid) if log.isEnabledFor(20) else None)
        return
    if int(nxt.get("modelType") or 0) != int(cur.get("modelType") or 0):
        log.warning("CsTransform: %s(%s) -> %s(%s) 不是同一系列",
                    gunid, cur.get("modelType"), newgunid, nxt.get("modelType"))
        return
    if int(nxt.get("version") or 0) != int(cur.get("version") or 0) + 1:
        log.warning("CsTransform: 版本不连续 %s -> %s",
                    cur.get("version"), nxt.get("version"))
        return

    cap = int(cur.get("maxHolding") or 0)
    progress = stackable.progress_of(role, gunid)
    if cap > 0 and progress < cap:
        (log.info("role %s 强化进度没满（%s/%s），不能升版本", role.name,
                 progress, cap) if log.isEnabledFor(20) else None)
        return

    _card_need = 0
    if int(nxt.get("type") or 0) == 1:
        from . import equip as _eq
        _card_need = max(0, int(nxt.get("price") or 0))
        have_cards = int(_eq.legend_card_count(role))
        if have_cards < _card_need:
            (log.info("role %s 传奇改装卡不足：需要 %s 张，只有 %s 张",
                     role.name, _card_need, have_cards) if log.isEnabledFor(20) else None)
            _eq.send_legend_cards(session, role)
            return

    need = max(0, int(cur.get("parts") or 0))
    piece = int(cur.get("pieceId") or 0)
    if need > 0 and piece > 0:
        if not stackable.take_item(role, piece, need, _world):
            (log.info("role %s 碎片不足：需要 %s 个 %s，只有 %s", role.name, need,
                     piece, stackable.item_count(role, piece)) if log.isEnabledFor(20) else None)
            equip.push_stack_counts(session, role, [piece])
            return

    if not equip.replace_owned_item(role, gunid, newgunid, _world):
        # 没换成（比如背包里根本没有这把枪）—— 把碎片退回去
        if need > 0 and piece > 0:
            stackable.add_item(role, piece, need, _world)
        (log.info("role %s 升版本失败：背包里没有 %s", role.name, gunid) if log.isEnabledFor(20) else None)
        return

    stackable.set_progress(role, gunid, 0, _world)
    stackable.set_progress(role, newgunid, 0, _world)
    # 改装成功后才真正扣传奇改装卡（先扣再换的话，换失败就白扣了）
    if _card_need > 0:
        from . import equip as _eq
        try:
            left_cards = max(0, int(_eq.legend_card_count(role)) - _card_need)
            if _world is not None:
                _world.merge_role_data(role.roleid, legend_cards=left_cards)
            role.data = dict(role.data or {}, legend_cards=left_cards)
        except Exception:
            (log.debug("扣改装卡失败", exc_info=True) if log.isEnabledFor(10) else None)
        _eq.send_legend_cards(session, role)
        (log.info("role %s 改装 %s -> %s（-改装卡 %s）", role.name, gunid,
                 newgunid, _card_need) if log.isEnabledFor(20) else None)
    (log.info("role %s 升版本 %s -> %s（-碎片 %s×%s）", role.name, gunid,
             newgunid, need, piece) if log.isEnabledFor(20) else None)

    session.send(ID.SC_TRANSFORM, newgunid=newgunid)
    _push_package_all(session, role)
    # 完成一次改装（版本 +1）额外给 3 点
    _grant_talent_point(session, role, 3)
    # 传奇龙武器每升一级按档位发芯片（改 2 / 改36 3 / 改37 4 / 改38 5）。
    # ★ v50 修正：`nxt` 来自 **Part 表**，只有 `version`(0~4)，没有 `star`
    #   （star 在 Item 表里）。v49 用 `nxt.get("star")` 恒取到 0，于是每次
    #   只发 1 个芯片、改·38 也不发生命芯片 —— 实测「炎龙改满只回 10 血」
    #   （= 5 个 ×2）就是这么来的。改用 Part.version 判定。
    _ver = int(nxt.get("version") or 0)
    _mt = int(nxt.get("modelType") or 0)
    if _mt == _ANGRY_MODEL_TYPE:
        # 【v59】怒龙芯片改为「改·38 专属、上限 1 个」：
        #   改/改36/改37 不再发芯片，改·38 发 1 个。
        if _ver >= 4:
            _grant_angry_chip(session, role)
    else:
        _cnt = {1: 2, 2: 3, 3: 4, 4: 5}.get(_ver, 1)
        _grant_legend_chip(session, role, _mt, _cnt)
    # 「改·38」(version 4) 再额外给 2 个「生命+5」芯片（每把龙一次）
    if _ver >= 4:
        _grant_life_chip(session, role, _mt)
    if need > 0 and piece > 0:
        equip.push_stack_counts(session, role, [piece])
    # 装备界面也要刷新：已装配的方案里那把枪已经换 id 了
    try:
        from . import equipment
        session.send(equipment.ID.SC_EQUIP_GROUP,
                     equipgroup=equip.equip_group_payload(role))
    except Exception:
        (log.debug("升版本后刷新装备方案失败", exc_info=True) if log.isEnabledFor(10) else None)


# --------------------------------------------------------------------------
# 碎片
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_PARTS_HECHENG, "equip.CsPartsHecheng")
async def on_parts_hecheng(session: Session, msg: dict) -> None:
    """碎片合成整枪。partsid 是**碎片**的 id，不是枪 id。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    partsid = int(msg.get("partsid") or 0)
    fusion = fusion_for(partsid)
    if fusion is None:
        (log.info("CsPartsHecheng: %s 没有对应的合成配方", partsid) if log.isEnabledFor(20) else None)
        return
    need = max(1, int(fusion.get("number") or 1))
    gunid = int(fusion.get("itemId") or 0)
    have = stackable.item_count(role, partsid)
    if have < need:
        (log.info("role %s 碎片不足：%s/%s 片 %s", role.name, have, need, partsid) if log.isEnabledFor(20) else None)
        # 失败也要回一条：客户端「合成」按钮进的是等待态，不回包会一直转圈
        session.send(ID.SC_PARTS_HECHENG, partsid=partsid, number=have, gunid=0)
        equip.push_stack_counts(session, role, [partsid])
        return
    if not stackable.take_item(role, partsid, need, _world):
        return
    added = equip.grant_items(role, [gunid], _world)
    left = stackable.item_count(role, partsid)
    (log.info("role %s 碎片合成 %s（-片 %s×%s）-> %s%s", role.name, gunid,
             need, partsid, gunid, "" if added else "（已拥有）") if log.isEnabledFor(20) else None)
    session.send(ID.SC_PARTS_HECHENG, partsid=partsid, number=left, gunid=gunid)
    if added:
        session.send(ID.SC_PACKAGE_SYNC, synctype=1,
                     itemlist=equip.package_add_payload(added, role))
    equip.push_stack_counts(session, role, [partsid])
    _push_removed(session, role, [partsid])
    # 合成出来的枪可能要立刻能装备：把装备方案也补一份
    try:
        from . import equipment
        session.send(equipment.ID.SC_EQUIP_GROUP,
                     equipgroup=equip.equip_group_payload(role))
    except Exception:
        (log.debug("合成后刷新装备方案失败", exc_info=True) if log.isEnabledFor(10) else None)


def _push_removed(session: Session, role, ids) -> None:
    """数量归 0 的道具要发 ScPackageRemove(983042)，否则背包列表还挂着这一条，
    客户端显示「还有 1 片」而服务端是 0 —— 用户报的「最后一片卖不掉」。"""
    try:
        gone = [int(i) for i in ids if stackable.item_count(role, i) <= 0]
        if gone:
            session.send(983042, itemlist=gone)
    except Exception:
        (log.debug("推送背包移除失败", exc_info=True) if log.isEnabledFor(10) else None)


def _pairs(raw) -> List[List[int]]:
    """解码 CsExchangeParts.consumeparts：List<Pairs{first, second}>。"""
    if raw is None:
        return []
    if isinstance(raw, dict):
        raw = raw.get("_items") or raw.get("items") or []
    out: List[List[int]] = []
    for it in raw or []:
        if isinstance(it, dict):
            try:
                a, b = int(it.get("first") or 0), int(it.get("second") or 0)
            except (TypeError, ValueError):
                continue
        elif isinstance(it, (list, tuple)) and len(it) >= 2:
            try:
                a, b = int(it[0]), int(it[1])
            except (TypeError, ValueError):
                continue
        else:
            continue
        if a > 0 and b > 0:
            out.append([a, b])
    return out


@ROUTER.register(ID.CS_EXCHANGE_PARTS, "equip.CsExchangeParts")
async def on_exchange_parts(session: Session, msg: dict) -> None:
    """强化页「兑换碎片」：拿手里**其它碎片**当材料填进度。

    客户端 ``FusionWindow.OnConfirmChange`` 发的是
    ``CsExchangeParts(partsid=goal.partsId, partsnum=份数, consumeparts=[(材料 id, 个数)])``。
    原来服务端**一条协议都没注册**，所以点「确认兑换」完全没有反应 ——
    进度条会走，钻石也不扣，但什么都不会发生（用户报的「执行不了」）。

    规则（``Fusion`` 表）：``exchangeNum`` = 填满一格需要多少材料（15），
    ``exchangeGem`` = 每兑换一个碎片花多少钻石（10）。填满一格得 1 片，
    可以一次兑换多份（``partsnum``）。

    服务端自己复核：材料按实际持有量封顶、份数按材料总量封顶、钻石不够
    就直接拒绝，绝不信任客户端传来的数字。
    """
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return

    ERR_NODIAMOND, ERR_NOPARTS = 1, 2
    partsid = int(msg.get("partsid") or 0)
    want = int(msg.get("partsnum") or 0)
    picks = _pairs(msg.get("consumeparts"))

    fusion = fusion_for(partsid) if partsid else None
    if fusion is None:
        (log.info("CsExchangeParts: %s 没有兑换配方", partsid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_EXCHANGE_PARTS, res=ERR_NOPARTS)
        return

    per = max(1, int(fusion.get("exchangeNum") or 15))
    gem_per = max(0, int(fusion.get("exchangeGem") or 0))
    log.info("CsExchangeParts role=%s 目标碎片=%s 份数=%s 材料=%s（合计 %s，1 份要 %s 个）",
             role.name, partsid, want, picks, sum(n for _i, n in picks), per)
    if int(fusion.get("exchange") or 0) <= 0:
        # Fusion.exchange == 0 = 这把枪的碎片不允许用材料兑换（原版设定）
        (log.info("CsExchangeParts: %s 不开放兑换", partsid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_EXCHANGE_PARTS, res=ERR_NOPARTS)
        return

    # 1) 每种材料按**实际持有量**封顶
    cur = stackable.counts(role)
    take: Dict[int, int] = {}
    for iid, n in picks:
        # 【v10】不能用 counts 的裸值：老存档的碎片只写进 pkg_items、
        # item_counts 没有行，裸值是 0 -> 「选满 15 片点确认」被算成 0 片
        # -> res=2 -> 客户端弹「兑换失败」（用户报的那个）。
        # item_count() 缺行时会回落到 pkg_items（=1）。
        have = stackable.item_count(role, iid)
        (log.info("  材料 %s 客户端选 %s / 实际持有 %s", iid, n, have)
         if log.isEnabledFor(20) else None)
        n = min(int(n), have)
        if n > 0:
            take[iid] = take.get(iid, 0) + n
    total = sum(take.values())

    # 1b) 【v9】兜底：选的这批凑不满一格时，用**其它碎片**补上。
    #     客户端 `FusionWindow` 只按本地缓存的数量发请求，服务端账本
    #     常比它少（碎片进背包时只加了 pkg_items、没进 item_counts 的老存档），
    #     于是「选满 15 片点确认」在这里被算成 0 片 → 直接回 res=2 →
    #     客户端弹「兑换失败」。玩家手里的碎片是真的，不能因为账本对不上就拒绝。
    if total < per:
        skip = set(take) | {int(partsid)}
        # 玩家实际持有的碎片：pkg_items 里有的都算（老存档的 counts 里没有行）
        held: Dict[int, int] = {}
        for iid in ((role.data or {}).get('pkg_items') or ()):
            try:
                iid = int(iid)
            except (TypeError, ValueError):
                continue
            if iid in skip or not _is_piece(iid):
                continue
            cnt = stackable.item_count(role, iid)
            if cnt > 0:
                held[iid] = cnt
        others = sorted(held.items(), key=lambda kv: -kv[1])
        short = per - total
        for iid, cnt in others:
            if short <= 0:
                break
            use = min(cnt, short)
            take[iid] = take.get(iid, 0) + use
            total += use
            short -= use
            (log.info("  兜底补材料 %s ×%s（剩 %s 个）", iid, use, short)
             if log.isEnabledFor(20) else None)

    if total <= 0:
        (log.info("role %s 兑换碎片失败：没有可用材料（背包碎片 %s 种）",
                 role.name, len(cur)) if log.isEnabledFor(20) else None)
        session.send(ID.SC_EXCHANGE_PARTS, res=ERR_NOPARTS)
        return

    # 2) 份数：客户端点的份数和材料能支撑的份数取小
    n = want if want > 0 else total // per
    n = min(n, total // per)
    if n <= 0:
        (log.info("role %s 兑换碎片失败：材料 %s 个不足 %s 个（1 份）",
                 role.name, total, per) if log.isEnabledFor(20) else None)
        session.send(ID.SC_EXCHANGE_PARTS, res=ERR_NOPARTS)
        return

    cost = n * gem_per
    if cost > role.gold:
        (log.info("role %s 兑换碎片失败：钻石 %s < %s", role.name, role.gold, cost)
         if log.isEnabledFor(20) else None)
        session.send(ID.SC_EXCHANGE_PARTS, res=ERR_NODIAMOND)
        return

    # 3) 从材料里精确扣 need 个（按列表顺序，够用为止）
    need = n * per
    consume: Dict[int, int] = {}
    left = need
    for iid, cnt in take.items():
        if left <= 0:
            break
        use = min(cnt, left)
        consume[iid] = use
        left -= use
    if left > 0 or not stackable.take_items(role, consume, _world):
        session.send(ID.SC_EXCHANGE_PARTS, res=ERR_NOPARTS)
        return

    role.gold -= cost
    _world.update_role(role.roleid, gold=role.gold)
    stackable.add_item(role, partsid, n, _world)

    (log.info("role %s 兑换碎片 %s ×%s（-材料 %s 个，-%s 钻石）",
             role.name, partsid, n, need, cost) if log.isEnabledFor(20) else None)

    session.send(ID.SC_EXCHANGE_PARTS, res=0)
    session.send(983043, gold=role.gold, money=role.money, diamond=role.diamond)
    # 材料数量 + 目标碎片数量都要立刻刷，否则界面停在旧数字
    equip.push_stack_counts(session, role, sorted(set(list(consume) + [partsid])))
    _push_removed(session, role, sorted(set(list(consume) + [partsid])))


@ROUTER.register(ID.CS_SELL_PARTS, "equip.CsSellParts")
async def on_sell_parts(session: Session, msg: dict) -> None:
    """卖碎片换钻石。

    【v46】用户口径：
      * 手里有 N 片时最多只能卖 **N-1** 片（最后一片必须留着，不能卖光）；
      * 只有 1 片时不能卖；
      * 收益 **20 钻石/片**（原来是 200）。

    `ScSellParts.number` 的语义是**本次卖掉的片数**，不是剩余数 ——
    客户端 `SellPieceDialog.OnPieceSell` 里是 `pieceAmount -= num`。
    原来这里发的是剩余数，卖 1 片（8→7）弹窗会算成 8-7=1，直接显示
    「1/1」再也不能继续卖。现在发实际卖出的片数。
    """
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    partsid = int(msg.get("partsid") or 0)
    number = max(0, int(msg.get("number") or 0))
    if partsid <= 0 or number <= 0:
        return

    have = stackable.item_count(role, partsid)
    if have <= 0:
        session.send(ID.SC_SELL_PARTS, partsid=partsid, number=0)
        equip.push_stack_counts(session, role, [partsid])
        return

    # 【v58】用户口径：最后一片也要能卖掉（原来强留 1 片，导致「剩一片卖不掉、
    # 又不够 20 片合成」的两头堵）。这里不再保留。
    sold = min(number, have)
    if not stackable.take_item(role, partsid, sold, _world):
        (log.info("role %s 卖碎片失败：%s 不够 %s 个", role.name, partsid, sold) if log.isEnabledFor(20) else None)
        session.send(ID.SC_SELL_PARTS, partsid=partsid, number=0)
        equip.push_stack_counts(session, role, [partsid])
        return

    from ..config import CONFIG
    per = max(0, int(getattr(CONFIG, "parts_diamond_per_piece", 20) or 0))
    gain = per * sold
    if gain:
        # 卖碎片换的是**钻石**（蓝宝石 = account 的 gold 字段）。
        # 原来写成 role.diamond（那个字段存的是「荣誉/白宝石 bloodGem」），
        # 所以玩家看到「出售收益显示 50 荣誉、实际到账 1」且货币也对不上。
        role.gold += gain
        _world.update_role(role.roleid, gold=role.gold)
    left = stackable.item_count(role, partsid)
    (log.info("role %s 卖碎片 %s×%s -> +%s 钻石（剩 %s 片）",
             role.name, partsid, sold, gain, left) if log.isEnabledFor(20) else None)
    session.send(ID.SC_SELL_PARTS, partsid=partsid, number=sold)
    equip.push_stack_counts(session, role, [partsid])
    _push_removed(session, role, [partsid])
    if gain:
        session.send(983043, gold=role.gold, money=role.money,
                     diamond=role.diamond)


@ROUTER.register(ID.CS_SALE_STUDY_POINT, "equip.CsSaleStudyPoint")
async def on_sale_study_point(session: Session, msg: dict) -> None:
    """强化点换荣誉（客户端「强化点回收」）。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    saletype = int(msg.get("saletype") or 0)
    from ..config import CONFIG
    block = max(1, int(getattr(CONFIG, "study_point_sale_block", 1000) or 1000))
    rate = max(1, int(getattr(CONFIG, "study_point_sale_honor", 10) or 10))
    if not stackable.take_study_point(role, block, _world):
        session.send(ID.SC_SALE_STUDY_POINT, result=2, usedpoint=0, addhonor=0)
        return
    honor = max(1, block // 1000 * rate) if block >= 1000 else rate
    # 同样是荣誉，不是金币（与 on_sell_parts 保持同一口径）
    role.diamond += honor
    _world.update_role(role.roleid, diamond=role.diamond)
    (log.info("role %s 回收强化点 %s（type=%s）-> +%s 荣誉", role.name, block,
             saletype, honor) if log.isEnabledFor(20) else None)
    session.send(ID.SC_SALE_STUDY_POINT, result=0, usedpoint=block,
                 addhonor=honor)
    push_study_point(session, role)
    session.send(983043, gold=role.gold, money=role.money, diamond=role.diamond)
