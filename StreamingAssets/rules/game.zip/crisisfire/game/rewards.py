"""战斗奖励领取（PrizePanel）.

客户端 `PrizePanel` 有四个领取按钮，各发一条请求：

    onGetPercetiveReward -> new CsGetScoreReward()      无字段
    onGetRoomReward      -> new CsGetFightReward(1)     房间首胜
    onGetSingleReward    -> new CsGetFightReward(3)     单机首胜
    onGetRankReward      -> new CsGetFightReward(?)     排位首胜

按钮状态由两条 Info 消息驱动（**服务端必须主动推**）：

    // MissionBar.UpdateState(code)
    label.text = (code != 2) ? TextPool.Get(130) : TextPool.Get(131);
    SetEnabled(code == 1);
    //  code = 0 未达成 / 1 可领 / 2 已领

    private void onFightRewardInfo(ScFightRewardInfo core)
    {
        firstRoomBtn.UpdateState(core.roomtask);
        firstSingleBtn.UpdateState(core.robottask);
        firstRankBtn.UpdateState(core.rangetask);
    }
    private void onScorerewardInfo(ScScoreRewardInfo core)
    {
        getPercetiveReward.isEnabled = num >= 60 && core.rewardstatu == 0;
    }

`num >= 60` 对上 `HighscoreReward.percetage = 60` —— 最高分要达到 60% 才算达标。

配置表：

    TargetReward (6 行)   id, score, rewardGold, rewardEXP, rewardBloodGem
        3000/5000/7000/10000/15000/20000 分 -> 100~1000 金币 + 50~1000 经验 + 10~200 血钻
    HighscoreReward (1 行) id, percetage=60, gold=1000, bloodGem=1000
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.rewards")


class ID:
    SC_GET_FIGHT_REWARD = 1114139
    SC_FIGHT_REWARD_INFO = 1114140
    SC_GET_SCORE_REWARD = 1114142
    SC_SCORE_REWARD_INFO = 1114143
    CS_GET_FIGHT_REWARD = 1114138
    CS_GET_SCORE_REWARD = 1114141

    SC_PACKAGE_SYNC = 983041
    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117


# 任务状态（对齐 MissionBar.UpdateState）
TASK_LOCKED = 0        # 未达成
TASK_CLAIMABLE = 1     # 可领（按钮亮）
TASK_CLAIMED = 2       # 已领

# fighttype -> role.data 里的状态键。房间=1，单机=3（客户端只发这两个）。
FIGHT_TYPES = {
    1: "reward_room",
    3: "reward_single",
    2: "reward_robot",
    4: "reward_rank",
}

# 首胜奖励的数值。
# 配置里**没有**「首胜奖励」这张表（GameReward 是每局结算用的），所以这几个数
# 是服务端策略，要调改这里。
FIRST_WIN_REWARD = {
    1: {"gold": 500, "bloodgem": 50, "gem": 0},      # 房间首胜
    3: {"gold": 300, "bloodgem": 30, "gem": 0},      # 单机首胜
    2: {"gold": 300, "bloodgem": 30, "gem": 0},
    4: {"gold": 800, "bloodgem": 80, "gem": 0},      # 排位首胜
}


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


def _data(role) -> Dict[str, Any]:
    return dict(role.data or {})


def _int(d: Dict[str, Any], key: str, default: int = 0) -> int:
    try:
        return int(d.get(key) or default)
    except (TypeError, ValueError):
        return default


# --------------------------------------------------------------------------
# 分数（ScScoreRewardInfo 用）
# --------------------------------------------------------------------------
def scores_of(role) -> Dict[str, int]:
    """四个分数。robot/range 由 robot 模块维护，room/rank 由战斗结算维护。"""
    d = _data(role)
    return {
        "robotscore": _int(d, "robot_score"),
        "rangescore": _int(d, "range_score"),
        "rankscore": _int(d, "rank_score"),
        "roomscore": _int(d, "room_score"),
    }


def best_score(role) -> int:
    d = _data(role)
    return _int(d, "best_score")


def score_reward_state(role) -> int:
    """0 = 可领，1 = 已领。客户端判的是 `core.rewardstatu == 0`。"""
    return 1 if _int(_data(role), "score_reward_claimed") else 0


def push_fight_reward_info(session: Session, role) -> None:
    """ScFightRewardInfo —— 三个首胜按钮的状态。"""
    d = _data(role)
    session.send(ID.SC_FIGHT_REWARD_INFO,
                 roomtask=_int(d, FIGHT_TYPES[1], TASK_LOCKED),
                 robottask=_int(d, FIGHT_TYPES[3], TASK_LOCKED),
                 rangetask=_int(d, FIGHT_TYPES[4], TASK_LOCKED))


def push_score_reward_info(session: Session, role) -> None:
    """ScScoreRewardInfo —— 分数 + 是否已领。"""
    sc = scores_of(role)
    hr = gamedata.table("HighscoreReward")
    top = float(hr[0].get("percetage") or 60) if hr else 60.0
    session.send(ID.SC_SCORE_REWARD_INFO,
                 robotscore=sc["robotscore"], rangescore=sc["rangescore"],
                 rankscore=sc["rankscore"], roomscore=sc["roomscore"],
                 toprate=top, rewardstatu=score_reward_state(role))


def push_all(session: Session, role) -> None:
    push_fight_reward_info(session, role)
    push_score_reward_info(session, role)


# --------------------------------------------------------------------------
# 标记某类首胜「可领」
# --------------------------------------------------------------------------
def mark_claimable(role, fighttype: int) -> None:
    """打完一局就把它标成可领（如果还没领过）。"""
    key = FIGHT_TYPES.get(int(fighttype))
    if key is None or _world is None:
        return
    d = _data(role)
    if _int(d, key, TASK_LOCKED) == TASK_LOCKED:
        _world.merge_role_data(role.roleid, **{key: TASK_CLAIMABLE})


def record_score(role, kind: str, score: int) -> None:
    """记录一次分数（取历史最高）。kind: robot / range / rank / room。"""
    if _world is None:
        return
    d = _data(role)
    key = f"{kind}_score"
    if int(score) > _int(d, key):
        best = max(_int(d, "best_score"), int(score))
        _world.merge_role_data(role.roleid, **{key: int(score), "best_score": best})


# --------------------------------------------------------------------------
# 领取
# --------------------------------------------------------------------------
def _grant(role, gold: int, bloodgem: int, gem: int, exp: int = 0) -> bool:
    """发奖，返回是否真的发了东西。"""
    if _world is None:
        return False
    if gold or bloodgem or gem:
        from .wallet import change
        change(_world,role,coins=gold,gems=gem,honor=bloodgem)
    if exp:
        from . import leveling
        leveling.apply_exp(_world, role, int(exp))
    return bool(gold or bloodgem or gem or exp)


@ROUTER.register(ID.CS_GET_FIGHT_REWARD, "user.CsGetFightReward")
async def on_get_fight_reward(session: Session, msg: dict) -> None:
    """领首胜奖励。`fighttype` 决定是哪一种。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    fighttype = int(msg.get("fighttype") or 1)
    key = FIGHT_TYPES.get(fighttype)
    if key is None:
        (log.info("role %s 请求了未知的 fighttype=%s", role.name, fighttype) if log.isEnabledFor(20) else None)
        push_fight_reward_info(session, role)
        return
    d = _data(role)
    state = _int(d, key, TASK_LOCKED)
    if state != TASK_CLAIMABLE:
        # 没达成或已领过 —— 把状态同步回去（按钮会自己变灰）
        (log.info("role %s fighttype=%s 当前状态 %s，不可领", role.name,
                 fighttype, state) if log.isEnabledFor(20) else None)
        push_fight_reward_info(session, role)
        return

    r = FIRST_WIN_REWARD.get(fighttype, {"gold": 0, "bloodgem": 0, "gem": 0})
    _grant(role, r["gold"], r["bloodgem"], r["gem"])
    _world.merge_role_data(role.roleid, **{key: TASK_CLAIMED})
    (log.info("role %s 领首胜奖励 fighttype=%s -> %s", role.name, fighttype, r) if log.isEnabledFor(20) else None)

    session.send(ID.SC_GET_FIGHT_REWARD, fighttype=fighttype,
                 gold=int(r["gold"]), bloodgem=int(r["bloodgem"]),
                 gem=int(r["gem"]))
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    push_fight_reward_info(session, role)


def score_tier(role) -> Optional[Dict[str, Any]]:
    """当前分数能拿到的**最高一档** TargetReward。"""
    sc = scores_of(role)
    best = max(sc.values()) if sc else 0
    rows = sorted((r for r in gamedata.table("TargetReward")),
                  key=lambda r: int(r.get("score") or 0), reverse=True)
    for r in rows:
        try:
            if best >= int(r.get("score") or 0):
                return r
        except (TypeError, ValueError):
            continue
    return None


@ROUTER.register(ID.CS_GET_SCORE_REWARD, "user.CsGetScoreReward")
async def on_get_score_reward(session: Session, msg: dict) -> None:
    """领分数奖励（PrizePanel 的「百分比奖励」按钮）。

    客户端只在 `num >= 60 && rewardstatu == 0` 时让点 —— 60 是
    `HighscoreReward.percetage`。服务端照 TargetReward 的档位发。
    """
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    if score_reward_state(role) != 0:
        (log.info("role %s 分数奖励已领过", role.name) if log.isEnabledFor(20) else None)
        push_score_reward_info(session, role)
        return
    row = score_tier(role)
    if row is None:
        # 分数不够任何一档
        (log.info("role %s 分数不够领奖（%s）", role.name, scores_of(role)) if log.isEnabledFor(20) else None)
        push_score_reward_info(session, role)
        return

    gold = int(row.get("rewardGold") or 0)
    blood = int(row.get("rewardBloodGem") or 0)
    exp = int(row.get("rewardEXP") or 0)
    _grant(role, gold, blood, 0, exp)
    _world.merge_role_data(role.roleid, score_reward_claimed=1)
    (log.info("role %s 领分数奖励 档位=%s -> 金%s 钻%s 经验%s", role.name,
             row.get("id"), gold, blood, exp) if log.isEnabledFor(20) else None)

    session.send(ID.SC_GET_SCORE_REWARD, gold=gold, bloodgem=blood)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    from .handlers import _property_of
    session.send(ID.SC_USER_INFO, roleid=role.roleid,
                 property=_property_of(role))
    push_score_reward_info(session, role)
