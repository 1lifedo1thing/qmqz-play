"""Single-player 机器人关卡 and 靶场 results.

Unlike the online room, a robot level runs **entirely inside the client**
(`OfflineServer : FightServer` drives the round, the bots and the kills
locally).  The server only sees two things:

    on login      -> push ScRobotLevelStatus   which levels are unlocked
    after a match <- CsRobotLevelResult        report the result
                  -> ScRobotLevelReward        first-clear reward

Both matter.  `ScRobotLevelStatus.process()` sets `RobotLevelData.OpenID`,
which `RobotLevelWindow` uses to mark each level passed / current / locked:

    levelListDatas[i] = RobotLevelListData.toData(lvl, lvl.id < openid, lvl.id > openid)

and `QuickGameDialog` indexes `RobotConfigs.aiLevels[OpenID - 1]`, so leaving
OpenID at its default 0 is an index of -1.

The reward itself is configured per level in the client's AILevel table
(`rewardGold` / `rewardBloodGem` / `rewardGem` / `exp`), and the client shows
exactly one currency per level (RewardRobotDialog picks the first non-zero of
gold / honor / gem).  Currency names come from the Concept table:

    Concept 1 金币 -> ScRobotLevelReward.gold      -> Role.gold
    Concept 2 荣誉 -> ScRobotLevelReward.bloodgem  -> Role.money
    Concept 3 钻石 -> ScRobotLevelReward.gem       -> Role.diamond
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import leveling

log = logging.getLogger("crisisfire.robot")


class ID:
    SC_ROBOT_LEVEL_STATUS = 1114124
    CS_ROBOT_LEVEL_RESULT = 1114125
    SC_SCORE_CHANGE = 1114126
    CS_RANGE_RESULT = 1114127
    SC_ROBOT_LEVEL_REWARD = 1114129
    SC_RANGE_RESULT = 1114130

    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# progress, kept in Role.data
# --------------------------------------------------------------------------
DEFAULT_OPEN = 1


def _open_level(role) -> int:
    """当前可挑战的关卡号，**必须 clamp 在 AILevel 行数以内**。

    客户端 `QuickGameDialog.OnEnable` 是裸索引：
        RobotConfigs.Instance.aiLevels[RobotLevelData.OpenID - 1]
    而 OpenID 就是这里下发的 currentlevel。存档里的 `robot_open` 如果是
    旧版本写入的 21+（或者被改档），这个索引会越界 → IndexOutOfRange
    → 点机器人关卡直接闪退。所以下发端必须先钳住。
    """
    try:
        v = int((role.data or {}).get("robot_open", DEFAULT_OPEN))
    except (TypeError, ValueError):
        v = DEFAULT_OPEN
    return max(1, min(v, max_robot_level()))


def _range_progress(role):
    d = role.data or {}
    try:
        level = max(1, int(d.get("range_level", 1)))
    except (TypeError, ValueError):
        level = 1
    try:
        best = max(0, int(d.get("range_max_score", 0)))
    except (TypeError, ValueError):
        best = 0
    return level, best


def ai_level(levelid: int) -> Optional[Dict[str, Any]]:
    """AILevel rows are keyed by `id`, which is the robot level id."""
    for row in gamedata.table("AILevel"):
        if row.get("id") == levelid:
            return row
    return None


def max_robot_level() -> int:
    return max((int(r.get("id") or 0) for r in gamedata.table("AILevel")),
               default=1)


def level_status(role) -> Dict[str, int]:
    level, best = _range_progress(role)
    return {
        "currentlevel": _open_level(role),
        "rangelevel": level,
        "maxrangescore": best,
    }


def send_level_status(session: Session, role) -> None:
    session.send(ID.SC_ROBOT_LEVEL_STATUS, **level_status(role))


# --------------------------------------------------------------------------
# robot level result -> reward
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_ROBOT_LEVEL_RESULT, "user.CsRobotLevelResult")
async def on_robot_result(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        log.warning("CsRobotLevelResult with no role (session %s)", session)
        return

    level = int(msg.get("level") or 0)
    passed = int(msg.get("passed") or 0) == 1
    score = int(msg.get("score") or 0)
    (log.info("robot level %s result: passed=%s score=%s kills=%s deaths=%s "
             "headshot=%s time=%s", level, passed, score, msg.get("kill"),
             msg.get("death"), msg.get("headshot"), msg.get("battletime")) if log.isEnabledFor(20) else None)

    cfg = ai_level(level) or {}
    cleared = role.data.get("web_training_clears", range(1, _open_level(role)))
    first_clear = passed and bool(cfg) and level not in cleared

    if not passed or not cfg:
        # a loss grants nothing
        gold = honor = gem = exp = 0
    elif first_clear:
        gold = int(cfg.get("rewardGold") or 0)
        honor = int(cfg.get("rewardBloodGem") or 0)
        gem = int(cfg.get("rewardGem") or 0)
        exp = int(cfg.get("exp") or 0)
    else:
        # replaying a level that is already cleared: experience only, so the
        # one-off first-clear currency cannot be farmed
        gold = honor = gem = 0
        exp = int(cfg.get("exp") or 0) // 4

    from .wallet import change
    change(_world,role,coins=gold,gems=gem,honor=honor)
    old_rank, new_rank = leveling.apply_exp(_world, role, exp)

    if first_clear:
        _world.merge_role_data(role.roleid,
                               robot_open=max(_open_level(role), min(level + 1, max_robot_level())),
                               web_training_clears=sorted(set(cleared) | {level}))
        (log.info("role %s cleared robot level %s -> unlocked %s",
                 role.name, level, _open_level(role)) if log.isEnabledFor(20) else None)

    if cfg and int(msg.get("battletime") or 0) > 0:
        from . import tasks
        tasks.record(role, live_type=tasks.LIVE_ROBOT, session=session)
    session.send(ID.SC_ROBOT_LEVEL_REWARD, score=score, gold=gold,
                 bloodgem=honor, levelid=level, exp=exp, gem=gem)
    send_level_status(session, role)

    # currency counters and the exp bar in the lobby header
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    from .handlers import _property_of
    session.send(ID.SC_USER_INFO, roleid=role.roleid, property=_property_of(role))
    if new_rank > old_rank:
        (log.info("role %s unlocked: %s", role.name,
                 ", ".join(leveling.unlocked_features(new_rank))) if log.isEnabledFor(20) else None)


# --------------------------------------------------------------------------
# 靶场 (range / shooting gallery)
# --------------------------------------------------------------------------
RANGE_GOALS = [100, 300, 600, 1000, 1500, 2200, 3000, 4000, 5200, 6600]


def range_goal(level: int) -> int:
    if 1 <= level <= len(RANGE_GOALS):
        return RANGE_GOALS[level - 1]
    return RANGE_GOALS[-1] + (level - len(RANGE_GOALS)) * 1500


@ROUTER.register(ID.CS_RANGE_RESULT, "user.CsRangeResult")
async def on_range_result(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return

    score = int(msg.get("score") or 0)
    level, best = _range_progress(role)
    levelfrom = level

    # clear as many goals as the score reaches
    while score >= range_goal(level):
        level += 1

    if score > best:
        best = score

    exp = 0
    gold = 0
    honor = 0
    old_rank = new_rank = max(1, int(role.level or 1))
    if level > levelfrom:
        exp = 50 * (level - levelfrom)
        gold = 200 * (level - levelfrom)
        from .wallet import change
        change(_world,role,coins=gold)
        old_rank, new_rank = leveling.apply_exp(_world, role, exp)
        _world.merge_role_data(role.roleid, range_level=level,
                               range_max_score=best)

    (log.info("range result: score=%s level %s->%s best=%s (+%s exp, +%s gold)",
             score, levelfrom, level, best, exp, gold) if log.isEnabledFor(20) else None)

    if score > 0:
        from . import tasks
        tasks.record(role, live_type=tasks.LIVE_RANGE, session=session)
    session.send(ID.SC_RANGE_RESULT, score=score, nextgoal=range_goal(level),
                 levelfrom=levelfrom, levelto=level, exp=exp, gold=gold,
                 bloodgem=honor)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    from .handlers import _property_of
    session.send(ID.SC_USER_INFO, roleid=role.roleid, property=_property_of(role))