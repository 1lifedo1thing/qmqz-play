"""Reconstructed room BOT perception and patrol from UC's training client."""
from functools import lru_cache
import logging
import math
from random import Random
import time

from .. import gamedata

log = logging.getLogger("crisisfire.bots")


def enabled(battle):
    return getattr(getattr(battle, "room", None), "gamemode", 0) in (1, 2, 3, 4, 9)


def uses_perception(battle):
    return enabled(battle) or getattr(battle, "biochem", None) is not None


@lru_cache(maxsize=2)
def training(level=1):
    # AI.level 1 is the profile assigned to the beginner RobotDesc entries.
    return next(row for row in gamedata.table("AI") if row["level"] == level)


def spawn_facing(battle, fighter, side, index, quat):
    from . import battle as protocol, bots

    if not uses_perception(battle) or not bots.is_bot(fighter.roleid):
        return quat
    scene = gamedata.map_row(battle.room.mapid)["scene"]
    points = protocol._spawnpoints().get(scene, {})
    rotations = points.get("police_quat" if side == 1 else "terrist_quat") or []
    if quat is None and index < len(rotations):
        quat = protocol._vec4(*rotations[index])
    if quat:
        state = getattr(battle, "_bot_motion", None)
        if state is None:
            state = battle._bot_motion = {}
        state.setdefault(fighter.roleid, {})["bot_facing"] = 2 * math.atan2(quat["y"], quat["w"])
    return quat


def reach(battle, fighter, fallback):
    from . import damage

    _, weapon = damage.active_weapon(fighter)
    gun = damage._table("Gun").get(weapon)
    return min(training()["visionRange"], gun["maximumRange"]) if gun else fallback


def angle_error(here, there, yaw):
    angle = math.atan2(there[0] - here[0], there[2] - here[2])
    return abs((angle - yaw + math.pi) % math.tau - math.pi)


def aligned(fighter, target, distance, state):
    # RobotConsts.Sightbias governs the attack state after the target is seen.
    if distance < .1:
        return True
    degrees = min(30, .5 + 15 / distance)
    return angle_error(fighter.syncpos, target.syncpos, state["bot_facing"]) <= math.radians(degrees)


def note_shot(battle, shooter, hits):
    from . import damage

    if not uses_perception(battle):
        return
    _, weapon = damage.active_weapon(shooter)
    loud = enabled(battle) or weapon in damage._table("Gun")
    note_attack(battle, shooter, (hit.targetid for hit in hits), loud=loud)


def note_attack(battle, shooter, victims, *, loud=False):
    if not uses_perception(battle) or shooter is None or shooter.syncpos is None:
        return
    victims = frozenset(victims)
    if not loud and not victims:
        return
    now = time.monotonic()
    noises = getattr(battle, "_bot_shot_noises", None)
    if noises is None:
        noises = battle._bot_shot_noises = {}
    for roleid, (at, _, _, _) in list(noises.items()):
        if now - at > 3:
            del noises[roleid]
    noises[shooter.roleid] = (now, shooter.syncpos, victims, loud)


def visible(here, there, colliders, state, settings):
    from . import bots

    distance = math.dist(here, there)
    cone = math.radians(settings["viewAngle"] / 2)
    return (distance <= settings["visionRange"]
            and (distance < .1 or angle_error(here, there, state.get("bot_facing", 0.0)) <= cone)
            and bots._visible(colliders, here, there))


def heard_enemies(battle, roleid, here, enemies, now, hearing, after=-math.inf):
    for targetid, (at, origin, victims, loud) in getattr(battle, "_bot_shot_noises", {}).items():
        if targetid not in enemies or not 0 <= now - at <= .75 or at <= after:
            continue
        distance = math.dist(here, origin)
        hit = roleid in victims
        if hit or (loud and distance <= hearing):
            yield not hit, distance, targetid, at, origin


def seek(battle, fighter, colliders, state, now, rng, level=1):
    from . import damage

    here, roleid = fighter.syncpos, fighter.roleid
    enemies = {other.roleid: other for other in battle.fighters.values()
               if other.roleid != roleid and other.born and other.hp > 0 and other.syncpos is not None
               and not damage.same_team(battle, roleid, other.roleid)}
    nearest = sorted((math.dist(here, other.syncpos), other.roleid) for other in enemies.values())[:2]
    settings = training(level)
    contact = state.get("contact")
    # Preserve an already seen target while it remains visible, even if two
    # other enemies have since moved closer.
    if contact and contact[0] in enemies:
        other = enemies[contact[0]]
        nearest.insert(0, (math.dist(here, other.syncpos), other.roleid))
    for distance, targetid in nearest:
        target = enemies[targetid]
        there = target.syncpos
        if visible(here, there, colliders, state, settings):
            state["contact"] = (targetid, there, now + rng.uniform(1, 3))
            return target, distance, there

    # Native ImpactRobot calls SetTarget for an actual shot. Damage alerts
    # the victim directly; other BOTs hear it only inside AI.hearRange.
    heard = min(heard_enemies(battle, roleid, here, enemies, now, settings["hearRange"],
                             state.get("last_heard", -math.inf)), default=None)
    if heard:
        _, _, targetid, at, origin = heard
        state["last_heard"] = at
        state["contact"] = contact = (targetid, origin, now + rng.uniform(1, 3))
        if level != 1:
            (log.info("BIO-BOT-HEARD role=%s source=%s location=%s", roleid, targetid, origin) if log.isEnabledFor(20) else None)
    if contact and contact[0] in enemies and now < contact[2] and math.dist(here, contact[1]) > .5:
        return None, None, contact[1]
    state.pop("contact", None)
    return None, None, None


@lru_cache(maxsize=32)
def patrol_points(scene, nav):
    points = next((row["points"] for row in gamedata.table("RoomPatrol") if row["scene"] == scene), ())
    result = []
    for x, y, z, yaw in points:
        point = x, y, z
        located = nav.locate(point)
        if located is not None and math.dist(point, located[1]) <= 1.5:
            result.append((nav.component[located[0]], located[1], yaw))
    return result


def patrol(battle, fighter, nav, state, neighbours, now, rng):
    from . import bots

    here = fighter.syncpos
    if (marker := state.get("island")) is not None:
        point, yaw = marker
        if math.dist(here, point) > .55:
            return point
        state["last_island"] = point
        state.pop("island")
        state["scan_yaw"] = yaw
        settings = training()
        idle = settings["idleTime"] + rng.uniform(-settings["idleWave"], settings["idleWave"])
        state["idle_until"] = now + max(.2, idle)
    if now < state.get("idle_until", 0):
        return None
    state.pop("scan_yaw", None)
    start = nav.locate(here)
    if start is None:
        return None
    scene = gamedata.map_row(battle.room.mapid)["scene"]
    component = nav.component[start[0]]
    points = [(point, yaw) for group, point, yaw in patrol_points(scene, nav)
              if group == component and point != state.get("last_island") and math.dist(here, point) > 1.5]
    occupied = [pos for rid, pos in neighbours.items() if rid != fighter.roleid]
    if points:
        # Avoid starting several squad members toward the same marker.
        rng.shuffle(points)
        point, yaw = min(points[:8], key=lambda p: sum(math.dist(p[0], pos) < 3 for pos in occupied))
    else:
        point = bots._anchor(nav, here, rng.randrange(1 << 20), occupied=occupied)
        yaw = None
    if point is not None:
        state["island"] = (point, yaw)
    return point


def scan(battle, fighter, colliders, state, now, level=1):
    from . import bots

    rng = state.get("search_rng")
    if rng is None:
        rng = state["search_rng"] = Random(bots._bot_seed(battle) ^ (fighter.roleid * 2654435761))
    return seek(battle, fighter, colliders, state, now, rng, level)


def plan(battle, fighter, nav, colliders, state, neighbours, now, reach_limit, level=1):
    target, distance, known = scan(battle, fighter, colliders, state, now, level)
    if known is not None:
        state.pop("scan_yaw", None)
        return target, distance, None if target is not None and distance <= reach_limit else known
    return None, None, patrol(battle, fighter, nav, state, neighbours, now, state["search_rng"])
