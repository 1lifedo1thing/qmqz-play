"""建房时把房间填满 BOT 成员（重建实现）。

客户端 RoomWindow 的「开始」倒计时条件是 **IsFull**（playerlimits == 人数），
不是"够人"——房间不满员时房主点开始没有任何反应（run5 实测，与 config.py
生化门槛注释同源结论）。因此在创建房间时就按 CF_BOTS>0 预填 BOT 成员到满员；
battle.begin 对全部成员 add() 成 fighter，bots.install 会跳过已存在的 roleid。

BOT roleid 段沿用 bots.BOT_ID_BASE，在受限区间轮换并避开活动成员。
"""
from __future__ import annotations

import logging

from . import bots as _bots
from . import rooms as R
from .. import gamedata
from ..config import CONFIG

log = logging.getLogger("crisisfire.room_fill")

# Exact (mapId, gameMode, equiplimitid) from GameRule, SpecialRule and the scene tables.
PRACTICE_ROOMS = (
    (14, 10, 0), (15, 10, 0), (9, 10, 0), (17, 10, 0),
    (6, 1, 0), (18, 1, 0), (1, 1, 0), (7, 2, 0), (13, 2, 0), (2, 3, 0), (5, 3, 0),
    (1, 1, 1), (6, 1, 3), (2, 1, 2), (18, 1, 4), (10, 1, 5),
    # LobbyWindow filters this shared list by QuickGame.mode. Keep distinct
    # native rules for all non-ranked quick-mode families, including PVE.
    (28, 12, 0), (26, 12, 0), (22, 12, 0),
    (19, 4, 0), (7, 4, 0), (9, 4, 0), (13, 4, 0), (14, 4, 0),
    (14, 8, 0), (15, 8, 0), (9, 8, 0), (17, 8, 0),
)
LOBBY_LINES = 8
# Local reconstructed UI command carried by the existing Int32 flags field.
# It is consumed before room flags are stored or sent back to any client.
LOCAL_REFILL_FLAG = 1 << 30


def ensure_practice_rooms(manager, line: int) -> None:
    """Seed open rooms using real lobby members and native map/mode pairs."""
    if CONFIG.bots_per_room <= 0 or not 0 <= line < LOBBY_LINES:
        return
    occupied = {room.practice_slot for room in manager.by_line(line)}
    for index, (mapid, mode, equiplimitid) in enumerate(PRACTICE_ROOMS):
        if index in occupied:
            continue
        rule = gamedata.rule_for_map(mapid, mode)
        row = gamedata.map_row(mapid) or {}
        if not rule or rule.get('gameMode') != mode or row.get('status') not in (0, 1):
            continue
        if not gamedata.map_has_spawns(mapid):
            continue
        cap = int(rule.get('roomMinTeamer') or 8) if mode in (8, 10) else R._player_limits(rule)
        if cap < 2:
            continue
        room = R.Room(manager.next_id(), 0, int(rule['id']), mapid, mode, cap,
                      title='BOT练习', line=line, practice_slot=index,
                      equiplimitid=equiplimitid)
        fill(room, manager=manager)
        manager.rooms[room.roomid] = room


def note_bot_kick(room, roleid: int) -> None:
    """Hold the removed seat across refresh, settings, ready and next matches."""
    if roleid in room.members and _bots.is_bot(roleid):
        room.kicked_bot_ids.add(int(roleid))
        room.bot_vacancies += 1
        room.bot_roster_managed = True


def human_takes_vacancy(room) -> None:
    if room.bot_vacancies and len(room.members) < room.playerlimits:
        room.bot_vacancies -= 1


def fill(room, *, manager=None, explicit=False) -> int:
    """Fill active lobbies, reserving one open seat in an unclaimed practice room."""
    if room.started or int(getattr(CONFIG, "bots_per_room", 0) or 0) <= 0:
        return 0
    humans = [m for m in room.members.values() if not _bots.is_bot(m.roleid)]
    waiting = not humans and room.practice_slot >= 0
    if not humans and not waiting:return 0
    total = max(len(humans), int(room.playerlimits or 0))
    if int(room.gamemode) == 12:
        capacity = int((gamedata.rule(room.levelid) or {})['maxTeamer'])
        if len(humans) > capacity:
            raise ValueError('challenge humans exceed native capacity')
        total = max(len(humans), min(total, capacity))
    room.playerlimits = total
    room.bot_roster_managed = True
    if explicit:
        room.bot_vacancies = 0
    from . import pve
    challenge = pve.is_pve(room.gamemode)
    bots = sorted((m for m in room.members.values() if _bots.is_bot(m.roleid)),
                  key=lambda m: m.roleid)
    held = min(max(0, room.bot_vacancies), max(0, total - len(humans) - int(waiting)))
    free = max(0, total - len(humans) - int(waiting) - held)
    for member in bots[free:]:room.members.pop(member.roleid)
    bots = bots[:free]
    if humans and room.owner not in {m.roleid for m in humans}:
        room.owner = humans[0].roleid
        humans[0].invite = True
    # Keep IDs inside the documented BOT range even after 100+ room creations.
    # Reserve IDs across currently live rooms; never collide with real players
    # or the PVE monster range.
    if manager is None:
        from . import room_handlers
        manager = room_handlers.MANAGER
    used = {rid for r in manager.rooms.values() for rid in r.members}
    used.update(room.members)
    used.update(room.kicked_bot_ids)
    added = 0
    for i in range(free-len(bots)):
        roleid = None
        for offset in range(9999):
            candidate = _bots.BOT_ID_BASE+1+(room.roomid*100+i+offset)%9999
            if candidate not in used:
                roleid = candidate;used.add(candidate);break
        if roleid is None:raise RuntimeError('local BOT ID range exhausted')
        member = R.Member(roleid=roleid,
                          name=_bots.BOT_NAMES[(len(bots)) % len(_bots.BOT_NAMES)],
                          level=30, iconid=1, ready=True)
        room.members[roleid] = member;bots.append(member);added += 1
    counts = {side: sum(m.side == side for m in humans) for side in (1, 2)}
    for member in bots:
        side = 1 if challenge or counts[1] < total//2 else 2
        member.side = side;member.ready = True;counts[side] += 1
    if waiting:
        room.owner = bots[0].roleid
    if added:
        (log.info("room %s prefilled %d bot member(s) to full (%s slots)",
                 room.roomid, added, total) if log.isEnabledFor(20) else None)
    return added


def install() -> None:
    if int(getattr(CONFIG, "bots_per_room", 0) or 0) <= 0:
        return
    original_create = R.RoomManager.create
    if getattr(original_create, '_local_bot_fill', False):return

    def create(self, *a, **kw):
        room = original_create(self, *a, **kw)
        try:
            fill(room, manager=self)
        except Exception:
            log.exception("fill room failed")
        return room

    create._local_bot_fill = True
    R.RoomManager.create = create
    (log.info("room_fill installed (bots_per_room=%s)", CONFIG.bots_per_room) if log.isEnabledFor(20) else None)
