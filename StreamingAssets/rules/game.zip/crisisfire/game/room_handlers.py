"""Room lifecycle handlers (GS side) and the room-server handshake.

Wire flow, traced from the client:

    lobby -> BattleWindow
      CsShowLineStatus(1245207) -> ScLineInfo(1245208)
      CsRoomList(1245209)       -> ScRoomList(1245210)
      CsCreateRoom(1245185)     -> ScCreateRoomRes(1245186) + ScSyncRoomInfo(1245190)
      CsJoinRoom(1245187)       -> ScJoinRoomRes(1245188)   + ScSyncRoomInfo
      CsSetReadyState(1245194)  -> ScSyncRoomInfo broadcast
      CsStart(1245200)          -> ScStartRet(1245206) + ScLoginRoom(1245189)

    ScLoginRoom.process() -> RoomServer.SetLoginInfo(ip/port/token); when the
    battle scene finishes loading, ClientManager calls
    RoomServer.CreateConnection(10) on a SECOND TCP connection:

      CsPing(720899) x5 -> ScPing(720900)      (RTT probe)
      gclient.CsLogin(1441893) token/uin/roleid
      gclient.ScLoginRet(1441894) retcode=0

Note the room server uses the *gclient* CsLogin/ScLoginRet (1441893/1441894),
NOT the login-package pair (1179649/1179650).
"""
from __future__ import annotations

import asyncio
import itertools
import logging
import time
from dataclasses import dataclass
from typing import Dict, Optional

from .. import gamedata
from ..config import CONFIG
from ..net.server import ROUTER, Session
from . import rooms as R
from .world import World

log = logging.getLogger("crisisfire.room")


class ID:
    SC_LINE_INFO = 1245208
    CS_SHOW_LINE_STATUS = 1245207
    CS_ROOM_LIST = 1245209
    SC_ROOM_LIST = 1245210
    CS_CREATE_ROOM = 1245185
    SC_CREATE_ROOM_RES = 1245186
    CS_JOIN_ROOM = 1245187
    SC_JOIN_ROOM_RES = 1245188
    SC_LOGIN_ROOM = 1245189
    SC_SYNC_ROOM_INFO = 1245190
    SC_ADD_PLAYER = 1245191
    SC_REMOVE_PLAYER = 1245192
    SC_SYNC_PLAYER_FLAG = 1245193
    CS_SET_READY_STATE = 1245194
    # 踢人是一对消息，两个号不能混：
    #   1245204 CsKickout  roomid, kickoutid   客户端 -> 服务端（房主踢人）
    #   1245205 ScKickout  roomid              服务端 -> 客户端（通知被踢的人）
    # 原来只写了 CS_KICKOUT = 1245205（名字叫 Cs、值是 Sc 的号），于是
    # 路由注册在 1245205 上 —— 客户端发的是 1245204，**请求从来没被处理**。
    CS_KICKOUT = 1245204
    SC_KICKOUT = 1245205
    CS_CHANGE_SIDE = 1245199
    CS_START = 1245200
    SC_START_RET = 1245206
    CS_QUIT = 1245203
    CS_CHANGE_ROOM_INFO = 1245211
    SC_CHANGE_ROOM_INFO = 1245212
    CS_REPARE_LAST_EQUIPS = 1245216
    SC_REPARE_LAST_EQUIPS_RET = 1245217
    # 客户端会发、原来服务端静默丢弃的三条（见 tools/audit_handlers.py）：
    CS_ROOM_PASSWORD = 1245247       # 房主设/清房间密码（FightManager.EncryptRoom）
    CS_JOIN_FRIEND_ROOM = 1245233    # 「加入好友房间」——按好友 roleid 找房间
    CS_REPORT = 1245246              # 举报玩家

    # room server (gclient namespace)
    CS_PING = 720899
    SC_PING = 720900
    ROOM_CS_LOGIN = 1441893
    ROOM_SC_LOGIN_RET = 1441894


# ScStartRet.retcode
START_OK = 0
START_NOT_OWNER = 1
START_NOT_READY = 2

MANAGER = R.RoomManager()
_world: Optional[World] = None

# --------------------------------------------------------------------------
# 房间连接意外断开后的有界重连保留
# --------------------------------------------------------------------------
# 原生客户端没有「按秒」的重连窗口常量，能查到的只有行为：
#   * RoomServer.DoRejoin() 原样重发 CsLogin(原 token, uin, roleid)；
#   * ConnectionServer.CheckAlive(10f) 每秒探测，CreateConnection(10) 最多 10 次重试；
#   * 只有 com.gwebtop.gclient.ScFightEnd.process() 才置 willClosed 并主动 Close。
# 120 秒是**重建参数**（覆盖现场 54 秒宿主停顿 + 客户端最多 10 次重试），
# 不是官方服务端常数，也不用于延长 GS/房间 socket 的 idle timeout。
ROOM_RECONNECT_GRACE_SECONDS = 120.0


@dataclass
class _ReconnectGrace:
    roleid: int
    roomid: int
    old_sid: int
    epoch: int
    deadline: float
    handle: object = None


_GRACES: Dict[int, _ReconnectGrace] = {}
_GRACE_SEQ = itertools.count(1)

# (roomid, roleid) -> 该角色在当前 Battle 对象上真正成功接受过 room login。
# 不能用「Battle.add 已经把房间成员都加进 fighters」来判断重连：第一个真人
# begin() 时就会把第二个尚未连接的真人也 add 进去，但第二个真人的第一次
# room login 仍必须收到自己的 ScBornPrepare。
_ROOM_LOGINS: Dict[tuple, object] = {}


def bind_world(world: World) -> None:
    global _world
    _world = world


def _room_login_accepted(b, roleid: int) -> bool:
    if b is None:
        return False
    return _ROOM_LOGINS.get((int(b.room.roomid), int(roleid))) is b


def _mark_room_login(b, roleid: int) -> None:
    if b is not None:
        _ROOM_LOGINS[(int(b.room.roomid), int(roleid))] = b


def _forget_room_logins(roomid: int) -> None:
    rid = int(roomid or 0)
    for key in list(_ROOM_LOGINS):
        if key[0] == rid:
            _ROOM_LOGINS.pop(key, None)


def active_reconnect_grace(roleid: int) -> Optional[_ReconnectGrace]:
    return _GRACES.get(int(roleid or 0))


def cancel_reconnect_grace(roleid: int, reason: str = "") -> bool:
    g = _GRACES.pop(int(roleid or 0), None)
    if g is None:
        return False
    handle = g.handle
    if handle is not None:
        try:
            handle.cancel()
        except Exception:
            (log.debug("cancel reconnect grace failed role=%s", roleid,
                      exc_info=True) if log.isEnabledFor(10) else None)
    (log.info("room reconnect grace cleared: role=%s room=%s (%s)",
             g.roleid, g.roomid, reason or "cancelled") if log.isEnabledFor(20) else None)
    return True


def cancel_room_reconnect_graces(roomid: int, reason: str = "") -> None:
    for rid, g in list(_GRACES.items()):
        if g.roomid == int(roomid or 0):
            cancel_reconnect_grace(rid, reason)
    # 房间删除 / 整场结束 / 新一局时，上一场「已成功 room login」的标记
    # 一并失效；新 Battle 对象本来也会让旧标记自然失配。
    _forget_room_logins(roomid)


def retain_room_connection(session: Session) -> bool:
    """处理 room 连接的意外 close。

    返回 True 表示这次 close 已经被处理（保留角色/Battle，或迟到的旧连接
    无需再动新连接），调用方不得再走 `cleanup_role`。返回 False 时按原逻辑
    正常清理。
    """
    roleid = int(getattr(session, "roleid", 0) or 0)
    if not roleid or getattr(session, "kind", "") != "room":
        return False

    # 新连接已经接管这个角色：旧连接迟到的 close 只能退出，不能踢掉新人。
    if _world is not None:
        current = _world.session_of_role(roleid, "room")
        if current is not None and current is not session and not current.closed:
            (log.info("stale room close for role %s ignored; newer session %s kept",
                     roleid, current) if log.isEnabledFor(20) else None)
            return True

    room = MANAGER.room_of(roleid)
    if room is None:
        return False
    from . import battle as battle_mod
    b = battle_mod.BATTLES.get(room.roomid)
    if b is None or b.fight_over or not room.started:
        return False
    if roleid not in room.members or roleid not in b.fighters:
        return False
    gs = _world.session_of_role(roleid, "gs") if _world is not None else None
    if gs is None or gs.closed:
        return False

    existing = _GRACES.get(roleid)
    if existing is not None and existing.roomid == room.roomid:
        # 同一条旧连接重复 close：保留最初的截止时间，不无限续期。
        (log.info("room close repeated for role=%s room=%s; keep original grace",
                 roleid, room.roomid) if log.isEnabledFor(20) else None)
        return True

    cancel_reconnect_grace(roleid, "replaced")
    epoch = next(_GRACE_SEQ)
    entry = _ReconnectGrace(roleid=roleid, roomid=room.roomid,
                            old_sid=getattr(session, "sid", 0),
                            epoch=epoch,
                            deadline=time.time() + ROOM_RECONNECT_GRACE_SECONDS)
    _GRACES[roleid] = entry
    try:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.get_event_loop()
        entry.handle = loop.call_later(
            ROOM_RECONNECT_GRACE_SECONDS, _reconnect_grace_expired,
            roleid, room.roomid, epoch)
    except Exception:
        _GRACES.pop(roleid, None)
        log.warning("cannot arm reconnect grace for role=%s; normal cleanup",
                    roleid, exc_info=True)
        return False

    (log.info("room connection lost: holding role=%s room=%s for %.0fs "
             "reconnect grace (gs alive, match active, old_session=%s)",
             roleid, room.roomid, ROOM_RECONNECT_GRACE_SECONDS,
             getattr(session, "sid", 0)) if log.isEnabledFor(20) else None)
    return True


def _reconnect_grace_expired(roleid: int, roomid: int, epoch: int) -> None:
    g = _GRACES.get(roleid)
    if g is None or g.roomid != roomid or g.epoch != epoch:
        return
    _GRACES.pop(roleid, None)

    if _world is not None:
        live = _world.session_of_role(roleid, "room")
        if live is not None and not live.closed:
            return

    room = MANAGER.room_of(roleid)
    if room is None or room.roomid != roomid:
        return
    from . import battle as battle_mod
    b = battle_mod.BATTLES.get(room.roomid)
    if b is None or b.fight_over or not room.started:
        (log.info("reconnect grace ended for role=%s room=%s: match no longer active",
                 roleid, room.roomid) if log.isEnabledFor(20) else None)
        return
    if roleid not in room.members:
        return

    (log.info("reconnect grace expired: role=%s room=%s -> normal cleanup",
             roleid, room.roomid) if log.isEnabledFor(20) else None)
    try:
        cleanup_role(roleid)
    except Exception:
        log.exception("room cleanup after reconnect timeout failed role=%s",
                      roleid)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _member_of(session: Session) -> Optional[R.Member]:
    if session.roleid is None:
        return None
    role = _world.role(session.roleid) if _world else None
    if role is None:
        return None
    from . import equip
    return R.Member(roleid=role.roleid, name=role.name, level=role.level,
                    iconid=role.iconid, subjoins=equip.subjoins_of(role))


def _kind_for(type_id: int) -> str:
    """这条消息该走哪条连接.

    打战斗时客户端同时挂着两条连接，而消息归属取决于协议命名空间：

        com.gwebtop.gclient.*  (1441xxx)  -> 房间服（RoomServer）
        com.gwebtop.fight.*    (1245xxx)  -> 大厅服（FightManager）
        其余                              -> 大厅服

    不区分的话，房间窗口的消息会发到战斗连接上（或反过来）—— 客户端收得到
    TCP 包，但那条连接上的 manager 不认识这个协议号，表现就是「什么都没发生」。
    """
    from .. import proto
    name = proto.name_for_id(int(type_id)) or ""
    return "room" if name.startswith("com.gwebtop.gclient.") else "gs"


def _sessions_of(room: R.Room, kind: str = ""):
    """房间里每个成员的一条连接。

    **不能只信 `world._online`。** 打战斗时房间服连接会覆盖 `_online`，
    战斗结束那条连接 detach 之后，如果 `_online` 里没恢复成大厅连接，
    这里就找不到人 —— 下一局开局的 `ScLoginRoom` 直接发丢，客户端永远
    连不上房间服（实测：三人开局只有一个人进了战斗，另外两个卡在房间界面，
    20 秒后被服务端「force-spawning」硬塞进战场、还一件装备都没有）。

    所以：先按 `kind` 精确找，找不到就退回到这个角色**任意一条活着的连接**。
    """
    if _world is None:
        return
    for roleid in list(room.members):
        s = None
        if kind:
            s = _world.session_of_role(roleid, kind)
        if s is None or s.closed:
            alive = _world.sessions_of_role(roleid)
            s = alive[0] if alive else None
        if s is not None and not s.closed:
            yield s


def _broadcast(room: R.Room, type_id: int, **fields) -> None:
    for s in _sessions_of(room, _kind_for(type_id)):
        s.send(type_id, **fields)


def _send_room_info(session: Session, room: R.Room) -> None:
    if session is None or session.closed:
        return
    # `roomid` 是 1.9 新增的尾字段：1.9 的 unmarshal 最后一定会读一个 int，
    # 少发就抛 MarshalException，而客户端的 ConnectionObject.TryProcess 用
    # `catch (Exception) {}` 把它**静默吞掉** —— process() 不执行，房间界面永远
    # 打不开（1.7.1 不读这个字段，多发的 4 字节会被帧长跳过，所以两边都能用）。
    session.send(ID.SC_SYNC_ROOM_INFO,
                 roominfo=room.roominfo(), owner=room.owner,
                 players=room.player_map(), roomid=room.roomid)
    from . import pve_support
    pve_support.sync_buffs(session, room)


def _sync_room(room: R.Room) -> None:
    for session in _sessions_of(room, _kind_for(ID.SC_SYNC_ROOM_INFO)):
        _send_room_info(session, room)


def _sync_room_to(room: R.Room, session: Session) -> None:
    """重连成功后只给这一条连接重建房间成员表快照。

    客户端 `FightManager.Response(ScSyncRoomInfo)` 只做
    `CurrentRoom.SetRoomInfo`（清空成员表 -> 重新 AddPlayer -> SynRoomInfo），
    不碰 DataPool / 出生 / HP / 装备 / 感染状态，所以可以安全用于 rejoin。
    """
    _send_room_info(session, room)


def _line_counts() -> list:
    """Room count per line. The client indexes this by line id."""
    from . import room_fill
    counts = [0] * room_fill.LOBBY_LINES
    for line in range(len(counts)):
        room_fill.ensure_practice_rooms(MANAGER, line)
    for room in MANAGER.rooms.values():
        if 0 <= room.line < len(counts):
            counts[room.line] += 1
    return counts


# --------------------------------------------------------------------------
# room list
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_SHOW_LINE_STATUS, "CsShowLineStatus")
async def on_show_line(session: Session, msg: dict) -> None:
    session.send(ID.SC_LINE_INFO, lineroomcount=_line_counts())


@ROUTER.register(ID.CS_ROOM_LIST, "CsRoomList")
async def on_room_list(session: Session, msg: dict) -> None:
    line = int(msg.get("lineidx") or 0)
    from . import room_fill
    room_fill.ensure_practice_rooms(MANAGER, line)
    rows = [r.roomstatus() for r in MANAGER.by_line(line)]
    (log.info("room list: line=%s -> %d room(s)  %s", line, len(rows),
             session) if log.isEnabledFor(20) else None)
    session.send(ID.SC_ROOM_LIST, lineidx=line, roomstatus=rows)


# --------------------------------------------------------------------------
# create / join
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_CREATE_ROOM, "CsCreateRoom")
async def on_create_room(session: Session, msg: dict) -> None:
    line = int(msg.get("line") or 0)
    member = _member_of(session)
    if member is None:
        log.warning("CsCreateRoom from a session with no role: %s", session)
        return
    old = MANAGER.room_of(member.roleid)
    if old is not None:
        MANAGER.leave(old.roomid, member.roleid)

    room = MANAGER.create(member, line=line)
    session.send(ID.SC_CREATE_ROOM_RES, roomid=room.roomid)
    _sync_room(room)


def _join_room(session: Session, room: R.Room, password: str) -> int:
    """把 session 的角色放进 room，返回 ScJoinRoomRes.retcode。

    CsJoinRoom（点房间列表）和 CsJoinFriendRoom（加入好友房间）走的是同一条
    加入逻辑，只是「房间从哪来」不同 —— 抽出来避免两份规则漂移。
    """
    if room.locked and password != room.password:
        return R.JOIN_PASSWORD
    if room.started:
        return R.JOIN_STARTED
    member = _member_of(session)
    if member is None:
        return R.JOIN_OTHER
    if member.roleid in room.members:
        return R.JOIN_OK
    if room.is_full():
        from . import bots
        replaceable = next((rid for rid in reversed(room.members) if bots.is_bot(rid)), None)
        if replaceable is None:return R.JOIN_FULL
        room.members.pop(replaceable)
        _broadcast(room, ID.SC_REMOVE_PLAYER, roleid=replaceable)

    old = MANAGER.room_of(member.roleid)
    if old is not None and old.roomid != room.roomid:
        MANAGER.leave(old.roomid, member.roleid)
        _broadcast(old, ID.SC_REMOVE_PLAYER, roleid=member.roleid)
        if MANAGER.get(old.roomid) is not None:
            _sync_room(old)

    # balance sides like the client's own room window does.
    # PVE（挑战模式）例外：所有玩家都必须在 side=1，否则第二个人会被
    # 分到 terrist，出生点和怪物同一侧，客户端视野/伤害判定都会怪。
    from . import room_fill
    room_fill.human_takes_vacancy(room)
    assign_side(room, member)
    room.members[member.roleid] = member
    if room.practice_slot >= 0:
        room.practice_slot = -1
        room.owner = member.roleid
        member.invite = True
    (log.info("ROOM-JOIN room=%s map=%s mode=%s rule=%s equip=%s players=%s",
             room.roomid, room.mapid, room.gamemode, room.levelid, room.equiplimitid, len(room.members)) if log.isEnabledFor(20) else None)
    return R.JOIN_OK


def assign_side(room, member) -> None:
    """给进房的人分配 side：普通模式平衡两边，PVE 一律 side=1。"""
    from . import pve as _pve
    if _pve.is_pve(getattr(room, "gamemode", 0)):
        member.side = 1
        return
    police = sum(1 for m in room.members.values() if m.side == 1)
    terrist = len(room.members) - police
    member.side = 1 if police <= terrist else 2


def _after_join(session: Session, room: R.Room) -> None:
    """ScJoinRoomRes(retcode=0) 之后的成员广播。"""
    member = room.members.get(session.roleid)
    if member is not None:
        _broadcast(room, ID.SC_ADD_PLAYER, playerinfo=member.to_playerinfo(),
                   roleid=member.roleid)
    from . import room_fill
    room_fill.fill(room)
    _sync_room(room)


@ROUTER.register(ID.CS_JOIN_ROOM, "CsJoinRoom")
async def on_join_room(session: Session, msg: dict) -> None:
    roomid = int(msg.get("roomid") or 0)
    password = msg.get("password") or ""
    room = MANAGER.get(roomid)

    if room is None:
        session.send(ID.SC_JOIN_ROOM_RES, roomid=roomid, retcode=R.JOIN_NO_ROOM)
        return
    ret = _join_room(session, room, password)
    session.send(ID.SC_JOIN_ROOM_RES, roomid=roomid, retcode=ret)
    if ret == R.JOIN_OK:
        _after_join(session, room)


@ROUTER.register(ID.CS_JOIN_FRIEND_ROOM, "fight.CsJoinFriendRoom")
async def on_join_friend_room(session: Session, msg: dict) -> None:
    """「加入好友房间」：CsJoinFriendRoom(roleid, password)。

    客户端（FightManager.JoinRoomByRoleId / JoinFriendRoomPassword）只发好友的
    **roleid**，房间号由服务端反查。原来没有 handler，点了好友列表里的
    「加入房间」服务端毫无反应（客户端在 `SetTryInfo(trying: true, roleid)`
    之后一直等 ScJoinRoomRes）。
    """
    friendid = int(msg.get("friendid") or msg.get("roleid") or 0)
    password = msg.get("password") or ""
    room = MANAGER.room_of(friendid) if friendid else None
    if room is None:
        (log.info("CsJoinFriendRoom: 好友 %s 不在任何房间 (%s)", friendid, session) if log.isEnabledFor(20) else None)
        session.send(ID.SC_JOIN_ROOM_RES, roomid=0, retcode=R.JOIN_NO_ROOM)
        return
    ret = _join_room(session, room, password)
    session.send(ID.SC_JOIN_ROOM_RES, roomid=room.roomid, retcode=ret)
    if ret == R.JOIN_OK:
        _after_join(session, room)


# --------------------------------------------------------------------------
# in-room state
# --------------------------------------------------------------------------
def _refresh_member_subjoins(room: R.Room) -> None:
    """Re-read decorations for every member that has a real role row.

    A Member is a snapshot; one created before a decoration change would carry
    the old PlayerInfo map into the match.  Bots have no role row and keep
    their current value.  ready / side / owner are deliberately untouched.
    """
    if _world is None:
        return
    from . import equip
    for roleid, member in room.members.items():
        role = _world.role(roleid)
        if role is not None:
            member.subjoins = equip.subjoins_of(role)


async def _start_battle(room: R.Room) -> None:
    """Hand every member the room-server address and open the battle.

    The client does NOT send CsStart -- there is no call site for it anywhere in
    the assembly, only the class and its codec registration.  The owner's 开始
    button ends up in RoomWindow.OnReady, which requires everyone else to be
    ready and then calls Ready(true), i.e. CsSetReadyState.  So "the owner
    readied up" IS the start signal.
    """
    if room.started:return
    rule = gamedata.rule(room.levelid)
    if not rule or (rule["mapId"], rule["gameMode"]) != (room.mapid, room.gamemode):
        log.error("ROOM-START-REJECT room=%s map=%s mode=%s rule=%s",
                  room.roomid, room.mapid, room.gamemode, room.levelid)
        _sync_room(room)
        return
    from . import room_fill, battle
    # 【v47】开局任何一步异常都不许把「进战斗」这一步吞掉：以前 `fill()` /
    # `_refresh_member_subjoins()` 抛一次，下面的 ScLoginRoom 就发不出去，
    # 客户端表现是加载界面卡在 90%、BGM 还在响。现在每一步各自兜底。
    for _stage, _fn in (
            ("fill", lambda: room_fill.fill(room)),
            ("subjoins", lambda: _refresh_member_subjoins(room)),
            ("reconnect", lambda: cancel_room_reconnect_graces(
                room.roomid, "new battle")),
            ("drop", lambda: battle.drop(room.roomid))):
        try:
            _fn()
        except Exception:
            log.exception("ROOM-START %s failed room=%s", _stage, room.roomid)
    room.started = True
    room.new_token()

    port = CONFIG.room_port
    # `ScLoginRoom` 是 com.gwebtop.fight.*（1245xxx）—— 走大厅服那条连接。
    # 这里必须显式传 "gs"：不带 kind 的话依赖 `_online`，而战斗结束房间连接
    # detach 后 `_online` 可能不指向大厅连接，开局包会静默丢掉。
    for s in _sessions_of(room, "gs"):
        # 每个客户端告诉它自己连进来的那个地址（--advertise auto）：
        # 局域网玩家收到 192.168.x.x，皎月连玩家收到 10.x，互不影响。
        host = CONFIG.advertised_host(getattr(s, "local", ""))
        s.send(ID.SC_LOGIN_ROOM, roomid=room.roomid, ip=host, port=port,
               token=room.token, levelid=room.levelid)
    (log.info("ROOM-START room=%s map=%s mode=%s rule=%s equip=%s players=%s",
             room.roomid, room.mapid, room.gamemode, room.levelid, room.equiplimitid, len(room.members)) if log.isEnabledFor(20) else None)
    _sync_room(room)


def _everyone_ready(room: R.Room) -> bool:
    """Mirror of CurrentRoom.IsReadyExcept(owner): everyone but the owner."""
    return all(m.ready for rid, m in room.members.items() if rid != room.owner)


@ROUTER.register(ID.CS_SET_READY_STATE, "CsSetReadyState")
async def on_ready(session: Session, msg: dict) -> None:
    """准备 / 取消准备 —— and, for the owner, 开始战斗.

    The client tracks this in `PlayerInfo.flags` bit 0 and only updates it from
    `ScSyncPlayerFlag`:

        // FightManager.Response(ScSyncPlayerFlag)
        CurrentRoom.instance.SynPlayerFlag(playerFlag);
        onRoomInfoChanged?.Invoke();

        // CurrentRoom
        public bool isReady(int roleid) => (player.flags & 5) != 0;

    Broadcasting only `ScSyncRoomInfo` (as this used to) left `flags` at 0, so
    the 准备按钮 looked dead.  Send the flag message as well -- that is what the
    room UI reacts to.
    """
    room = MANAGER.room_of(session.roleid)
    if room is None:
        return
    member = room.members.get(session.roleid)
    if member is None:
        return
    member.ready = bool(msg.get("ready"))
    from . import room_fill
    room_fill.fill(room)
    (log.info("role %s ready=%s in room %s", member.roleid, member.ready,
             room.roomid) if log.isEnabledFor(20) else None)
    _broadcast(room, ID.SC_SYNC_PLAYER_FLAG, roleid=member.roleid,
               flags=member.flags(), side=member.side)
    _sync_room(room)

    # 房主准备 = 开始（见 _start_battle 的说明）
    if member.ready and session.roleid == room.owner and not room.started:
        if _everyone_ready(room):
            await _start_battle(room)
        else:
            waiting = [m.name for rid, m in room.members.items()
                       if rid != room.owner and not m.ready]
            (log.info("room %s not started: 还有人没准备 %s", room.roomid, waiting) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_CHANGE_SIDE, "CsChangeSide")
async def on_change_side(session: Session, msg: dict) -> None:
    room = MANAGER.room_of(session.roleid)
    if room is None:
        return
    member = room.members.get(session.roleid)
    if member is None:
        return
    side = int(msg.get("side") or 1)
    from . import pve as _pve
    if _pve.is_pve(room.gamemode):
        side = 1
    member.side = side
    from . import room_fill
    room_fill.fill(room)
    (log.info("role %s switched to side %s in room %s", member.roleid,
             member.side, room.roomid) if log.isEnabledFor(20) else None)
    # changing sides also goes through ScSyncPlayerFlag -- SynPlayerFlag moves
    # the entry between the police and terrist lists
    _broadcast(room, ID.SC_SYNC_PLAYER_FLAG, roleid=member.roleid,
               flags=member.flags(), side=member.side)
    _broadcast(room, ID.SC_ADD_PLAYER, playerinfo=member.to_playerinfo(),
               roleid=member.roleid)
    _sync_room(room)


def _resolve_room_rule(mapid: int, gamemode: int):
    if gamemode in (11, 13, 14):
        return None  # Dedicated 1.9 modes need their own local rules.
    row = gamedata.map_row(mapid)
    if not row or row.get("status") not in (0, 1) or not gamedata.map_has_spawns(mapid):
        return None
    rule = gamedata.rule_for_map(mapid, gamemode)
    return rule if rule and rule["gameMode"] == gamemode else None


@ROUTER.register(ID.CS_CHANGE_ROOM_INFO, "CsChangeRoomInfo")
async def on_change_room_info(session: Session, msg: dict) -> None:
    """Apply the native map/mode/equipment selection as a single room update."""
    room = MANAGER.room_of(session.roleid)
    if (room is None or room.owner != session.roleid or room.started
            or int(msg.get("roomid") or room.roomid) != room.roomid):
        return
    from . import special_modes
    info = msg.get("roominfo") or {}
    from . import room_fill
    explicit_refill = bool(int(info.get('flags') or 0) & room_fill.LOCAL_REFILL_FLAG)
    if explicit_refill and room.gamemode != 12:
        session.send(ID.SC_CHANGE_ROOM_INFO, roominfo=room.roominfo())
        return
    if explicit_refill:
        current = room.roominfo()
        if any(int(info.get(key, current[key])) != int(current[key])
               for key in ('levelid', 'mapid', 'gamemode', 'equiplimitid', 'playerlimits')):
            session.send(ID.SC_CHANGE_ROOM_INFO, roominfo=current)
            return
    mapid = int(info.get("mapid") or room.mapid)
    mode = int(info.get("gamemode") or room.gamemode)
    limit = int(info.get("equiplimitid", room.equiplimitid))
    rule = gamedata.rule(room.levelid) if (mapid, mode) == (room.mapid, room.gamemode) else None
    if not rule or (rule["mapId"], rule["gameMode"]) != (mapid, mode):
        rule = _resolve_room_rule(mapid, mode)
    if rule is None or (limit and (mode != 1 or special_modes.rule(limit) is None)):
        log.warning("ROOM-CHANGE-REJECT room=%s map=%s mode=%s equip=%s",
                    room.roomid, mapid, mode, limit)
        session.send(ID.SC_CHANGE_ROOM_INFO, roominfo=room.roominfo())
        return

    if mode != room.gamemode:
        capacity = R._player_limits(rule)
        if mode in (8, 10):
            capacity = max(capacity, len(room.members))
    else:
        capacity = int(info.get("playerlimits") or room.playerlimits)
    # Room settings can resize the BOT roster, never strand real members.
    from . import bots, room_fill
    humans = [member for member in room.members.values() if not bots.is_bot(member.roleid)]
    minimum = len(humans)
    if mode not in (4, 8, 10, 12):
        minimum = max(sum(member.side == side for member in humans) * 2 for side in (1, 2))
    if mode == 12 and len(humans) > int(rule["maxTeamer"]):
        session.send(ID.SC_CHANGE_ROOM_INFO, roominfo=room.roominfo())
        return
    maximum = int(rule["maxTeamer"]) if mode == 12 else 8
    room.playerlimits = max(minimum, min(capacity, maximum))
    if mode == 12:
        for member in humans:
            member.side = 1
    if room.gamemode == 12 and mode != 12:
        from . import pve_support
        pve_support.clear_buffs(room)
    room.levelid, room.mapid, room.gamemode, room.equiplimitid = int(rule["id"]), mapid, mode, limit
    if info.get("title"):
        room.title = str(info["title"])
    if "flags" in info:
        _allowed = R.FLAG_JOINABLE | R.FLAG_AUTOAIM
        # 【v49】排位/联赛不允许任何路径打开辅助瞄准（包括客户端改房请求）。
        if getattr(room, "local_rank_match", False):
            _allowed &= ~R.FLAG_AUTOAIM
        room.flags = int(info["flags"] or 0) & _allowed
    (log.info("ROOM-SETTINGS room=%s map=%s mode=%s rule=%s equip=%s",
             room.roomid, room.mapid, room.gamemode, room.levelid, room.equiplimitid) if log.isEnabledFor(20) else None)
    room_fill.fill(room, explicit=explicit_refill)
    _broadcast(room, ID.SC_CHANGE_ROOM_INFO, roominfo=room.roominfo())
    _sync_room(room)


@ROUTER.register(ID.CS_ROOM_PASSWORD, "fight.CsRoomPassword")
async def on_room_password(session: Session, msg: dict) -> None:
    """房主设/清房间密码（InputModal -> FightManager.EncryptRoom）。

    `CsRoomPassword(roomid, password)`；空字符串 = 取消密码。客户端不等待
    专用回包 —— 它靠广播的 `ScChangeRoomInfo` 刷新，房间列表那边靠
    `RoomInfo.flags & 16`（`RoomItemData.locked`）显示锁。原来没有 handler，
    设了密码也等于没设（房间列表不显示锁、进人也不校验）。
    """
    room = MANAGER.room_of(session.roleid)
    if room is None or room.owner != session.roleid:
        return
    roomid = int(msg.get("roomid") or room.roomid)
    if roomid != room.roomid:
        return
    password = str(msg.get("password") or "")
    room.password = password
    (log.info("room %s 密码已%s（%s）", room.roomid,
             "设置" if password else "清除", session) if log.isEnabledFor(20) else None)
    _broadcast(room, ID.SC_CHANGE_ROOM_INFO, roominfo=room.roominfo())
    _sync_room(room)


@ROUTER.register(ID.CS_REPORT, "fight.CsReport")
async def on_report(session: Session, msg: dict) -> None:
    """举报玩家：只落日志（客户端发出后不等回包）。"""
    (log.info("收到举报：%s 举报 roleid=%s room=%s reason=%s ext=%r",
             session, msg.get("criminalid"), msg.get("roomid"),
             msg.get("reason"), msg.get("extinfo")) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_REPARE_LAST_EQUIPS, "CsRepareLastEquips")
async def on_repare_equips(session: Session, msg: dict) -> None:
    # nothing to restore yet; ack so the client's UI unblocks
    session.send(ID.SC_REPARE_LAST_EQUIPS_RET, retcode=0)


@ROUTER.register(ID.CS_QUIT, "com.gwebtop.fight.CsQuit")
async def on_quit(session: Session, msg: dict) -> None:
    roomid = int(msg.get("roomid") or 0)
    room = MANAGER.get(roomid) or MANAGER.room_of(session.roleid)
    if room is None:
        cancel_reconnect_grace(session.roleid, "CsQuit")
        return
    roleid = session.roleid
    # CsQuit 是玩家明确退出：绝不能进入断线保留。
    cancel_reconnect_grace(roleid, "CsQuit")
    left = MANAGER.leave(room.roomid, roleid)
    (log.info("role %s quit room %s", roleid, roomid) if log.isEnabledFor(20) else None)
    # 不要回发 CsQuit —— 那是客户端→服务端的消息，客户端没有它的处理分支。
    # 告诉房主「有人走了」用 ScRemovePlayer（和 cleanup_role 保持一致）。
    if left is not None:
        _broadcast(left, ID.SC_REMOVE_PLAYER, roleid=roleid)
        _sync_room(left)


@ROUTER.register(1441901, "com.gwebtop.gclient.RoleQuit")
async def on_role_quit(session: Session, msg: dict) -> None:
    """战斗里「退出」（GameOption → QuitWarning → Commander.Quit）。

    客户端只把 RoleQuit 发上来，**自己不做任何场景切换**：

        Commander.Quit(roleid):
            RoomServer.Instance.Send(new RoleQuit(roleid));
            CurrentRoom.instance.Clear();
            VoteManager.Destroy();

    真正「离开战斗」是收到**服务端回来的** RoleQuit：

        ClientManager.RoleQuit(roleid):
            if (DataPool.IsHero(roleid)) {          // 自己
                CurrentRoom.Reset(); Battle_Quit(-1);
                Spawner.Release(); Destroy();       // 这才切回大厅
            } else { CurrentRoom.RemovePlayer(roleid); ... }

    服务端原来**没有这条消息的 handler**，所以点「确定退出」之后客户端
    站在战斗场景里等回包，永远出不去 —— 就是「进入游戏后无法退出」。
    这里把 RoleQuit 回给本人 + 广播给其他人，再把人从房间/战斗里摘掉。
    """
    raw_roleid = msg.get("roleid")
    roleid = int(raw_roleid or session.roleid or 0)
    if not roleid:
        return
    # RoleQuit 是玩家明确退出战斗：不保留、等迟到 close 也不重建 grace。
    cancel_reconnect_grace(roleid, "RoleQuit")
    room = MANAGER.room_of(roleid)
    if room is None:
        return

    from . import battle as battle_mod

    # 1) 回给本人 —— 客户端靠它走 hero 分支离开战斗场景
    target = session
    if _world is not None:
        target = _world.session_of_role(roleid, "room") or session
    if target is not None and not target.closed:
        target.send(battle_mod.ID.ROLE_QUIT, roleid=roleid)

    # 2) 战斗内的状态：模型、复活倒计时、出生保护定时器
    b = battle_mod.BATTLES.get(room.roomid)
    f = None
    if b is not None:
        f = b.fighters.pop(roleid, None)
        try:
            b._cancel_relive(roleid)
        except Exception:
            (log.debug("cancel relive failed role=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
        b._inv_timers.pop(roleid, None)
        # 其余人收到会把模型删掉、显示「XXX 离开了」
        b.send_others(roleid, battle_mod.ID.ROLE_QUIT, roleid=roleid)
        if not b.fighters:
            # 最后一个走的人：房间回到「等待开始」，否则下一局开始不了
            room.started = False
            battle_mod.drop(room.roomid)

    # 3) 房间成员表 + 广播同步
    left = MANAGER.leave(room.roomid, roleid)
    (log.info("role %s quit battle of room %s (raw_roleid=%s born=%s hp=%s 距上次死亡=%.1fs 房间剩 %d 人)",
             roleid, room.roomid, raw_roleid, getattr(f, "born", None), getattr(f, "hp", None),
             (time.time() - float(getattr(f, "dead_at", 0) or 0)) if getattr(f, "dead_at", 0) else -1.0,
             len(room.members)) if log.isEnabledFor(20) else None)
    if left is None:
        battle_mod.drop(room.roomid)
        return
    _sync_room(left)


@ROUTER.register(ID.CS_KICKOUT, "CsKickout")
async def on_kickout(session: Session, msg: dict) -> None:
    """房主踢人。CsKickout(1245204) roomid + kickoutid。"""
    room = MANAGER.room_of(session.roleid)
    if room is None or room.owner != session.roleid:
        return
    target = int(msg.get("kickoutid") or msg.get("roleid") or 0)
    if target == session.roleid or target not in room.members:
        return
    from . import room_fill, bots, battle as battle_mod
    if bots.is_bot(target):
        room_fill.note_bot_kick(room, target)
        active = battle_mod.BATTLES.get(room.roomid)
        if active is not None:
            active._cancel_relive(target)
            timer = active._inv_timers.pop(target, None)
            if timer is not None:
                timer.cancel()
            removed = active.fighters.pop(target, None)
            if removed is not None:
                removed.born, removed.hp = False, 0.
            for attribute in ('_bot_motion', '_bot_ammo', '_bot_shot_at', '_bot_spawn_at'):
                getattr(active, attribute, {}).pop(target, None)
            if active.challenge is not None:
                allies = active.challenge.allies
                for attribute in ('ammo', 'motion', 'supply_due', 'supply_goals'):
                    getattr(allies, attribute, {}).pop(target, None)
            active.send_all(battle_mod.ID.ROLE_QUIT, roleid=target)
    cancel_reconnect_grace(target, "kicked")
    # ScKickout 属于 com.gwebtop.fight（大厅服消息段，客户端走 FightManager），
    # 所以要发到大厅服那条连接。打战斗时 _online 里存的是房间服连接
    # （房间服登录会把它覆盖掉），直接 session_of_role() 会发错连接。
    victim = None
    if _world is not None:
        victim = (_world.session_of_role(target, "gs")
                  or _world.session_of_role(target))
    if victim is not None:
        # ScKickout 只有 roomid —— 客户端 Response(ScKickout) 直接
        # CurrentRoom.Clear() + Callboard.Show(12)，根本不看是谁被踢。
        victim.send(ID.SC_KICKOUT, roomid=room.roomid)
    left = MANAGER.leave(room.roomid, target)
    if left is not None:
        _broadcast(left, ID.SC_REMOVE_PLAYER, roleid=target)
        _sync_room(left)
    else:
        MANAGER.remove(room.roomid)
    (log.info("room %s kicked role %s", room.roomid, target) if log.isEnabledFor(20) else None)


# --------------------------------------------------------------------------
# start -> hand the client the room server address
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_START, "CsStart")
async def on_start(session: Session, msg: dict) -> None:
    """Kept for completeness -- the client never actually sends CsStart.

    Everyone reaching this point is treated as "the owner pressed 开始"; the
    real trigger is the owner's CsSetReadyState (see on_ready).
    """
    room = MANAGER.room_of(session.roleid)
    if room is None:
        session.send(ID.SC_START_RET, retcode=START_NOT_OWNER)
        return
    if room.owner != session.roleid:
        session.send(ID.SC_START_RET, retcode=START_NOT_OWNER)
        return

    session.send(ID.SC_START_RET, retcode=START_OK)
    await _start_battle(room)


# --------------------------------------------------------------------------
# room server (second TCP connection)
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_PING, "room.CsPing")
async def on_room_ping(session: Session, msg: dict) -> None:
    """RoomServer.Ping() probes 5 times before sending CsLogin."""
    session.send(ID.SC_PING, ts=int(time.time() * 1000))


@ROUTER.register(ID.ROOM_CS_LOGIN, "gclient.CsLogin")
async def on_room_login(session: Session, msg: dict) -> None:
    token = msg.get("token") or b""
    username = msg.get("username") or ""
    roleid = int(msg.get("roleid") or 0)

    (log.info("room login: roleid=%s user=%r token=%dB on %s",
             roleid, username, len(token), session) if log.isEnabledFor(20) else None)

    token_room = next((r for r in MANAGER.rooms.values()
                       if r.token == token), None)
    role_room = MANAGER.room_of(roleid) if roleid else None
    # 原 token 命中优先；否则只允许回落到「该角色仍在成员表里的房间」。
    room = token_room or role_room
    token_matched = bool(token_room is not None and token_room is room)

    if room is None:
        log.warning("room login for roleid=%s found no room (token mismatch?)", roleid)
        session.send(ID.ROOM_SC_LOGIN_RET, retcode=1)
        return

    # **已开始的房间：当前 token + 成员表必须同时成立。**
    # 这一步必须发生在给 session.roleid 赋值之前：被拒绝的连接 close 时
    # roleid 仍为 0，不会进入 on_session_closed 的正常玩家清理。
    # 实机 1.8.1 原生每次都发当前 16B token；旧 token（例如上一局 token）
    # 即使 roleid 仍在成员表里也不能接管。
    if room.started:
        if token != room.token or roleid not in room.members:
            log.warning("room login rejected role=%s room=%s: started room "
                        "requires current token + membership "
                        "(token_match=%s member=%s)",
                        roleid, room.roomid, token_matched,
                        roleid in room.members)
            session.send(ID.ROOM_SC_LOGIN_RET, retcode=1)
            return
    elif roleid not in room.members:
        # 未开始房间也只允许本房间成员登录；保留原 token/角色兜底语义。
        log.warning("room login rejected role=%s room=%s: not a member",
                    roleid, room.roomid)
        session.send(ID.ROOM_SC_LOGIN_RET, retcode=1)
        return

    session.roleid = roleid
    session.role_name = username
    session.phase = "in_room"
    session.localsid = room.roomid
    if _world:
        _world.mark_online(roleid, session)
    (log.info("role %s(%s) entered room %s", username, roleid, room.roomid) if log.isEnabledFor(20) else None)
    session.send(ID.ROOM_SC_LOGIN_RET, retcode=0)

    from . import battle as battle_mod
    b = battle_mod.BATTLES.get(room.roomid)
    grace = _GRACES.get(roleid)
    grace_reconnect = grace is not None and grace.roomid == room.roomid
    # 只有「这个 Battle 上这个 role 已经真正成功 room login 过」才算重连。
    # Battle.add() 在第一个真人 begin() 时会把所有成员（包括还没连接的第二
    # 个真人）都加入 fighters，不能用 members/fighters 判断。
    reconnecting = grace_reconnect or _room_login_accepted(b, roleid)
    finished_room = b is not None and b.fight_over
    if reconnecting or finished_room:
        cancel_reconnect_grace(roleid, "room reconnect")
        # 只补安全快照：客户端 RetrySuccess 路径没有状态同步请求，
        # ScSyncRoomInfo 只重建 CurrentRoom 成员表，不重置 HP/装备/感染。
        # 它属于 com.gwebtop.fight（1245xxx），必须走仍然存活的大厅服连接，
        # 不能发到刚重连上的 room 连接（客户端那侧由 FightManager 处理）。
        target = (_world.session_of_role(roleid, "gs")
                  if _world is not None else None)
        if target is not None and not target.closed:
            _sync_room_to(room, target)
        _mark_room_login(b, roleid)
        f = b.fighters.get(roleid) if b is not None else None
        (log.info("room reconnect restored role=%s room=%s without begin/Born "
                 "(hp=%s born=%s equip=%d, token_match=%s)",
                 roleid, room.roomid, getattr(f, "hp", None),
                 getattr(f, "born", None),
                 len(getattr(f, "equipmap", {}) or {}), token_matched) if log.isEnabledFor(20) else None)
        return

    # 该角色在这个 Battle 上第一次成功 room login：保留原 begin(only=session)
    # 流程。即使别的真人已经 begin 过，本客户端仍需要自己的 ScBornPrepare。
    started_battle = battle_mod.battle_for(room)
    started_battle.begin(only=session)
    _mark_room_login(started_battle, roleid)


def cleanup_role(roleid: int) -> None:
    """Called when a session drops, so rooms do not keep ghosts."""
    # 正常清理入口：无论来自断线超时、超时定时器还是显式退出，都先注销 grace，
    # 避免旧定时器在角色已经离开后再次触发。
    cancel_reconnect_grace(roleid, "cleanup_role")
    room = MANAGER.room_of(roleid)
    if room is None:
        return
    from . import battle

    left = MANAGER.leave(room.roomid, roleid)
    (log.info("role %s dropped out of room %s", roleid, room.roomid) if log.isEnabledFor(20) else None)
    if left is None:
        battle.drop(room.roomid)
        return

    b = battle.BATTLES.get(room.roomid)
    if b is not None:
        b.fighters.pop(roleid, None)
        if not b.fighters:
            # 人全没了：房间回到「等待开始」，别让下一局被 JOIN_STARTED 挡住
            room.started = False
    _broadcast(left, ID.SC_REMOVE_PLAYER, roleid=roleid)
    # **`ID.ROLE_QUIT` 从来就不存在** —— 这一行每次有玩家断线都会抛
    # `AttributeError`，把后面的 `_sync_room` 一起跳过，房间状态就残留在
    # 别人客户端上（房主看到已离开的人还在，进而影响下一局）。
    # `ScRemovePlayer` 才是客户端认的「有人离开」消息，已经在上行发了。
    _sync_room(left)


# 注册邀请 / 投票踢人的 handler（模块内用 ROUTER 注册，import 即生效）
from . import social as _social  # noqa: E402,F401
from . import slot as _slot  # noqa: E402,F401  注册神秘转盘 handler
