"""Room model and match lifecycle.

A room lives on the GS connection (create / join / ready / start) and, once
started, the GS hands the client a `ScLoginRoom` pointing at the room server,
where the match itself is driven.

Everything a room advertises to the client (`levelid`, `mapid`, `gamemode`,
`playerlimits`) must exist in the config tables -- the client resolves
`roominfo.levelid` through `CsGameRuleMgr.getRule` and dereferences the
result, so an unknown id is an immediate null reference on their side.
"""
from __future__ import annotations

import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .. import gamedata

log = logging.getLogger("crisisfire.rooms")

# RoomStatus.status values the client understands
ROOM_OPEN = 0
ROOM_STARTED = 1

# ScJoinRoomRes.retcode -- must match FightManager.Response(ScJoinRoomRes):
#
#     case 1: Callboard.Show(8);   break;   // 房间已满
#     case 2: Callboard.Show(11);  break;   // 您没有达到要求
#     case 3: Callboard.Show(9);   break;
#     case 4: Callboard.Show(10);  break;   // 房间已不存在
#     case 6: Callboard.Show(163); break;   // 新手线路等级限制
#     case 7: Callboard.Show(478); break;   // 不在战斗中或房间已满
#     case 8: { InputModal password } break; // 密码错误，弹输入框
#     case 9: Callboard.Show(528); break;
#     case 10: Callboard.Show(599, 20); break;
#
# The similarly-named JOIN_* constants in ScLoginRet.cs belong to the *login*
# protocol, not to this one.  Using them here made every failure show the wrong
# message -- and when the player clicks a room in the list (`quickJoining`),
# the client skips the whole switch, so a failed join showed nothing at all.
JOIN_OK = 0
JOIN_FULL = 1                 # 房间已满
JOIN_LEVEL = 2                # 您没有达到要求
JOIN_OTHER = 3
JOIN_NO_ROOM = 4              # 房间已不存在
JOIN_STARTED = 7              # 不在战斗中或房间已满
JOIN_PASSWORD = 8             # 密码错误，弹输入框


# PlayerInfo.flags bits (CurrentRoom.isReady / IsReadyExcept / CanInvited)
FLAG_READY = 1           # 已准备
FLAG_INVITE = 2          # 邀请权限（客户端里的「助理」）

# RoomInfo.flags bits -- 客户端 `RoomItemData.status` 是这么读的：
#     canJoin = (roominfo.flags & 2) > 0;
#     locked  = (roominfo.flags & 0x10) > 0;
# 原来 `roominfo()` 只发 `1 if not password else 0`，**密码位（16）永远不出现**，
# 于是房间列表里带密码的房间不显示锁、`CheckRoomEncrypt` 永远不开密码框。
FLAG_PUBLIC = 1              # 公开（出现在房间列表）
FLAG_JOINABLE = 2            # 允许中途加入
FLAG_AUTOBALANCE = 4
FLAG_AUTOAIM = 8
FLAG_PASSWORD = 16           # 房间带密码
_USER_FLAGS = FLAG_JOINABLE | FLAG_AUTOAIM


def _default_room_flags() -> int:
    """新建房间的默认设置位（【v49】默认打开「自动瞄准 / 辅助瞄准」）。

    客户端这条链是完整的：`DataPool.AutoAiming` 联机取
    `CurrentRoom.AutoAim` → `roomInfo.flags & 8`；打开后 `DetectAssistor`
    每帧做球形检测，`TouchRotator.Update` 把视角 Lerp 到目标点。
    原来 `Room.flags` 默认 0 → 所有联机房都没有这个功能（用户实测
    「机器人关卡有、联机没有」）。这里只改**默认值**，房主仍可在建房界面
    用那颗「自动瞄准」按钮关掉（走 CsChangeRoomInfo 覆盖）。
    `CF_ROOM_AUTOAIM=0` 可整体关回 v48 行为。
    """
    try:
        from ..config import CONFIG
        if int(getattr(CONFIG, "room_auto_aim", 1) or 0) <= 0:
            return 0
    except Exception:
        pass
    return FLAG_AUTOAIM

# 注意 bit 1 **不是**「已进入战斗」：客户端 CurrentRoom 用它的只有这一处
#     public bool CanInvited(int roleid)
#         => (userInfo.playerInfo.flags & 2) > 0;
# 房主在成员卡片里点「设为助理」发 CsEnableInvite(roleid, enabled, roomid)，
# 服务端把这一位设上/清掉后广播 ScSyncPlayerFlag，成员卡片才会画成助理。


def _player_limits(rule: Dict[str, Any]) -> int:
    """这个规则下房间的 playerlimits。

    `roominfo.playerlimits` 是**总人数**：CurrentRoom.IsFull 直接拿它和人数比
    (`playerLimits == getUserSize()`)，BattleSide 用 `playerLimits / 2` 算每边人数。

    普通模式：maxTeamer 是每边人数，乘 2。
    生化模式（gameMode 8）：maxTeamer = 0（生化没有分边概念，IsSingle），
    官方用 roomMinTeamer = 8 表示人数门槛。但**客户端根本不读 roomMinTeamer** ——
    它只认 IsFull，也就是 playerlimits == 人数。所以生化房直接把这个值设成
    想要的人数即可，否则客户端会一直等满 8 人才开始。
    """
    from ..config import CONFIG
    # 8 = 生化模式，10 = 生化英雄（客户端 Judger.IsBiochemistry 两者都算）
    if int(rule.get("gameMode") or 0) in (8, 10):
        official = int(rule.get("roomMinTeamer") or 8)
        want = int(getattr(CONFIG, "biochem_min_players", 2) or 2)
        return max(1, min(official, want))
    if rule.get("gameMode") == 12:
        return int(rule["maxTeamer"])
    # 【v19】SOLO 战（mode4）是 FFA。规则表 maxTeamer=1 -> 2 人房，
    # 一个人打一个 BOT 根本不成局，也体现不出「对所有人攻击」。
    # 统一按 8 人满员填房，配合 damage.same_team(mode4)=False 与
    # bots._side_of(mode4)=每人唯一 实现全员互殴。自建房同样生效。
    if int(rule.get("gameMode") or 0) == 4:
        return 8
    try:
        return int(rule.get("maxTeamer", 4)) * 2 or 8
    except (TypeError, ValueError):
        return 8


@dataclass
class Member:
    roleid: int
    name: str
    level: int
    iconid: int
    side: int = 1                 # 1 = police, 2 = terrorist
    ready: bool = False
    invite: bool = False          # 助理财产（PlayerInfo.flags bit 1）
    # {actorid: {pos: subjoinid}} -- the same shape PlayerInfo.subjoins carries.
    # Snapshotted in room_handlers._member_of from role.data["subjoins"] so the
    # room / battle roster sees exactly what is worn in the lobby.
    subjoins: Dict[int, Dict[int, int]] = field(default_factory=dict)
    joined: float = field(default_factory=time.time)
    pve_buffs: set[int] = field(default_factory=set)

    def to_playerinfo(self) -> Dict[str, Any]:
        """com.gwebtop.fight.PlayerInfo as the client expects it.

        `flags` bit 0 is 准备.  The room UI reads it as

            // CurrentRoom
            public bool isReady(int roleid) => (player.flags & 5) != 0;
            public bool IsReadyExcept(int except)
            { ... if ((item.playerInfo.flags & 1) == 0) return false; ... }

        and with a hard-coded 0 the 准备 button visibly did nothing.
        (bit 1 is the 助理/invite permission -- see FLAG_INVITE.)
        """
        from . import handlers, pve_progress
        role = handlers.world.role(self.roleid) if handlers.world is not None else None
        return {
            "prop": {
                "rank": self.level, "exp": 0, "createtime": 0,
                "name": self.name, "iconid": self.iconid,
                "teamid": 0, "teamname": "",
                "medals": {}, "medalsshow": {},
                "vipstatus": 0, "monthcard": int(pve_progress.month_active(role)),
            },
            "subjoins": {
                int(actor): {"subjoins": {int(pos): int(itemid)
                                          for pos, itemid in slots.items()}}
                for actor, slots in (self.subjoins or {}).items() if slots
            },
            "flags": self.flags(),
            "side": self.side,
        }

    def flags(self) -> int:
        flags = FLAG_READY if self.ready else 0
        if self.invite:
            flags |= FLAG_INVITE
        return flags


@dataclass
class Room:
    roomid: int
    owner: int
    levelid: int
    mapid: int
    gamemode: int
    playerlimits: int
    title: str = ""
    password: str = ""
    # 客户端可调的房间设置位（2 = 允许中途加入，8 = 自动瞄准）。密码位和
    # 「公开」位由服务端在 roominfo() 里拼，不存这里。
    # 【v49】默认带上 8（自动瞄准），见 `_default_room_flags`。
    flags: int = field(default_factory=_default_room_flags)
    line: int = 0
    members: Dict[int, Member] = field(default_factory=dict)
    started: bool = False
    token: bytes = b""
    created: float = field(default_factory=time.time)
    practice_slot: int = -1     # Unclaimed BOT lobby template index.
    equiplimitid: int = 0
    # Room-session policy only; never written into player saves.
    kicked_bot_ids: set[int] = field(default_factory=set)
    bot_vacancies: int = 0
    bot_roster_managed: bool = False

    # -- helpers ---------------------------------------------------------
    @property
    def locked(self) -> bool:
        return bool(self.password)

    def status(self) -> int:
        return ROOM_STARTED if self.started else ROOM_OPEN

    def roominfo(self) -> Dict[str, Any]:
        """com.gwebtop.room.RoomInfo

        `flags` 必须按客户端的位定义拼：1 = 公开、2 = 允许中途加入、
        8 = 自动瞄准、16 = 有密码。`RoomItemData.locked` 只认 16 —— 少了它，
        房间列表里带密码的房间和不带密码的长得一模一样，客户端也不会弹
        密码输入框（见 FLAG_* 常量）。
        """
        flags = FLAG_PUBLIC | (int(self.flags or 0) & _USER_FLAGS)
        # 【v49】排位 / 联赛（rank_queue 打上 local_rank_match 的房）**恒不
        # 开辅助瞄准**。用户要求：这两个模式不能用自动瞄准。这里在唯一拼
        # flags 的出口裁决，普通房建房页那颗开关（CsChangeRoomInfo →
        # self.flags）改不到高难房：flags 是每房独立的实例字段，且即使某房
        # 先被当普通房开过 8、之后被匹配复用，roominfo 也会把它抹掉。
        # ScSyncRankRoomInfo 同样下发 room.roominfo()，所以一并覆盖。
        if getattr(self, "local_rank_match", False):
            flags &= ~FLAG_AUTOAIM
        if self.password:
            flags |= FLAG_PASSWORD
        return {
            "levelid": self.levelid,
            "mapid": self.mapid,
            "gamemode": self.gamemode,
            "equiplimitid": self.equiplimitid,
            "playerlimits": self.playerlimits,
            "flags": flags,
            "title": self.title,
        }

    def roomstatus(self) -> Dict[str, Any]:
        """com.gwebtop.fight.RoomStatus, as used by ScRoomList."""
        owner = self.members.get(self.owner)
        return {
            "roomid": self.roomid,
            "status": self.status(),
            "memberscount": len(self.members),
            "roominfo": self.roominfo(),
            "owner": {
                "rank": owner.level if owner else 1,
                "exp": 0,
                "name": owner.name if owner else "",
                "iconid": owner.iconid if owner else 0,
            },
        }

    def player_map(self) -> Dict[int, Dict[str, Any]]:
        return {rid: m.to_playerinfo() for rid, m in self.members.items()}

    def is_full(self) -> bool:
        # `roominfo.playerlimits` is the TOTAL player count, not a MemberLimit
        # id: CurrentRoom.IsFull compares it straight against the member count
        # (`playerLimits == getUserSize()`) and BattleSide derives per-side
        # slots from `playerLimits / 2`.  So honour the number itself first.
        if self.playerlimits > 0:
            return len(self.members) >= self.playerlimits
        # Fall back to the table.  Its columns are id + limit
        # ({id:2, limit:8, name:'最大8人'}) -- there is no max/count, so the old
        # lookup silently returned 8 for every room.
        cap = 8
        for row in gamedata.member_limits():
            if row.get("id") == self.playerlimits:
                cap = int(row.get("limit") or 8)
                break
        return len(self.members) >= cap

    def new_token(self) -> bytes:
        self.token = secrets.token_bytes(16)
        return self.token


class RoomManager:
    """All rooms on this GS, keyed by roomid."""

    def __init__(self):
        self.rooms: Dict[int, Room] = {}
        self._next = 1

    def next_id(self) -> int:
        rid = self._next
        self._next += 1
        return rid

    def by_line(self, line: int) -> List[Room]:
        return [r for r in self.rooms.values() if r.line == line]

    def get(self, roomid: int) -> Optional[Room]:
        return self.rooms.get(roomid)

    def room_of(self, roleid: int) -> Optional[Room]:
        for r in self.rooms.values():
            if roleid in r.members:
                return r
        return None

    def create(self, owner: Member, line: int = 0,
               levelid: Optional[int] = None) -> Room:
        levelid = gamedata.default_levelid() if levelid is None else levelid
        rule = gamedata.rule(levelid)
        if rule is None or not gamedata.map_has_spawns(rule["mapId"]):
            raise ValueError(f"unplayable room rule {levelid}")
        room = Room(
            roomid=self.next_id(),
            owner=owner.roleid,
            levelid=levelid,
            mapid=int(rule["mapId"]),
            gamemode=int(rule["gameMode"]),
            playerlimits=_player_limits(rule),
            line=line,
            title="",
        )
        room.members[owner.roleid] = owner
        # 1.7.1 的 RoomWindow.OnInvite 检查的是 **自己** 的 flags bit 1：
        #   if (CurrentRoom.instance.canInvited(UserManager.GetUserId())) ...
        # 房主自己如果没有这一位，点邀请只会弹 Callboard 39（1.9 的 OperPanel
        # 没有这个检查，所以只有 1.9 能邀请）。房主默认给邀请权限。
        owner.invite = True
        room.new_token()
        self.rooms[room.roomid] = room
        (log.info("room %s created by %r (levelid=%s mapid=%s mode=%s)",
                 room.roomid, owner.name, room.levelid, room.mapid, room.gamemode) if log.isEnabledFor(20) else None)
        return room

    def remove(self, roomid: int) -> None:
        # 删房是房间生命周期的终点：立即释放该房间的重连 grace 定时器，
        # 不等到 120 秒超时。
        try:
            from . import room_handlers as _rh
            _rh.cancel_room_reconnect_graces(roomid, "room removed")
        except Exception:
            (log.debug("取消房间 %s 的重连 grace 失败", roomid, exc_info=True) if log.isEnabledFor(10) else None)
        self.rooms.pop(roomid, None)
        # 一并清掉战场对象。
        #
        # `next_id()` 是递增的，但**服务端一重启房间号就从 1 重新开始** ——
        # 那时 BATTLES[1] 里若还留着上一个进程的战场，新房间会拿到脏对象，
        # 表现就是「点开始不进入战斗」。延迟导入避免和 battle 循环引用。
        try:
            from . import battle as _b
            if roomid in _b.BATTLES:
                _b.drop(roomid)
                (log.info("room %s 的战场对象已清理", roomid) if log.isEnabledFor(20) else None)
        except Exception:
            (log.debug("清理战场对象失败 room=%s", roomid, exc_info=True) if log.isEnabledFor(10) else None)

    def leave(self, roomid: int, roleid: int) -> Optional[Room]:
        """Drop a member; the room only dies when it becomes empty.

        **房主离开时把房主转给下一个人，而不是解散房间。**
        原来 `roleid == room.owner` 就直接 `remove` 掉房间：服务端这边房间对象
        没了，但另外两个人还在房间里 —— 他们收不到任何通知（客户端上房主还挂在
        成员列表里），之后点开始/退出都对着一个不存在的房间。
        实测症状：「房主退出房间后，另外两个人视角里房主还在」。
        """
        room = self.rooms.get(roomid)
        if room is None:
            return None
        room.members.pop(roleid, None)
        from .bots import is_bot
        humans = [rid for rid in room.members if not is_bot(rid)]
        if not humans:
            self.remove(roomid)
            (log.info("room %s closed (empty)", roomid) if log.isEnabledFor(20) else None)
            return None
        if roleid == room.owner:
            room.owner = humans[0]
            room.members[room.owner].invite = True
            (log.info("room %s owner -> %s", roomid, room.owner) if log.isEnabledFor(20) else None)
        if not room.started:
            from . import room_fill
            room_fill.fill(room)
        return room
