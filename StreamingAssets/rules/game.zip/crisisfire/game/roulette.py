"""幸运转盘 (GemLottery).

**Why clicking it froze the whole panel.** `RoulettePanel.Ernie` disables every
button *before* the result arrives, and the close button is one of them:

    private void Ernie(int times)
    {
        if (!RechargeManager.CanPlayRoulette) { DialogMgr.Load("OpenRoulette"); return; }
        ...
        ActivityManager.GoGemLottery(times, (int)plateType);   // -> CsGemLottery
        FixButtons(enable: false);                             // <- 关闭键也禁用了
        roulettePlate.FixAnimation(auto: false);
    }

    private void FixButtons(bool enable)
    {
        exchange.isEnabled = enable;
        close.isEnabled = enable;            // 无法退回大厅
        normalButton.isEnabled = enable;
        ernie.isEnabled = enable;
        ...
    }

The only way back is the wheel animation finishing:

    // ActivityManager.GemLottery(lottery)  <- ScGemLottery.process()
    mylotterys.Add(lottery); LotteryDone?.Invoke();
        -> RoulettePlate.OnLotteryDone  -> machine.Startup(mylotterys[0].id, -1, ...)
        -> RouletteMachine.OnFlagCompleted -> Completed -> RoulettePlate.RouletteCompleted
        -> Completed() -> PlateCompleted() -> FixButtons(true)

so with no `ScGemLottery` the panel stays locked forever.

Plate -> pool, from the GemLottery table's id layout (type 1 = ids 1..14, a
14-cell wheel; type 2 = 16..24; type 4/5 = 25..27; type 3 = 28..37):

    CsGemLotteryInfo(0)  Normal            -> type 1
    CsGemLotteryInfo(1)  Silver            -> type 2 (and 3)
    CsGemLotteryInfo(2)  Golden / Advanced -> type 4 + 5 (and 3)

`CsGemLotteryInfo` is what RoulettePanel asks for on enable, so that call also
remembers which plate the player is looking at -- 1.7.1's
`ActivityManager.GoGemLottery(multiple, type)` drops the `type` argument and
only sends `CsGemLottery(multiple)`.

`RouletteCell.lotteryid` is baked into the prefab, so an id that is not on the
wheel makes `RouletteMachine.FindCell` return -1: the animation is skipped but
`Completed` still fires, which unblocks the UI.  A wrong pick is therefore
cosmetic, never fatal.
"""
from __future__ import annotations

import logging
import random
import time
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import equip

log = logging.getLogger("crisisfire.roulette")


class ID:
    CS_GEM_LOTTERY = 1048585
    SC_GEM_LOTTERY = 1048586
    SC_GEM_LOTTERY_LIST = 1048587
    CS_GEM_LOTTERY_INFO = 1048588
    SC_GEM_LOTTERY_INFO = 1048589

    CS_GOLDEN_LOTTERY = 1048639
    SC_GOLDEN_LOTTERY = 1048640
    CS_GOLDEN_LOTTERY_RESET = 1048641
    SC_GOLDEN_LOTTERY_INFO = 1048642
    # 中奖全服播报（com.gwebtop.shop.ScGemLotteryBrd，info:LotteryHistoryInfo）
    SC_GEM_LOTTERY_BRD = 1048604

    SC_PACKAGE_SYNC = 983041
    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


class _ReplyGuard:
    """保证转盘请求**一定**有回包。

    客户端 `RoulettePanel.Ernie` 在点下「转动 / 转动10次」的瞬间就调用
    `FixButtons(false)`，而 `FixButtons` 写的是全局静态开关
    `UICamera.enableEvents = false` —— 不只是转盘按钮，整个游戏所有 UI
    都点不动了。唯一能把开关翻回来的是转盘动画走完后的
    `PlateCompleted -> FixButtons(true)`，而动画必须收到 `ScGemLottery`
    才会启动。

    因此：任何一条分支（余额不足、抽奖表为空、发奖异常、甚至是编码失败）
    都不能让这条请求「静默结束」。所有 `ScGemLottery` 都经 `send()` 走，
    `finish()` 在请求结束时兜底补发一次，确保客户端动画一定启动。
    """

    def __init__(self, session, type_id: int, fallback: Dict[str, Any]):
        self.session = session
        self.type_id = int(type_id)
        self.fallback = fallback
        self.sent = False

    def send(self, **fields: Any) -> None:
        try:
            self.session.send(self.type_id, **fields)
            self.sent = True
        except Exception:
            self.sent = False
            log.exception("转盘回包编码/发送失败 type=%s %s",
                          self.type_id, fields)

    def finish(self) -> None:
        if self.sent:
            return
        try:
            self.session.send(self.type_id, **self.fallback)
            self.sent = True
            log.warning("转盘结算未回包，兜底补发 type=%s", self.type_id)
        except Exception:
            log.exception("转盘兜底回包也失败 type=%s", self.type_id)


def _safe_send(session, type_id: int, **fields: Any) -> None:
    """非关键推送失败不能中断结算（更不能再把异常抛到消息分发层）。"""
    try:
        session.send(type_id, **fields)
    except Exception:
        log.exception("转盘附加推送失败 type=%s", type_id)


# plate id (what CsGemLotteryInfo carries) -> GemLottery.type values
PLATE_POOLS = {
    0: [1],          # Normal
    1: [2, 3],       # Silver
    2: [4, 5, 3],    # Golden / Advanced
}

# fallback if the config is not what we expect
DEFAULT_PLATE = 0
PLATE_NORMAL = 0


def plate_of(role) -> int:
    try:
        return int((role.data or {}).get("roulette_plate", DEFAULT_PLATE))
    except (TypeError, ValueError):
        return DEFAULT_PLATE


def set_plate(role, plate: int) -> None:
    if _world is not None:
        _world.merge_role_data(role.roleid, roulette_plate=int(plate))


def pool_rows(plate: int) -> List[Dict[str, Any]]:
    types = set(PLATE_POOLS.get(plate, PLATE_POOLS[DEFAULT_PLATE]))
    rows = [r for r in gamedata.table("GemLottery")
            if r.get("type") in types and int(r.get("ratio") or 0) > 0]
    if rows:
        return rows
    # never leave the wheel with nothing to land on
    return [r for r in gamedata.table("GemLottery")
            if int(r.get("ratio") or 0) > 0]


def draw(plate: int) -> Optional[Dict[str, Any]]:
    rows = pool_rows(plate)
    if not rows:
        return None
    weights = [max(1, int(r.get("ratio") or 1)) for r in rows]
    return random.choices(rows, weights=weights, k=1)[0]


def prize_value(row: Dict[str, Any], pool: int = 0) -> int:
    """奖池奖要按池子算，其余按固定值。

    奖池奖（`poolRatio > 0`）本身没有 gem/gold 字段，它的价值 = 当前奖池 × 比例：

        Text 425   "{0}%奖池钻石"
        Text 20001 "...一旦获得最高奖『奖池大奖』时，您将直接获得奖池中钻石的
                     50%，上不封顶！"

    `poolRatio` 是**百分比的 100 倍**（5000 = 50.00%）。不算这个的话客户端会显示 0。
    """
    try:
        ratio = int(row.get("poolRatio") or 0)
    except (TypeError, ValueError):
        ratio = 0
    if ratio > 0:
        return max(0, int(pool)) * ratio // 10000
    # **不能把 itemNum 当价值**：它是「物品个数」（几乎都是 1），不是货币。
    # 神秘转盘 `on_golden` 会把 prize_value 的返回值传给 `_grant_advanced`，
    # 后者在物品没发成时会把 value 当钻石加给玩家 —— 表现就是
    # 「抽一次扣 100 钻，又莫名返 1 钻（净扣 99）」。
    for k in ("gem", "honor", "gold", "exp", "coupon"):
        try:
            v = int(row.get(k) or 0)
        except (TypeError, ValueError):
            v = 0
        if v > 0:
            return v
    return 0


# 幸运积分（Text 20001「转动转盘同时可获得幸运积分，积分可兑换各种奖励」）
#
# 【v46】用户口径：**十连给 200 分**（= 每抽 20 分）。积分走
# `exchange.exchange_tickets`（客户端底部那个笑脸计数器），
# 兑换商店读的也是它。
POINTS_PER_SPIN = 20

# 每次转动的消耗（Price[9].gem = 20 钻）。
#
# ★【v1.0.3】早期注释「客户端自己本地扣钱，服务端不能再扣」是**错的**。
# 客户端 `RoulettePanel.Ernie` 确实做了
#     userInfo.gold -= num * price.gem * currencyMultiple;  UserManager.UpdateAccount();
# 但那只是本地内存预演。服务端才是权威钱包，转盘结算时会推
# `ScAcountSync(gold=role.gold, ...)`，把**没有扣过**的余额覆盖回客户端，
# 于是单抽 / 十连看起来都不花钱（用户实测：20 钻 1 次、200 钻十连都不扣）。
# 所以服务端必须自己扣一次，且必须在任何发奖之前，最后无条件推余额同步
# ——客户端那次本地扣减不会造成双扣，它只会被这条同步刷成权威值。
#
# 客户端公式（RoulettePanel.Ernie / CurrencyMultiple）：
#     paid = times - luckyTickets        （只有 Normal 盘抵扣免费券）
#     cost = paid * Price[9].gem * {Normal:1, Silver:10, Golden:100}
# `CsGemLottery` 只带 multiple（1 或 10），盘面由 `CsGemLotteryInfo` 记在 role 上。
SPIN_COST = 20
PRICE_SPIN_ID = 9
PLATE_MULTIPLE = {0: 1, 1: 10, 2: 100}

# 每次转动往奖池里累积多少钻石。用户口径：每一抽 200，十连 2000。
SPIN_POOL_GAIN = 200

# 奖池大奖给奖池的百分比（`GemLottery.poolRatio` 是百分比的 100 倍：
# 5000 = 50%）。抽中之后**只扣掉派发出去的这部分**，池子不清零。
POOL_PRIZE_PCT = 5000


def _points_per_spin() -> int:
    """每一抽给多少幸运积分（可调；默认 20 → 十连 200）。"""
    try:
        from ..config import CONFIG
        return max(0, int(getattr(CONFIG, "roulette_points_per_spin",
                                  POINTS_PER_SPIN)))
    except (TypeError, ValueError):
        return POINTS_PER_SPIN


def _pool_gain() -> int:
    """每一抽往奖池累积多少钻石（默认 200 → 十连 2000）。"""
    try:
        from ..config import CONFIG
        return max(0, int(getattr(CONFIG, "roulette_pool_gain",
                                  SPIN_POOL_GAIN)))
    except (TypeError, ValueError):
        return SPIN_POOL_GAIN


def _spin_price() -> int:
    """Price[9].gem —— 与客户端 `GameData.instance.getPrice(9)` 同源。"""
    for row in gamedata.table("Price") or []:
        if int(row.get("id") or 0) == PRICE_SPIN_ID:
            return max(1, int(row.get("gem") or SPIN_COST))
    return SPIN_COST


def _spin_cost(role, plate: int, times: int):
    """返回 (应扣钻石, 消耗的免费券数)，逐项对齐 `RoulettePanel.Ernie`。

    钻石 = `role.gold`；`Price[9].gem` 的单位也是钻石（见 wallet.py 的映射注释）。
    """
    from . import exchange as _ex
    paid = max(0, int(times))
    free = 0
    if int(plate) == PLATE_NORMAL:       # 只有 Normal 盘能用免费券
        free = min(paid, _ex.lucky_of(role))
        paid -= free
    unit = _spin_price() * PLATE_MULTIPLE.get(int(plate), 1)
    return paid * unit, free


def broadcast_lottery_win(role, prize_id: int, value: int) -> None:
    """ScGemLotteryBrd —— 中奖全服播报。

        ActivityManager.GemLotteryBrd(info):
            if (gemLottery.poolRatio > 0) LotteryMsg(TextPool.Get(10001, rolename, value));
            else if (gemLottery.itemNum > 0) LotteryMsg(TextPool.Get(10002, rolename, item.name));

    只有「大奖」才播（奖池奖或实物奖），发金币/经验那种不刷屏。
    """
    if _world is None:
        return
    row = next((r for r in gamedata.table("GemLottery")
                if int(r.get("id") or 0) == int(prize_id)), None)
    if row is None:
        return
    try:
        pool_ratio = int(row.get("poolRatio") or 0)
        itemnum = int(row.get("itemNum") or 0)
    except (TypeError, ValueError):
        return
    if pool_ratio <= 0 and itemnum <= 0:
        return
    info = {"id": int(prize_id), "value": int(value), "rolename": role.name}
    for s in _world.sessions():
        if s.closed or not s.roleid:
            continue
        try:
            s.send(ID.SC_GEM_LOTTERY_BRD, info=info)
        except Exception:
            (log.debug("中奖播报发送失败 -> %s", s, exc_info=True) if log.isEnabledFor(10) else None)


# --------------------------------------------------------------------------
# 转盘信息
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_GEM_LOTTERY_INFO, "shop.CsGemLotteryInfo")
async def on_info(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    plate = int(msg.get("lotterytype") or 0)
    set_plate(role, plate)

    _hist = role.data.get("roulette_history") if role else None
    _hn = len(_hist) if isinstance(_hist, list) else 0

    (log.info("role %s opened the wheel plate %s (%d prize rows, %d history)",
             role.name, plate, len(pool_rows(plate)), _hn) if log.isEnabledFor(20) else None)
    try:
        _send_info(session, role, plate)
    except Exception:
        # 中奖名单里混进脏数据也不能让面板拿不到 ScGemLotteryInfo。
        log.exception("推转盘信息失败，改推空列表")
        _safe_send(session, ID.SC_GEM_LOTTERY_INFO, lotterytype=int(plate),
                   cashpool=0, lotteryhistory=[], cashlottery=_empty_history())
    # 【v46】plate=2 = 金盘 / 神秘转盘。**客户端从来不请求 ScGoldenLotteryInfo**
    # （全工程没有 CsGoldenLotteryInfo 这个协议），所以神盘的状态只能由
    # 服务端主动推：玩家一切到这个页签就推一次。否则客户端 advancedGifts
    # 一直是空的 → GiftEmpty 恒真、格子上的奖品和已抽位置全是错的，
    # 表现就是「抽完又扣一次钻石、还看不到奖励」。
    if plate == 2:
        try:
            send_advanced_info(session, role)
        except Exception:
            (log.debug("推神秘转盘信息失败", exc_info=True) if log.isEnabledFor(10) else None)


def _empty_history() -> Dict[str, Any]:
    return {"id": 0, "value": 0, "rolename": ""}


# --------------------------------------------------------------------------
# 转动
# --------------------------------------------------------------------------
_ITEM_BY_ID: Optional[Dict[int, Dict[str, Any]]] = None


def _item_row(iid: int) -> Dict[str, Any]:
    global _ITEM_BY_ID
    if _ITEM_BY_ID is None:
        _ITEM_BY_ID = {}
        for row in gamedata.table("Item"):
            try:
                _ITEM_BY_ID[int(row["id"])] = row
            except (KeyError, TypeError, ValueError):
                continue
    return _ITEM_BY_ID.get(int(iid or 0)) or {}


def _display_score(row: Dict[str, Any], value: int) -> int:
    """十连只播一次动画时，挑哪一格当展示：奖池大奖 > 实物（星级高）> 货币。"""
    try:
        if int(row.get("poolRatio") or 0) > 0:
            return 10 ** 9 + int(value or 0)
        iid = int(row.get("item") or 0)
        if iid > 0:
            try:
                star = int(_item_row(iid).get("star") or 0)
            except (TypeError, ValueError):
                star = 0
            return 10 ** 6 + star * 100
    except (TypeError, ValueError):
        pass
    return int(value or 0)


def _send_info(session: Session, role, plate: int) -> None:
    """推一次 ScGemLotteryInfo（奖池数额 + 最近中奖名单）。"""
    history = (role.data or {}).get("roulette_history") if role else None
    rows = []
    if isinstance(history, list):
        for h in history[-8:]:
            try:
                rows.append({"id": int(h["id"]), "value": int(h.get("value") or 0),
                             "rolename": str(h.get("rolename") or "")})
            except (KeyError, TypeError, ValueError):
                continue
    session.send(ID.SC_GEM_LOTTERY_INFO, lotterytype=int(plate),
                 cashpool=int((role.data or {}).get("roulette_pool") or 0),
                 lotteryhistory=rows,
                 cashlottery=rows[0] if rows else _empty_history())


@ROUTER.register(ID.CS_GEM_LOTTERY, "shop.CsGemLottery")
async def on_lottery(session: Session, msg: dict) -> None:
    """外层只负责「保证有回包」，结算本体放 `_lottery_impl`。

    见 `_ReplyGuard`：这里任何异常都不能让客户端停在
    `UICamera.enableEvents = false` 的死锁状态。
    """
    guard = _ReplyGuard(session, ID.SC_GEM_LOTTERY,
                        {"lottery": {"id": 1, "value": 0}})
    try:
        await _lottery_impl(session, msg, guard)
    except Exception:
        log.exception("转盘结算异常 role=%s", getattr(session, "roleid", 0))
    finally:
        guard.finish()


async def _lottery_impl(session: Session, msg: dict, guard: _ReplyGuard) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        # the panel disables its own buttons before sending, so answer anyway
        guard.send(lottery={"id": 1, "value": 0})
        return

    multiple = int(msg.get("multiple") or 1)
    multiple = max(1, min(10, multiple))
    plate = plate_of(role)

    # 【v1.0.3】先扣费、后抽奖。客户端的本地扣减只是预演，服务端才是真值。
    cost, free_spins = _spin_cost(role, plate, multiple)
    balance = int(role.gold or 0)
    if cost > balance:
        # 防绕过：正常客户端 CanBuy 会先拦住，这里拦的是伪造协议 / 余额竞态。
        (log.info("role %s 转盘钻石不足 (%s < %s, x%s plate%s)",
                 role.name, balance, cost, multiple, plate) if log.isEnabledFor(20) else None)
        session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                     diamond=role.diamond)
        # Ernie 已经把按钮禁用了，必须回一个正常的 Lottery 让动画走完，
        # 否则面板卡死（没有 ScGemLottery 就不会 FixButtons(true)）。
        guard.send(lottery={"id": 1, "value": 0})
        return
    if cost:
        from .wallet import change
        change(_world, role, gems=-cost)
    if free_spins:
        from . import exchange as _ex
        for _ in range(free_spins):
            _ex.consume_lucky(role)
        _ex.send_tickets(session, role)

    pool = int(role.data.get("roulette_pool") or 0)
    gain = _pool_gain()
    points = _points_per_spin()

    results: List[Dict[str, Any]] = []
    drawn: List[Dict[str, Any]] = []
    history_add: List[Dict[str, Any]] = []
    gold = honor = gem = exp = coupon = pool_win = 0
    itemids: List[int] = []

    for _ in range(multiple):
        row = draw(plate)
        if row is None:
            log.error("no GemLottery rows to draw from")
            break
        prize_id = int(row["id"])
        try:
            pool_ratio = int(row.get("poolRatio") or 0)
        except (TypeError, ValueError):
            pool_ratio = 0

        # 先累积再判定：这样「抽中的那一次」本身也往池子里加了。
        pool += gain
        if pool_ratio > 0:
            # 奖池大奖：派发奖池的 poolRatio（5000 = 50%），
            # 并且**只从奖池里扣掉派出去的这一部分**（原来直接清零）。
            value = max(0, pool) * pool_ratio // 10000
            pool = max(0, pool - value)
            pool_win += value
        else:
            value = prize_value(row)

        gold += int(row.get("gold") or 0)
        honor += int(row.get("honor") or 0)
        gem += int(row.get("gem") or 0)
        exp += int(row.get("exp") or 0)
        coupon += int(row.get("coupon") or 0)
        itemid = int(row.get("item") or 0)
        itemnum = max(0, int(row.get("itemNum") or 0))
        if itemid and itemnum:
            itemids.extend([itemid] * itemnum)

        results.append({"id": prize_id, "value": int(value)})
        drawn.append(row)
        history_add.append({"id": prize_id, "value": int(value),
                            "rolename": role.name})

    if not results:
        # 钱已经扣了，就算没抽出结果也要把权威余额刷回去。
        session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                     diamond=role.diamond)
        guard.send(lottery={"id": 1, "value": 0})
        return

    # **十连：奖励还是 10 份，但只让转盘转一次**（用户口径：省时间）。
    # 客户端每收到一个 LotteryInfo 就转一次并单独播一次「获得」提示
    # （RouletteCompleted 里 mylotterys.RemoveAt(0) 后接着 Startup 下一个），
    # 所以这里只回**最值钱的那一个**当展示，其余 9 份照样已经发放
    # （货币/道具/积分/奖池都在上面结算完了，背包同步里有全部 10 件）。
    #
    # ★【2.0.2】这条回包必须**最先发**：客户端点下按钮的那一刻就把
    #   `UICamera.enableEvents` 全局关掉了，后面的发奖 / 推背包 / 推余额 /
    #   日常任务任何一步出异常都不能把它拖住，否则整个界面点不动。
    show = max(range(len(results)),
               key=lambda i: _display_score(drawn[i], results[i]["value"]))
    guard.send(lottery=results[show])
    # 立刻把权威余额刷回客户端：本地 Ernie 已经预扣过一次，
    # 这一步无论后面发奖出什么岔子都必须成功，否则余额显示会停在旧值。
    _safe_send(session, ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
               diamond=role.diamond)

    (log.info("role %s spun the wheel (plate %s, x%s) -> %s pool=%s",
             role.name, plate, multiple,
             [(r["id"], r["value"]) for r in results],
             int(role.data.get("roulette_pool") or 0)) if log.isEnabledFor(20) else None)

    # 【2.0.2】发奖阶段的任何异常都只记日志：回包与余额同步已经在
    # 上面发出，绝不能让异常冒到消息分发层把转盘面板留在死锁态。
    try:
        added: List[int] = []
        ranked = False
        if gold or honor or gem or pool_win:
            from .wallet import change
            change(_world, role, coins=gold, gems=gem + pool_win, honor=honor)
        if exp:
            from . import leveling
            old_rank, new_rank = leveling.apply_exp(_world, role, exp)
            ranked = new_rank != old_rank
        if coupon:
            tickets = int((role.data or {}).get("exchange_tickets") or 0) + coupon
            _world.merge_role_data(role.roleid, exchange_tickets=tickets)
        if itemids:
            added = equip.grant_items(role, itemids, _world)

        # remember it for the "recent winners" strip
        hist = list(role.data.get("roulette_history") or [])
        hist.extend(history_add)
        _world.merge_role_data(role.roleid, roulette_history=hist[-20:],
                               roulette_pool=max(0, pool))

        # 展示用回包已在发奖之前发出，见上。
        if added:
            _safe_send(session, ID.SC_PACKAGE_SYNC, synctype=1,
                       itemlist=equip.package_add_payload(added, role))
        # 【v1.0.3】无条件推权威余额：即使这一抽只有道具、或什么都没中，
        # 也必须把「已扣 cost 钻」的结果刷回客户端。原实现只在有货币/经验奖时
        # 才推，客户端会停留在本地预演的余额上，重开面板又变回去 = 不消耗。
        _safe_send(session, ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                   diamond=role.diamond)
        if gold or honor or gem or exp or pool_win:
            from .handlers import _property_of
            try:
                _safe_send(session, ID.SC_USER_INFO, roleid=role.roleid,
                           property=_property_of(role))
            except Exception:
                log.exception("转盘推 ScUserInfo 失败 role=%s", role.name)
        if ranked:
            from .handlers import push_lobby_state
            push_lobby_state(session, role)

        # 中奖全服播报（Text 10001 奖池大奖 / Text 10002 实物大奖）
        from . import tasks
        tasks.record(role, task_type=tasks.ROULETTE, live_type=tasks.LIVE_ROULETTE, session=session)
        for r in results:
            broadcast_lottery_win(role, r["id"], r["value"])

        # 幸运积分：**每抽 20 分，十连 200 分**（原来一次请求只加 20，
        # 十连也只给 20 —— 这就是「十连积分给的不对」）。
        try:
            from . import exchange as _ex
            _ex.add_tickets(role, points * len(results))
            _ex.send_tickets(session, role)
        except Exception:
            (log.debug("发幸运积分失败", exc_info=True) if log.isEnabledFor(10) else None)

        # 奖池数额 / 中奖名单变了，推一次让面板上的「奖池大奖」跟着变。
        try:
            _send_info(session, role, plate)
        except Exception:
            (log.debug("推转盘信息失败", exc_info=True) if log.isEnabledFor(10) else None)

    except Exception:
        log.exception("转盘发奖阶段异常 role=%s", getattr(role, "name", "?"))


# --------------------------------------------------------------------------
# 神秘转盘（RoulettePlate.Type.Advanced / PromoteLegend）
#
# 和幸运转盘是两套完全独立的系统：
#
#   页签      RoulettePlate.Type.Advanced      控件 AdvancedMachine / AdvancedCell
#   门槛      VIP >= 3（Text 519）             玩法 8 格，抽中即锁定；可花金币刷新
#   门槛      Text 580「神秘转盘有机会获得传奇武器改装卡」
#
# 格子数 8 是**从资源包读出来的**，不是猜的（tools/read_roulette_cells.py）：
#   MainUI.unity3d -> PlateAdvance -> Roulette -> Prize1..Prize8
# 三个独立证据都指向 8：
#   1) 预制体里正好 8 个 Prize 节点（PlateNormal/PlateConstant 是 14 个）
#   2) LotteryPrice 表正好 8 行（100/160/260/380/460/680/880/1280）
#   3) SuperLottery 表正好 8 行
#
# 为什么必须确认：AdvancedMachine.Fill 是按顺序写定长数组的
#     cells[num].Fill(id, posids.Contains(num));
# 发多了直接 IndexOutOfRangeException **崩客户端**。
#
# 奖品 id 由服务端决定（machine.Fill(advancedGifts, ...)，而 advancedGifts 来自
# ScGoldenLotteryInfo.lotterys）。AdvancedCell.Fill(id) -> Refresh() 里是
#     GemLottery g = GameData.GetGemLottery(lotteryid);
# 所以 lotterys 里放的是 **GemLottery 的 id**。
# --------------------------------------------------------------------------
ADVANCED_CELLS = 8

# 8 个奖品格。id 25/26/27 有明确依据：
#   25 = type 4, Icon_LegendCard, broadcast=1 —— Text 580 说的传奇武器改装卡，
#        客户端里 `if (lotteryid == 25)` 还有专门的特判
#   26/27 = type 5, broadcast=1
# 其余 5 个从 type 3 里取（那批是全表时长最长的顶级物品，1296000 秒）。
# 这一条是**推断**，要调就改这里。
ADVANCED_POOL = (25, 26, 27, 28, 29, 30, 31, 32)


def _adv_state(role) -> Dict[str, Any]:
    st = (role.data or {}).get("adv_lottery")
    if not isinstance(st, dict) or not st.get("gifts"):
        st = {"gifts": list(ADVANCED_POOL), "finished": []}
        _save(role, st)
    st.setdefault("finished", [])
    # 【v46】`finished` 必须去重、去越界。历史上出现过重复的 pos
    # （客户端 ScGoldenLottery 只在 `IndexOf(pos)==-1` 时才记录，
    # 服务端却无条件追加），重复项会让「8 格都抽过了」判定失败 ——
    # `free` 还剩一个，于是再点一次就按第 9 档价格（表里没有 → 回落到
    # 第 1 档 = 100 钻）白扣一次钻石，客户端还因为 pos 重复而不播动画。
    clean: List[int] = []
    for v in st["finished"]:
        try:
            i = int(v)
        except (TypeError, ValueError):
            continue
        if 0 <= i < ADVANCED_CELLS and i not in clean:
            clean.append(i)
    st["finished"] = clean
    return st


def _save(role, st: Dict[str, Any]) -> None:
    if _world is not None:
        _world.merge_role_data(role.roleid, adv_lottery=st)


def _lottery_price(index: int) -> int:
    """LotteryPrice[id].price —— 客户端按 finishedGifts.Count + 1 取。

    【v46】越界必须返回**最后一档**（1280），不能回落第 1 档（100）。
    客户端 `GameData.GetLotteryPrice` 的兜底是 `lotteryPrices[1]`（= 100），
    服务端原来也跟着回落 —— 于是「8 格抽完后再点一下」会按 100 钻
    白扣一次。真实抽奖只会用到 1..8 档，这里只是防御。
    """
    rows = {int(r.get("id") or 0): r for r in gamedata.table("LotteryPrice")}
    row = rows.get(int(index))
    if row is None:
        row = rows[max(rows)] if rows else {}
    try:
        return max(0, int(row.get("price") or 0))
    except (TypeError, ValueError):
        return 0


def _reset_cost() -> int:
    """刷新花费。OnRefreshAdvance 里检查 UserManager.GetMoney() < 500 -> 提示 579。"""
    return 500


def send_advanced_info(session: Session, role) -> None:
    """ScGoldenLotteryInfo —— lotterys 是 list<int>（GemLottery id），不是结构体列表。"""
    st = _adv_state(role)
    gifts = [int(i) for i in st["gifts"]][:ADVANCED_CELLS]
    session.send(ID.SC_GOLDEN_LOTTERY_INFO, lotterys=gifts,
                 finishids=[int(i) for i in st["finished"]])


def _unlock_advanced(session: Session, role) -> None:
    """神秘转盘面板靠 `ScGoldenLotteryInfo -> OnAdvancedGifts -> FixButtons(true)`
    解锁；任何异常路径都必须补推一次，否则全游戏 UI 都点不动。
    """
    if role is None or session is None:
        return
    try:
        send_advanced_info(session, role)
    except Exception:
        log.exception("神秘转盘解锁回包失败 role=%s", getattr(role, "name", "?"))
        try:
            session.send(ID.SC_GOLDEN_LOTTERY_INFO,
                         lotterys=list(ADVANCED_POOL), finishids=[])
        except Exception:
            log.exception("神秘转盘兜底回包也失败")


@ROUTER.register(ID.CS_GOLDEN_LOTTERY_RESET, "shop.CsGoldenLotteryReset")
async def on_golden_reset(session: Session, msg: dict) -> None:
    """刷新奖池。外层兜底：无论成败都推一次 ScGoldenLotteryInfo 解锁按钮。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    try:
        await _golden_reset_impl(session, msg)
    except Exception:
        log.exception("神秘转盘刷新异常 role=%s", getattr(session, "roleid", 0))
    finally:
        _unlock_advanced(session, role)


async def _golden_reset_impl(session: Session, msg: dict) -> None:
    """刷新奖池（OnRefreshAdvance / 抽满后 GiftEmpty 自动触发）。

    刷新收费：`UserManager.GetMoney() < 500` 时客户端拦在本地（Callboard.Show(579)），
    服务端也要收，否则改个客户端就能白刷。
    """
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    cost = _reset_cost()
    st = _adv_state(role)
    # 抽满了是免费自动刷新；没抽满才算主动刷新
    full = len(st["finished"]) >= ADVANCED_CELLS
    if not full and role.money < cost:
        send_advanced_info(session, role)
        return
    if not full:
        role.money -= cost
        if _world is not None:
            _world.update_role(role.roleid, money=role.money)

    st = {"gifts": list(ADVANCED_POOL), "finished": []}
    _save(role, st)
    (log.info("role %s 神秘转盘刷新%s -> %d 格", role.name,
             "(免费)" if full else f"(-{cost}钞票)", len(st["gifts"])) if log.isEnabledFor(20) else None)
    send_advanced_info(session, role)
    if not full:
        session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                     diamond=role.diamond)


@ROUTER.register(ID.CS_GOLDEN_LOTTERY, "shop.CsGoldenLottery")
async def on_golden(session: Session, msg: dict) -> None:
    """抽一格。外层兜底：无论成败都推一次 ScGoldenLotteryInfo 解锁按钮。"""
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    try:
        await _golden_impl(session, msg)
    except Exception:
        log.exception("神秘转盘抽奖异常 role=%s", getattr(session, "roleid", 0))
    finally:
        _unlock_advanced(session, role)


async def _golden_impl(session: Session, msg: dict) -> None:
    """抽一格。

    协议语义（ActivityManager）：
        if (finishedGifts.IndexOf(lottery.pos) == -1) finishedGifts.Add(lottery.pos);

    `pos` 是**抽中的格子序号**（0..7），不是奖品 id —— 客户端拿它锁定该格，
    并让指针停在那一格（RoulettePanel.OnFinishedGift -> machine.Startup(id, GiftPos)）。
    """
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    st = _adv_state(role)
    finished = [int(i) for i in st["finished"]]
    free = [i for i in range(ADVANCED_CELLS) if i not in finished]
    if not free:
        # 【v46】8 格已全部抽完：**直接免费换一盘**，绝不再收费。
        # 客户端 PlateCompleted 会自己发 CsGoldenLotteryReset，正常情况下
        # 走不到这里；但客户端与服务端一旦错位（例如旧版本留下的重复 pos），
        # 这里就是最后一道保险 —— 宁可白送一盘，也不能白扣钻石。
        st = {"gifts": list(ADVANCED_POOL), "finished": []}
        _save(role, st)
        (log.info("role %s 神秘转盘已抽满，免费换盘（未扣费）", role.name) if log.isEnabledFor(20) else None)
        send_advanced_info(session, role)
        return

    price = _lottery_price(len(finished) + 1)
    if role.gold < price:
        (log.info("role %s 神秘转盘金币不足 (%s < %s)", role.name, role.gold, price) if log.isEnabledFor(20) else None)
        session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                     diamond=role.diamond)
        # 客户端点「抽取」时已经把按钮全禁用了，只有 ScGoldenLotteryInfo
        # 能让它恢复（OnAdvancedGifts -> FixButtons(true)）。少这一条，
        # 钻石不够时整个面板会卡死。
        send_advanced_info(session, role)
        return
    role.gold -= price
    if _world is not None:
        _world.update_role(role.roleid, gold=role.gold)

    # 【v47】神秘转盘也送幸运积分：**每消耗 10 钻石 = 1 积分**
    # （和幸运转盘共用 exchange.exchange_tickets，兑换商店读同一份）。
    try:
        pts = int(price) // 10
        if pts > 0:
            from . import exchange as _ex
            _ex.add_tickets(role, pts)
            _ex.send_tickets(session, role)
    except Exception:
        (log.debug("神秘转盘发积分失败", exc_info=True) if log.isEnabledFor(10) else None)

    pos = random.choice(free)
    # 这一格上摆的是哪个 GemLottery
    gifts = [int(i) for i in st["gifts"]][:ADVANCED_CELLS]
    prize_id = gifts[pos] if pos < len(gifts) else 0
    row = next((r for r in gamedata.table("GemLottery")
                if int(r.get("id") or 0) == prize_id), None)
    value = prize_value(row) if row else 0

    session.send(ID.SC_GOLDEN_LOTTERY, pos=int(pos),
                 lottery={"id": int(prize_id), "value": int(value)})

    st["finished"] = finished + [int(pos)]
    _save(role, st)

    # 发奖
    got = _grant_advanced(role, prize_id, value)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    if got:
        from .handlers import push_lobby_state
        push_lobby_state(session, role)
    (log.info("role %s 神秘转盘抽中第 %s 格 id=%s (花费 %s 金币, %s/%s 已抽)",
             role.name, pos, prize_id, price, len(st["finished"]),
             ADVANCED_CELLS) if log.isEnabledFor(20) else None)
    send_advanced_info(session, role)


def _grant_advanced(role, prize_id: int, value: int) -> bool:
    """发神秘转盘的奖：物品进背包，纯货币直接加。"""
    if not prize_id:
        return False
    row = next((r for r in gamedata.table("GemLottery")
                if int(r.get("id") or 0) == prize_id), None)
    if row is None:
        return False
    try:
        itemid = int(row.get("item") or 0)
    except (TypeError, ValueError):
        itemid = 0
    from . import equip
    # **传奇改装卡。** `GemLottery` id=25 是神秘转盘的第一格（type=4,
    # Icon_LegendCard, broadcast=1），但它的 `item` 字段是 0 ——
    # 所以 `_grant_advanced` 原来抽中它等于空奖，什么都不发。
    # 客户端对 `lotteryid == 25` 有专门特判，Text 580 也写着
    # 「神秘转盘有机会获得传奇武器改装卡」，这里补上真实物品。
    if not itemid and int(prize_id) == 25:
        itemid = int(equip.LEGEND_CARD_ID)
    if itemid:
        added = equip.grant_items(role, [itemid], _world)
        if added:
            # 立刻同步背包 + 改装卡张数，否则要重登才看得见
            try:
                sess = (_world.session_of_role(role.roleid) if _world else None)
                if sess is not None and not getattr(sess, "closed", False):
                    sess.send(ID.SC_PACKAGE_SYNC, synctype=1,
                              itemlist=equip.package_add_payload(added, role))
                    if int(itemid) == int(equip.LEGEND_CARD_ID):
                        equip.send_legend_cards(sess, role)
            except Exception:
                (log.debug("神秘转盘发奖同步失败", exc_info=True) if log.isEnabledFor(10) else None)
            return True
    # 只有**纯货币格**才把 value 当钻石发。物品格（item / itemNum 有值）
    # 一律不走这里，否则重复物品/发放失败时会把 itemNum=1 当成 1 钻加回去。
    # 奖池大奖（poolRatio）单独按 value 派发。
    try:
        _itemnum = int(row.get("itemNum") or 0)
        _pool_ratio = int(row.get("poolRatio") or 0)
        _gem = int(row.get("gem") or 0)
        _gold = int(row.get("gold") or 0)
    except (TypeError, ValueError):
        _itemnum = _pool_ratio = _gem = _gold = 0
    if itemid or _itemnum:
        return False
    gain = int(value or 0) if _pool_ratio > 0 else (_gem + _gold)
    if gain > 0:
        role.gold += gain
        if _world is not None:
            _world.update_role(role.roleid, gold=role.gold)
        return True
    return False
