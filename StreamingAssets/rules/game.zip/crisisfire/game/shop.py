"""Shop, gift packs and VIP packs.

Why 商场 was view-only and 英雄级武器 said "请先充值VIP":

    // DepotManager.SendBuy
    GsServer.Instance.Send(new CsBuy(shopid, 1));        // -> ScBuyRet

    // PackPanel.OnBuyPack   (the 传奇/英雄 weapons live in the pack panel)
    if (UserManager.VipStatus < 1)
        Callboard.Show(589);                             // "VIP1以上玩家可购买豪华礼包"
    else
        ActivityManager.GoBuyGift(SelectedGiftId, gift);// -> CsBuyGift

    // UserManager.cs
    public static int VipStatus => RechargeData.vipLevelCurrent;   // default -1!

`RechargeData.vipLevelCurrent` is only ever set by `ScVipCashSync`, which the
server never sent, so it stayed at -1 and every VIP check failed.  One message
fixes the packs, 神秘转盘 (needs >= 3), 超级军备 (needs >= VIP_BIG_GACHA),
world chat and the avatar unlocks.

Note the Gift config sets vip = 0 on all ten packs -- the level-1 gate is
hardcoded in PackPanel, not read from the table.

Gift contents come straight from the client's Gift table:

    level 6  3980钻狂龙   -> 606011 狂龙AWP        (英雄级狙击)
    level 7  3980钻魔龙   -> 404081 魔龙M4A1
    level 8  3980钻炎龙   -> 403081 炎龙AK47
    level 9  4980钻血龙   -> 111101 血龙左轮
    level 10 4980钻屠龙   -> 870211 屠龙尼泊尔
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session
from . import equip, premium_ammo, pve_progress, vip

log = logging.getLogger("crisisfire.shop")


class ID:
    CS_BUY = 1048577
    SC_BUY_RET = 1048578
    SC_CASH_LIST = 1048579

    CS_BUY_GIFT = 1048590
    SC_BUY_GIFT = 1048591
    SC_GIFT_SYNC = 1048592

    CS_BUY_CARD = 1048593
    SC_BUY_CARD = 1048594
    SC_WEEK_CARD_SYNC = 1048597
    SC_VIP_CARD_SYNC = 1048598

    CS_BUY_VIP_GIFT = 1048643
    SC_BUY_VIP_GIFT = 1048644
    SC_VIP_GIFT_SYNC = 1048645

    SC_PACKAGE_SYNC = 983041
    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117

    # 这里原来有个 CS_BUY_ACTOR = 786469，注释写着 CsBuyActor 但 786469 其实是
    # ScSlotMachineAdd（真正的 CsBuyActor 是 786445，由 equipment.py 处理）。
    # 而且它从未被使用 —— 留着只会误导，删掉。


# ScBuyRet.retcode
BUY_OK = 0
# 客户端 `ScBuyRet`：SUCCESS=0 / ERR_NO_MONEY=1 / ERR_LEVEL=2。
# 服务端原来写的是 0/1/2/3，整体错开一位，导致「金币不足」在客户端被
# 当成等级不足、真正的等级不足反而越界。按客户端常量对齐，未知错误
# 统一归到 2（客户端对非 0 都是 Callboard.Show(5)，提示一致）。
BUY_UNKNOWN = 2
BUY_NO_MONEY = 1
BUY_LEVEL = 2
BUY_VIP = 4
BUY_LIMIT = 5


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# config lookups
# --------------------------------------------------------------------------
def shop_row(shopid: int) -> Optional[Dict[str, Any]]:
    return next((r for r in gamedata.table("Shop") if r.get("id") == shopid), None)


def gift_row(giftid: int) -> Optional[Dict[str, Any]]:
    return next((r for r in gamedata.table("Gift")
                 if r.get("giftLevel") == giftid), None)


def vip_gift_row(giftid: int) -> Optional[Dict[str, Any]]:
    return next((r for r in gamedata.table("VIPGift") if r.get("id") == giftid), None)


def card_row(cardid: int) -> Optional[Dict[str, Any]]:
    return next((r for r in gamedata.table("Card") if r.get("id") == cardid), None)


def _as_ids(value) -> List[int]:
    """Gift.item is a LinkedList<int>; accept list / {_items: [...]} / scalar."""
    if value is None:
        return []
    if isinstance(value, dict):
        value = value.get("_items")
    if isinstance(value, list):
        out = []
        for v in value:
            try:
                i = int(v)
            except (TypeError, ValueError):
                continue
            if i > 0:
                out.append(i)
        return out
    try:
        i = int(value)
        return [i] if i > 0 else []
    except (TypeError, ValueError):
        return []


def gift_items(row: Dict[str, Any]) -> List[int]:
    ids = _as_ids(row.get("item"))
    # the head/role lists are cosmetic unlocks handled client-side
    return ids


def gift_ammo_counts(row: Dict[str, Any]) -> Dict[int, int]:
    """礼包里每种弹药的**标注数量**（Gift.ammo 与 Gift.ammoNum 一一对应）。

    截图里 5 个豪华礼包标着 500/500/1000/150/300 发穿甲弹；客户端读的就是
    这两列。原来 `grant_items()` 只把 ammo id 当成普通道具 +1，于是玩家领到
    「1 发」，数量全是假的。
    """
    ids = _as_ids(row.get("ammo"))
    nums = _as_ids(row.get("ammoNum"))
    out: Dict[int, int] = {}
    for i, aid in enumerate(ids):
        n = nums[i] if i < len(nums) else 0
        if aid > 0 and n > 0:
            out[aid] = out.get(aid, 0) + int(n)
    return out


def grant_gift_ammo(role, row: Dict[str, Any], world=None,
                    already: int = 1) -> Dict[int, int]:
    """把礼包的弹药补到 ammoNum，返回 {id: 发放后数量}。

    ``already``：`grant_items()` 已经为礼包里每个 ammo id 加过 1 发（它把
    可叠加道具一律 +1），这里只补差额，避免多发 1 发。
    """
    from . import stackable
    delta = {aid: int(n) - int(already)
             for aid, n in gift_ammo_counts(row).items()
             if int(n) > int(already)}
    if not delta:
        return {}
    return stackable.add_items(role, delta, world)


def gift_ammo_sync(session, row: Dict[str, Any], role) -> None:
    """把弹药的**真实数量**推给客户端（synctype=2 modify）。

    只靠 `SC_PACKAGE_SYNC synctype=1` 的 added 列表不够：玩家早就拥有该弹种
    时它不在 added 里，客户端看到的还是旧的「1 发」。
    """
    ids = list(gift_ammo_counts(row))
    if not ids:
        return
    session.send(ID.SC_PACKAGE_SYNC, synctype=2,
                 itemlist=equip.package_add_payload(ids, role))


# --------------------------------------------------------------------------
# push helpers
# --------------------------------------------------------------------------
def _push_money(session: Session, role) -> None:
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    from .handlers import _property_of
    session.send(ID.SC_USER_INFO, roleid=role.roleid, property=_property_of(role))


def _push_backpack(session: Session, itemids: List[int], role=None) -> None:
    if not itemids:
        return
    session.send(ID.SC_PACKAGE_SYNC, synctype=1,
                 itemlist=equip.package_add_payload(itemids, role))


def owned_gifts(role) -> List[int]:
    try:
        return [int(g) for g in (role.data or {}).get("gifts", [])]
    except (TypeError, ValueError):
        return []


# 【v59】怒龙礼包（4980 钻，Gift.giftLevel=11）：只发枪，**不再**送怒龙芯片。
# 芯片改成怒龙改·38 时由 research._grant_angry_chip 发 1 个（上限 1 个）。
# 因为不再写进 `gifts`，重复购买的去重改用一个独立标记 `gift_bought`。
ANGRY_CHIP_GIFT = 11


def _bought_gifts(role) -> List[int]:
    """已买过、但不写进 gifts 的礼包（目前只有怒龙礼包）。"""
    try:
        return [int(g) for g in (role.data or {}).get("gift_bought", [])]
    except (TypeError, ValueError):
        return []


# 【v50】v49 误把 `Icon_PackN`（图标名）当成 Gift.giftLevel，把服务端
# Gift.json 的龙礼包编号改成了 6炎龙/7魔龙/8血龙/9屠龙/10狂龙，
# 还把存档里已有的芯片按 `{6:10,7:7,8:6,9:8,10:9}` 迁走 —— 结果
# 「买炎龙发血龙枪」。官方编号本来就是 8炎龙/6狂龙/7魔龙/9血龙/10屠龙，
# 两边一致，根本不存在错位。v50 已把 Gift.json 改回官方编号，这里把
# 被 v49 迁过的存档**反向转回**，保证老芯片效果不改归属。
_V49_REMAP_REVERSE = {10: 6, 7: 7, 6: 8, 8: 9, 9: 10}


def migrate_legend_gift_ids(world, role) -> None:
    """撤销 v49 的编号迁移（只对被迁过的账号执行一次）。

    必须在登录推 ScGiftSync / ScPackageSync 之前调用。列表推导对每个元素
    独立查表，避免环形映射被链式覆盖。新账号（没有 v49 marker）不动。
    """
    if world is None or role is None:
        return
    fresh = world.role(role.roleid) or role
    data = dict(fresh.data or {})
    if data.get("legend_gift_ids_v50"):
        return
    if data.get("legend_gift_ids_v49"):
        try:
            old = [int(g) for g in (data.get("gifts") or [])]
        except (TypeError, ValueError):
            old = []
        data["gifts"] = [_V49_REMAP_REVERSE.get(g, g) for g in old]
        (log.info("GIFT-ID-ROLLBACK role=%s 恢复官方编号 %s -> %s",
                 role.name, old, data["gifts"]) if log.isEnabledFor(20) else None)
    data["legend_gift_ids_v50"] = 1
    world.merge_role_data(role.roleid, **data)
    role.data = dict(fresh.data or {})


def owned_vip_gifts(role) -> List[int]:
    try:
        return [int(g) for g in (role.data or {}).get("vip_gifts", [])]
    except (TypeError, ValueError):
        return []


def send_gift_sync(session: Session, role) -> None:
    session.send(ID.SC_GIFT_SYNC, gifts=owned_gifts(role))
    session.send(ID.SC_VIP_GIFT_SYNC, gifts=owned_vip_gifts(role))


def card_bonus(role) -> Dict[str, int]:
    """当前生效的月卡/周卡收益加成。

    `Card.addGold / addExp` 是**百分比**（周卡 30 = 金币与经验各 +30%），
    `addHonorLimit` 是荣誉上限的**点数**。原来服务端只记了到期时间
    （`card_X_until`），收益一项都没接 —— 界面上写的「金币+30% EXP+30%」
    纯属装饰。这里把还在有效期内的卡汇总起来。
    """
    import time
    out = {"addGold": 0, "addExp": 0, "addHonorLimit": 0}
    if role is None:
        return out
    now = int(time.time())
    data = role.data or {}
    for row in gamedata.table("Card"):
        try:
            cardid = int(row.get("id") or 0)
            until = int(data.get(f"card_{cardid}_until", 0) or 0)
        except (TypeError, ValueError):
            continue
        if cardid <= 0 or until <= now:
            continue
        for k in out:
            try:
                out[k] += int(row.get(k) or 0)
            except (TypeError, ValueError):
                continue
    return out


def push_cards(session: Session, role) -> None:
    """登录时把周卡/月卡的到期时间推给客户端。

    客户端 `ActivityManager.weekCardADestTime/weekCardBDestTime` 只由
    `ScWeekCardSync(cardid, desttime)` 写；不推的话周卡界面永远显示
    「未购买」，即使服务端已经记了 `card_X_until`。
    card 2 = 周卡 A，card 3 = 黄金周卡 B（1 是月卡，走充值流程）。
    """
    import time
    now = int(time.time())
    data = role.data or {}
    pve_progress.sync_month(session, role)
    for cardid in (2, 3):
        try:
            until = int(data.get(f"card_{cardid}_until", 0) or 0)
        except (TypeError, ValueError):
            until = 0
        if until > now:
            session.send(ID.SC_WEEK_CARD_SYNC, cardid=cardid, desttime=until - pve_progress.SERVER_EPOCH)


# --------------------------------------------------------------------------
# 商场购买
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_BUY, "shop.CsBuy")
async def on_buy(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        log.warning("CsBuy with no role (%s)", session)
        return

    shopid = int(msg.get("id") or 0)
    count = max(1, int(msg.get("count") or 1))
    row = shop_row(shopid)
    if row and row.get("discount") == 1:
        row = {**row, **{field: (row[field] + 1) // 2 for field in ("gem", "gold", "bloodGem")}}

    if row is None:
        log.warning("CsBuy: unknown shop id %s", shopid)
        session.send(ID.SC_BUY_RET, id=shopid, retcode=BUY_UNKNOWN,
                     gold=role.money, gem=role.gold, honor=role.diamond)
        return

    # unlockLevel is a rank requirement (UserManager.CanBuy checks currency,
    # the UI checks the rank)
    need_rank = int(row.get("unlockLevel") or 1)
    if role.level < need_rank:
        (log.info("role %s rank %s < %s for shop %s", role.name, role.level,
                 need_rank, shopid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_BUY_RET, id=shopid, retcode=BUY_LEVEL,
                     gold=role.money, gem=role.gold, honor=role.diamond)
        return

    item = int(row.get("itemId") or 0)
    if item in premium_ammo.paid_rows():
        if not 1 <= int(msg.get("count") or 0) <= 100:
            _fail(session, role, shopid, BUY_LIMIT, "invalid ammo quantity")
            return
        costs = {key: int(row[field]) * count
                 for key, field in (("coins", "gold"), ("gems", "gem"), ("honor", "bloodGem"))}
        quantity = int(row["subCount"]) * count
        if premium_ammo.count(role, item) + quantity > equip.item_row(item)["maxPile"]:
            _fail(session, role, shopid, BUY_LIMIT, "ammo stack full")
            return
        changes, before = premium_ammo.stock_change(role, {item: quantity})
        try:
            _world.award_local(role.roleid, changes, **{key: -value for key, value in costs.items()})
        except ValueError:
            _fail(session, role, shopid, BUY_NO_MONEY, "insufficient ammo purchase balance")
            return
        session.send(ID.SC_BUY_RET, id=shopid, retcode=BUY_OK,
                     gold=role.money, gem=role.gold, honor=role.diamond)
        premium_ammo.sync_stock(session, role, before)
        _push_money(session, role)
        return

    gold = int(row.get("gold") or 0) * count
    honor = int(row.get("bloodGem") or 0) * count
    gem = int(row.get("gem") or 0) * count

    # 【v55】币种必须和客户端 `UserManager.CanBuy(Shop)` 一一对应：
    #   ItemHelper.isBloodGem → mUserInfo.diamond = role.diamond（荣誉）
    #   ItemHelper.isGem      → mUserInfo.gold    = role.gold   （钻石）
    #   ItemHelper.isVirtual  → mUserInfo.money   = role.money  （金币）
    # 老代码把 `Shop.gold`（金币价）也拿去扣 `role.gold`（钻石），于是
    # 「商城买金币道具不掉金币、反而偷偷扣钻石」——就是玩家报的那个 bug。
    currency = "honor" if honor else ("gem" if gem else "gold")
    if currency == "honor":
        if honor > role.diamond:
            _fail(session, role, shopid, BUY_NO_MONEY, "荣誉点不足")
            return
    elif currency == "gem":
        if gem > role.gold:
            _fail(session, role, shopid, BUY_NO_MONEY, "钻石不足")
            return
    else:
        if gold > role.money:
            _fail(session, role, shopid, BUY_NO_MONEY, "金币不足")
            return

    if currency == "honor":
        role.diamond -= honor
    elif currency == "gem":
        role.gold -= gem
    else:
        role.money -= gold
    _world.update_role(role.roleid, gold=role.gold, money=role.money,
                       diamond=role.diamond)

    itemid = int(row.get("itemId") or 0)
    subcount = max(1, int(row.get("subCount") or 1)) * count
    # 数量必须真的发出去：旧代码只把 `count` 乘进扣款、发货永远 1 件。
    # 可叠加道具（碎片/弹药）靠重复 id 累加计数；唯一装备会去重，多买不亏钱。
    #
    # **可叠加道具的返回值为空 ≠ 发不出货。**
    # `grant_items` 对已拥有的可叠加物品只加计数、不放进 `added`（它按
    # 「新道具」语义返回）。原来这里拿 `not added` 判失败，于是穿甲弹/
    # 碎片第二次购买起会「数量 +30、钱全额退回、还弹购买失败」。
    # 正确判据是「发完之后数量有没有变多」。
    from . import stackable as _stack
    _holder = role
    if _world is not None:
        try:
            _holder = _world.role(role.roleid) or role
        except Exception:
            _holder = role
    _before = _stack.item_count(_holder, itemid) if itemid else 0
    added = (equip.grant_items(role, [itemid] * subcount, _world)
             if itemid else [])
    _after = _stack.item_count(_holder, itemid) if itemid else 0
    grew = bool(itemid) and _after > _before
    if grew and not added:
        # 让 ScPackageSync 能把新数量推给客户端
        added = [itemid]

    # 发不出东西（已拥有 / 道具无效）就别扣钱 —— 否则玩家连点几次就一直掉钱
    if not added:
        if currency == "honor":
            role.diamond += honor
        elif currency == "gem":
            role.gold += gem
        else:
            role.money += gold
        _world.update_role(role.roleid, gold=role.gold, money=role.money,
                           diamond=role.diamond)
        (log.info("role %s 买 shop %s 但没东西可发（已拥有 %s），已退款",
                 role.name, shopid, itemid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_BUY_RET, id=shopid, retcode=BUY_UNKNOWN,
                     gold=role.money, gem=role.gold, honor=role.diamond)
        return

    (log.info("role %s bought shop %s (%s x%s) for %s %s: +%s",
             role.name, shopid, equip.item_name(itemid), subcount,
             {"honor": honor, "gem": gem, "gold": gold}[currency], currency, added) if log.isEnabledFor(20) else None)

    session.send(ID.SC_BUY_RET, id=shopid, retcode=BUY_OK,
                 gold=role.money, gem=role.gold, honor=role.diamond)
    _push_backpack(session, added, role)
    _push_money(session, role)


def _fail(session: Session, role, shopid: int, code: int, why: str) -> None:
    (log.info("purchase refused for %s: %s", role.name, why) if log.isEnabledFor(20) else None)
    # ScBuyRet 的 gold/gem/honor 三个字段就是 Shop 表的 gold/gem/bloodGem，
    # 只有埋点会用；按币种照实回填，别再交叉串。
    session.send(ID.SC_BUY_RET, id=shopid, retcode=code,
                 gold=role.money, gem=role.gold, honor=role.diamond)


# --------------------------------------------------------------------------
# 礼包（含英雄级武器）
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_BUY_GIFT, "shop.CsBuyGift")
async def on_buy_gift(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    giftid = int(msg.get("giftid") or 0)
    row = gift_row(giftid)
    if row is None:
        log.warning("CsBuyGift: unknown gift %s", giftid)
        return

    owned = owned_gifts(role)
    # 【v59】怒龙礼包（4980 钻，giftLevel=11）不再赠送怒龙芯片：
    #   芯片改成「怒龙改·38 才给 1 个、上限 1 个」（research._grant_angry_chip）。
    #   但礼包还得只卖一次，所以单独记一个购买标记，不能再靠 gifts 去重。
    bought = _bought_gifts(role)
    if giftid in owned or giftid in bought:
        (log.info("role %s already owns gift %s", role.name, giftid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_GIFT_SYNC, gifts=owned)
        return

    # PackPanel gates on UserManager.VipStatus >= 1 before it even sends
    if vip.level_of(role) < 1 and vip.cash_of(role) <= 0:
        (log.info("role %s has no VIP; gift %s needs VIP 1", role.name, giftid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_GIFT_SYNC, gifts=owned)
        return

    price = int(row.get("price") or 0)
    # 客户端 `UserManager.CanBuy(Gift)` 比的是 `mUserInfo.gold` —— 也就是
    # **钻石**（服务端字段叫 role.gold）。原来这里扣 role.diamond（荣誉），
    # 有钻石没荣誉的玩家买礼包会被直接拒绝。
    if price > role.gold:
        (log.info("role %s needs %s gem for gift %s (has %s)",
                 role.name, price, giftid, role.gold) if log.isEnabledFor(20) else None)
        session.send(ID.SC_GIFT_SYNC, gifts=owned)
        _push_money(session, role)
        return

    changes, before = premium_ammo.stock_change(role, premium_ammo.gift_deltas(row))
    if int(giftid) == ANGRY_CHIP_GIFT:
        bought.append(int(giftid))
        _world.award_local(role.roleid, {**changes, "gift_bought": bought}, gems=-price)
        (log.info("role %s bought 怒龙礼包 %s（不送芯片，芯片需改·38）",
                 role.name, giftid) if log.isEnabledFor(20) else None)
    else:
        owned.append(giftid)
        _world.award_local(role.roleid, {**changes, "gifts": owned}, gems=-price)
    itemids = gift_items(row)
    added = equip.grant_items(role, itemids, _world)
    premium_ammo.sync_stock(session, role, before)

    (log.info("role %s bought gift %s (%s) for %s diamond: %s",
             role.name, giftid, row.get("name"), price,
             [equip.item_name(i) for i in added] or itemids) if log.isEnabledFor(20) else None)

    session.send(ID.SC_BUY_GIFT, giftid=giftid)
    session.send(ID.SC_GIFT_SYNC, gifts=owned)
    _push_backpack(session, added, role)
    gift_ammo_sync(session, row, role)
    _push_money(session, role)


# --------------------------------------------------------------------------
# 周卡 / 月卡
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_BUY_CARD, "shop.CsBuyCard")
async def on_buy_card(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    cardid = int(msg.get("cardid") or 0)
    if cardid == 1:
        pve_progress.sync_month(session, role, activate=True)
        return
    row = card_row(cardid)
    if row is None:
        log.warning("CsBuyCard: unknown card %s", cardid)
        return

    import time
    price = int(row.get("priceGem") or row.get("price") or 0)
    # 客户端 GoBuyCard 用 `UserManager.GetGem()` = mUserInfo.gold（钻石）
    if price > role.gold:
        (log.info("role %s needs %s gem for card %s", role.name, price, cardid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                     diamond=role.diamond)
        return

    role.gold -= price
    _world.update_role(role.roleid, gold=role.gold)
    until = int(time.time()) + int(row.get("duration") or 0)
    _world.merge_role_data(role.roleid, **{f"card_{cardid}_until": until})

    (log.info("role %s bought card %s for %s diamond until %s",
             role.name, cardid, price, until) if log.isEnabledFor(20) else None)
    session.send(ID.SC_BUY_CARD, cardid=cardid)
    session.send(ID.SC_WEEK_CARD_SYNC, cardid=cardid, desttime=until - pve_progress.SERVER_EPOCH)
    _push_money(session, role)


# --------------------------------------------------------------------------
# VIP 专属礼包
# --------------------------------------------------------------------------
@ROUTER.register(ID.CS_BUY_VIP_GIFT, "shop.CsBuyVIPGift")
async def on_buy_vip_gift(session: Session, msg: dict) -> None:
    role = _world.role(session.roleid) if (_world and session.roleid) else None
    if role is None:
        return
    giftid = int(msg.get("giftid") or 0)
    row = vip_gift_row(giftid)
    if row is None:
        log.warning("CsBuyVIPGift: unknown vip gift %s", giftid)
        return

    owned = owned_vip_gifts(role)
    need = int(row.get("vipLevel") or 0)
    # ActivityManager.CanBuyVipGift: !HasVipGift(gift) && vipLevelCurrent >= level
    if giftid in owned or vip.level_of(role) < need:
        (log.info("vip gift %s needs VIP%s (role %s has VIP%s)", giftid, need,
                 role.name, vip.level_of(role)) if log.isEnabledFor(20) else None)
        session.send(ID.SC_VIP_GIFT_SYNC, gifts=owned)
        return

    price = int(row.get("gem") or 0)
    # 客户端 `CanBuy(VIPGift)` 用 mUserInfo.gold（钻石）
    if price > role.gold:
        session.send(ID.SC_VIP_GIFT_SYNC, gifts=owned)
        _push_money(session, role)
        return

    role.gold -= price
    _world.update_role(role.roleid, gold=role.gold)
    added = equip.grant_items(role, _as_ids(row.get("itemId")), _world)
    owned.append(giftid)
    _world.merge_role_data(role.roleid, vip_gifts=owned)

    (log.info("role %s bought VIP gift %s (VIP%s) for %s diamond: %s",
             role.name, giftid, need, price, added or row.get("info")) if log.isEnabledFor(20) else None)
    session.send(ID.SC_BUY_VIP_GIFT, giftid=giftid)
    session.send(ID.SC_VIP_GIFT_SYNC, gifts=owned)
    _push_backpack(session, added, role)
    _push_money(session, role)
