"""神秘转盘 / 强化点制造机（老虎机）.

协议（客户端 Strengthener / SlotForm）::

    CsSlotMachineStart(786466) {moneytype, multiple}
        -> ScSlotMachineStart(786467) {multiple, selectids[3]}
    CsSlotMachineAdd  (786468) {}                     <- 不带任何字段
        -> ScSlotMachineAdd  (786469) {selectid, remaintimes}
    CsSlotMachineEnd  (786470) {}
        -> ScSlotMachineEnd  (786471) {studypoint}
        -> ScStudyPointSync  (786473) {studypoint}

客户端 `SlotForm.UpdateBase` 的**权威公式**（对齐它才不会「显示 20000、
实际到账 3000」）::

    num  = max(Strengthener.GetOdds(slotCount), 200) * multiple
    num2 = max(Strengthener.GetTopIncome(),   200) * multiple

`multiple` 就是**下注档位倍率**：`CalcMultiple() = amount / PriceGem|PriceHonor`
（PriceGem=1、PriceHonor=Price[8].bloodGem=20），所以
20 荣誉 / 1 钻石 = 1 倍、200 荣誉 / 10 钻石 = 10 倍、100 钻石 = 100 倍。
`GetOdds` 只按图案表 `SlotMachine.win` 算基础值，**乘倍率和 200 保底都在 UI 层**，
所以服务端结算必须自己做这两步。

奖池 `SlotMachine`（7 行 = 7 种图案）::

    id  probability[4]  win[3]  price[3]  premium[2]
    1   [1428,1428,1428,900]  [4000,20000,100000]  [1,1,6]  [1,2]

`win[k]` = 同图案出现 k+2 次时的强化点；`price[sames-1] + premium[appends-1]`
是追加第 4 格的价格（再乘 multiple，且**一律扣钻石**）。
"""
from __future__ import annotations

import logging
import random
from collections import Counter
from typing import Any, Dict, List

from .. import gamedata
from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.slot")

# roleid -> 本次转盘的完整状态。追加第 4 格 / 结算时都要用到档位倍率，
# 而 CsSlotMachineAdd / End **不带任何字段**，所以只能存服务端。
#   {"ids": [3~4 个行 id], "multiple": int, "moneytype": int, "appends": int}
_pending: Dict[int, Dict[str, Any]] = {}

# 对齐 Strengthener.MinGainPoint / MaxGainPoint
MIN_GAIN_POINT = 200
MAX_APPENDS = 3                 # 客户端 AppSurplus 初值


class ID:
    CS_START = 786466
    SC_START = 786467
    CS_ADD = 786468
    SC_ADD = 786469
    CS_END = 786470
    SC_END = 786471
    SC_FAIL = 786472
    SC_STUDY_POINT_SYNC = 786473
    SC_ACOUNT_SYNC = 983043


# 客户端 `Strengthener.CalcMultiple`：
#     multiple = amount / ((moneytype != 1) ? PriceGem : PriceHonor)
#     PriceGem   = 1
#     PriceHonor = Price[8].bloodGem = 20
PRICE_HONOR_ID = 8
PRICE_GEM_UNIT = 1


def _unit_price(moneytype: int) -> int:
    if int(moneytype or 0) == 1:
        for row in gamedata.table("Price"):
            if int(row.get("id") or 0) == PRICE_HONOR_ID:
                return int(row.get("bloodGem") or 20)
        return 20
    return PRICE_GEM_UNIT


def _rows() -> List[Dict[str, Any]]:
    """SlotMachine 的 7 行 = 7 种图案（金徽章/冲锋枪/手枪/护甲/手雷/对讲机/墨镜）。"""
    return gamedata.table("SlotMachine") or []


def _ints(value) -> List[int]:
    if isinstance(value, dict):
        items = value.get("_items") or []
        size = int(value.get("_size") or len(items))
        return [int(x or 0) for x in items[:size]]
    if isinstance(value, list):
        return [int(x or 0) for x in value]
    return []


def _pick(weights: List[int]) -> int:
    total = sum(w for w in weights if w > 0)
    if total <= 0:
        return 0
    roll = random.randint(1, total)
    acc = 0
    for i, w in enumerate(weights):
        acc += max(0, w)
        if roll <= acc:
            return i
    return 0


def _pick_slot(rows: List[Dict[str, Any]], slot_index: int) -> int:
    """从 7 行里按 `probability[slot_index]` 权重挑一个**行 id**（不是图案索引）。

    客户端 `Strengthener.Start(mult, ids)` 直接拿 ids 去 `GetSlot(id)` 查行，
    所以这里必须回**行 id**（1~7），否则 `GetSlot` 查不到、客户端显示的
    预估奖励恒为 0。
    """
    weights = []
    for r in rows:
        prob = _ints(r.get("probability"))
        w = prob[slot_index] if slot_index < len(prob) else (prob[0] if prob else 0)
        weights.append(w)
    idx = _pick(weights)
    if 0 <= idx < len(rows):
        return int(rows[idx].get("id") or 0)
    return int(rows[0].get("id") or 0) if rows else 0


def _settle_points(rows: List[Dict[str, Any]], ids: List[int]) -> int:
    """图案基础值：出现 2 次 -> win[0]，3 次 -> win[1]，4 次 -> win[2]。

    对齐客户端 `Strengthener.GetOdds`（`num += slot.win[出现次数 - 2]`）。
    **不含 200 保底、不含档位倍率**，那两步在 `_final_points` 做。
    """
    by_id = {int(r.get("id") or 0): r for r in rows}
    points = 0
    for sid, n in Counter(ids).items():
        if n < 2:
            continue
        row = by_id.get(int(sid))
        if not row:
            continue
        win = _ints(row.get("win"))
        k = min(n - 2, len(win) - 1)
        if 0 <= k < len(win):
            points += int(win[k] or 0)
    return points


def _final_points(rows: List[Dict[str, Any]], ids: List[int],
                  multiple: int) -> int:
    """对齐 `SlotForm.UpdateBase`：`max(GetOdds, 200) * multiple`。"""
    base = _settle_points(rows, ids)
    return max(int(base or 0), MIN_GAIN_POINT) * max(1, int(multiple or 1))


def _max_slot4(rows: List[Dict[str, Any]], ids: List[int]) -> int:
    """对齐 `Strengthener.GetMaxSlot4()`：追加第 4 格「最能赚」的图案 id。"""
    head = list(ids[:3])
    if not head:
        return 0
    cnt = Counter(head)
    best_id, best_n = 0, 0
    for sid, n in cnt.items():
        if n > best_n:
            best_id, best_n = int(sid), n
    if best_n > 1:
        return best_id
    by_id = {int(r.get("id") or 0): r for r in rows}

    def _win0(sid: int) -> int:
        win = _ints(by_id.get(int(sid), {}).get("win"))
        return int(win[0] or 0) if win else 0

    return max(head, key=_win0)


def _append_price(rows: List[Dict[str, Any]], ids: List[int],
                  appends: int, slot4id: int) -> int:
    """对齐 `Strengthener.GetAppendPrice(sames, slot4id, appends)`。"""
    by_id = {int(r.get("id") or 0): r for r in rows}
    row = by_id.get(int(slot4id)) or (rows[0] if rows else {})
    head = list(ids[:3])
    sames = max(1, min(3, max(Counter(head).values()) if head else 1))
    price = _ints(row.get("price"))
    premium = _ints(row.get("premium"))
    base = price[sames - 1] if sames - 1 < len(price) else 1
    extra = 0
    if appends > 0 and appends - 1 < len(premium):
        extra = int(premium[appends - 1] or 0)
    return max(1, int(base) + extra)


def _charge_gems(session: Session, role, world, cost: int) -> bool:
    """追加第 4 格一律扣钻石（客户端追加按钮画的是钻石图标）。"""
    if int(getattr(role, "gold", 0) or 0) < int(cost):
        session.send(ID.SC_FAIL, result=1)
        return False
    role.gold -= int(cost)
    world.update_role(role.roleid, gold=role.gold, diamond=role.diamond)
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)
    return True


@ROUTER.register(ID.CS_START, "equip.CsSlotMachineStart")
async def on_slot_start(session: Session, msg: Dict[str, Any]) -> None:
    from . import handlers

    world = handlers.world
    role = world.role(session.roleid) if (world and session.roleid) else None
    if role is None:
        return
    # `moneytype` 的合法值是 **0（钻石）** 和 1（荣誉）—— 不能写
    # `int(msg.get("moneytype") or 1)`：0 是 falsy，会被当成 1，钻石档全走成荣誉档。
    raw_type = msg.get("moneytype")
    moneytype = 1 if raw_type is None else int(raw_type)
    multiple = max(1, int(msg.get("multiple") or 1))
    rows = _rows()
    unit = _unit_price(moneytype)
    cost = max(1, unit) * multiple

    # **货币映射以客户端为准**（Strengthener.CheckAccount）：
    #     moneytype == 1 -> GetHornor() = userInfo.diamond（荣誉）
    #     moneytype == 0 -> GetGem()    = userInfo.gold   （钻石）
    if moneytype == 1:
        if role.diamond < cost:
            (log.info("转盘荣誉不足 role=%s 需要 %s", role.name, cost) if log.isEnabledFor(20) else None)
            session.send(ID.SC_FAIL, result=1)
            return
        role.diamond -= cost
    else:
        if role.gold < cost:
            (log.info("转盘钻石不足 role=%s 需要 %s", role.name, cost) if log.isEnabledFor(20) else None)
            session.send(ID.SC_FAIL, result=1)
            return
        role.gold -= cost
    world.update_role(role.roleid, gold=role.gold, diamond=role.diamond)
    # 客户端点「下注」只做 CheckAccount，不会本地扣钱 —— 必须推余额
    session.send(ID.SC_ACOUNT_SYNC, gold=role.gold, money=role.money,
                 diamond=role.diamond)

    # 三个转轮（主格）各自独立挑一个**行 id**（1~7），允许重复。
    ids = [_pick_slot(rows, i) for i in range(3)]
    # `ScSlotMachineStart.multiple` 必须回传正确档位倍率：客户端
    # `Strengthener.Start(mult, ids)` 会用它重设 `multiple`，UI 的
    # 收益预估 / 追加价都读这个字段。
    session.send(ID.SC_START, multiple=multiple, selectids=ids)

    _pending[int(role.roleid)] = {
        "ids": list(ids), "multiple": multiple,
        "moneytype": moneytype, "appends": 0,
    }
    (log.info("转盘 role=%s moneytype=%s x%s -> %s 花费 %s 预估 %s 点",
             role.name, moneytype, multiple, ids, cost,
             _final_points(rows, ids, multiple)) if log.isEnabledFor(20) else None)
    from . import tasks
    tasks.record(role, task_type=tasks.MANUFACTURE, live_type=tasks.LIVE_MANUFACTURE, session=session)


@ROUTER.register(ID.CS_END, "equip.CsSlotMachineEnd")
async def on_slot_end(session: Session, msg: Dict[str, Any]) -> None:
    """「收取强化点」：`max(图案基础值, 200) * 档位倍率` 写库并推同步。"""
    roleid = int(session.roleid or 0)
    rows = _rows()
    state = _pending.pop(roleid, None)
    if not state:
        session.send(ID.SC_END, studypoint=0)
        return
    points = _final_points(rows, list(state.get("ids") or []),
                           int(state.get("multiple") or 1))
    if points > 0:
        from . import handlers, stackable
        world = handlers.world
        role = world.role(roleid) if (world and roleid) else None
        if role is not None:
            total = stackable.add_study_point(role, points, world)
            session.send(ID.SC_STUDY_POINT_SYNC, studypoint=total)
            (log.info("转盘结算 role=%s 强化点 +%s -> %s (x%s, ids=%s)",
                     roleid, points, total, state.get("multiple"),
                     state.get("ids")) if log.isEnabledFor(20) else None)
    session.send(ID.SC_END, studypoint=points)


@ROUTER.register(ID.CS_ADD, "equip.CsSlotMachineAdd")
async def on_slot_add(session: Session, msg: Dict[str, Any]) -> None:
    """「追加」第 4 个转轮：扣钻石 + 回传结果 + 剩余追加次数。"""
    from . import handlers

    roleid = int(session.roleid or 0)
    state = _pending.get(roleid)
    if not state:
        session.send(ID.SC_ADD, selectid=0, remaintimes=0)
        return
    rows = _rows()
    ids = list(state.get("ids") or [])
    multiple = max(1, int(state.get("multiple") or 1))
    appends = int(state.get("appends") or 0)
    if appends >= MAX_APPENDS:
        session.send(ID.SC_ADD, selectid=0, remaintimes=0)
        return

    # 追加价 = GetAppendPrice(sames, maxSlot4, appends) * multiple（钻石）
    slot4id = _max_slot4(rows, ids)
    unit = _append_price(rows, ids, appends, slot4id)
    cost = max(1, unit) * multiple
    world = handlers.world
    role = world.role(roleid) if (world and roleid) else None
    if role is None or not _charge_gems(session, role, world, cost):
        (log.info("转盘追加钻石不足 role=%s 需要 %s", roleid, cost) if log.isEnabledFor(20) else None)
        return

    sid = _pick_slot(rows, 3)
    if sid:
        if len(ids) >= 4:
            ids[3] = sid           # 第 2/3 次追加：重转第 4 格
        else:
            ids.append(sid)        # 第 1 次追加：开启第 4 格
    appends += 1
    state["ids"] = ids
    state["appends"] = appends
    remaintimes = max(0, MAX_APPENDS - appends)
    session.send(ID.SC_ADD, selectid=sid, remaintimes=remaintimes)
    (log.info("转盘加注 role=%s 图案=%s 扣钻 %s 累计 %s 预估 %s 点 剩余 %s",
             roleid, sid, cost, ids,
             _final_points(rows, ids, multiple), remaintimes) if log.isEnabledFor(20) else None)
