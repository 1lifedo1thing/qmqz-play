"""房间社交：邀请好友 + 投票踢人.

两条链路客户端都有消息、服务端原来一条 handler 都没有（点了没反应）。

邀请（客户端 InviteListMgr / CMGEInviteeMgr）::

    CsEnableInvite(1245213) {roleid, enabled, roomid}   -> 只记标记
    CsInvite(1245195)       {id, roomid}                -> 给目标推 ScInviteInfo

投票踢人（客户端 VoteManager）::

    CsVoteKickout(1245255)         {roomid, kickoutid, reason}
        -> ScVoteKickoutRes(1245256) {roomid, result}    发起是否成功
        -> ScVoteKickoutInfo(1245257) {voteid, kickid, reason, neednum, remaintime}  广播
    CsVoteKickoutResponse(1245258) {roomid, response}    每人一票
        -> ScVoteKickoutFinal(1245261) {kickid, result}  1 通过 / 0 否决
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from ..net.server import ROUTER, Session
from . import rooms as R

log = logging.getLogger("crisisfire.social")


class ID:
    CS_INVITE = 1245195
    SC_INVITE_INFO = 1245196
    CS_REJECT = 1245197
    SC_REJECT = 1245198
    CS_ENABLE_INVITE = 1245213
    CS_VOTE_KICKOUT = 1245255
    SC_VOTE_KICKOUT_RES = 1245256
    SC_VOTE_KICKOUT_INFO = 1245257
    CS_VOTE_KICKOUT_RESPONSE = 1245258
    SC_VOTE_KICKOUT_FINAL = 1245261
    SC_KICKOUT = 1245199


# 一票有效时间（秒）—— 客户端用 remaintime 做倒计时
VOTE_SECONDS = 30

# roomid -> {"voteid", "kickid", "reason", "votes": {roleid: 0/1}, "until"}
_votes: Dict[int, Dict[str, Any]] = {}

_next_vote_id = [1]


def _world():
    from . import handlers
    return handlers.world


def _room_of(session: Session) -> Optional[R.Room]:
    from . import room_handlers as _rh
    if not session.roleid:
        return None
    return _rh.MANAGER.room_of(int(session.roleid))


def _member_name(roleid: int) -> str:
    world = _world()
    if world is None:
        return ""
    role = world.role(roleid)
    return getattr(role, "name", "") if role is not None else ""


# ---------------------------------------------------------------------- 邀请
@ROUTER.register(ID.CS_ENABLE_INVITE, "fight.CsEnableInvite")
async def on_enable_invite(session: Session, msg: Dict[str, Any]) -> None:
    """房主把成员设为/取消「助理」= PlayerInfo.flags bit 1。

    客户端链路（BattleRoomDialog.onUpgrade）：

        FightManager.EnableInvite(roleid, !isAssistant ? 1 : 0, roomid);
        // 之后成员卡片用 CurrentRoom.CanInvited(roleid) 判断画不画助理图标：
        //   return userInfo != null && (userInfo.playerInfo.flags & 2) > 0;

    原来这里只往一个没人读的 `_invite_enabled` 字典里写标记，flags 一位都不
    改 —— 所以客户端上点「设为助理」完全没反应。
    """
    room = _room_of(session)
    if room is None:
        return
    if int(session.roleid or 0) != room.owner:
        (log.info("role %s 想改房间 %s 的邀请权限，但不是房主",
                 session.roleid, room.roomid) if log.isEnabledFor(20) else None)
        return
    roleid = int(msg.get("roleid") or 0)
    member = room.members.get(roleid)
    if member is None or roleid == room.owner:
        return
    member.invite = bool(int(msg.get("enabled") or 0))
    from . import room_handlers as _rh
    _rh._broadcast(room, _rh.ID.SC_SYNC_PLAYER_FLAG, roleid=member.roleid,
                   flags=member.flags(), side=member.side)
    (log.info("房间 %s：role %s 邀请权限(助理)=%s",
             room.roomid, roleid, member.invite) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_INVITE, "fight.CsInvite")
async def on_invite(session: Session, msg: Dict[str, Any]) -> None:
    target = int(msg.get("id") or msg.get("roleid") or 0)
    roomid = int(msg.get("roomid") or 0)
    room = _room_of(session)
    if room is None or room.roomid != roomid:
        (log.info("邀请失败：roomid=%s 不属于 %s", roomid, session) if log.isEnabledFor(20) else None)
        return
    if target <= 0 or target == int(session.roleid or 0) \
            or target in room.members:
        return
    world = _world()
    if world is None:
        return
    target_session = (world.session_of_role(target, "gs")
                      or world.session_of_role(target))
    if target_session is None or target_session.closed:
        (log.info("邀请失败：role %s 不在线", target) if log.isEnabledFor(20) else None)
        return
    inviter = int(session.roleid or 0)
    role = world.role(inviter)
    # ScInviteInfo.inviterinfo 是 **com.gwebtop.friend.BasicInfo**
    # {rank, exp, name, iconid}，不是 PlayerInfo —— 以前塞了 prop/subjoins/
    # flags/side 那一套，字段名全对不上，客户端收到的是 rank=0 name=""。
    info = {
        "rank": int(getattr(role, "level", 1) or 1),
        "exp": int(getattr(role, "exp", 0) or 0),
        "name": getattr(role, "name", "") if role is not None else "",
        "iconid": int(getattr(role, "iconid", 0) or 0),
    }
    target_session.send(
        ID.SC_INVITE_INFO,
        inviter=inviter,
        inviterinfo=info,
        roomid=room.roomid,
        gamemode=int(room.gamemode or 0),
        isquingifying=0,
        pwd=room.password or "",
    )
    (log.info("role %s 邀请 role %s 进房间 %s", inviter, target, roomid) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_REJECT, "fight.CsReject")
async def on_reject_invite(session: Session, msg: Dict[str, Any]) -> None:
    """被邀请人点「拒绝」→ ScReject 回到邀请人（FightManager.Response）。"""
    inviter = int(msg.get("inviter") or 0)
    if inviter <= 0 or inviter == int(session.roleid or 0):
        return
    world = _world()
    if world is None:
        return
    peer = (world.session_of_role(inviter, "gs")
            or world.session_of_role(inviter))
    if peer is not None and not peer.closed:
        peer.send(ID.SC_REJECT, rejector=int(session.roleid or 0))
    (log.info("role %s 拒绝了 role %s 的邀请", session.roleid, inviter) if log.isEnabledFor(20) else None)


# ---------------------------------------------------------------------- 投票
@ROUTER.register(ID.CS_VOTE_KICKOUT, "fight.CsVoteKickout")
async def on_vote_kickout(session: Session, msg: Dict[str, Any]) -> None:
    room = _room_of(session)
    if room is None:
        return
    kickid = int(msg.get("kickoutid") or 0)
    if kickid not in room.members or kickid == room.owner:
        session.send(ID.SC_VOTE_KICKOUT_RES, roomid=room.roomid, result=0)
        (log.info("投票踢人失败：kickid=%s 不在房间或是房主", kickid) if log.isEnabledFor(20) else None)
        return
    if room.roomid in _votes:
        session.send(ID.SC_VOTE_KICKOUT_RES, roomid=room.roomid, result=0)
        return
    voteid = _next_vote_id[0]
    _next_vote_id[0] += 1
    need = max(1, (len(room.members) + 1) // 2)     # 过半
    _votes[room.roomid] = {
        "voteid": voteid, "kickid": kickid,
        "reason": str(msg.get("reason") or ""),
        "votes": {}, "need": need,
        "until": time.time() + VOTE_SECONDS,
    }
    session.send(ID.SC_VOTE_KICKOUT_RES, roomid=room.roomid, result=1)
    _broadcast_info(room)
    (log.info("房间 %s 发起投票踢人 voteid=%s kickid=%s 需要 %s 票",
             room.roomid, voteid, kickid, need) if log.isEnabledFor(20) else None)


def _broadcast_info(room: R.Room) -> None:
    from . import room_handlers as _rh
    v = _votes.get(room.roomid)
    if not v:
        return
    remain = max(1, int(v["until"] - time.time()))
    _rh._broadcast(room, ID.SC_VOTE_KICKOUT_INFO,
                   voteid=v["voteid"], kickid=v["kickid"], reason=v["reason"],
                   neednum=v["need"], remaintime=remain)


@ROUTER.register(ID.CS_VOTE_KICKOUT_RESPONSE, "fight.CsVoteKickoutResponse")
async def on_vote_response(session: Session, msg: Dict[str, Any]) -> None:
    from . import room_handlers as _rh
    room = _room_of(session)
    if room is None:
        return
    v = _votes.get(room.roomid)
    if not v:
        return
    roleid = int(session.roleid or 0)
    v["votes"][roleid] = int(msg.get("response") or 0)
    yes = sum(1 for x in v["votes"].values() if x)
    if yes >= v["need"]:
        _finish(room, v, yes)
        return
    if time.time() > v["until"]:
        _finish(room, v, yes)
        return
    _broadcast_info(room)


def _finish(room: R.Room, v: Dict[str, Any], yes: int) -> None:
    from . import room_handlers as _rh
    passed = yes >= v["need"]
    _votes.pop(room.roomid, None)
    _rh._broadcast(room, ID.SC_VOTE_KICKOUT_FINAL, kickid=v["kickid"],
                   result=1 if passed else 0)
    (log.info("房间 %s 投票结束 kickid=%s 赞成 %s/%s -> %s",
             room.roomid, v["kickid"], yes, v["need"], "通过" if passed else "否决") if log.isEnabledFor(20) else None)
    if not passed:
        return
    left = _rh.MANAGER.leave(room.roomid, v["kickid"])
    if left is not None:
        _rh._broadcast(left, ID.SC_REMOVE_PLAYER, roleid=v["kickid"])
    s = _world().session_of_role(v["kickid"]) if _world() is not None else None
    if s is not None and not s.closed:
        s.send(ID.SC_KICKOUT, roomid=room.roomid)
