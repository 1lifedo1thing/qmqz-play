"""Equipment variants of team combat, from the 1.8.1 SpecialRule table."""
from functools import lru_cache

from .. import gamedata

DAGGER = 1
PISTOL = 2
GRENADE = 3
WEAPON_SLOTS = (11, 12, 41, 42, 50)


@lru_cache(maxsize=None)
def rule(limit: int):
    return next((row for row in gamedata.table("SpecialRule") if row["id"] == limit), None)


@lru_cache(maxsize=1)
def _item_subtypes():
    return {row["id"]: row.get("subType") for row in gamedata.table("Item")}


def equipmap(equipment: dict, limit: int) -> dict:
    """Mirror VirtualServer.LimitEquip, keeping the original knife fallback."""
    special = rule(limit)
    if not limit or not special:
        return equipment
    result = dict(equipment)
    if special["mainEquipArgs"] == -1 or _item_subtypes().get(result.get(11)) != special["mainEquipType"]:
        result.pop(11, None)
    if special["viceEquipArgs"] == -1:
        result.pop(12, None)
    if special["grenadeArgs"] == -1:
        result.pop(41, None)
    result.pop(42, None)
    return result


def held_slot(equipment: dict) -> int:
    return next((slot for slot in WEAPON_SLOTS if equipment.get(slot)), 0)


def kill_target(game_rule: dict, limit: int, capacity: int) -> int:
    """DataPool.WinKillCount uses integer scaling by total room capacity."""
    special = rule(limit) if limit else None
    count = special["num"] if special else game_rule.get("winKillCount", 0)
    return int(count or 0) * capacity // 8
