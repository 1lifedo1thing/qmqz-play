"""生化房人类 BOT 的小队行为（抱团 / 坚守 / 被打散后重新汇合）。

用户口径（v57）：

* 开局 8 人散落在全图随机点，7 个 BOT 都是「落单」，会主动向最近的同伴靠；
* 任意两个 BOT 水平距离 <= SQUAD_JOIN(5m) —— 也就是「半径 5m 内有包括
  自己在内的 2 个以上」—— 即判定形成小队；成队后**不再主动抱团**，
  只在队心 SQUAD_HOLD(4.5m) 内小范围坚守；
* 落单的人类 BOT 被僵尸追时，撤退方向优先规划到最近的小队；
* 小队被打散（成员死亡 / 被冲开）剩下的成员自动回到落单，重新找人。

这里只做「谁和谁是一队」的划分，不碰移动/开火；具体走位由 bots 用
`center` 当 `pick_patrol(anchor=…)` 的锚点、用 `pick_retreat(toward=…)`
的汇合方向来落地。划分本身带迟滞（散伙半径 > 成队半径），否则站在
5m 边缘的两个 BOT 会一秒内组队/散伙几十次，表现是原地抽搐。
"""

from __future__ import annotations

import math
from typing import Dict, Mapping

SQUAD_JOIN = 5.0        # 成队半径（水平）
SQUAD_KEEP = 9.0        # 迟滞：已成队的两人在 9m 内不算散伙
SQUAD_HOLD = 4.5        # 坚守半径：小队成员只在队心这么大范围内活动
SQUAD_MAX = 4           # 一个小队最多收几个人
SQUAD_LEVEL = 1.8       # 必须同一层才算同队（跨楼层不算抱团）
SQUAD_SEEK_MAX = 90.0   # 落单者最远愿意跨图汇合的直线距离
SQUAD_REFRESH = 0.45    # 重新划分的间隔（秒），10Hz 下每 4~5 帧一次


def _xz(a, b) -> float:
    return math.hypot(float(a[0]) - float(b[0]), float(a[2]) - float(b[2]))


def _level(a, b) -> float:
    return abs(float(a[1]) - float(b[1]))


def _recent_pairs(battle) -> Dict[int, frozenset]:
    prev = getattr(battle, "_bio_squad_prev", None)
    return prev if isinstance(prev, dict) else {}


def _cluster(positions: Mapping[int, tuple], prev: Dict[int, frozenset],
             cap: int = SQUAD_MAX):
    """按「最近的先合并」聚类，每组最多 cap 人。

    顺序很重要：按 rid 顺序 union 会让「先遇到的两个远的人」抢先成组，
    剩下真正挨着的两个人反而被 cap 挡在外面。这里把所有候选配对按距离
    排一遍（n<=8，最多 28 对），近的先成组，符合「就近抱团」的直觉。
    """
    rids = sorted(positions)
    parent = {r: r for r in rids}
    weight = {r: 1 for r in rids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        if weight[ra] + weight[rb] > cap:
            return False
        if weight[ra] < weight[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        weight[ra] += weight[rb]
        return True

    pairs = []
    for i, a in enumerate(rids):
        for b in rids[i + 1:]:
            pa, pb = positions[a], positions[b]
            if _level(pa, pb) > SQUAD_LEVEL:
                continue
            d = _xz(pa, pb)
            same_before = b in prev.get(a, ())
            if d <= (SQUAD_KEEP if same_before else SQUAD_JOIN):
                pairs.append((d, a, b))
    pairs.sort()
    for _, a, b in pairs:
        union(a, b)

    groups: Dict[int, list] = {}
    for r in rids:
        groups.setdefault(find(r), []).append(r)
    return groups


def _center(members, positions):
    """队心取「离组内质心最近的成员所在点」。

    质心常常落在墙里 / 两轨之间（地铁那种无网格口袋），直接拿去当巡逻
    锚点会让整队往一个到不了的地方挤。用真实成员位置做队心，天然可站立。
    """
    if len(members) == 1:
        return tuple(positions[members[0]])
    cx = sum(float(positions[r][0]) for r in members) / len(members)
    cy = sum(float(positions[r][1]) for r in members) / len(members)
    cz = sum(float(positions[r][2]) for r in members) / len(members)
    best = min(members, key=lambda r: math.hypot(
        float(positions[r][0]) - cx, float(positions[r][2]) - cz))
    return (float(positions[best][0]), cy, float(positions[best][2]))


def plan(battle, positions: Mapping[int, tuple], now: float = 0.0,
         nav=None) -> Dict[int, dict]:
    """划分小队，返回 {roleid: {'size','center','mates','leader','toward'}}。

    `toward` 只给落单者：最近小队的队心（没有小队时退化为最近的同伴），
    逃跑时用它当汇合方向。位置全不可达（另一层/另一张图连通块）时
    `toward` 仍给出坐标，由调用方用 nav 校验后再用。
    """
    if not positions:
        return {}
    cache = getattr(battle, "_bio_squad_cache", None)
    prev = _recent_pairs(battle)
    if (cache is not None and now - float(cache.get("at", -1e9)) < SQUAD_REFRESH
            and cache.get("n") == len(positions)):
        return cache["data"]

    groups = _cluster(positions, prev)
    data: Dict[int, dict] = {}
    # 先建立组表：中心只算一次，避免每个成员各算一遍。
    info = []
    for members in groups.values():
        members = sorted(members)
        center = _center(members, positions)
        info.append((members, center))
    # 只有「还没满员」的小队可以当汇合目标：满员的队伍不再吸收新人，
    # 否则 8 个 BOT 会一路吞并成一个大团，僵尸一刀能砍一串。
    squads = [(m, c) for m, c in info if 2 <= len(m) < SQUAD_MAX]
    loners = [(m[0], c) for m, c in info if len(m) == 1]

    for members, center in info:
        for r in members:
            data[r] = {"size": len(members), "center": center,
                       "mates": tuple(x for x in members if x != r),
                       "leader": min(members), "toward": None}

    # 落单者的汇合方向：优先最近的小队队心，没有小队就找最近的另一个落单者。
    for r, _ in loners:
        here = positions[r]
        best, best_d = None, None
        for members, center in squads:
            d = _xz(here, center)
            if d <= SQUAD_SEEK_MAX and (best_d is None or d < best_d):
                best, best_d = center, d
        if best is None:
            for other, opos in positions.items():
                if other == r:
                    continue
                if _level(here, opos) > SQUAD_LEVEL:
                    continue
                d = _xz(here, opos)
                if d <= SQUAD_SEEK_MAX and d > 0.01 and (best_d is None or d < best_d):
                    best, best_d = opos, d
        data[r]["toward"] = tuple(best) if best is not None else None
        data[r]["toward_dist"] = best_d

    try:
        # now<=0（单测/无时钟）不写时间戳，下次调用强制重算。
        battle._bio_squad_cache = {"at": now if now > 0 else -1e9,
                                   "n": len(positions), "data": data}
        battle._bio_squad_prev = {r: frozenset(v["mates"]) for r, v in data.items()}
    except Exception:
        pass
    return data


def forget(battle) -> None:
    """新回合 / 换图时清掉上一局的划队结果。"""
    for key in ("_bio_squad_cache", "_bio_squad_prev"):
        try:
            setattr(battle, key, None)
        except Exception:
            pass
