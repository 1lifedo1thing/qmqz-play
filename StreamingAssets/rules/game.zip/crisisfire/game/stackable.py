"""可叠加道具计数 / 强化点余额 / 枪械强化进度.

服务端原来的背包只有「拥有 / 不拥有」两种状态 —— `pkg_items` 是一个 id 列表，
`subcount` 恒等于 1。碎片、强化点、弹药包这类**需要数量**的道具根本存不住：

  * 商城买 5 个碎片只发 1 个（`grant_items` 只按 id 去重）
  * 碎片合成 `CsPartsHecheng`(786487) 没法校验「够不够 15 片」
  * 枪械强化 `CsGunResearch`(786477) 没法扣强化点

这个模块是它们共同的地基。三份数据都放在 `Role.data`（JSON blob）里，
和 `gifts` / `loadouts` 一样的存法：

    data["item_counts"]   = {"200016": 15, ...}   可叠加道具的数量
    data["study_point"]   = 12000                 强化点余额（ScStudyPointSync 786473）
    data["gun_research"]  = {"101101": 3, ...}   每把枪的强化进度（ScGunProgress 786476）

数量与「是否拥有」是**两套并存的**：id 仍在 `pkg_items` 里（背包列表靠它渲染），
`item_counts` 只管数量。这样老的存档不需要迁移，读不到数量的道具按 1 处理。
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, Optional

from .. import gamedata

log = logging.getLogger("crisisfire.stackable")

COUNTS_KEY = "item_counts"
POINTS_KEY = "study_point"
RESEARCH_KEY = "gun_research"

_item_index: Optional[Dict[int, Dict[str, Any]]] = None


def _items() -> Dict[int, Dict[str, Any]]:
    global _item_index
    if _item_index is None:
        _item_index = {}
        for row in gamedata.table("Item"):
            try:
                _item_index[int(row["id"])] = row
            except (KeyError, TypeError, ValueError):
                continue
    return _item_index


# --------------------------------------------------------------------------
# 可叠加判定
# --------------------------------------------------------------------------
def stack_max(itemid: int) -> int:
    """该道具的堆叠上限。1 = 不可叠加（枪 / 刀 / 防弹衣 / 时装）。"""
    row = _items().get(int(itemid)) or {}
    try:
        return max(1, int(row.get("maxPile") or 1))
    except (TypeError, ValueError):
        return 1


def stackable(itemid: int) -> bool:
    return stack_max(itemid) > 1


# --------------------------------------------------------------------------
# role.data 读写
# --------------------------------------------------------------------------
def _blob(role) -> Dict[str, Any]:
    return dict(getattr(role, "data", None) or {})


def _target(role, world):
    """以 world 里的 role 为准 —— 传进来的可能是读出来的游离对象。"""
    if world is not None:
        fresh = world.role(role.roleid)
        if fresh is not None:
            return fresh
    return role


def _save(role, world, **kv: Any) -> None:
    if world is not None:
        world.merge_role_data(role.roleid, **kv)
    data = _blob(role)
    data.update(kv)
    try:
        role.data = data
    except Exception:
        pass


# -- 数量 ------------------------------------------------------------------
def counts(role) -> Dict[int, int]:
    raw = _blob(role).get(COUNTS_KEY) or {}
    out: Dict[int, int] = {}
    if isinstance(raw, dict):
        for k, v in raw.items():
            try:
                out[int(k)] = int(v)
            except (TypeError, ValueError):
                continue
    return out


def item_count(role, itemid: int) -> int:
    from . import premium_ammo
    if int(itemid) in premium_ammo.paid_rows():
        return premium_ammo.count(role, int(itemid))
    saved = counts(role)
    if int(itemid) in saved:
        return saved[int(itemid)]
    return int(int(itemid) in (_blob(role).get('pkg_items') or ()))


def add_items(role, delta: Dict[int, int], world=None) -> Dict[int, int]:
    """批量加数量（同一个 id 一次性写一条 DB，避免反复 merge）。"""
    patch = {int(k): int(v) for k, v in delta.items() if int(v) != 0}
    if not patch:
        return counts(role)
    target = _target(role, world)
    from . import premium_ammo
    paid = {iid: n for iid, n in patch.items() if iid in premium_ammo.paid_rows()}
    if paid:
        changes, _ = premium_ammo.stock_change(target, paid)
        _save(target, world, **changes)
        patch = {iid: n for iid, n in patch.items() if iid not in paid}
    cur = counts(target)
    for iid, n in patch.items():
        cap = stack_max(iid)
        cur[iid] = max(0, min(cap, item_count(target, iid) + n))
    _save(target, world, **{COUNTS_KEY: {str(k): v for k, v in cur.items()}})
    return cur


def add_item(role, itemid: int, n: int = 1, world=None) -> int:
    return add_items(role, {int(itemid): int(n)}, world).get(int(itemid), 0)


def take_items(role, need: Dict[int, int], world=None) -> bool:
    """扣数量。不够就**一个都不扣**（要么全成，要么全不成）。

    【v10】两个坑：

    * 老存档的碎片只写在 `pkg_items` 里、`item_counts` 没有对应行，
      原来直接拿 `counts` 比 → `0 < 1` → **最后一片永远卖不掉 / 兑换不掉**。
      现在缺行时按 `item_count()`（会回落到 pkg_items = 1）算。
    * 扣到 0 的 id 必须**同时从 pkg_items 删掉**，否则背包列表还挂着这一条，
      客户端显示「还有 1 片」，服务端认为 0，两边永远对不上。
    """
    req = {int(k): int(v) for k, v in need.items() if int(v) > 0}
    if not req:
        return True
    target = _target(role, world)
    cur = counts(target)

    def _have(iid: int) -> int:
        return int(cur[iid]) if iid in cur else item_count(target, iid)

    for iid, n in req.items():
        if _have(iid) < n:
            return False
    zero = []
    for iid, n in req.items():
        left = _have(iid) - n
        cur[iid] = left
        if left <= 0:
            zero.append(iid)
    patch: Dict[str, Any] = {}
    for iid in zero:
        cur.pop(iid, None)
    patch[COUNTS_KEY] = {str(k): v for k, v in cur.items()}
    if zero:
        gone = set(zero)
        keep = [int(i) for i in ((target.data or {}).get('pkg_items') or ())
                if int(i) not in gone]
        patch['pkg_items'] = sorted(keep)
    _save(target, world, **patch)
    return True


def take_item(role, itemid: int, n: int = 1, world=None) -> bool:
    return take_items(role, {int(itemid): int(n)}, world)


# -- 强化点 ----------------------------------------------------------------
def study_point(role) -> int:
    try:
        return max(0, int(_blob(role).get(POINTS_KEY) or 0))
    except (TypeError, ValueError):
        return 0


def set_study_point(role, n: int, world=None) -> int:
    target = _target(role, world)
    val = max(0, int(n))
    _save(target, world, **{POINTS_KEY: val})
    return val


def add_study_point(role, n: int, world=None) -> int:
    return set_study_point(role, study_point(role) + int(n), world)


def take_study_point(role, n: int, world=None) -> bool:
    need = int(n)
    if need <= 0:
        return True
    cur = study_point(role)
    if cur < need:
        return False
    set_study_point(role, cur - need, world)
    return True


# -- 强化进度 --------------------------------------------------------------
def research_map(role) -> Dict[int, int]:
    raw = _blob(role).get(RESEARCH_KEY) or {}
    out: Dict[int, int] = {}
    if isinstance(raw, dict):
        for k, v in raw.items():
            try:
                out[int(k)] = int(v)
            except (TypeError, ValueError):
                continue
    return out


def progress_of(role, gunid: int) -> int:
    return research_map(role).get(int(gunid), 0)


def set_progress(role, gunid: int, n: int, world=None) -> int:
    target = _target(role, world)
    cur = research_map(target)
    val = max(0, int(n))
    if val <= 0:
        cur.pop(int(gunid), None)
    else:
        cur[int(gunid)] = val
    _save(target, world, **{RESEARCH_KEY: {str(k): v for k, v in cur.items()}})
    return val
