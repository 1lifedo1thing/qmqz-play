"""天赋 / 强化天赋（Talent / ResearchTalent）。

客户端会发这三条，服务端原来**一条都没有**（面板打开是空的、加点没反应）：

    2686980 CsAddTalent(talentid)           -> 2686981 ScAddTalent(talentid, talentpoint)
    2686982 CsAddResearchTalent(talentid)   -> 2686983 ScAddResearchTalent(...)
    2686984 CsResetTalent(talenttype)       -> 2686985 ScResetTalent(talenttype)

面板数据只能由服务端主动推（没有「请求天赋」的消息）：

    2686977 ScTalentSync(researchpoint, researchtalents, point, talents)
    2686978 ScTalentPointSync(point)
    2686979 ScResearchTalentPointSync(researchpoint)

点数规则（官方没有配置表，这里按客户端语义定）：

* 普通天赋点：每提升一级军衔得 1 点，已用掉的从可用里扣
  （`VisibleTalentPoint = clamp(talentPoint, 0, TalentPointMax - UsedTalentPoint)`）。
* 强化点：由超级军备/礼包发放（`gacha` 每次抽奖按 GachaRP 送），
  花掉才减少。`ScResearchTalentPointSync` 带的是**剩余可用**。
* 解锁条件：`Talent.unlockPoints <= 已投入的点数`（客户端 TalentLayerItem 同款判定）。
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .. import gamedata
from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.talent")


class ID:
    SC_TALENT_SYNC = 2686977
    SC_TALENT_POINT = 2686978
    SC_RESEARCH_POINT = 2686979
    CS_ADD_TALENT = 2686980
    SC_ADD_TALENT = 2686981
    CS_ADD_RESEARCH = 2686982
    SC_ADD_RESEARCH = 2686983
    CS_RESET = 2686984
    SC_RESET = 2686985


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# 配置
# --------------------------------------------------------------------------
def _row(table: str, tid: int) -> Dict[str, Any]:
    for r in gamedata.table(table):
        if int(r.get("id") or 0) == int(tid):
            return r
    return {}


def _max_level(row: Dict[str, Any]) -> int:
    return max(1, int(row.get("maxLevel") or 1))


def _unlock(row: Dict[str, Any]) -> int:
    return max(0, int(row.get("unlockPoints") or 0))


# --------------------------------------------------------------------------
# per-role 状态（都存 role.data）
# --------------------------------------------------------------------------
def _levels(role, key: str) -> Dict[int, int]:
    raw = (role.data or {}).get(key)
    out: Dict[int, int] = {}
    if isinstance(raw, dict):
        for k, v in raw.items():
            try:
                lv = int(v)
                if lv > 0:
                    out[int(k)] = lv
            except (TypeError, ValueError):
                continue
    return out


def talents(role) -> Dict[int, int]:
    return _levels(role, "talents")


def research_talents(role) -> Dict[int, int]:
    return _levels(role, "research_talents")


def _save(role, **kv) -> None:
    if _world is not None:
        _world.merge_role_data(role.roleid, **kv)


def earned_points(role) -> int:
    """按军衔算总共拿到过多少天赋点：每级 1 点。"""
    try:
        rank = max(1, int(role.level or 1))
    except (TypeError, ValueError):
        rank = 1
    return max(0, rank - 1)


def point_of(role) -> int:
    """当前可用天赋点。"""
    spent = sum(talents(role).values())
    return max(0, earned_points(role) - spent)


def research_point_of(role) -> int:
    try:
        return max(0, int((role.data or {}).get("research_point") or 0))
    except (TypeError, ValueError):
        return 0


def sync_payload(role) -> Dict[str, Any]:
    return dict(
        researchpoint=research_point_of(role),
        researchtalents=research_talents(role),
        point=point_of(role),
        talents=talents(role),
    )


def push_on_login(session: Session, role) -> None:
    session.send(ID.SC_TALENT_SYNC, **sync_payload(role))


# --------------------------------------------------------------------------
# 加点
# --------------------------------------------------------------------------
def add_talent(role, talentid: int) -> Optional[int]:
    """普通天赋 +1。返回新等级；失败返回 None（客户端不会收到回包）。"""
    row = _row("Talent", talentid)
    if not row:
        return None
    cur = talents(role)
    level = int(cur.get(int(talentid), 0))
    if level >= _max_level(row):
        return None
    if _unlock(row) > sum(cur.values()):
        return None
    if point_of(role) <= 0:
        return None
    cur[int(talentid)] = level + 1
    _save(role, talents={str(k): v for k, v in cur.items()})
    return level + 1


def add_research(role, talentid: int) -> Optional[int]:
    row = _row("ResearchTalent", talentid)
    if not row:
        return None
    cur = research_talents(role)
    level = int(cur.get(int(talentid), 0))
    if level >= _max_level(row):
        return None
    if _unlock(row) > sum(cur.values()):
        return None
    if research_point_of(role) <= 0:
        return None
    cur[int(talentid)] = level + 1
    _save(role, research_talents={str(k): v for k, v in cur.items()},
          research_point=research_point_of(role) - 1)
    return level + 1


def reset_type(role, talenttype: int) -> bool:
    """重置某一类天赋。普通天赋按军衔现算，强化天赋把点退回 `research_point`。"""
    changed = False
    cur = talents(role)
    drop = [tid for tid in cur if int(_row("Talent", tid).get("type") or -1)
            == int(talenttype)]
    if drop:
        for tid in drop:
            cur.pop(tid, None)
        _save(role, talents={str(k): v for k, v in cur.items()})
        changed = True
    rcur = research_talents(role)
    rdrop = [tid for tid in rcur
             if int(_row("ResearchTalent", tid).get("type") or -1)
             == int(talenttype)]
    if rdrop:
        refund = sum(int(rcur[tid]) for tid in rdrop)
        for tid in rdrop:
            rcur.pop(tid, None)
        _save(role, research_talents={str(k): v for k, v in rcur.items()},
              research_point=research_point_of(role) + refund)
        changed = True
    return changed


# --------------------------------------------------------------------------
# 路由
# --------------------------------------------------------------------------
def _role(session: Session):
    if _world is None or not session.roleid:
        return None
    return _world.role(session.roleid)


@ROUTER.register(ID.CS_ADD_TALENT, "task.CsAddTalent")
async def on_add_talent(session: Session, msg: dict) -> None:
    role = _role(session)
    tid = int(msg.get("talentid") or 0)
    if role is None or not tid:
        return
    level = add_talent(role, tid)
    if level is None:
        (log.info("role %s 加点失败 talent=%s（点不够/已满/未解锁）",
                 role.roleid, tid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_TALENT_POINT, point=point_of(role))
        return
    session.send(ID.SC_ADD_TALENT, talentid=tid, talentpoint=level)
    session.send(ID.SC_TALENT_POINT, point=point_of(role))
    (log.info("role %s talent %s -> %s, 剩余 %s 点", role.roleid, tid, level,
             point_of(role)) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_ADD_RESEARCH, "task.CsAddResearchTalent")
async def on_add_research(session: Session, msg: dict) -> None:
    role = _role(session)
    tid = int(msg.get("talentid") or 0)
    if role is None or not tid:
        return
    level = add_research(role, tid)
    if level is None:
        (log.info("role %s 强化天赋加点失败 talent=%s", role.roleid, tid) if log.isEnabledFor(20) else None)
        session.send(ID.SC_RESEARCH_POINT,
                     researchpoint=research_point_of(role))
        return
    session.send(ID.SC_ADD_RESEARCH, talentid=tid, talentpoint=level)
    session.send(ID.SC_RESEARCH_POINT, researchpoint=research_point_of(role))
    (log.info("role %s 强化天赋 %s -> %s, 剩余强化点 %s", role.roleid, tid,
             level, research_point_of(role)) if log.isEnabledFor(20) else None)


@ROUTER.register(ID.CS_RESET, "task.CsResetTalent")
async def on_reset(session: Session, msg: dict) -> None:
    role = _role(session)
    ttype = int(msg.get("talenttype") or 0)
    if role is None:
        return
    reset_type(role, ttype)
    session.send(ID.SC_RESET, talenttype=ttype)
    session.send(ID.SC_TALENT_POINT, point=point_of(role))
    session.send(ID.SC_RESEARCH_POINT, researchpoint=research_point_of(role))
    (log.info("role %s 重置天赋类型 %s（剩余 %s 点 / 强化点 %s）",
             role.roleid, ttype, point_of(role), research_point_of(role)) if log.isEnabledFor(20) else None)
