"""Daily tasks and liveness from the UC 1.9 client contract."""
import copy
import time

from .. import gamedata
from ..net.server import ROUTER

DAILY_SYNC = 2686986
DAILY_CHANGE = 2686987
DAILY_CLAIMED = 2686989
LIVE_SYNC = 1048599
LIVE_CLAIMED = 1048601

MANUFACTURE = 1
RANKED_MATCH = 2
ROULETTE = 3
REPAIR = 4
CLAN_MATCH = 10
CHALLENGE_WIN = 11
CHALLENGE_KILL = 12
CHALLENGE_PICKUP = 13
CHALLENGE_MEDAL = 14
ROOM_TASKS = {2: 5, 8: 6, 1: 7, 3: 8, 4: 9}

# Liveness.type uses different numbering from DailyTask.taskType.
LIVE_RANKED = 1
LIVE_MANUFACTURE = 2
LIVE_ENHANCE = 3
LIVE_ROULETTE = 4
LIVE_RANGE = 5
LIVE_ROBOT = 6

_world = None


def bind_world(world):
    global _world
    _world = world


def _state(role):
    day = time.strftime("%Y-%m-%d")
    saved = (role.data or {}).get("daily")
    if isinstance(saved, dict) and saved.get("day") == day:
        state = copy.deepcopy(saved)
    else:
        state = {"day": day}
    for key, default in (("tasks", {}), ("claimed", []), ("liveness", 0), ("liveclaimed", [])):
        state.setdefault(key, default)
    return state


def task_map(role):
    state = _state(role)
    return {row["id"]: -1 if row["id"] in state["claimed"] else
            min(row["times"], state["tasks"].get(str(row["id"]), 0))
            for row in gamedata.table("DailyTask")}


def _send_live(session, state):
    # ActivityManager.LivenessSync assigns reward to mylivelevel, and the
    # button asks for mylivelevel + 1.
    session.send(LIVE_SYNC, liveness=state["liveness"], reward=max(state["liveclaimed"], default=0))


def send_sync(session, role):
    session.send(DAILY_SYNC, tasks=task_map(role))
    _send_live(session, _state(role))


def record(role, *, task_type=None, amount=1, live_type=None, session=None):
    if role is None or _world is None or amount <= 0:
        return
    state = _state(role)
    updates = {}
    for row in gamedata.table("DailyTask"):
        if row["taskType"] != task_type or row["id"] in state["claimed"]:
            continue
        key = str(row["id"])
        before = state["tasks"].get(key, 0)
        after = min(row["times"], before + amount)
        if after > before:
            updates[row["id"]] = after
            state["tasks"][key] = after
    live = next((row["liveness"] for row in gamedata.table("Liveness")
                 if row["type"] == live_type), 0)
    if not updates and not live:
        return
    state["liveness"] += live
    _world.merge_role_data(role.roleid, daily=state)
    session = session or _world.session_of_role(role.roleid, "gs")
    if session is not None and not session.closed:
        for taskid, progress in updates.items():
            session.send(DAILY_CHANGE, taskid=taskid, taskvalue=progress)
        if live:
            _send_live(session, state)


def record_room(battle, role):
    fighter = battle.fighters[role.roleid]
    if not (fighter.born_at or fighter.kills or fighter.deaths):
        return
    mode = battle.room.gamemode
    if getattr(battle.room, "local_rank_match", False):
        record(role, task_type=RANKED_MATCH, live_type=LIVE_RANKED)
    else:
        record(role, task_type=ROOM_TASKS.get(mode))
    team = int(role.data.get("teamid", 0) or 0)
    if not team or mode == 4:
        return
    side = fighter.side
    for other in battle.fighters.values():
        if other.roleid != role.roleid and other.side == side and other.born_at:
            teammate = _world.role(other.roleid)
            if teammate is not None and int(teammate.data.get("teamid", 0) or 0) == team:
                record(role, task_type=CLAN_MATCH)
                break


def _send_wallet(session, role):
    from .handlers import _property_of
    session.send(983043, gold=role.gold, money=role.money, diamond=role.diamond)
    session.send(1114117, roleid=role.roleid, property=_property_of(role))


@ROUTER.register(2686988, "task.CsGetDailyTaskReward")
async def claim_task(session, message):
    role = _world.role(session.roleid) if _world is not None else None
    taskid = message.get("taskid")
    row = next((row for row in gamedata.table("DailyTask") if row["id"] == taskid), None)
    if role is None or row is None:
        return
    state = _state(role)
    if taskid in state["claimed"]:
        session.send(DAILY_CLAIMED, taskid=taskid)
        return
    progress = state["tasks"].get(str(taskid), 0)
    if progress < row["times"]:
        session.send(DAILY_CHANGE, taskid=taskid, taskvalue=progress)
        return
    state["claimed"].append(taskid)
    _world.award_daily(role.roleid, state, exp=row["expReward"], coins=row["goldReward"],
                       gems=row["gemReward"], honor=row["honorReward"])
    session.send(DAILY_CLAIMED, taskid=taskid)
    _send_wallet(session, role)


@ROUTER.register(1048600, "shop.CsGetLivenessReward")
async def claim_liveness(session, _message):
    role = _world.role(session.roleid) if _world is not None else None
    if role is None:
        return
    state = _state(role)
    tier = max(state["liveclaimed"], default=0) + 1
    row = next((row for row in gamedata.table("LiveReward") if row["liveLevel"] == tier), None)
    if row is not None and state["liveness"] >= row["liveDemand"]:
        state["liveclaimed"].append(tier)
        _world.award_daily(role.roleid, state, exp=row["rewardExp"], coins=row["rewardGold"],
                           gems=row["rewardGem"], honor=row["rewardHonor"])
        session.send(LIVE_CLAIMED, livelevel=tier)
        _send_wallet(session, role)
    _send_live(session, state)
