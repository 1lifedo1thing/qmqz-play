"""VIP and the recharge state that gates the 幸运转盘.

`ScVipCashSync(1048606)` is the single message that drives both:

    // ScVipCashSync.process()
    RechargeData.Sync(viplevel, cashall);

    public static void Sync(int lvl, int cash)
    {
        bool flag = vipLevelCurrent != -1 && vipLevelCurrent < lvl;   // ranked up
        vipLevelCurrent = lvl;                                        // -1 = none
        accumulateValue = cash;
        UserManager.userInfo.pro.vipstatus = lvl;                     // the VIP badge
        VipCashChanged?.Invoke();
        if (flag) DialogMgr.queueDialog("VipLevelUp");
    }

and the 幸运转盘 refuses to open without it:

    RechargeManager.CanPlayRoulette => RechargeData.accumulateValue > 0

which is exactly what Text 358 says: 「充值即可开启幸运转盘」.

VIP tiers come from the client's Vip table, keyed by cumulative recharge:

    VIP1  >= 600        VIP3  >= 10000      VIP10 >= 300000
    VIP2  >= 3000       VIP6  >= 100000     VIP25 >= 30000000
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from .. import gamedata
from ..net.server import ROUTER, Session

log = logging.getLogger("crisisfire.vip")


class ID:
    SC_VIP_CASH_SYNC = 1048606      # com.gwebtop.shop.ScVipCashSync
    SC_VIP_CARD_SYNC = 1048598
    SC_VIP_STATUS = 1441950         # gclient, in-battle badge
    SC_VIP_EXPIRE = 1114118
    SC_ACOUNT_SYNC = 983043
    SC_USER_INFO = 1114117


_world = None


def bind_world(world) -> None:
    global _world
    _world = world


# --------------------------------------------------------------------------
# tiers
# --------------------------------------------------------------------------
_tiers: Optional[List[Tuple[int, int, Dict[str, Any]]]] = None   # (recharge, level, row)


def _table() -> List[Tuple[int, int, Dict[str, Any]]]:
    global _tiers
    if _tiers is None:
        rows = []
        # 1.9 客户端导出的表名是 **VIP.json**（全大写），1.7.1 是 Vip.json；
        # 原来只查 "Vip"，1.9 下必然空表，登录还会 ERROR「VIP grants will do nothing」。
        vip_rows = gamedata.table("VIP") or gamedata.table("Vip")
        for r in vip_rows:
            try:
                rows.append((int(r.get("recharge") or 0), int(r["vipLevel"]), r))
            except (KeyError, TypeError, ValueError):
                continue
        rows.sort()
        _tiers = rows
        if not rows:
            log.error("Vip table is empty -- VIP grants will do nothing")
    return _tiers


def max_vip() -> int:
    return max((lv for _r, lv, _row in _table()), default=0)


def vip_for_recharge(cash: int) -> int:
    """Highest VIP level whose recharge threshold the player has reached."""
    best = 0
    for threshold, level, _row in _table():
        if cash >= threshold:
            best = level
        else:
            break
    return best


def recharge_for_vip(level: int) -> int:
    for threshold, lv, _row in _table():
        if lv == level:
            return threshold
    return 0


def vip_row(level: int) -> Optional[Dict[str, Any]]:
    for _t, lv, row in _table():
        if lv == level:
            return row
    return None


def vip_name(level: int) -> str:
    return "无" if level <= 0 else f"VIP{level}"


# --------------------------------------------------------------------------
# per-role state, kept in Role.data
# --------------------------------------------------------------------------
def cash_of(role) -> int:
    try:
        return max(0, int((role.data or {}).get("cash_all", 0)))
    except (TypeError, ValueError):
        return 0


def level_of(role) -> int:
    """0 when the role has never recharged (the client uses -1 for 'none')."""
    return vip_for_recharge(cash_of(role))


def send_sync(session: Session, role) -> None:
    """Push VIP + recharge state.  Also unblocks the 幸运转盘."""
    session.send(ID.SC_VIP_CASH_SYNC, viplevel=level_of(role),
                 cashall=cash_of(role))


def grant_cash(role, cash: int) -> Tuple[int, int]:
    """Add cumulative recharge, recompute VIP, persist.  Returns (old, new)."""
    old = level_of(role)
    total = cash_of(role) + max(0, int(cash))
    new = vip_for_recharge(total)
    if _world is not None:
        _world.merge_role_data(role.roleid, cash_all=total)
    _notify_rank_up(role, old, new)
    return old, new


def set_cash(role, cash: int) -> Tuple[int, int]:
    old = level_of(role)
    total = max(0, int(cash))
    new = vip_for_recharge(total)
    if _world is not None:
        _world.merge_role_data(role.roleid, cash_all=total)
    _notify_rank_up(role, old, new)
    return old, new


def _notify_rank_up(role, old: int, new: int) -> None:
    if new > old:
        row = vip_row(new) or {}
        (log.info("role %s reached VIP%s (recharge=%s, +%s gold, +%s exp per day)",
                 role.name, new, cash_of(role), row.get("gold"), row.get("exp")) if log.isEnabledFor(20) else None)


# --------------------------------------------------------------------------
# login push
# --------------------------------------------------------------------------
def push_on_login(session: Session, role) -> None:
    send_sync(session, role)


# --------------------------------------------------------------------------
# daily VIP perks (config: Vip.gold / Vip.exp are the per-day bonuses)
# --------------------------------------------------------------------------
def daily_bonus(role) -> Dict[str, int]:
    row = vip_row(level_of(role)) or {}
    return {"gold": int(row.get("gold") or 0),
            "exp": int(row.get("exp") or 0),
            "gift": int(row.get("vipGift") or -1)}


def summary(role) -> Dict[str, Any]:
    lvl = level_of(role)
    nxt = lvl + 1 if lvl < max_vip() else 0
    return {
        "level": lvl,
        "name": vip_name(lvl),
        "cash": cash_of(role),
        "nextLevel": nxt,
        "nextRecharge": recharge_for_vip(nxt) if nxt else 0,
        "canPlayRoulette": cash_of(role) > 0,
        "daily": daily_bonus(role),
    }


def unlocked(role) -> Dict[str, bool]:
    """What VIP opens, mirroring RechargeData's own gates."""
    lvl = level_of(role)
    return {
        "roulette": cash_of(role) > 0,   # RechargeManager.CanPlayRoulette
        "present": lvl >= 5,             # RechargeData.CanPresent
        "vipGift": lvl >= 1,
    }
