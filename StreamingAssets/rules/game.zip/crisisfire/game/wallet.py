"""1.8.1 account fields, calibrated on UserManager.CanBuy/OnAccountChange.

Configuration/reward gold -> account money (coins), gem -> account gold
(blue gems), bloodGem/honor -> account diamond (honor). Names alone are unsafe.
This helper changes future awards only; it never migrates an existing balance.
"""


def change(world, role, *, coins=0, gems=0, honor=0):
    values={'money':int(role.money)+int(coins),
            'gold':int(role.gold)+int(gems),
            'diamond':int(role.diamond)+int(honor)}
    if min(values.values())<0:
        raise ValueError('insufficient account balance')
    world.update_role(role.roleid,**values)
    for key,value in values.items():setattr(role,key,value)
    return values
