"""Biochem human-BOT weapon catalogue (local reconstructed policy).

Data sources are the shipped client tables already extracted in this package:

    server/crisisfire/gamedata/Item.json    id, equipPos, subType, resource, tex
    server/crisisfire/gamedata/Gun.json     clip/ammo, shootSpeed, range, damage
    server/crisisfire/gamedata/Melee.json   range/speed/damag/bioDamage

Resource presence is *not* guessed from ``tex == 0``.  The client reads the
weapon row's ``resource`` and its native material index ``tex`` directly:

    AArsenal.cs:168  loader.LoadGunPrefab(gunName, texid)
    AArsenal.cs:179  AssetLoader.GetTpsMaterialHolder(gunName, texid)
    Level.cs:414     assetLoader.LoadGunPrefab(gunItem.resource, gunItem.tex)

The exact per-id model/material evidence is in the sibling audit
(``challenge_probe_20261103/equipment_audit/summary.json``).  This module embeds
only the resulting verified (resource -> texture indices) set, so production
does not read the audit directory at runtime and an unknown row fails closed.

Classification follows real call paths, not slot guesses:

* equipPos 11/12 with a Gun row and verified resources -> switchable gun.
* equipPos 50 with a Melee row and verified resources -> switchable melee.
* 711001 is the LauncherID proxy (ClientManager.SetupWeapon/WeaponChange);
  711002 is the alternate launcher (Launcher.missile=741111); 711011 is C4
  (Consts.ExplosiveID / Level.LoadExplosive); 711021 is the explosive pad.
* equipPos 41/42 are grenade projectiles; 711001 is the held proxy, they are
  never ordinary main/vice/melee choices.
* 8001 is the BioHero forced melee (ClientManager.cs:2396 / Consts.cs:132).
* 605171 is a reserved/stale row whose M82A3 tex_1 material is absent.
* 731051/742111 are orphan Item rows with no Grenade/Launcher/Gun/Melee row.

No network, device, database, archive, or production file is touched.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from random import Random
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

POS_MAIN_GUN = 11
POS_VICE_GUN = 12
POS_MELEE = 50
GRENADE_SLOTS = (41, 42)

CATEGORY_BY_SUBTYPE: Dict[int, str] = {
    11: "pistol",
    12: "shotgun",
    13: "smg",
    14: "rifle",
    15: "mg",
    16: "sniper",
}
CATEGORY_LABEL_ZH: Dict[str, str] = {
    "pistol": "手枪", "shotgun": "散弹枪", "smg": "冲锋枪",
    "rifle": "步枪", "mg": "机枪", "sniper": "狙击枪", "melee": "近战",
}
MAIN_CATEGORY_ORDER: Tuple[str, ...] = ("rifle", "smg", "shotgun", "mg", "sniper")

# Verified from equipment_audit/summary.json -> model_texture_audit.rows:
# every id below is category="held_weapon" with no missing_required dependency.
# Keys are the *base model resource*; values are native material indices that
# actually exist for that resource (TPS and FPS where the call path needs them).
VERIFIED_RESOURCES: Dict[str, Tuple[int, ...]] = {'AA-12': (0, 1, 20, 21, 22), 'ACR': (0, 1), 'AK47': (0, 1, 20), 'AK47C': (20, 21), 'AK47_A': (20, 21, 22, 23), 'AK47_L_BL': (99,), 'AK47_L_BL02': (99,), 'AK47_L_YL': (99,), 'AK47_L_YL02': (99,), 'AKM': (0, 1), 'AUG': (0, 1, 20), 'AUG_Gold': (20,), 'AWP': (0, 1, 20), 'AWP_L_G': (99,), 'AWP_L_G02': (99,), 'AWP_L_KL': (99,), 'AWP_L_KL02': (99,), 'Axe': (0, 20), 'Dagger_1': (0, 20), 'Dagger_2': (0,), 'Dagger_3': (20,), 'Dagger_L_3Up': (99,), 'DesertEagle': (0,), 'DesertEagle_Gold': (20,), 'F2000': (0, 1), 'FAMAS': (0, 1), 'Flash_NewYear01': (20,), 'G17': (0,), 'G18': (0,), 'G18_L_Knight': (99,), 'G18_L_Knight02': (99,), 'G36': (0, 1), 'Gatlin': (0, 1), 'Grenade1': (0, 20), 'Grenade2': (0, 20), 'GrenadeBio01': (0,), 'GrenadeBio02': (0,), 'Grenade_NewYear01': (20,), 'IMBEL_MD3': (0, 1), 'KSG': (0, 1), 'Katana': (0,), 'L86LSW': (0, 1), 'M1014': (0, 1, 20), 'M14EBR': (0, 1), 'M16A4': (0, 1), 'M1911': (0,), 'M1928': (0, 1), 'M1928_L_Knight': (99,), 'M1928_L_Knight02': (99,), 'M200': (0, 1), 'M240': (0, 1), 'M249': (20, 21, 22), 'M4A1': (0,), 'M4A1B': (0, 1, 20, 21, 22, 23), 'M4A1B_NY02': (20,), 'M4A1C': (20, 21), 'M4A1_A': (20, 21), 'M4A1_Crystal': (20,), 'M4A1_Dis': (1,), 'M4A1_L_ML': (99,), 'M4A1_L_ML02': (99,), 'M4_L_Bio': (99,), 'M4_L_Bio02': (99,), 'M82A1': (0, 1), 'M82A1_SP': (20,), 'M82A3': (20, 21, 22, 23, 24), 'M9': (0,), 'M93R': (0,), 'MG4': (0, 1), 'MK46_L_Knight': (99,), 'MK46_L_Knight02': (99,), 'MP5K': (0, 1), 'MP5N': (0, 1, 20), 'MP5N_Gold': (20,), 'Mini-Uzi': (0, 1), 'P90': (0, 1), 'PP2000': (0, 1, 20), 'Python': (0, 20), 'Python_L_A': (99,), 'Python_L_B': (99,), 'QBZ95(VD)_SP': (20,), 'QBZ95_00': (0,), 'QBZ95_01': (1,), 'QBZ95_SP': (20,), 'QSZ92': (0,), 'RPD': (0, 1), 'RPG_DT': (0,), 'SCAR': (0, 1, 20), 'SPAS-12': (0, 1), 'STI': (0,), 'SVD': (0, 1), 'Striker': (0, 1), 'Striker_L_Knight': (99,), 'Striker_L_Knight02': (99,), 'Super-V': (0, 1, 20), 'TAR21': (0, 1, 20), 'TMP': (0, 1), 'UMP45': (0, 1), 'USP45': (0,), 'WA2000': (0, 1)}

# Real call-path exclusions.  Each id is listed in catalog.json with its own
# reason/evidence string; this dict is the runtime fail-closed rule.
SPECIAL_REASONS: Dict[int, Tuple[str, str]] = {
    711001: ("internal_launcher_proxy",
             "Consts.LauncherID; ClientManager.SetupWeapon/WeaponChange pass "
             "the real grenade id as ammo; Launcher.missile=0"),
    711002: ("internal_launcher_alt",
             "Consts.Rocket_1_ID; Launcher row missile=741111; no ordinary "
             "warehouse call site in this build"),
    711011: ("internal_bomb_c4",
             "Consts.ExplosiveID / GameRule.blastId; Level.LoadExplosive loads C4"),
    711021: ("internal_bomb_pad",
             "Consts.ExplosivePadID; ClientManager.cs:394; AArsenal.cs:192 "
             "special attach"),
    8001: ("hero_melee",
           "Consts.HeroMeleeID; ClientManager.cs:2396 sets equips[50]=8001 "
           "only for BioHero"),
    605171: ("reserved_missing_texture",
             "reserved/stale row; M82A3 tex_1 absent while only tex_20..24 exist"),
    731051: ("orphan_reserved",
             "only Item.json contains id; no Grenade/Launcher/Gun/Melee/code ref"),
    742111: ("orphan_reserved",
             "only Item.json contains id; no model and no code reference"),
}

AUDIT_SOURCE = ("challenge_probe_20261103/equipment_audit/summary.json "
                "model_texture_audit.rows")


def texture_verified(resource: Any, tex: Any) -> bool:
    """True only for a resource/material pair the audit actually found."""
    name = str(resource or "").strip()
    if not name:
        return False
    try:
        index = int(tex)
    except (TypeError, ValueError):
        return False
    return index in VERIFIED_RESOURCES.get(name, ())


# 【v47】手册 subType 写错的枪：显式纠正（用户实测点名）。
# 507011~507020「暴烈骑士」全系：Item.subType 写的是 14(步枪)，但弹匣
# 90~104 发、射速 0.123~0.129，和 MG4(100发/0.11)、加特林(96发) 同一档，
# 弹链供弹 —— **实际是机枪**。不纠正的话它会被当成步枪：吃步枪的 BOT 枪池、
# 吃步枪的散布口径、`_auto_spray` 之外的判定也跟着偏。
CATEGORY_OVERRIDE: Dict[int, str] = {
    507011: "mg", 507012: "mg", 507013: "mg", 507014: "mg", 507015: "mg",
    507016: "mg", 507017: "mg", 507018: "mg", 507019: "mg", 507020: "mg",
}


def category_of(item: Mapping[str, Any]) -> str:
    try:
        iid = int(item.get("id") or 0)
    except (TypeError, ValueError):
        iid = 0
    if iid in CATEGORY_OVERRIDE:
        return CATEGORY_OVERRIDE[iid]
    try:
        return CATEGORY_BY_SUBTYPE.get(int(item.get("subType") or 0), "")
    except (TypeError, ValueError):
        return ""


def _i(row: Mapping[str, Any], key: str, default: int = 0) -> int:
    try:
        return int(row.get(key) or default)
    except (TypeError, ValueError):
        return default


def _f(row: Mapping[str, Any], key: str, default: float = 0.0) -> float:
    try:
        return float(row.get(key) or default)
    except (TypeError, ValueError):
        return default


def _by_id(rows: Optional[Iterable[Mapping[str, Any]]]
           ) -> Dict[int, Mapping[str, Any]]:
    if rows is None:
        return {}
    if isinstance(rows, Mapping):
        return {int(k): v for k, v in rows.items() if isinstance(v, Mapping)}
    out: Dict[int, Mapping[str, Any]] = {}
    for row in rows:
        try:
            out[int(row.get("id") or 0)] = row
        except (TypeError, ValueError, AttributeError):
            continue
    return out


def _table(name: str) -> List[Mapping[str, Any]]:
    try:
        from .. import gamedata
        return list(gamedata.table(name) or [])
    except Exception:
        # Standalone test import: fall back to the package on sys.path.
        try:
            from crisisfire import gamedata  # type: ignore
            return list(gamedata.table(name) or [])
        except Exception:
            return []


@dataclass(frozen=True)
class CatalogEntry:
    itemid: int
    name: str
    slot: int
    category: str
    resource: str
    tex: int
    base_id: int
    included: bool
    reason: str
    evidence: str
    clip: int = 0
    ammo: int = 0
    shoot_speed: float = 0.0
    shoot_interval: float = 0.0
    reload_seconds: float = 0.0
    effective_range: float = 0.0
    basic_damage: float = 0.0
    bio_damage: float = 0.0
    speed_down: float = 0.0
    bullet_per_shot: int = 1
    fire_per_shot: int = 1
    melee_range: float = 0.0
    melee_speed: float = 0.0
    melee_damage: float = 0.0
    melee_bio_damage: float = 0.0
    fan_angle: float = 0.0

    @property
    def is_gun(self) -> bool:
        return self.slot in (POS_MAIN_GUN, POS_VICE_GUN)

    @property
    def is_melee(self) -> bool:
        return self.slot == POS_MELEE

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.itemid, "name": self.name, "slot": self.slot,
            "category": self.category, "resource": self.resource,
            "tex": self.tex, "base_id": self.base_id,
            "included": self.included, "reason": self.reason,
            "evidence": self.evidence,
            "clip": self.clip, "ammo": self.ammo,
            "shoot_speed": self.shoot_speed,
            "shoot_interval": self.shoot_interval,
            "reload_seconds": self.reload_seconds,
            "effective_range": self.effective_range,
            "basic_damage": self.basic_damage,
            "bio_damage": self.bio_damage,
            "speed_down": self.speed_down,
            "bullet_per_shot": self.bullet_per_shot,
            "fire_per_shot": self.fire_per_shot,
            "melee_range": self.melee_range,
            "melee_speed": self.melee_speed,
            "melee_damage": self.melee_damage,
            "melee_bio_damage": self.melee_bio_damage,
            "fan_angle": self.fan_angle,
        }


@dataclass
class WeaponCatalog:
    entries: Dict[int, CatalogEntry]
    by_slot: Dict[int, Tuple[int, ...]]
    by_category: Dict[str, Tuple[int, ...]]
    counts: Dict[str, int]
    excluded: Dict[str, int]

    # -- selection -----------------------------------------------------
    def pool(self, slot: int, category: str = "") -> Tuple[int, ...]:
        if category:
            return tuple(i for i in self.by_slot.get(int(slot), ())
                         if self.entries[i].category == category)
        return self.by_slot.get(int(slot), ())

    def _pick(self, pool: Sequence[int], round_index: int,
              index: int) -> Optional[int]:
        if not pool:
            return None
        offset = (int(round_index) + int(index)) % len(pool)
        return int(pool[offset])

    def select_main(self, round_index: int = 0, index: int = 0) -> Optional[int]:
        r, i = int(round_index), int(index)
        category = MAIN_CATEGORY_ORDER[(r + i) % len(MAIN_CATEGORY_ORDER)]
        pool = self.pool(POS_MAIN_GUN, category) or self.pool(POS_MAIN_GUN)
        if not pool:
            return None
        # A category repeats every 5 rounds for a fixed BOT.  Advance the
        # variant once per category cycle (not once per round) so a category
        # whose pool length shares a factor with 5 (e.g. sniper=60) still
        # enumerates every id instead of only every 5th.
        cycle = (r // len(MAIN_CATEGORY_ORDER)) + i
        return int(pool[cycle % len(pool)])

    def select_vice(self, round_index: int = 0, index: int = 0) -> Optional[int]:
        return self._pick(self.pool(POS_VICE_GUN), round_index, index)

    def select_melee(self, round_index: int = 0, index: int = 0) -> Optional[int]:
        return self._pick(self.pool(POS_MELEE), round_index, index)

    def loadout(self, round_index: int = 0, index: int = 0) -> Dict[int, int]:
        out: Dict[int, int] = {}
        for slot, pick in ((POS_MAIN_GUN, self.select_main(round_index, index)),
                           (POS_VICE_GUN, self.select_vice(round_index, index)),
                           (POS_MELEE, self.select_melee(round_index, index))):
            if pick:
                out[slot] = int(pick)
        return out

    def schedule(self, rounds: int, bots: int = 1
                 ) -> List[Tuple[int, int, Dict[int, int]]]:
        """Deterministic (round, bot, loadout) rows used by coverage tests."""
        return [(r, i, self.loadout(r, i))
                for r in range(int(rounds)) for i in range(int(bots))]

    def base_id(self, itemid: int) -> int:
        entry = self.entries.get(int(itemid))
        return entry.base_id if entry is not None else int(itemid)

    def entry(self, itemid: int) -> Optional[CatalogEntry]:
        return self.entries.get(int(itemid))


def _reload_values(raw: Any) -> List[float]:
    if raw is None:
        return []
    if isinstance(raw, Mapping):
        raw = raw.get("_items") or raw.get("items") or []
    if isinstance(raw, (int, float)):
        return [float(raw)]
    out: List[float] = []
    for value in raw:
        try:
            out.append(float(value))
        except (TypeError, ValueError):
            continue
    return out


def _reload_seconds(gun: Mapping[str, Any]) -> float:
    values = _reload_values(gun.get("reloadSpeed"))
    kind = _i(gun, "reloadType")
    if kind == 1 and values:
        seconds = values[0]
    elif kind == 3 and len(values) >= 3:
        seconds = values[0] + values[1] + values[2]
    else:
        seconds = sum(values)
    return max(0.05, seconds) if seconds > 0 else 2.5


def build_catalog(items=None, guns=None, melees=None) -> WeaponCatalog:
    """Build the full per-id catalogue; unknown resources fail closed."""
    item_rows = _by_id(items if items is not None else _table("Item"))
    gun_rows = _by_id(guns if guns is not None else _table("Gun"))
    melee_rows = _by_id(melees if melees is not None else _table("Melee"))

    entries: Dict[int, CatalogEntry] = {}
    # Weapon-relevant rows + the two internal bomb controllers (equipPos 33).
    relevant = {iid for iid, row in item_rows.items()
                if _i(row, "equipPos") in
                (POS_MAIN_GUN, POS_VICE_GUN, POS_MELEE) + GRENADE_SLOTS + (43,)}
    relevant.update({711011, 711021})
    for iid in sorted(relevant):
        item = item_rows.get(iid)
        if item is None:
            continue
        slot = _i(item, "equipPos")
        name = str(item.get("name") or "")
        resource = str(item.get("resource") or "").strip()
        tex = _i(item, "tex")
        reason = "included"
        evidence = ""
        included = False
        category = "melee" if slot == POS_MELEE else category_of(item)
        clip = ammo = 0
        shoot_speed = shoot_interval = reload_seconds = effective_range = 0.0
        basic_damage = bio_damage = speed_down = 0.0
        bullet_per_shot = fire_per_shot = 1
        melee_range = melee_speed = melee_damage = melee_bio_damage = 0.0
        fan_angle = 0.0

        special = SPECIAL_REASONS.get(iid)
        if special is not None:
            reason, evidence = special
            category = ""          # internal/hero/reserved, never a BOT pick
        elif slot in GRENADE_SLOTS:
            reason = "grenade_projectile"
            evidence = ("equipPos 41/42; held proxy is 711001 and the real id "
                        "is passed as ammo (ClientManager.cs:200-219)")
        elif slot == 43:
            reason = "orphan_reserved"
            evidence = "equipPos 43 orphan Item row with no weapon subsystem row"
        elif slot == POS_MELEE:
            melee = melee_rows.get(iid)
            if melee is None:
                reason = "missing_melee_row"
                evidence = "Item.equipPos=50 but no Melee row"
            elif not texture_verified(resource, tex):
                reason = "unverified_resource_or_texture"
                evidence = f"{resource!r} tex={tex} not in audit verified set"
            else:
                category = "melee"
                included = True
                reason = "ordinary_melee"
                evidence = ("Item.equipPos=50 + Melee row + audit present "
                            "model/material")
                melee_range = _f(melee, "range")
                melee_speed = _f(melee, "speed")
                melee_damage = _f(melee, "damag")
                melee_bio_damage = _f(melee, "bioDamage")
                fan_angle = _f(melee, "fanAngle")
        elif slot in (POS_MAIN_GUN, POS_VICE_GUN):
            gun = gun_rows.get(iid)
            if gun is None:
                reason = "missing_gun_row"
                evidence = "Item row has no Gun row"
            elif not category:
                reason = "unverified_category"
                evidence = f"Item.subType={_i(item, 'subType')} has no real category"
            elif not texture_verified(resource, tex):
                reason = "unverified_resource_or_texture"
                evidence = f"{resource!r} tex={tex} not in audit verified set"
            elif _i(gun, "clip") <= 0 or _f(gun, "shootSpeed") <= 0:
                reason = "invalid_gun_stats"
                evidence = "Gun.clip<=0 or Gun.shootSpeed<=0"
            else:
                included = True
                reason = "ordinary_gun"
                evidence = ("Item.equipPos=11/12 + Gun row + subType category "
                            "+ audit present model/material")
                clip = _i(gun, "clip")
                ammo = max(clip, _i(gun, "ammo"))
                shoot_speed = _f(gun, "shootSpeed")
                shoot_interval = _f(gun, "shootInterval")
                reload_seconds = _reload_seconds(gun)
                effective_range = _f(gun, "effectiveRange", 35.0)
                basic_damage = _f(gun, "basicDamage")
                bio_damage = _f(gun, "bioDamage")
                speed_down = _f(gun, "speedDown")
                bullet_per_shot = max(1, _i(gun, "bulletPerShot", 1))
                fire_per_shot = max(1, _i(gun, "firePerShoot", 1))
        else:
            reason = "not_weapon_slot"
            evidence = f"Item.equipPos={slot}"

        base_id = iid
        if slot in (POS_MAIN_GUN, POS_VICE_GUN, POS_MELEE):
            peers = [j for j, row in item_rows.items()
                     if _i(row, "equipPos") == slot
                     and str(row.get("resource") or "").strip() == resource]
            plain = [j for j in peers if _i(item_rows[j], "tex") == 0]
            base_id = min(plain) if plain else (min(peers) if peers else iid)

        entries[iid] = CatalogEntry(
            itemid=iid, name=name, slot=slot, category=category,
            resource=resource, tex=tex, base_id=int(base_id),
            included=included, reason=reason, evidence=evidence,
            clip=clip, ammo=ammo, shoot_speed=shoot_speed,
            shoot_interval=shoot_interval,
            reload_seconds=reload_seconds, effective_range=effective_range,
            basic_damage=basic_damage, bio_damage=bio_damage,
            speed_down=speed_down, bullet_per_shot=bullet_per_shot,
            fire_per_shot=fire_per_shot,
            melee_range=melee_range, melee_speed=melee_speed,
            melee_damage=melee_damage, melee_bio_damage=melee_bio_damage,
            fan_angle=fan_angle)

    included_ids = {i for i, e in entries.items() if e.included}
    by_slot: Dict[int, Tuple[int, ...]] = {}
    for slot in (POS_MAIN_GUN, POS_VICE_GUN, POS_MELEE):
        by_slot[slot] = tuple(sorted(
            i for i in included_ids if entries[i].slot == slot))
    by_category: Dict[str, Tuple[int, ...]] = {}
    for entry in entries.values():
        if entry.included:
            by_category.setdefault(entry.category, ())
    for cat in sorted(by_category):
        by_category[cat] = tuple(sorted(
            i for i in included_ids if entries[i].category == cat))
    excluded: Dict[str, int] = {}
    for entry in entries.values():
        if not entry.included:
            excluded[entry.reason] = excluded.get(entry.reason, 0) + 1
    counts = {
        "weapon_rows_audited": len(entries),
        "included": len(included_ids),
        "guns": len(by_slot[POS_MAIN_GUN]) + len(by_slot[POS_VICE_GUN]),
        "main_guns": len(by_slot[POS_MAIN_GUN]),
        "vice_guns": len(by_slot[POS_VICE_GUN]),
        "melee": len(by_slot[POS_MELEE]),
        "excluded": len(entries) - len(included_ids),
        **{f"category_{k}": len(v) for k, v in sorted(by_category.items())},
    }
    return WeaponCatalog(entries=entries, by_slot=by_slot,
                         by_category=by_category, counts=counts,
                         excluded=excluded)


# ---------------------------------------------------------------------------
# Route/mobility preference: preferences only, never movement or jump code.
# ---------------------------------------------------------------------------
@dataclass
class RouteState:
    route: str = "idle"
    safe: bool = False
    airborne: bool = False
    until: float = 0.0
    reason: str = ""
    mobility_until: float = 0.0
    mobility_reason: str = ""


_FALLBACK_ROUTES: Dict[int, Tuple[Any, RouteState]] = {}


def _route_holder(target: Any) -> RouteState:
    """Return the persistent RouteState for a target.

    RouteState itself, a dict-like object, or an object with a writable
    ``route_state`` works.  Fighter uses ``__slots__``, so a bounded id-keyed
    fallback keeps a preference across calls when the main coordinator passes
    the Fighter directly.  In the BOT driver prefer ``bots.route_state``.
    """
    if isinstance(target, RouteState):
        return target
    state = getattr(target, "route_state", None)
    if isinstance(state, RouteState):
        return state
    if isinstance(state, dict):
        return RouteState(**{k: state.get(k, getattr(RouteState, k))
                             for k in RouteState.__dataclass_fields__})
    key = id(target)
    hit = _FALLBACK_ROUTES.get(key)
    if hit is not None and hit[0] is target:
        return hit[1]
    state = RouteState()
    try:
        setattr(target, "route_state", state)
    except Exception:
        if len(_FALLBACK_ROUTES) > 256:
            _FALLBACK_ROUTES.clear()
        _FALLBACK_ROUTES[key] = (target, state)
    return state


def notify_route_state(target: Any, *, route: str = "idle", safe: bool = False,
                       airborne: bool = False, until: float = 0.0,
                       reason: str = "") -> RouteState:
    """Main coordinator -> BOT preference.  No movement/jump is performed."""
    state = _route_holder(target)
    state.route = str(route or "idle")
    state.safe = bool(safe)
    state.airborne = bool(airborne)
    state.until = float(until or 0.0)
    state.reason = str(reason or "")
    return state


def request_mobility_weapon(target: Any, now: float, *,
                            reason: str = "route",
                            duration: float = 1.0,
                            weapon: str = "melee") -> Dict[str, Any]:
    """Express a preference for knife/light weapon during safe movement.

    Returns ``{"slot": 50|0, "reason": ..., "until": ...}``; it does not switch
    the weapon itself.  The caller (bots/human tactical policy) decides when a
    legal WeaponChange may be sent.
    """
    state = _route_holder(target)
    state.mobility_until = float(now) + max(0.0, float(duration))
    state.mobility_reason = str(reason or "route")
    slot = POS_MELEE if str(weapon or "melee") == "melee" else 0
    return {"slot": slot, "reason": state.mobility_reason,
            "until": state.mobility_until}


def weapon_preference(target: Any, now: float, *,
                      threat_visible: bool = False,
                      threat_dist: float = float("inf"),
                      safe: float = 0.0,
                      melee_ready: bool = True) -> str:
    """Return ``melee`` or ``gun`` for the current route/threat snapshot."""
    state = _route_holder(target)
    if threat_visible:
        # Any target the caller considers engaged cancels route mobility.
        return "gun"
    if not melee_ready:
        return "gun"
    if now < state.mobility_until:
        return "melee"
    if state.route in ("parkour", "transfer", "route", "safe") and not threat_visible:
        return "melee"
    return "gun"


# ---------------------------------------------------------------------------
# Module-level default catalogue (built lazily from the shipped tables).
# ---------------------------------------------------------------------------
_CATALOG: Optional[WeaponCatalog] = None


def catalog() -> WeaponCatalog:
    global _CATALOG
    if _CATALOG is None:
        _CATALOG = build_catalog()
    return _CATALOG


def _safe_knight(itemid: int, star: int, entry) -> bool:
    """【v20】4-9★ 骑士/龙系列里「确认没问题」的枪，允许进高难 BOT 池。

    v19 一律按 `tex != 0 / levelTag` 排除，实测过度保守：这些 id 全都有
    Gun.json 真实数据、都在 cat.pool(11) 里、APK 里也确实有对应 FPS 模型
    （`{resource}_fps` 与 `{resource}_tex_99`）。白名单见
    rank_profiles.SAFE_KNIGHT_IDS；10★ 以上、缺数据/缺模型的仍排除。
    """
    from . import rank_profiles as _rp
    try:
        return (int(itemid) in _rp.SAFE_KNIGHT_IDS
                and 4 <= int(star) <= 9
                and int(getattr(entry, "tex", 0) or 0) != 0)
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# 【v1.0.2】两条 BOT 武器池是**互不相干**的两套，不要混用：
#   A. PVE 机器人关卡 / 靶场 BOT —— 纯客户端离线跑（OfflineServer），
#      武器只来自客户端 Configs 的 RobotDesc.primWeapon 表，服务端不下发装备。
#      该表已净化为 1-4★、tex=0 的基础枪（见 cfg/patch_configs_final.py (d) 段）。
#   B. 联机对战 BOT（竞技 / 生化 / 排位 / 联赛）—— 本文件 basic_bot_loadout()
#      按房间星级区间发枪，高难房才允许 4-9★ 骑士 / 龙系列。
# 历史上把 A 当成 B 的「下游」排查过多次，全部白费；改任何一边前先确认模式。
PVE_FORBIDDEN_STAR = 9     # A 池禁止 >=9★（骑士/龙）
PVE_FORBIDDEN_TEX  = 20    # A 池禁止 tex>=20（纯染色皮肤 & 骑士龙 tex=99）


@lru_cache(maxsize=None)
def basic_bot_pool(slot: int, category: str = "", lo: int = 0,
                   hi: int = -1, allow_knights: bool = False) -> Tuple[int, ...]:
    """BOT 可选武器池：**同一把枪的多个星级版本都放进来**。

    原来按 `resource` 去重后每把枪只留最低星那个，全房 21 把枪来来回回
    就那几支。现在按「模型 + 星级」去重，多样性直接翻倍。

    排除规则（v21 修正；v21.1 放开改造满级 tex=1）：
    * `tex` 只放行 `0` 与 `1`：
        - tex=0  = 永久版基础模型；
        - tex=1  = 「改造满级」升级模型（客户端确有 `{res}_tex_1` FPS 模型，
                  与纯皮肤不同），经 `texture_verified` 审计 46/47 通过，放开。
    * `tex` 20~24（黄金/赤魔/幽魂/猎魂等纯染色皮肤）与 tex=99（骑士/传奇）
      仍排除（tex=99 仅由高难房 SAFE_KNIGHT_IDS 另行放行）。这些在旧客户端
      没有第一把模型，放进去会「出生即退图」，即用户说的「皮肤=期限版」要排除。
    * 唯一例外：M82A3(605171) 在 `VERIFIED_RESOURCES` 里只有 tex 20~24、
      没有 tex=1 模型，被 `texture_verified` 判为未验证 → `included=False`，
      在 catalog 构建阶段就被剔除，永远不会进池（脏数据/作废行）。
    * 期限版（同名同星、id+1,000,000 的另一份）不在这里判，靠下面的
      `(resource, star)` 去重保留永久版（小写 id）自动丢弃，不会进池。
    * `levelTag` 只是 Icon_Elite/Knight/Legend 的**图标徽章**，不是期限标记；
      永久版 tex=0 的枪（蟒蛇/M93R 等）带 Icon_Elite 不该被误杀，故不再用它过滤。
    高难房额外放行「确认没问题」的 4-9★ 骑士 / 龙系列（tex=99），走 SAFE_KNIGHT_IDS。

    【v19】lo/hi 给高难房做星级区间（含端点）：排位 4-7、联赛 7-9。
    hi<0 表示沿用全局 `bot_pool_max_star`，即原来的行为。
    """
    from ..config import CONFIG
    try:
        max_star = int(getattr(CONFIG, "bot_pool_max_star", 4) or 4)
    except (TypeError, ValueError):
        max_star = 4
    hi_star = max_star if hi is None or int(hi) < 0 else int(hi)
    lo_star = max(0, int(lo or 0))
    items = _by_id(_table("Item"))
    cat = catalog()
    out: list = []
    seen = set()
    for itemid in cat.pool(slot, category):
        entry = cat.entries[itemid]
        item = items[itemid]
        star = _i(item, "star")
        if not lo_star <= star <= hi_star:
            continue
        if entry.tex not in (0, 1):
            # 只排除纯皮肤（tex 20~24：黄金/赤魔/幽魂等）与 tex=99（骑士/传奇）。
            # tex=0（永久版基础模型）与 tex=1（改造满级升级模型，已 texture_verified
            # 审计通过）都放行。tex=1 是升级系统改的模型/贴图、客户端确有模型，
            # 与纯染色皮肤不同 —— v21.1 放开。
            # 期限版是「同名同星、id+1,000,000」的另一份，靠下面的
            # (resource, star) 去重保留永久版（小写 id）自动干掉，不在这里判。
            # levelTag 只是 Icon_Elite/Knight/Legend 图标徽章，不是期限标记，
            # 永久版 tex=0 的枪（如蟒蛇/M93R）带它也不该被误杀 —— v21 修正。
            # 高难房额外放行「确认没问题」的 4-9★ 骑士 / 龙系列（tex=99）。
            if not (allow_knights and slot == POS_MAIN_GUN
                    and _safe_knight(itemid, star, entry)):
                continue
        key = (entry.resource, star)
        if key in seen:
            continue
        seen.add(key)
        out.append(int(itemid))
    return tuple(sorted(out))


def basic_bot_loadout(index: int, round_index: int = 0, *, seed: int = 0,
                      main_category: str = "", stars=None,
                      allow_knights: Optional[bool] = None) -> Dict[int, int]:
    """Shuffle each basic pool once per match/round, then spread picks by BOT index.

    【v19】stars=(lo,hi) 时按高难房星级区间抽枪；某个槽位在该区间里没有
    安全枪（例如 7-9 星的副武器/近战）就退回默认池，避免 BOT 空手出生。
    """
    rng = Random(seed + round_index)
    categories = list(MAIN_CATEGORY_ORDER)
    rng.shuffle(categories)
    # Keep the RNG draws for each slot independent of the BOT's main category.
    offsets = {slot: rng.getrandbits(32) for slot in (POS_MAIN_GUN, POS_VICE_GUN, POS_MELEE)}
    main_category = main_category or categories[index % len(categories)]
    result = {}
    # 只有高难房会传 stars；顺便放行 4-9★ 的安全骑士/龙系列。
    # 【v30】allow_knights 显式给定时以它为准（生化房 1-7★ 但要禁骑士）。
    _knights = (stars is not None) if allow_knights is None else bool(allow_knights)
    for slot in offsets:
        cat_name = main_category if slot == POS_MAIN_GUN else ""
        if stars:
            pool = list(basic_bot_pool(slot, cat_name, int(stars[0]),
                                       int(stars[1]), allow_knights=_knights))
            if not pool:
                pool = list(basic_bot_pool(slot, cat_name))
        else:
            pool = list(basic_bot_pool(slot, cat_name))
        if pool:
            Random(offsets[slot]).shuffle(pool)
            result[slot] = pool[index % len(pool)]
    return result


def clear_cache() -> None:
    global _CATALOG
    _CATALOG = None
    basic_bot_pool.cache_clear()
