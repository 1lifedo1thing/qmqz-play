"""Multi-pellet / burst shot settlement shared by relay and human BOTs.

Why this module exists
----------------------
`bots._fire` used to send one `ScShoot` per due round.  That is correct for a
gun with `firePerShoot=1, bulletPerShoot=1`, but wrong for the 36 shotguns and
14 burst rows in this package: the client sends `ScMultiShoot` instead.

Native reads (``work/decomp_181``):

    AGun.cs:1031-1045  shootPerFire = max(1, Gun.firePerShoot)
                       bulletPerShoot = max(1, Gun.bulletPerShoot)
                       harmPerFire = Mathf.Max(shootPerFire, bulletPerShoot)
    AGun.cs:386-433    FireTask: one trigger event per Gun.shootSpeed,
                       shootSurplus = shootPerFire rounds spaced
                       Gun.shootInterval
    AGun.cs:519-555    OneShot: every round does surplusBullets-- (one magazine
                       round), and only firstTrigger with harmPerFire > 1 calls
                       GetAimRays() then Warrior.MultiShoot(shoots)
    AGun.cs:463-514    GetAimRays fills one ray per harmPerFire slot;
                       Util.UniformInCircle(cachedBulletpoints, grapeshotdistribution)
    Robot.cs:316-320   ShootDistribution(dir, grape) = InsideEllipse(grape*.25,
                       grape*.25) degrees  <- the BOT path
    Util.cs:145-164    UniformInCircle: one point per equal sector with a random
                       radius in [0, radius]
    ClientManager.cs:727-755  MultiShoot(shooterid, shoots) -> DamageTargets

So: a shotgun consumes **one** shell and emits `bulletPerShoot` rays; a burst
row (firePerShoot=3, bulletPerShoot=3) consumes 3 rounds and emits 3 rays on
the trigger's first round only.  Those 3 rounds may be released over several
dispatches, but the native `firstTrigger` ray group is emitted exactly once
per trigger.  `ScMultiShoot` carries a list of `ShootDamage` (each with its
own position/dir/targets), exactly like `ShootDamage.cs`.

Hit model status
----------------
The per-ray cone below reproduces the documented `grapeshotdistribution`
spread (Robot.ShootDistribution => ``grape * 0.25`` degrees) and lets each
pellet miss.  It is a **reconstruction**: the native Robot path also adds
``Robot.GetShootDirection(Random.Range(DistributionMin, DistributionMax))``
whose accuracy comes from Robot AI params that are not present in this
package's tables, and the player path uses screen-space pixels.  No attempt is
made to claim those missing values; the cone is the only table-backed part.

No production file, device, database or network is touched.
"""
from __future__ import annotations

import math
import random
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

SC_MULTI_SHOOT = 1441900          # == battle.ID.SC_MULTI_SHOOT
MAX_PELLETS = 32                  # malformed-row guard
BODY_RADIUS = 0.35                # geometry.BODY_RADIUS

# 【v1.1.0】打击者全族单独加散布（度）。用户口径：「每把打击者都加 0.5」。
# 判据用 Item.resource == "Striker"（大小写不敏感），共 6 个 id：
#   203081 打击者 / 203082 哨兵 / 203083 破墙者 / 203084 粉碎者 /
#   203085 爆裂 / 1203081 打击者（克隆）。
# 全表霰弹只有 Striker 这一族命中，其它霰弹（SPAS-12 / AA-12 / KSG / M1014）
# 以及步枪、机枪、冲锋枪、狙击枪完全不受影响。
STRIKER_SPREAD_BONUS = 0.5


def _damage():
    from . import damage
    return damage


def _f(row: Any, key: str, default: float = 0.0) -> float:
    try:
        return float(getattr(row, key, default) or default)
    except (TypeError, ValueError):
        return default


def _i(row: Any, key: str, default: int = 0) -> int:
    try:
        return int(getattr(row, key, default) or default)
    except (TypeError, ValueError):
        return default


def needs_multi(info: Any) -> bool:
    """True for rows whose native OneShot calls Warrior.MultiShoot."""
    if info is None:
        return False
    return (max(1, _i(info, "bullet_per_shot", 1)) > 1
            or max(1, _i(info, "fire_per_shot", 1)) > 1)


def pellet_spread_deg(info: Any, moving: bool = False,
                      running: bool = False, crawling: bool = False) -> float:
    """多弹丸枪的**弹丸锥半径**（度）。

    两条路径，靠 `bulletPerShoot` 和 `firePerShoot` 区分：

    * **霰弹**（`bulletPerShoot > firePerShoot`，一扣扳机 8 颗弹丸、只消耗 1 发）：
      用这把枪自己的 `minDistributionStand/Walk/Run/Crouch`（2~4°），
      这样 9★ 的 AA-12炼狱/打击者·爆裂 比 1★ SPAS-12 更紧，跑动时更散
      （上限 5°=旧值，绝不会比改前更散）。旧实现一律 `grapeshot*0.25`=5°，
      **36 把霰弹全一样**，10m 只剩 1/8 弹丸命中 —— 用户实测「太弱」就是这个。
    * **三连发/多弹丸步枪**（`bulletPerShoot == firePerShoot`，M93R/FAMAS/M16A4）：
      保持 `grapeshot*0.25` 不变，它们的弹丸本来就是同一次扣扳机的连续弹。
    """
    if info is None:
        return 0.0
    bps = max(1, _i(info, "bullet_per_shot", 1))
    fps = max(1, _i(info, "fire_per_shot", 1))
    if bps <= 1:
        return 0.0
    if bps > fps:
        if crawling:
            v = _f(info, "dist_min_crouch", 0.0)
        elif running:
            v = _f(info, "dist_min_run", 0.0)
        elif moving:
            v = _f(info, "dist_min_walk", 0.0)
        else:
            v = _f(info, "dist_min_stand", 0.0)
        # 兜底：老存档没有 distribution 字段时回到 grape*0.25。
        if v > 0:
            try:
                from ..config import CONFIG
                k = float(getattr(CONFIG, "bot_shotgun_spread_scale", 1.0) or 1.0)
            except (TypeError, ValueError):
                k = 1.0
            base = max(0.0, min(5.0, v * max(0.1, k)))
            # 【v1.1.0】加成放在 5° 上限**之外**：打击者跑动姿态原表是
            # 5.53~6.0，已被 min(5.0) 截平；若在截断前加会被吃掉，
            # 就不是「每个姿态都 +0.5」了。联赛基准下精确 +0.5°，
            # 其它模式仍按既有 _mode_spread_scale 一起缩放。
            if str(getattr(info, "resource", "") or "").strip().upper() == "STRIKER":
                base += STRIKER_SPREAD_BONUS
            return base
    grape = max(0, _i(info, "grapeshot", 1))
    return max(0.0, grape * 0.25)


def gun_spread_deg(info: Any, moving: bool = False,
                   running: bool = False) -> float:
    """枪械散布角（度），直接来自 Gun.json 的 min/maxDistribution*。

    服务端原来**完全没用**这张表：`pellet_spread_deg` 只处理霰弹，普通枪
    恒返回 0 —— bot 的子弹是零散布直线，所以远距离也枪枪咬肉。这里按
    姿态取「最小散布」作为基准（连发累积由调用方决定要不要叠）。

    霰弹（bulletPerShoot > 1）仍走 pellet 锥角，那是弹丸自身的分布。
    """
    if info is None:
        return 0.0
    if max(1, _i(info, "bullet_per_shot", 1)) > 1:
        return pellet_spread_deg(info, moving=moving, running=running)
    if running:
        v = _f(info, "dist_min_run", 0.0)
    elif moving:
        v = _f(info, "dist_min_walk", 0.0)
    else:
        v = _f(info, "dist_min_stand", 0.0)
    if v <= 0:
        # 老存档/异常行兜底：没有散布数据就别加惩罚
        return 0.0
    return max(0.0, v)


# bot 的「已瞄准」修正。
#
# Gun.json 里的 min/maxDistribution* 是**腰射**散布：步枪 2~3°，而狙击
# （狂龙改·38）站立就是 35°、跑动 38° —— 原版玩家必须开镜才能把散布压下来，
# bot 不会开镜，直接套用等于永远打不中。所以：
#   * 瞄准类武器（shootSpeed ≥ 0.75s，狙击/半自动重火力）按开镜处理，给 0.4°
#   * 其余武器用表里的站立散布，但封顶 6°（防止异常行让 bot 变木桩）
#   * 霰弹继续用 pellet 锥角，那是弹丸自身的分布，不该被压掉
BOT_SNIPER_SPREAD = 1.0           # 狙击固定锥（表值是脏数据，见下）；v8: 0.4→1.0
BOT_SPREAD_CAP = 6.0
BOT_AIM_SHOOT_SPEED = 0.75

# 【v1.0.5】散布表「脏值」识别。Gun.json 的 min/maxDistribution* 对普通枪是
# 2~20 的内部单位，但**慢射精确步枪 / 狙击**那一套被填成了 34~55 / 180~490。
# 原实现只靠 shoot_speed >= 0.75 认狙击，于是 0.46~0.74 的 M14EBR 三兄弟
# (34/300) 和 WA2000 两把 (38/340) 漏判，套公式算出 25~28° 的天女散花：
# 20m 处命中半径只有 1.00°，命中率 ≈ 0.16%，表现就是「联赛 BOT 根本打不中人」。
# 这 6 把是全表 423 把里唯一 >6° 的，其余全部 <=3°。
DIRTY_SPREAD_MIN = 30.0         # dist_min_* 超过它就是脏表
DIRTY_SPREAD_MAX = 200.0        # dist_max_* 超过它就是脏表

# 【v1.0.7】用户口径：「枪族内出异常的对标族内其他正常的改好，不再削弱 =
# 不人为降低命中率」。即异常行（M14EBR 三把 24.95°、WA2000 女妖/女武神
# 28.20°）一律对齐族内正常狙击的 BOT_SNIPER_SPREAD=1.00°，
# 撤销 v1.0.5 的 1.50° 与 v1.0.6 WA2000 全系 1.12° 这两个人工削弱锥。
# 结果：BOT 可拿的 30 把狙击枪全部 1.00°（竞技/联赛），20m 100%，
# 拐点 20.05m；修正脏表错误这件事本身保留，不再二次压命中率。
# 想切回 v1.0.6：加回 BOT_DIRTY_SPREAD=1.5 / BOT_WA2000_SPREAD=1.12 及
# official_spread_deg 里的 WA2000 入口分支即可。

# 官方 AI 的散布口径（Robot.GetShootDirection）：
#   waggle = Random.Range(DistributionMin, DistributionMax)   # 按姿态取
#   r      = (waggle + 4*(1 - accuracy/2000)) * 0.33          # 度
# accuracy 来自 rank：Lv4 军官 rank 22~43 → 500+15*(rank-1) = 815~1130，
# 取中位 rank32 = 965。
SPREAD_ACCURACY_L4 = 965
SPREAD_OFFICIAL_K = 0.33


def _accuracy_penalty(accuracy: float) -> float:
    """官方精度惩罚：4 × (1 − accuracy/2000) 度（rank 越高越小）。"""
    return 4.0 * max(0.0, 1.0 - float(accuracy) / 2000.0)


def _spread_scale() -> float:
    try:
        from ..config import CONFIG
        return max(0.0, float(getattr(CONFIG, "bot_spread_scale", 0.4)))
    except (TypeError, ValueError):
        return 0.4


def _fixed_cone_deg(s: float, base: float) -> float:
    """固定小锥：把 mode 的 scale 映射到 [0.4, 1.0] 倍，不套 waggle 公式。"""
    return max(0.0, float(base)) * (
        1.0 if s <= 0 else max(0.4, min(1.0, s / 0.4)))


# 【v1.0.9】狙击枪「等效命中点」平衡，方案 C（DPS 严格平衡）。
# 锚点 M200 (602061)：1.90 秒/发、拐点 20.05 m、散布 1.00°。
#   拐点² / p = 20.05² / 1.90 = 211.58   ->   d* = 14.5458 × √p
#   spread°   = atan(0.35 / d*)          （由拐点反推散布，见 aim_shoots）
# 为什么是平方根：拐点后命中率 P ∝ d*²，射速 = 1/p，要让
#   「命中率 × 射速」对每把枪都相等，必须 d* ∝ √p。
# 三套方案里唯一让 DPS 指数在任意拐点后距离恒为 1.00 的公式。
# 【方案沿革】v1.0.8 曾按「(1/p)×d* = 10.5526」线性落地（方案 B），
#   实测会过度压低快枪（M14EBR 20m 只有 7%），v1.0.9 改成本式。
# ★ 字面写法「秒/发 × 拐点 = 38.095」方向是反的：M14EBR 会拿到 76.19 m
#   拐点 / 0.26°，20m 与 40m 都 100%，DPS 变成 M200 的 8.8 倍，已否决。
# 只作用于 Gun.actType == 6 的狙击枪（全表 66 把，BOT 池 30 把）；
# 步枪 / 霰弹 / 冲锋枪、以及走客户端 RobotDesc 的 PVE 离线关卡完全不受影响。
SNIPER_ACT_TYPE = 6
SNIPER_BALANCE_REF_PERIOD = 1.90
SNIPER_BALANCE_REF_KNEE = 20.05
SNIPER_BALANCE_C = (SNIPER_BALANCE_REF_KNEE
                    / math.sqrt(SNIPER_BALANCE_REF_PERIOD))       # 14.5458
SNIPER_BALANCE_INVARIANT = (SNIPER_BALANCE_REF_KNEE ** 2
                            / SNIPER_BALANCE_REF_PERIOD)          # 211.58


def balanced_sniper_spread_deg(period: float) -> float:
    """由 shootSpeed（秒/发）反推狙击散布角（度，联赛基准）。

    d* = SNIPER_BALANCE_C × √p，spread = atan(BODY_RADIUS / d*)。
    """
    p = max(0.05, float(period or 0.0))
    knee = SNIPER_BALANCE_C * math.sqrt(p)
    return math.degrees(math.atan2(BODY_RADIUS, knee))


def official_spread_deg(info: Any, *, moving: bool = False,
                        running: bool = False, crawling: bool = False,
                        accuracy: int = SPREAD_ACCURACY_L4,
                        scale: Optional[float] = None,
                        sniper_deg: Optional[float] = None) -> float:
    """还原官方 Bot 的散布锥（度），按**当前持有那把枪 + 当前姿态**取表。

    表里的 min/maxDistribution* 对绝大多数枪是同一套单位（2~30），但
    **狙击枪是脏数据**（最小 44、最大 315），套公式会变成 15~100 度的乱扫。
    【v1.0.9】`actType == 6` 的狙击枪改走 `balanced_sniper_spread_deg()`，
    由 shootSpeed 反推散布（等效命中点平衡）；其余瞄准类武器
    (shootSpeed >= 0.75) 仍走固定小锥 `BOT_SNIPER_SPREAD`（1.00°）。

    `scale` 是把官方公式映射到我们这套「圆柱体命中」判定的标定系数：
    1.0 = 完全按官方算（在我们的判定下过散，10m 只有 ~27% 命中），
    默认 0.4 让 Lv4 军官落在「10m 必中、20m 四成、30m 两成」。
    """
    if info is None:
        return 0.0
    if max(1, _i(info, "bullet_per_shot", 1)) > 1:
        return pellet_spread_deg(info, moving=moving, running=running,
                                 crawling=crawling)
    try:
        period = float(getattr(info, "shoot_speed", 0.0) or 0.0)
    except (TypeError, ValueError):
        period = 0.0

    # 【v1.0.9】狙击枪按「等效命中点」平衡：actType=6 全部改由 shootSpeed
    # 反推散布，替代 v1.0.7 的统一 1.00° 固定锥。放在最前面，这样
    # M14EBR / WA2000 这些 shootSpeed<0.75 的快狙也走同一条口径，
    # 不再需要脏表分支兜它们。生化房按 sniper_deg/1.00 比例缩放
    # （0.4 -> ×0.4，保持「生化 BOT 更准」的原有设定）。
    if _i(info, "act_type", 0) == SNIPER_ACT_TYPE:
        base = balanced_sniper_spread_deg(period)
        if sniper_deg is not None:
            base *= max(0.0, float(sniper_deg)) / BOT_SNIPER_SPREAD
        s = _spread_scale() if scale is None else float(scale)
        return _fixed_cone_deg(s, base)

    # 【v1.0.7】撤销 WA2000 全系 1.12° 专用锥：这 6 把按 shootSpeed 自然
    # 分成「狙击固定锥」和「脏表行对标 1.00°」两条路径，结果同为 1.00°，
    # 不需要按 resource 硬统一，也不再人为把 20m 命中率从 100% 压到 80%。
    if period >= BOT_AIM_SHOOT_SPEED:
        base = BOT_SNIPER_SPREAD if sniper_deg is None else max(0.0, float(sniper_deg))
        s = _spread_scale() if scale is None else float(scale)
        return _fixed_cone_deg(s, base)

    if crawling:
        lo, hi = _f(info, "dist_min_crouch", 0.0), _f(info, "dist_max_crouch", 0.0)
    elif running:
        lo, hi = _f(info, "dist_min_run", 0.0), _f(info, "dist_max_run", 0.0)
    elif moving:
        lo, hi = _f(info, "dist_min_walk", 0.0), _f(info, "dist_max_walk", 0.0)
    else:
        lo, hi = _f(info, "dist_min_stand", 0.0), _f(info, "dist_max_stand", 0.0)
    # 【v1.0.5 + v1.0.7】脏散布表保护：这类枪的 max 是「连发累积上限」，
    # 不是单发散布，取 (min+max)/2 会算出 24.95° / 28.20° 的天女散花。
    # v1.0.5 先收敛到 1.50°；【v1.0.7】按用户口径改为对标族内正常值
    # BOT_SNIPER_SPREAD=1.00°，不再人为降低命中率。这里覆盖 M14EBR 全系
    # 与 WA2000 女妖/女武神。生化房 sniper_deg=0.4 仍照旧尊重。
    if lo >= DIRTY_SPREAD_MIN or hi >= DIRTY_SPREAD_MAX:
        base = BOT_SNIPER_SPREAD if sniper_deg is None else max(0.0, float(sniper_deg))
        s = _spread_scale() if scale is None else max(0.0, float(scale))
        return _fixed_cone_deg(s, base)
    if hi <= 0 and lo <= 0:
        # 老存档/异常行：没有散布数据就不加惩罚（宁可必中也不要朝天开枪）
        return 0.0
    if hi < lo:
        lo, hi = hi, lo
    waggle = (lo + hi) * 0.5          # 官方是 Random.Range(lo,hi)，取均值即可
    s = _spread_scale() if scale is None else max(0.0, float(scale))
    # ★ BOT_SPREAD_CAP 原先定义了却从未启用；作为最后兜底，防止以后再有
    #   异常表把散布顶到几十度。正常枪 <=3°，不受影响。
    return min(BOT_SPREAD_CAP,
               max(0.0, (waggle + _accuracy_penalty(accuracy)) * SPREAD_OFFICIAL_K * s))


def bot_spread_deg(info: Any, **kw) -> float:
    """bot 实际使用的散布角（度）。转发到官方口径实现。"""
    return official_spread_deg(info, **kw)


def volley_rounds(info: Any, rounds: int) -> List[int]:
    """Split due rounds into native trigger events (AGun.FireTask).

    One trigger event spends ``firePerShoot`` rounds; a partial trigger (clip
    ran dry) spends whatever is left.
    """
    fire = max(1, _i(info, "fire_per_shot", 1))
    left = max(0, int(rounds))
    out: List[int] = []
    while left > 0:
        take = min(fire, left)
        out.append(take)
        left -= take
    return out


def rays_per_volley(info: Any, rounds: Optional[int] = None) -> int:
    """Rays in the first OneShot of a trigger = harmPerFire.

    ``harmPerFire = max(firePerShoot, bulletPerShoot)`` (AGun.cs:1045) and
    native ``firstTrigger`` emits that whole group even when only one round is
    left in the magazine (AGun.cs:527-554).  The parameter is accepted for
    callers that used to pass the dispatch round count, but the ray count must
    not be derived from it: a 3-round burst split 1+2 across dispatches still
    emits one group of 3 rays, not 3+3.
    """
    return min(MAX_PELLETS, max(1, _i(info, "fire_per_shot", 1),
                                 _i(info, "bullet_per_shot", 1)))


def _rand(seed: int) -> random.Random:
    return random.Random(int(seed) & 0x7FFFFFFF)


def _basis(d: Tuple[float, float, float]):
    up = (0.0, 1.0, 0.0) if abs(d[1]) < 0.9 else (1.0, 0.0, 0.0)
    right = (d[1] * up[2] - d[2] * up[1],
             d[2] * up[0] - d[0] * up[2],
             d[0] * up[1] - d[1] * up[0])
    n = math.sqrt(right[0] ** 2 + right[1] ** 2 + right[2] ** 2) or 1.0
    right = (right[0] / n, right[1] / n, right[2] / n)
    up = (right[1] * d[2] - right[2] * d[1],
          right[2] * d[0] - right[0] * d[2],
          right[0] * d[1] - right[1] * d[0])
    return right, up


def _rotate(d, off_deg: float, azimuth: float):
    if off_deg <= 1e-9:
        return d
    right, up = _basis(d)
    t = math.tan(math.radians(off_deg))
    ax, ay = math.cos(azimuth) * t, math.sin(azimuth) * t
    v = (d[0] + right[0] * ax + up[0] * ay,
         d[1] + right[1] * ax + up[1] * ay,
         d[2] + right[2] * ax + up[2] * ay)
    n = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
    return (v[0] / n, v[1] / n, v[2] / n)


def pellet_offsets(shooterid: int, weaponid: int, seq: int, count: int,
                   spread_deg: float) -> List[Tuple[float, float]]:
    """Deterministic UniformInCircle analogue: (offset_deg, azimuth_rad)."""
    count = max(1, min(MAX_PELLETS, int(count)))
    if spread_deg <= 1e-9:
        return [(0.0, 0.0)] * count
    step = 2.0 * math.pi / count
    out: List[Tuple[float, float]] = []
    for i in range(count):
        rnd = _rand((int(shooterid) * 2654435761)
                    ^ (int(weaponid) * 40503)
                    ^ (int(seq) * 9176) ^ (i * 7919))
        azimuth = step * (i + rnd.random())
        radius = spread_deg * math.sqrt(rnd.random())
        out.append((radius, azimuth))
    return out


def _v3(p) -> Dict[str, int]:
    return {"x": int(round(p[0] * 100)), "y": int(round(p[1] * 100)),
            "z": int(round(p[2] * 100))}


def _wired(v) -> Dict[str, int]:
    return {"x": int(round(v[0] * 20000)), "y": int(round(v[1] * 20000)),
            "z": int(round(v[2] * 20000))}


def aim_shoots(shooterid: int, weaponid: int, seq: int,
               origin: Sequence[float], aim_dir: Sequence[float],
               targetid: int, target_pos: Sequence[float], dist: float,
               info: Any, count: Optional[int] = None,
               ray_clear=None, *, aim_spread_deg: Optional[float] = None,
               aim_error=(0.0, 0.0)) -> List[Dict[str, Any]]:
    """Build one ShootDamage dict per ray, with table-backed pellet spread.

    ``targets`` is empty for a ray that misses, so the client still renders the
    tracer but the server deals no damage for it.  ``ray_clear(a, b)`` is the
    optional static-geometry channel test; every pellet ray gets its own
    segment query, so a wall that blocks an off-centre pellet cannot be missed
    just because the centre LOS was clear (and vice versa).
    """
    n = rays_per_volley(info) if count is None else int(count)
    n = max(1, min(MAX_PELLETS, n))
    # 没显式给散布时用**枪械自己的真实散布**（原来这里只算了霰弹锥角，
    # 普通枪 = 0°，等于必中）。
    if aim_spread_deg is None:
        spread = bot_spread_deg(info)
    else:
        spread = aim_spread_deg
    radius = BODY_RADIUS + max(0.0, _f(info, "hit_radius", -1.0))
    if dist is not None and float(dist) > 0.05:
        half_deg = math.degrees(math.atan2(radius, float(dist)))
    else:
        half_deg = 90.0
    d = (float(aim_dir[0]), float(aim_dir[1]), float(aim_dir[2]))
    nrm = math.sqrt(d[0] ** 2 + d[1] ** 2 + d[2] ** 2) or 1.0
    d = (d[0] / nrm, d[1] / nrm, d[2] / nrm)
    # Segment length to the aimed body point (target_pos + 1.2 m), not the
    # horizontal distance, so each pellet's own corridor is tested exactly.
    ox, oy, oz = float(origin[0]), float(origin[1]), float(origin[2])
    tx, ty, tz = float(target_pos[0]), float(target_pos[1]), float(target_pos[2])
    seg = math.sqrt((tx - ox) ** 2 + (ty + 1.2 - oy) ** 2 + (tz - oz) ** 2)
    out: List[Dict[str, Any]] = []
    aim = _rotate(d, *aim_error)
    threshold = math.cos(math.radians(half_deg))
    for off, azimuth in pellet_offsets(shooterid, weaponid, seq, n, spread):
        ray = _rotate(aim, off, azimuth)
        hit = sum(a * b for a, b in zip(d, ray)) >= threshold
        if hit and ray_clear is not None and seg > 0.05:
            end = (ox + ray[0] * seg, oy + ray[1] * seg, oz + ray[2] * seg)
            hit = bool(ray_clear((ox, oy, oz), end))
        out.append({
            "position": _v3(origin),
            "dir": _wired(ray),
            "targets": ([{
                "targetid": int(targetid),
                "sd": float(dist),
                "hitpart": 2,
                "hitpos": _v3((target_pos[0], target_pos[1] + 1.2,
                               target_pos[2])),
                "targetpos": _v3(target_pos),
            }] if hit else []),
        })
    return out


def settle_multi(battle, shooterid: int, shoots: Sequence[Dict[str, Any]],
                 is_biochem: bool, log_tag: str = "",
                 recoil: bool = True, extra_hits=None, player_reported=False) -> int:
    """Single damage/death/spawn-protection exit for ScMultiShoot.

    Mirrors ``battle.settle_shoot`` for the multi path:

    * shooter must exist, be born and alive, and the round must still run;
      otherwise nothing is resolved and **nothing is sent**;
    * every ray goes through ``damage.resolve_shoot`` -> same-team and
      spawn-protection/invincible checks, born/hp checks and melee reach;
    * a victim that dies is reported with ``on_kill`` exactly once, after all
      rays have been resolved (later rays already skip hp<=0);
    * bio recoil is registered like the single-shot path.

    Returns the number of damaging hits.
    """
    shooter = battle.fighters.get(int(shooterid))
    if (shooter is None or not getattr(shooter, "born", False)
            or float(getattr(shooter, "hp", 0) or 0) <= 0):
        return 0
    if getattr(battle, "round_over", False) or getattr(battle, "fight_over",
                                                     False):
        return 0
    dmg = _damage()
    from . import premium_ammo
    challenge = getattr(battle, "challenge", None)
    profile, paid_rays = ({}, 0)
    if player_reported and shoots:
        profile, paid_rays = premium_ammo.spend(battle, shooter, rays=len(shoots), multi=True)
    payloads: List[Dict[str, Any]] = []
    hits_all = []
    for index, shoot in enumerate(shoots or []):
        ammo = profile if index < paid_rays else {}
        if player_reported and challenge is None and extra_hits is None:
            from .battle import fill_empty_player_shot
            shoot = fill_empty_player_shot(battle, shooterid, shoot, ammo)
        hits = list(dmg.resolve_shoot(battle, int(shooterid), shoot,
                                      is_biochem=is_biochem, ammo=ammo) or [])
        if challenge is not None:
            hits.extend(challenge.on_shoot(shooterid, shoot, ammo=ammo) or [])
        elif extra_hits is not None:
            hits.extend(extra_hits(shoot) or [])
        payloads.append(dmg.shoot_damage_payload(shoot, hits))
        hits_all.extend(hits)
    if payloads:
        from . import room_ai
        room_ai.note_shot(battle, shooter, hits_all)
    if is_biochem and hits_all and recoil:
        from . import bot_recoil
        bot_recoil.register(battle, int(shooterid), hits_all)
    if log_tag:
        try:
            from . import battle as B
            B.log.info("%s role=%s rays=%d hits=%d", log_tag, shooterid,
                       len(payloads), len(hits_all))
        except Exception:
            pass
    if payloads:
        try:
            from . import battle as B
            type_id = getattr(B.ID, "SC_MULTI_SHOOT", SC_MULTI_SHOOT)
        except Exception:
            type_id = SC_MULTI_SHOOT
        battle.send_all(type_id, shoots=payloads, shooterid=int(shooterid))
    known = set()
    for hit in hits_all:
        tid = int(hit.targetid)
        if hit.died and tid not in known:
            known.add(tid)
            if tid in battle.fighters:
                _, weapon = dmg.active_weapon(shooter)
                battle.on_kill(int(shooterid), tid, weapon)
            elif challenge is not None:
                _, weapon = dmg.active_weapon(shooter)
                challenge.send_deaths(shooterid, weapon, (tid,))
    return len(hits_all)


def bot_fire(battle, shooter, target, dist: float, info: Any,
             rounds: int = 0, seq: int = 0,
             is_biochem: Optional[bool] = None,
             log_tag: str = "BOTMULTI",
             events: Optional[Sequence[Dict[str, Any]]] = None,
             ray_clear=None, *, moving=False,
             aim_pos: Optional[Sequence[float]] = None) -> int:
    """BOT native trigger groups -> ScMultiShoot.

    ``events`` comes from ``human.AmmoState.drain_ray_events()`` and is the
    authoritative list: one entry per FireTask trigger whose *first* round was
    released by the dispatch that produced it.  Continuation rounds of a burst
    appear in the same dispatch's ``rounds`` count but have no event, so they
    never emit another ray group.  This is what keeps a 3-round trigger split
    as 1+2 dispatches at 3 rays total.

    ``rounds`` is only a legacy fallback for direct callers without an
    AmmoState; it groups the count as whole/partial triggers and emits one
    group of ``harmPerFire`` rays per group.  Production always passes events.

    Returns damaging hits; the magazine was already charged by
    ``AmmoState.take_shots`` (one round per consumed round), so this function
    never touches ammo.
    """
    fp = getattr(shooter, "syncpos", None)
    # ``aim_pos`` = 目标在「瞄准滞后」时刻的位置（bot 不开自瞄，打的是上一刻）。
    tp = aim_pos if aim_pos is not None else getattr(target, "syncpos", None)
    if fp is None or tp is None:
        return 0
    dx, dy, dz = tp[0] - fp[0], (tp[1] + 1.2) - (fp[1] + 1.5), tp[2] - fp[2]
    n = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
    aim = (dx / n, dy / n, dz / n)
    origin = (fp[0], fp[1] + 1.5, fp[2])
    bio = (getattr(battle, "biochem", None) is not None
           if is_biochem is None else bool(is_biochem))
    if events is None:
        groups: List[Dict[str, Any]] = [
            {"rays": rays_per_volley(info)} for _ in volley_rounds(info, rounds)]
    else:
        groups = list(events)
    hits = 0
    for event in groups:
        count = int((event or {}).get("rays", 0) or 0)
        if count <= 0:
            continue
        shoots = aim_shoots(int(shooter.roleid), _i(info, "itemid"),
                            int(seq), origin, aim,
                            int(target.roleid), tp, float(dist), info,
                            count=count, ray_clear=ray_clear)
        hits += settle_multi(battle, int(shooter.roleid), shoots, bio,
                             log_tag=log_tag)
        seq += 17
    return hits
