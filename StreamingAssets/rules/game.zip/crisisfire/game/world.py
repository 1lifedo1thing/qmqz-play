"""In-memory world state + SQLite persistence for accounts and roles.

The real game keeps a large per-role blob (equipment, depot, tasks, society,
...).  We store that as a JSON document keyed by role id, with a few hot
columns promoted for queries.
"""
from __future__ import annotations

import itertools
import json
import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

log = logging.getLogger("crisisfire.world")

# Starting wallet for a brand new role.  Generous on purpose: a private server
# exists to let people actually play, and the client's shop reads these.
# 【v18】账号基础货币：金币 10000 / 钻石 500 / 荣誉 500。
# 字段名反直觉（见下面 Role 定义）：money=金币、gold=钻石、diamond=荣誉。
START_MONEY = 10_000
START_GOLD = 500
START_DIAMOND = 500

# --- 账号密码 ---------------------------------------------------------------
# Passwords used to be stored in the clear and never checked, which meant any
# client could log into any account just by knowing the name -- and since the
# client defaulted to the literal name "player", every device shared one
# account.  Now the password is PBKDF2-hashed and verified.
PBKDF2_ROUNDS = 120_000


def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """Return (hash_hex, salt_hex).  Empty password is allowed but hashed too."""
    import hashlib
    import secrets
    salt_bytes = bytes.fromhex(salt) if salt else secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                             salt_bytes, PBKDF2_ROUNDS)
    return dk.hex(), salt_bytes.hex()


def verify_password(password: str, pw_hash: str, salt: str) -> bool:
    import hmac
    if not pw_hash or not salt:
        return False
    try:
        got, _ = hash_password(password, salt)
    except ValueError:
        return False
    return hmac.compare_digest(got, pw_hash)


# login() outcomes
LOGIN_OK = "ok"                 # 已有账号，密码正确
LOGIN_CREATED = "created"       # 新账号，已注册
LOGIN_BAD_PASSWORD = "bad_password"
LOGIN_BAD_NAME = "bad_name"
LOGIN_NOT_FOUND = "not_found"

# Account name rules.  The client sends "<typed name>$<platform>", so exactly
# one trailing platform suffix is allowed; anything else containing '$' is not.
NAME_MIN = 2
NAME_MAX = 16
_NAME_BAD = set(' \\/:*?"<>|\t\r\n$')
PLATFORM_SUFFIXES = ("local", "cyyd", "cmge", "cmbp", "ximi", "xmwa", "qihu",
                     "ppst", "yiwa", "duku", "putao", "37wa")


SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    userid      INTEGER PRIMARY KEY,
    account     TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL DEFAULT '',
    created     REAL NOT NULL,
    banned      INTEGER NOT NULL DEFAULT 0,
    ban_reason  TEXT NOT NULL DEFAULT '',
    ban_until   REAL NOT NULL DEFAULT 0,
    pw_hash     TEXT NOT NULL DEFAULT '',
    pw_salt     TEXT NOT NULL DEFAULT '',
    last_login  REAL NOT NULL DEFAULT 0,
    login_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS roles (
    roleid      INTEGER PRIMARY KEY,
    userid      INTEGER NOT NULL,
    name        TEXT NOT NULL,
    level       INTEGER NOT NULL DEFAULT 1,
    exp         INTEGER NOT NULL DEFAULT 0,
    gold        INTEGER NOT NULL DEFAULT 0,
    money       INTEGER NOT NULL DEFAULT 0,
    diamond     INTEGER NOT NULL DEFAULT 0,
    iconid      INTEGER NOT NULL DEFAULT 0,
    sex         INTEGER NOT NULL DEFAULT 0,
    data        TEXT NOT NULL DEFAULT '{}',
    created     REAL NOT NULL,
    last_login  REAL NOT NULL DEFAULT 0,
    UNIQUE(userid, name)
);
CREATE TABLE IF NOT EXISTS rooms (
    roomid      INTEGER PRIMARY KEY,
    owner       INTEGER NOT NULL,
    name        TEXT NOT NULL,
    mode        INTEGER NOT NULL DEFAULT 0,
    mapid       INTEGER NOT NULL DEFAULT 0,
    maxplayer   INTEGER NOT NULL DEFAULT 8,
    haspass     INTEGER NOT NULL DEFAULT 0,
    password    TEXT NOT NULL DEFAULT '',
    data        TEXT NOT NULL DEFAULT '{}',
    created     REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_roles_user ON roles(userid);
-- 好友 / 黑名单 / 待处理请求.  kind: 1 = 好友, 2 = 黑名单
CREATE TABLE IF NOT EXISTS friends (
    roleid   INTEGER NOT NULL,
    friendid INTEGER NOT NULL,
    kind     INTEGER NOT NULL DEFAULT 1,
    created  REAL NOT NULL,
    PRIMARY KEY (roleid, friendid, kind)
);
CREATE TABLE IF NOT EXISTS friend_requests (
    fromid  INTEGER NOT NULL,
    toid    INTEGER NOT NULL,
    created REAL NOT NULL,
    PRIMARY KEY (fromid, toid)
);
CREATE INDEX IF NOT EXISTS idx_friends_role ON friends(roleid, kind);
CREATE INDEX IF NOT EXISTS idx_freq_to ON friend_requests(toid);
"""


@dataclass
class Role:
    roleid: int
    userid: int
    name: str
    level: int = 1
    exp: int = 0
    gold: int = 0            # 1.8.1 account: blue gems (UserManager.CanBuy)
    money: int = 0           # 1.8.1 account: coins
    diamond: int = 0         # 1.8.1 account: honor / bloodGem
    iconid: int = 0
    sex: int = 0
    data: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "Role":
        return cls(
            roleid=row["roleid"], userid=row["userid"], name=row["name"],
            level=row["level"], exp=row["exp"], gold=row["gold"],
            money=row["money"], diamond=row["diamond"],
            iconid=row["iconid"], sex=row["sex"],
            data=json.loads(row["data"] or "{}"),
        )


@dataclass
class Account:
    userid: int
    account: str
    password: str
    pw_hash: str = ""
    pw_salt: str = ""
    roles: List[Role] = field(default_factory=list)

    def role_by_name(self, name: str) -> Optional[Role]:
        return next((r for r in self.roles if r.name == name), None)


class World:
    """Everything the server mutates.  One instance per process."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(db_path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.executescript(SCHEMA)
        self._migrate()
        self._db.commit()

        self._accounts: Dict[str, Account] = {}
        self._roles: Dict[int, Role] = {}
        self._sessions: Dict[int, Any] = {}          # sid -> Session
        self._online: Dict[int, Any] = {}            # roleid -> Session
        self._next_roleid = self._max("roles", "roleid", 100000) + 1
        self._next_userid = self._max("accounts", "userid", 1000) + 1
        self._room_seq = itertools.count(1)
        self.rooms: Dict[int, Dict[str, Any]] = {}
        (log.info("world db=%s next_roleid=%s next_userid=%s",
                 db_path, self._next_roleid, self._next_userid) if log.isEnabledFor(20) else None)

    # -- helpers ----------------------------------------------------------
    def _migrate(self) -> None:
        """Add columns introduced after a database was first created.

        ``CREATE TABLE IF NOT EXISTS`` does nothing to an existing table, so a
        database from an older build would be missing the password columns.
        """
        have = {r["name"] for r in
                self._db.execute("PRAGMA table_info(accounts)").fetchall()}
        want = {
            "pw_hash": "TEXT NOT NULL DEFAULT ''",
            "pw_salt": "TEXT NOT NULL DEFAULT ''",
            "last_login": "REAL NOT NULL DEFAULT 0",
            "login_count": "INTEGER NOT NULL DEFAULT 0",
        }
        added = []
        for col, decl in want.items():
            if col not in have:
                self._db.execute(f"ALTER TABLE accounts ADD COLUMN {col} {decl}")
                added.append(col)
        if added:
            (log.info("accounts 表补齐了字段: %s", ", ".join(added)) if log.isEnabledFor(20) else None)

    def _max(self, table: str, col: str, default: int) -> int:
        cur = self._db.execute(f"SELECT MAX({col}) AS m FROM {table}")
        row = cur.fetchone()
        return int(row["m"]) if row and row["m"] is not None else default

    # -- accounts ---------------------------------------------------------
    def valid_account_name(self, account_name: str) -> bool:
        """Check the part the player typed.

        `AndroidDelegate.uin` is `username + platformSurfix`, i.e. "bob$local",
        so strip exactly one recognised suffix and validate the rest.  Any
        remaining '$' (or other punctuation) is rejected.
        """
        name = (account_name or "").strip()
        base, sep, suffix = name.rpartition("$")
        if sep and suffix in PLATFORM_SUFFIXES:
            name = base
        if not (NAME_MIN <= len(name) <= NAME_MAX):
            return False
        return not (set(name) & _NAME_BAD)

    def login(self, account_name: str, password: str = "") -> tuple["Account", str]:
        """Register on first sight, then verify.

        Returns (account, status).  The account is always returned so callers
        can log/display it, but only LOGIN_OK / LOGIN_CREATED may proceed.
        """
        with self._lock:
            acct = self._accounts.get(account_name)
            if acct is None:
                row = self._db.execute(
                    "SELECT * FROM accounts WHERE account = ?", (account_name,)
                ).fetchone()
                if row is not None:
                    acct = Account(userid=row["userid"], account=row["account"],
                                   password=row["password"],
                                   pw_hash=row["pw_hash"] or "",
                                   pw_salt=row["pw_salt"] or "")
                    acct.roles = self._load_roles(acct.userid)
                    self._accounts[account_name] = acct
                    for r in acct.roles:
                        self._roles[r.roleid] = r

            now = time.time()
            if acct is None:
                # ---- register ------------------------------------------
                if not self.valid_account_name(account_name):
                    return (Account(userid=0, account=account_name, password=""),
                            LOGIN_BAD_NAME)
                userid = self._next_userid
                self._next_userid += 1
                pw_hash, pw_salt = hash_password(password)
                self._db.execute(
                    "INSERT INTO accounts(userid, account, password, created,"
                    " pw_hash, pw_salt, last_login, login_count)"
                    " VALUES(?,?,?,?,?,?,?,1)",
                    (userid, account_name, "", now, pw_hash, pw_salt, now),
                )
                self._db.commit()
                acct = Account(userid=userid, account=account_name, password="",
                               pw_hash=pw_hash, pw_salt=pw_salt)
                acct.roles = []
                self._accounts[account_name] = acct
                (log.info("registered account %r userid=%s", account_name, userid) if log.isEnabledFor(20) else None)
                return acct, LOGIN_CREATED

            # ---- existing ------------------------------------------------
            if not acct.pw_hash:
                # A database from before the account system: the row has no
                # hash, so adopt the password supplied on this first login.
                pw_hash, pw_salt = hash_password(password)
                self._db.execute(
                    "UPDATE accounts SET pw_hash=?, pw_salt=?, last_login=?,"
                    " login_count=login_count+1, password='' WHERE userid=?",
                    (pw_hash, pw_salt, now, acct.userid))
                self._db.commit()
                acct.pw_hash, acct.pw_salt = pw_hash, pw_salt
                (log.info("account %r 是旧数据，已用本次密码设定密码", account_name) if log.isEnabledFor(20) else None)
                return acct, LOGIN_OK

            if not verify_password(password, acct.pw_hash, acct.pw_salt):
                (log.info("login rejected: account=%r 密码错误", account_name) if log.isEnabledFor(20) else None)
                return acct, LOGIN_BAD_PASSWORD

            self._db.execute(
                "UPDATE accounts SET last_login=?, login_count=login_count+1"
                " WHERE userid=?", (now, acct.userid))
            self._db.commit()
            return acct, LOGIN_OK

    def set_password(self, account_name: str, password: str) -> bool:
        """GM: force a new password (also migrates a legacy row)."""
        with self._lock:
            pw_hash, pw_salt = hash_password(password)
            cur = self._db.execute(
                "UPDATE accounts SET pw_hash=?, pw_salt=?, password=''"
                " WHERE account=?", (pw_hash, pw_salt, account_name))
            self._db.commit()
            if cur.rowcount == 0:
                return False
            acct = self._accounts.get(account_name)
            if acct is not None:
                acct.pw_hash, acct.pw_salt, acct.password = pw_hash, pw_salt, ""
            (log.info("GM 重设了账号 %r 的密码", account_name) if log.isEnabledFor(20) else None)
            return True

    def account_list(self) -> List[Dict[str, Any]]:
        """GM: every account with its role count and last login."""
        rows = self._db.execute(
            "SELECT a.userid, a.account, a.created, a.last_login, a.login_count,"
            " a.banned, a.pw_hash,"
            " (SELECT COUNT(*) FROM roles r WHERE r.userid = a.userid)"
            "   AS rolecount"
            " FROM accounts a ORDER BY a.userid").fetchall()
        return [{"userid": int(r["userid"]), "account": r["account"],
                 "created": float(r["created"] or 0),
                 "last_login": float(r["last_login"] or 0),
                 "login_count": int(r["login_count"] or 0),
                 "banned": bool(r["banned"]),
                 "has_password": bool(r["pw_hash"]),
                 "roles": int(r["rolecount"] or 0)} for r in rows]

    def _load_roles(self, userid: int) -> List[Role]:
        cur = self._db.execute("SELECT * FROM roles WHERE userid = ?", (userid,))
        roles = [Role.from_row(r) for r in cur.fetchall()]
        for r in roles:
            self._roles[r.roleid] = r
        return roles

    def create_role(self, acct: Account, name: str, iconid: int = 0,
                    sex: int = 0, **extra: Any) -> Role:
        """Create a role with the private server's starting wallet."""
        with self._lock:
            roleid = self._next_roleid
            self._next_roleid += 1
            role = Role(roleid=roleid, userid=acct.userid, name=name,
                        iconid=iconid, sex=sex,
                        gold=START_GOLD, money=START_MONEY,
                        diamond=START_DIAMOND, data=dict(extra))
            self._db.execute(
                "INSERT INTO roles(roleid, userid, name, gold, money, diamond, "
                "iconid, sex, data, created) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (roleid, acct.userid, name, role.gold, role.money, role.diamond,
                 iconid, sex, json.dumps(role.data, ensure_ascii=False), time.time()),
            )
            self._db.commit()
            acct.roles.append(role)
            self._roles[roleid] = role
            (log.info("created role %r id=%s for %s (gold=%s money=%s diamond=%s)",
                     name, roleid, acct.account, role.gold, role.money, role.diamond) if log.isEnabledFor(20) else None)
            return role

    def save_role(self, role: Role) -> None:
        with self._lock:
            self._db.execute(
                "UPDATE roles SET name=?, level=?, exp=?, gold=?, money=?, "
                "diamond=?, iconid=?, sex=?, data=?, last_login=? WHERE roleid=?",
                (role.name, role.level, role.exp, role.gold, role.money,
                 role.diamond, role.iconid, role.sex,
                 json.dumps(role.data, ensure_ascii=False),
                 time.time(), role.roleid),
            )
            self._db.commit()

    def role(self, roleid: int) -> Optional[Role]:
        r = self._roles.get(roleid)
        if r is not None:
            return r
        row = self._db.execute("SELECT * FROM roles WHERE roleid = ?", (roleid,)).fetchone()
        if row is None:
            return None
        r = Role.from_row(row)
        self._roles[r.roleid] = r
        return r

    def most_recent_role(self) -> Optional[Role]:
        """最近活跃的角色（重建实现）。

        客户端断线重连时 `CsReconnectLogin.roleid` 可能是 0（客户端本地状态
        已被 ClearGameStatus 清掉，run4 实测），这时按 roles.last_login 兜底
        定位"刚才在玩"的那个角色；本地服单账号场景语义成立，多角色并存时
        恢复的是最近登录的一个。找不到返回 None，调用方维持原 retcode=5。
        """
        row = self._db.execute(
            "SELECT roleid FROM roles ORDER BY last_login DESC LIMIT 1").fetchone()
        if row is None:
            return None
        return self.role(int(row["roleid"]))

    # -- 好友 ---------------------------------------------------------------
    FRIEND = 1
    BLACK = 2

    def friends_of(self, roleid: int) -> List[int]:
        rows = self._db.execute(
            "SELECT friendid FROM friends WHERE roleid=? AND kind=?"
            " ORDER BY created", (roleid, self.FRIEND)).fetchall()
        return [int(r["friendid"]) for r in rows]

    def blacklist_of(self, roleid: int) -> List[int]:
        rows = self._db.execute(
            "SELECT friendid FROM friends WHERE roleid=? AND kind=?"
            " ORDER BY created", (roleid, self.BLACK)).fetchall()
        return [int(r["friendid"]) for r in rows]

    def are_friends(self, a: int, b: int) -> bool:
        row = self._db.execute(
            "SELECT 1 FROM friends WHERE roleid=? AND friendid=? AND kind=?",
            (a, b, self.FRIEND)).fetchone()
        return row is not None

    def has_blacklisted(self, owner: int, other: int) -> bool:
        row = self._db.execute(
            "SELECT 1 FROM friends WHERE roleid=? AND friendid=? AND kind=?",
            (owner, other, self.BLACK)).fetchone()
        return row is not None

    def _link(self, a: int, b: int, kind: int) -> None:
        self._db.execute(
            "INSERT OR IGNORE INTO friends(roleid, friendid, kind, created)"
            " VALUES(?,?,?,?)", (a, b, kind, time.time()))

    def add_friend(self, a: int, b: int) -> None:
        """Friendship is symmetric -- write both directions."""
        with self._lock:
            self._link(a, b, self.FRIEND)
            self._link(b, a, self.FRIEND)
            self._db.commit()

    def remove_friend(self, a: int, b: int) -> None:
        with self._lock:
            self._db.execute(
                "DELETE FROM friends WHERE kind=? AND ((roleid=? AND friendid=?)"
                " OR (roleid=? AND friendid=?))",
                (self.FRIEND, a, b, b, a))
            self._db.commit()

    def add_blacklist(self, a: int, b: int) -> None:
        with self._lock:
            self._link(a, b, self.BLACK)
            # 拉黑同时解除好友（客户端也是这么理解的）
            self._db.execute(
                "DELETE FROM friends WHERE kind=? AND ((roleid=? AND friendid=?)"
                " OR (roleid=? AND friendid=?))",
                (self.FRIEND, a, b, b, a))
            self._db.execute(
                "DELETE FROM friend_requests WHERE (fromid=? AND toid=?)"
                " OR (fromid=? AND toid=?)", (a, b, b, a))
            self._db.commit()

    def remove_blacklist(self, a: int, b: int) -> None:
        with self._lock:
            self._db.execute(
                "DELETE FROM friends WHERE kind=? AND roleid=? AND friendid=?",
                (self.BLACK, a, b))
            self._db.commit()

    def requests_to(self, roleid: int) -> List[int]:
        rows = self._db.execute(
            "SELECT fromid FROM friend_requests WHERE toid=? ORDER BY created",
            (roleid,)).fetchall()
        return [int(r["fromid"]) for r in rows]

    def has_request(self, a: int, b: int) -> bool:
        row = self._db.execute(
            "SELECT 1 FROM friend_requests WHERE fromid=? AND toid=?",
            (a, b)).fetchone()
        return row is not None

    def add_request(self, a: int, b: int) -> None:
        with self._lock:
            self._db.execute(
                "INSERT OR IGNORE INTO friend_requests(fromid, toid, created)"
                " VALUES(?,?,?)", (a, b, time.time()))
            self._db.commit()

    def drop_request(self, a: int, b: int) -> None:
        with self._lock:
            self._db.execute(
                "DELETE FROM friend_requests WHERE fromid=? AND toid=?",
                (a, b))
            self._db.commit()

    def role_exists(self, roleid: int) -> bool:
        return self.role(roleid) is not None

    def account_for_role(self, role: Role) -> Optional[Account]:
        """Look up the owning account -- needed when a session rejoins
        without ever having sent a login (fresh socket, only a roleid)."""
        with self._lock:
            for acct in self._accounts.values():
                if acct.userid == role.userid:
                    return acct
            row = self._db.execute(
                "SELECT * FROM accounts WHERE userid = ?", (role.userid,)).fetchone()
            if row is None:
                return None
            acct = Account(userid=row["userid"], account=row["account"],
                           password=row["password"])
            acct.roles = self._load_roles(acct.userid)
            self._accounts[acct.account] = acct
            return acct

    def role_named(self, name: str) -> Optional[Role]:
        row = self._db.execute("SELECT * FROM roles WHERE name = ?", (name,)).fetchone()
        return Role.from_row(row) if row else None

    # -- sessions ---------------------------------------------------------
    def attach(self, session) -> None:
        self._sessions[session.sid] = session

    def detach(self, session) -> None:
        self._sessions.pop(session.sid, None)
        if session.roleid and self._online.get(session.roleid) is session:
            self._online.pop(session.roleid, None)
            # **把 _online 指回还活着的那条连接。**
            # 打战斗时房间服连接会覆盖 _online；战斗结束它一 detach，
            # 如果只是 pop 掉，这个角色在 _online 里就"消失"了 ——
            # 大厅连接明明还活着，下一局开局的 ScLoginRoom 却发不出去
            # （实测：三人开局只有一个人进了战斗，另外两个停在房间界面）。
            rest = self.sessions_of_role(session.roleid)
            if rest:
                self._online[session.roleid] = rest[-1]

    def mark_online(self, roleid: int, session) -> None:
        self._online[roleid] = session

    def is_online(self, roleid: int) -> bool:
        s = self._online.get(roleid)
        return s is not None and not s.closed

    def session_of_role(self, roleid: int, kind: str = ""):
        """这个角色的会话。

        传 `kind`（"gs" / "room"）时按连接类型找 —— 打战斗时客户端同时挂着两条
        连接，`_online` 只记得最后登录的那条（房间服），而 `ScFightResult` 必须
        走大厅服那条（`ScFightEnd` 已经把房间服连接关了）。
        """
        if kind:
            for s in self._sessions.values():
                if s.roleid == roleid and not s.closed and s.kind == kind:
                    return s
            return None
        return self._online.get(roleid)

    def sessions(self) -> list:
        """所有活跃连接（全服播报用）。"""
        return [s for s in self._sessions.values() if not s.closed]

    def sessions_of_role(self, roleid: int) -> list:
        """这个角色的全部活跃连接。"""
        return [s for s in self._sessions.values()
                if s.roleid == roleid and not s.closed]

    def online_count(self) -> int:
        return sum(1 for s in self._online.values() if not s.closed)

    def online_sessions(self) -> List[Any]:
        """Live sessions, richest first (role > account > anonymous)."""
        out = [s for s in self._sessions.values() if not s.closed]
        out.sort(key=lambda s: (s.phase != "logged_in", s.sid))
        return out

    def session_by_sid(self, sid: int):
        return self._sessions.get(sid)

    # -- rooms ------------------------------------------------------------
    def new_room_id(self) -> int:
        return next(self._room_seq)

    # -- GM / admin -------------------------------------------------------
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            accounts = self._db.execute("SELECT COUNT(*) c FROM accounts").fetchone()["c"]
            roles = self._db.execute("SELECT COUNT(*) c FROM roles").fetchone()["c"]
            banned = self._db.execute(
                "SELECT COUNT(*) c FROM accounts WHERE banned = 1").fetchone()["c"]
        return {
            "accounts": accounts,
            "roles": roles,
            "banned": banned,
            "online": self.online_count(),
            "rooms": len(self.rooms),
            "sessions": sum(1 for s in self._sessions.values() if not s.closed),
        }

    def list_accounts(self, search: str = "", limit: int = 100,
                      offset: int = 0) -> List[Dict[str, Any]]:
        q = ("SELECT a.userid, a.account, a.created, a.banned, a.ban_reason, "
             "a.ban_until, (SELECT COUNT(*) FROM roles r WHERE r.userid = a.userid) "
             "AS rolecount FROM accounts a")
        args: List[Any] = []
        if search:
            q += " WHERE a.account LIKE ?"
            args.append(f"%{search}%")
        q += " ORDER BY a.userid DESC LIMIT ? OFFSET ?"
        args += [limit, offset]
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        return [dict(r) for r in rows]

    def list_roles(self, search: str = "", limit: int = 100,
                   offset: int = 0) -> List[Dict[str, Any]]:
        q = ("SELECT r.*, a.account FROM roles r "
             "LEFT JOIN accounts a ON a.userid = r.userid")
        args: List[Any] = []
        if search:
            q += (" WHERE r.name LIKE ? OR a.account LIKE ? OR CAST(r.roleid AS TEXT) = ?")
            args += [f"%{search}%", f"%{search}%", search]
        q += " ORDER BY r.roleid DESC LIMIT ? OFFSET ?"
        args += [limit, offset]
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["online"] = self.is_online(d["roleid"])
            d.pop("data", None)
            out.append(d)
        return out

    def update_role(self, roleid: int, **fields: Any) -> Optional[Role]:
        """Patch a role; only the whitelisted columns are accepted."""
        allowed = {"name", "level", "exp", "gold", "money", "diamond", "iconid", "sex"}
        with self._lock:
            role = self.role(roleid)
            if role is None:
                return None
            sets, args = [], []
            for k, v in fields.items():
                if k not in allowed or v is None:
                    continue
                if k == "name":
                    v = str(v).strip()
                    if not v:
                        continue
                    clash = self._db.execute(
                        "SELECT roleid FROM roles WHERE name = ? AND roleid != ?",
                        (v, roleid)).fetchone()
                    if clash:
                        raise ValueError(f"名称 {v!r} 已被角色 {clash['roleid']} 占用")
                else:
                    v = int(v)
                setattr(role, k, v)
                sets.append(f"{k} = ?")
                args.append(v)
            if not sets:
                return role
            args.append(roleid)
            self._db.execute(f"UPDATE roles SET {', '.join(sets)} WHERE roleid = ?", args)
            self._db.commit()
            return role

    def award_daily(self, roleid, state, *, exp, coins, gems, honor):
        self.award_local(roleid, {"daily": state}, exp=exp, coins=coins, gems=gems, honor=honor)

    def award_local(self, roleid, changes, *, exp=0, coins=0, gems=0, honor=0):
        from .leveling import rank_for_exp
        with self._lock:
            role = self.role(roleid)
            new_exp = role.exp + exp
            rank = rank_for_exp(new_exp) if exp else role.level
            data = {**role.data, **changes}
            money, gold, diamond = role.money + coins, role.gold + gems, role.diamond + honor
            if min(money, gold, diamond) < 0:
                raise ValueError("insufficient local balance")
            with self._db:
                self._db.execute(
                    "UPDATE roles SET exp=?,level=?,money=?,gold=?,diamond=?,data=? WHERE roleid=?",
                    (new_exp, rank, money, gold, diamond, json.dumps(data, ensure_ascii=False), roleid))
            role.exp, role.level = new_exp, rank
            role.money, role.gold, role.diamond = money, gold, diamond
            role.data = data

    def merge_role_data(self, roleid: int, **kv: Any) -> Optional[Role]:
        """Merge keys into the role's JSON `data` blob and persist it.

        `update_role` only touches whitelisted columns, so per-role progress
        (robot level unlocks, range best score, ...) lives in `data`.
        """
        with self._lock:
            role = self.role(roleid)
            if role is None:
                return None
            data = dict(role.data or {})
            data.update(kv)
            role.data = data
            self._db.execute("UPDATE roles SET data = ? WHERE roleid = ?",
                             (json.dumps(data, ensure_ascii=False), roleid))
            self._db.commit()
            return role

    def delete_role(self, roleid: int) -> bool:
        with self._lock:
            cur = self._db.execute("DELETE FROM roles WHERE roleid = ?", (roleid,))
            self._db.commit()
            self._roles.pop(roleid, None)
            for acct in self._accounts.values():
                acct.roles = [r for r in acct.roles if r.roleid != roleid]
            return cur.rowcount > 0

    def set_ban(self, account: str, banned: bool, reason: str = "",
                until: float = 0.0) -> bool:
        with self._lock:
            cur = self._db.execute(
                "UPDATE accounts SET banned = ?, ban_reason = ?, ban_until = ? "
                "WHERE account = ?",
                (1 if banned else 0, reason, until, account))
            self._db.commit()
            return cur.rowcount > 0

    def ban_info(self, account: str):
        """(banned, reason, until) for an account name."""
        with self._lock:
            row = self._db.execute(
                "SELECT banned, ban_reason, ban_until FROM accounts WHERE account = ?",
                (account,)).fetchone()
        if row is None:
            return False, "", 0.0
        until = float(row["ban_until"] or 0)
        if row["banned"] and until and until < time.time():
            # temporary ban expired
            self.set_ban(account, False)
            return False, "", 0.0
        return bool(row["banned"]), row["ban_reason"] or "", until

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()
