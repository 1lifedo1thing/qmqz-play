"""Collision-checked zombie attack hops and ordinary/airborne claw gating.

This is reconstructed BOT policy. Height, gravity, speed and claw properties
come from the current client tables and existing native-calibrated helpers.
"""
import math

from . import damage, parkour


def reach(prop):
    return damage.zombie_claw_reach(prop, bot=True)


def valid_target(battle, target):
    bio = getattr(battle, 'biochem', None)
    return bool(bio is not None and target is not None and target.born
                and target.hp > 0 and target.syncpos is not None
                and not bio.is_zombie(target.roleid))


def plan(battle, fighter, target, state, nav, scene, speed, now):
    from . import bots
    if (scene is None or nav is None or not valid_target(battle, target)
            or not battle.biochem.is_zombie(fighter.roleid)
            or state.get('jump') is not None or speed <= 0
            or now < state.get('client_jump_after', 0.)
            or now < state.get('attack_jump_probe_after', 0.)):
        return None
    state['attack_jump_probe_after'] = now + .4
    here, goal = tuple(fighter.syncpos), tuple(target.syncpos)
    prop = bots._zombie_prop(fighter.actorid)
    height = float(prop.get('jumpHeight') or parkour.HEIGHT)
    claw = reach(prop)
    dy = goal[1] - here[1]
    horizontal = math.hypot(goal[0]-here[0], goal[2]-here[2])
    if height <= 0 or claw <= 0 or dy < .35 or dy > height + claw:
        return None
    if math.dist(here, goal) <= claw and bots._visible(scene, here, goal):
        return None  # Already reachable without a jump.
    up = math.sqrt(2 * parkour.GRAVITY * height)
    airtime = 2 * up / parkour.GRAVITY
    if horizontal > speed * airtime + claw:
        return None
    foot = float(state.get('foot', 0.))
    ground = nav.ground(here)
    if ground is None or abs(here[1]-ground[1]-foot) > .12 or not scene.stand_clear(ground):
        return None
    ux, uz = ((goal[0]-here[0])/horizontal, (goal[2]-here[2])/horizontal) if horizontal > .01 else (0., 1.)
    advance = min(max(0., horizontal - claw*.65), speed*airtime*.7, 3.)
    # A vertical jump beside a high box is useful even when its top is too high
    # to land on. Forward hops are tried only with a real supported landing.
    candidates = [(0., 0.)]
    for length in (advance, min(advance, 1.2)):
        if length >= .2:
            candidates.extend((length, angle) for angle in (0., .35, -.35))
    best = None
    for length, angle in candidates:
        c, s = math.cos(angle), math.sin(angle)
        x, z = here[0] + length*(ux*c-uz*s), here[2] + length*(ux*s+uz*c)
        for y in sorted(scene.floors(x, z), key=lambda value: abs(value-ground[1])):
            rise = y + foot - here[1]
            if not -.85 <= rise < height or not scene.stand_clear((x,y,z)):
                continue
            end = tuple(round(v*100)/100 for v in (x,y+foot,z))
            loc = nav.locate(end)
            if loc is None or abs(loc[1][1]-y) > .15:
                continue
            duration = (up + math.sqrt(max(0., up*up - 2*parkour.GRAVITY*rise))) / parkour.GRAVITY
            flat = math.hypot(end[0]-here[0], end[2]-here[2])
            if duration <= 0 or flat/duration > speed + .001:
                continue
            jump = {'start': here, 'end': end, 'up': up, 'duration': duration,
                    'elapsed': 0., 'horizontal': ((end[0]-here[0])/duration, (end[2]-here[2])/duration)}
            previous, useful, clear = here, [], True
            count = max(16, math.ceil(duration/.04))
            for index in range(1, count+1):
                elapsed = duration*index/count
                position = parkour.point(jump, elapsed)
                if not parkour._body_clear(scene, previous, position):
                    clear = False
                    break
                if (math.dist(position, goal) <= claw and bots._visible(scene, position, goal)):
                    useful.append(elapsed)
                previous = position
            if clear and useful:
                score = (len(useful)/count, -flat)
                if best is None or score > best[0]:
                    best = score, jump
    return best[1] if best else None


def start(battle, fighter, target, state, nav, scene, speed, dt, now):
    jump = plan(battle, fighter, target, state, nav, scene, speed, now)
    if jump is None:
        return None
    from . import battle as B, bot_airlife, bots
    # A short-range ghost must start its existing windup at takeoff. Starting
    # it only on entering range would finish after that ghost has fallen out
    # of range again. This does not spend/reset an existing attack cooldown.
    bots._claw_gate(battle, fighter, prime_only=True)
    state.update(jump=jump, jump_since=now, jump_attack_target=target.roleid,
                 air_claw_windup=True)
    height = jump['up']**2/(2*parkour.GRAVITY)
    state['client_jump_after'] = now + jump['duration'] + bot_airlife.landing_tail(height)
    wire = lambda p: {axis: int(round(value*100)) for axis,value in zip('xyz',p)}
    vx, vz = jump['horizontal']
    battle.send_all(B.ID.SC_JUMP, roleid=fighter.roleid, pos=wire(jump['start']),
                    speed=wire((vx,jump['up'],vz)))
    B.log.info('BIO-ATTACK-JUMP role=%s target=%s height=%.2f start=%s end=%s',
               fighter.roleid, target.roleid, height, jump['start'], jump['end'])
    return parkour.advance(state, dt)


def claw(battle, fighter, target, scene, shots, now):
    """Use the same real position, range, facing, LOS and interval in the air."""
    from . import bots
    if not valid_target(battle, target) or not battle.biochem.is_zombie(fighter.roleid):
        return False
    prop = bots._zombie_prop(fighter.actorid)
    here, goal = tuple(fighter.syncpos), tuple(target.syncpos)
    distance = math.dist(here, goal)
    if (distance > reach(prop) or not bots._visible(scene, here, goal)
            or bots._spawn_fire_locked(battle, fighter.roleid, now)):
        return False
    yaw = getattr(fighter, '_bot_yaw', None)
    if yaw is not None:
        direction = math.atan2(goal[0]-here[0], goal[2]-here[2])
        difference = (direction-float(yaw)+math.pi) % (2*math.pi)-math.pi
        half = math.radians(float(prop.get('fanAngle') or 160.)*.8/2)
        if abs(difference) > half:
            return False
    interval = bots._profile(battle, fighter)[2]
    if now - float(shots.get(fighter.roleid, -math.inf)) < interval:
        return False
    fired = bots._fire(battle, fighter, target, distance, colliders=scene)
    if fired:
        shots[fighter.roleid] = now
    return bool(fired)
