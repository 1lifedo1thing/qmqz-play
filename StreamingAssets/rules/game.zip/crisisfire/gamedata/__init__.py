"""Game config tables, extracted from the client's Configs.assetBundle.

The bundle holds one TextAsset whose bytes are a Mono BinaryFormatter stream
(`Dictionary<Type, object>`).  .NET's own BinaryFormatter cannot read it, so
`tools/nrbf_reader.py` parses MS-NRBF directly and `tools/dump_configs.py`
writes one JSON per table here.

These tables are authoritative: the client looks up room rules by `levelid`
via ``CsGameRuleMgr.getRule`` and dereferences the result, so the server must
only ever advertise ids that exist here.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, List, Optional

log = logging.getLogger("crisisfire.gamedata")

_DIR = os.path.dirname(os.path.abspath(__file__))
_cache: Dict[str, List[Dict[str, Any]]] = {}


def table(name: str) -> List[Dict[str, Any]]:
    """Rows of a table, [] when the table is absent."""
    if name in _cache:
        return _cache[name]
    path = os.path.join(_DIR, name + ".json")
    rows: List[Dict[str, Any]] = []
    if os.path.isfile(path):
        try:
            with open(path, encoding="utf-8") as fh:
                rows = json.load(fh)
        except Exception:
            log.exception("failed to load table %s", name)
    else:
        log.warning("config table missing: %s", name)
    _cache[name] = rows
    return rows


def available() -> List[str]:
    return sorted(f[:-5] for f in os.listdir(_DIR) if f.endswith(".json"))


# --------------------------------------------------------------------------
# the tables the battle flow needs
# --------------------------------------------------------------------------
def game_rules() -> List[Dict[str, Any]]:
    return table("GameRule")


def maps() -> List[Dict[str, Any]]:
    return table("Map")


def game_modes() -> List[Dict[str, Any]]:
    return table("GameMode")


def member_limits() -> List[Dict[str, Any]]:
    return table("MemberLimit")


def rule(levelid: int) -> Optional[Dict[str, Any]]:
    return next((r for r in game_rules() if r.get("id") == levelid), None)


def map_row(mapid: int) -> Optional[Dict[str, Any]]:
    return next((m for m in maps() if m.get("id") == mapid), None)


_spawn_cache: Optional[Dict[str, Any]] = None


def spawn_table() -> Dict[str, Any]:
    """`spawnpoints.json`（场景名 -> {"police": [...], "terrist": [...]}）。"""
    global _spawn_cache
    if _spawn_cache is None:
        path = os.path.join(_DIR, "spawnpoints.json")
        try:
            with open(path, encoding="utf-8") as fh:
                _spawn_cache = json.load(fh)
        except Exception:
            log.exception("failed to load spawnpoints.json")
            _spawn_cache = {}
    return _spawn_cache


# 已知出生点残缺的地图场景（每边只有 1 个点 / 两队重叠），进图必炸
BAD_SCENES = {"SpaceLab_W", "subway"}


def map_has_spawns(mapid: int) -> bool:
    """这张地图的场景里有没有提取到出生点。

    没有的话 `Battle.spawn_pos()` 只能退回原点 `(0, 1, 0)` —— 人会直接出生在
    虚空里。实测：Map 16「决战斗室」的 scene 是 `dark_box`，而本客户端包里
    **根本没有这个场景**（只带了 level0..level15，没有 level16），所以这张图
    不能进，只能改模式、不能改到它。
    """
    scene = str((map_row(mapid) or {}).get("scene") or "")
    pts = spawn_table().get(scene) or {}
    return bool(pts.get("police") or pts.get("terrist"))


def rule_for_map(mapid: int, gamemode: int = 0) -> Optional[Dict[str, Any]]:
    """Resolve a GameRule for a map (and mode).

    `roominfo.levelid` is a **GameRule.id** -- the client does
    `CsGameRuleMgr.getRule(roominfo.levelid)` -- while the map picker only fills
    in `roominfo.mapid`:

        // FightManager.ChangeRoom
        RoomInfo roomInfo = new RoomInfo();
        roomInfo.mapid = mapid;
        roomInfo.playerlimits = playerlimit;
        roomInfo.flags = flag;
        roomInfo.gamemode = gamemode;
        GsServer.Instance.Send(new CsChangeRoomInfo(roominfo_, roomid));

    so the server has to derive levelid FROM mapid, not the other way round.
    Mirroring `CsGameRuleMgr.GetGameRuleIdByMap`: prefer an exact gameMode
    match, then a rule id below 1000 (the 1000+ rows are level-gated variants
    of the same map+mode), then the lowest id.
    """
    cands = [r for r in game_rules() if int(r.get("mapId") or 0) == mapid]
    if not cands:
        return None

    def rank(r: Dict[str, Any]):
        gm = int(r.get("gameMode") or 0)
        rid = int(r.get("id") or 0)
        return (0 if gm == gamemode else 1, 0 if rid < 1000 else 1, rid)

    return min(cands, key=rank)


def rules_for_map(mapid: int) -> List[Dict[str, Any]]:
    return [r for r in game_rules() if int(r.get("mapId") or 0) == mapid]


def rule_for_mode(gamemode: int) -> Optional[Dict[str, Any]]:
    """某个玩法（GameMode.id）的「通用」GameRule。

    有些玩法在 GameRule 里只有一行**不带地图**的通用配置 —— 例如黑暗模式
    （gameMode=9）只有 id=999、mapId 为空。`rule_for_map` 是按地图找的，
    永远找不到它，房间就会悄悄退回普通模式（实测：选了黑暗模式没反应，
    进图还是亮的）。这类玩法改用这里的通用行，地图仍用玩家选的那张。
    """
    cands = [r for r in game_rules()
             if int(r.get("gameMode") or 0) == int(gamemode)]
    if not cands:
        return None
    # 有带地图的就优先（更具体），否则用 mapId 为空的那行
    cands.sort(key=lambda r: (0 if r.get("mapId") else 1,
                              int(r.get("id") or 0)))
    return cands[0]


def default_levelid() -> int:
    """The new-room preview starts at map 1. Use its team rule."""
    row = rule_for_map(1, 1)
    if not row or row["gameMode"] != 1 or not map_has_spawns(1):
        raise ValueError("map 1 has no playable team rule")
    return int(row["id"])


def playable_rules() -> List[Dict[str, Any]]:
    """Rules whose map exists and is enabled -- safe to advertise."""
    out = []
    for r in game_rules():
        m = map_row(r.get("mapId", -1))
        if m is None:
            continue
        if m.get("status") not in (0, 1):
            continue
        out.append(r)
    return out


def summary() -> Dict[str, Any]:
    return {
        "tables": len(available()),
        "gameRules": len(game_rules()),
        "playable": len(playable_rules()),
        "maps": len(maps()),
        "gameModes": len(game_modes()),
        "memberLimits": len(member_limits()),
        "defaultLevelId": default_levelid(),
    }
