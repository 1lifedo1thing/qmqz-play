"""In-memory log ring buffer so the GM panel can show live server output.

The console still gets everything; this just keeps the last N formatted
records around for the web UI to poll.
"""
from __future__ import annotations

import collections
import logging
import threading
import time
from typing import Any, Deque, Dict, List


class LogBuffer(logging.Handler):
    """A logging handler that retains the most recent records."""

    def __init__(self, capacity: int = 800):
        super().__init__()
        self.capacity = capacity
        self._records: Deque[Dict[str, Any]] = collections.deque(maxlen=capacity)
        self._lock = threading.Lock()
        self._seq = 0

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = record.getMessage()
            if record.exc_info:
                msg += "\n" + self.format(record)
        except Exception:
            return
        with self._lock:
            self._seq += 1
            self._records.append({
                "seq": self._seq,
                "ts": time.time(),
                "time": time.strftime("%H:%M:%S", time.localtime(record.created)),
                "level": record.levelname,
                "name": record.name,
                "msg": msg,
            })

    def tail(self, since: int = 0, limit: int = 300,
             level: str | None = None) -> List[Dict[str, Any]]:
        """Records with seq > since, oldest first."""
        with self._lock:
            items = [r for r in self._records if r["seq"] > since]
        if level:
            wanted = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40}
            floor = wanted.get(level.upper(), 0)
            items = [r for r in items if wanted.get(r["level"], 0) >= floor]
        return items[-limit:]

    def last_seq(self) -> int:
        with self._lock:
            return self._seq


BUFFER = LogBuffer()


def install(level: int = logging.INFO) -> LogBuffer:
    """Attach the buffer to the root logger and return it."""
    root = logging.getLogger()
    BUFFER.setLevel(logging.DEBUG)
    root.addHandler(BUFFER)
    return BUFFER
