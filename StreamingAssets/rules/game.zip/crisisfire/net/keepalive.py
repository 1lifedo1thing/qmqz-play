"""服务端主动心跳.

客户端的 `ConnectionServer.CheckAlive(maxFreeTime)` 是按「**多久没收到消息**」
判断的，不是按「多久没发」：

    public void CheckAlive(float maxFreeTime)
    {
        if (!IsConnected || Time.time - lastReceivedTime < maxFreeTime)
        {
            return;
        }
        Debug.Log("Check Alive failed: " + GetType().Name);
        connection.Close();                       // ← 客户端自己断开
        ...
        Trigger Retry
    }

所以只要服务端闲着不发消息，客户端到点就会断开重连 —— 玩家看到的就是
「网络连接中断，点击重新登陆」。真机 logcat 里的原话：

    10-16 19:43:40 I Unity: On Connection Lost: GsServer
    10-16 19:48:08 I Unity: Check Alive failed: RoomServer
    10-16 19:48:08 I Unity: Trigger Retry: RoomServer

两个窗口不一样（`config.py`）：

    gs_idle_timeout   = 50s    大厅服
    room_idle_timeout = 10s    房间服

心跳周期取窗口的 40%，留足余量。

发什么：

    大厅服 (gs)   com.gwebtop.common.KeepAlive(2031617)
                  -> UserManager.KeepAlive(this)，就是标准保活消息
    房间服 (room) generial.ScPing(720900)  ts
                  -> RoomServer.Instance.OnPingRet(ts)，客户端自己的 ping 响应处理

两条都是客户端本来就在处理的消息，收到不会有副作用（不像凭空发明一条）。
"""
from __future__ import annotations

import asyncio
import logging
import time

from ..config import CONFIG

log = logging.getLogger("crisisfire.keepalive")

KEEPALIVE = 2031617          # com.gwebtop.common.KeepAlive
SC_PING = 720900             # com.gwebtop.generial.ScPing

# 相对超时窗口的提前量。0.4 表示「窗口用掉 40% 就补一次」。
SAFETY = 0.4
MIN_INTERVAL = 2.0
# 循环的检查间隔（真正的发送按各自的 last_sent 判断，这里只是巡检频率）
TICK = 2.0


def interval_for(kind: str) -> float:
    window = (CONFIG.room_idle_timeout if kind == "room"
              else CONFIG.gs_idle_timeout)
    return max(MIN_INTERVAL, float(window) * SAFETY)


def ping_session(session) -> bool:
    """给一个会话发心跳。返回是否发了。

    守卫是「**过了握手就发**」，不是「有角色才发」：
    玩家停在创建角色界面时 `roleid` 还是 0，但连接已经建立 —— 那段时间挂机
    同样会被客户端判成 idle 然后踢下线（实测 `phase=authed, roleid=0`）。
    """
    if session.closed:
        return False
    if getattr(session, "phase", "connected") == "connected":
        return False                   # 还没握手，别打扰
    now = time.time()
    if now - getattr(session, "last_sent", now) < interval_for(session.kind):
        return False
    try:
        # 房间服也发 KeepAlive（2031617）：实测发 ScPing 时 1.8.1 客户端会以
        # ~30 次/秒的频率狂发 CsPing（run6-walk8 观测），改发 KeepAlive 后
        # 客户端安静（旧线 v17 同款做法，重建实现）。
        session.send(KEEPALIVE)
        return True
    except Exception:
        (log.debug("心跳发送失败 -> %s", session, exc_info=True) if log.isEnabledFor(10) else None)
        return False


async def keepalive_loop(world, stop: asyncio.Event) -> None:
    """周期性给所有已登录会话补心跳，直到 stop 被设置。"""
    (log.info("心跳循环启动: 大厅每 %.0fs / 房间每 %.0fs（检查间隔 %.0fs）",
             interval_for("gs"), interval_for("room"), TICK) if log.isEnabledFor(20) else None)
    sent = 0
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=TICK)
            break                      # stop 被设置
        except asyncio.TimeoutError:
            pass
        except asyncio.CancelledError:
            break
        try:
            sessions = world.sessions() if world is not None else []
        except Exception:
            sessions = []
        for s in sessions:
            if ping_session(s):
                sent += 1
    (log.info("心跳循环退出（累计发送 %d 次）", sent) if log.isEnabledFor(20) else None)
