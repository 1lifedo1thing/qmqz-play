"""把客户端 <-> 服务端的每一帧记到 NDJSON 文件里（「抓自己的包」）。

为什么不用 tcpdump/mitmproxy
---------------------------
游戏战斗走的是自定义二进制 TCP 协议（`xio` 帧：compact_uint32(type) +
compact_uint32(len) + body），没有 TLS、没有压缩。在服务端进程里直接记
「解码后的帧」比抓网卡更准：时间戳就是服务端处理它的时刻，字段已经解好，
也不会被 TCP 拆包/粘包干扰。

用法
----
* 启动时开：`CF_RECORD=1 python server\\main.py ...`
* 运行中开/关：GM 面板 `GET/POST /api/record`（不用重启、不用断线）
* 输出：`server/logs/frames-YYYYmmdd-HHMMSS.ndjson`，一行一帧：

      {"t": 1761..., "dir": "in", "sid": 4, "kind": "room",
       "roleid": 100004, "type": 1441897, "name": "CsShoot",
       "body": "…hex…", "msg": {...}}

  回放/分析：`tools/replay_frames.py <file>`（按 type/角色过滤、统计时序）。

开销：每帧一次 JSON 序列化 + 写文件（逐行 flush）。生化一局几千帧，
文件几 MB，可以接受。心跳（720900 Ping）默认跳过。
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Dict, Optional

log = logging.getLogger("crisisfire.recorder")

# 这些协议是心跳/纯噪声，记了只会把文件撑大
_SKIP_TYPES = {720900}

_lock = threading.Lock()
_enabled = False
_fh = None
_path = ""
_count = 0
_started_at = 0.0


def _default_dir() -> str:
    here = os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))))          # server/
    return os.path.join(here, "logs")


def _open() -> None:
    global _fh, _path, _count, _started_at
    if _fh is not None:
        return
    out_dir = os.environ.get("CF_RECORD_DIR") or _default_dir()
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception:
        out_dir = _default_dir()
    name = "frames-%s.ndjson" % time.strftime("%Y%m%d-%H%M%S")
    _path = os.path.join(out_dir, name)
    _fh = open(_path, "w", encoding="utf-8", buffering=1)
    _count = 0
    _started_at = time.time()
    (log.info("录帧已开启 -> %s", _path) if log.isEnabledFor(20) else None)


def _close() -> None:
    global _fh
    if _fh is not None:
        try:
            _fh.close()
        except Exception:
            pass
        _fh = None


def set_enabled(on: bool) -> bool:
    """开/关录帧。返回当前状态。"""
    return False  # Release profile: no recording, including GM requests.
    global _enabled
    with _lock:
        on = bool(on)
        if on and not _enabled:
            _open()
        elif not on and _enabled:
            _close()
        _enabled = on
        return _enabled


def enabled() -> bool:
    return False  # Release profile.
    if _enabled:
        return True
    # 第一次调用时读环境变量（避免 import 顺序问题）
    if os.environ.get("CF_RECORD", "0").strip() in ("1", "true", "yes"):
        return set_enabled(True)
    return False


def status() -> Dict[str, Any]:
    return {
        "enabled": bool(_enabled),
        "file": _path,
        "frames": _count,
        "started_at": _started_at,
    }


def _jsonable(v: Any, depth: int = 0) -> Any:
    if depth > 6:
        return repr(v)
    if isinstance(v, dict):
        return {str(k): _jsonable(x, depth + 1) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x, depth + 1) for x in v]
    if isinstance(v, (bytes, bytearray)):
        raw = bytes(v)
        return {"len": len(raw), "hex": raw[:256].hex()}
    if isinstance(v, float):
        return round(v, 4)
    if isinstance(v, (int, str, bool)) or v is None:
        return v
    return repr(v)


def record(session, direction: str, type_id: int,
           body: bytes, msg: Optional[Dict[str, Any]] = None) -> None:
    """记一帧。`direction` 是 "in"（客户端->服务端）或 "out"。"""
    if type_id in _SKIP_TYPES or not enabled():
        return
    global _count
    item = {
        "t": round(time.time(), 4),
        "dir": direction,
        "sid": getattr(session, "sid", 0),
        "kind": getattr(session, "kind", ""),
        "roleid": getattr(session, "roleid", 0),
        "account": getattr(session, "account", ""),
        "type": int(type_id),
        "name": _name_for(type_id),
        "body": bytes(body).hex(),
    }
    if msg is not None:
        item["msg"] = _jsonable(msg)
    line = json.dumps(item, ensure_ascii=False, separators=(",", ":"))
    with _lock:
        if _fh is None:
            return
        try:
            _fh.write(line + "\n")
            _count += 1
        except Exception:
            (log.debug("写录帧文件失败", exc_info=True) if log.isEnabledFor(10) else None)


def _name_for(type_id: int) -> str:
    try:
        from .server import ROUTER
        return ROUTER.name_for(int(type_id))
    except Exception:
        return str(type_id)
