"""Asyncio TCP gateway speaking the xio framing.

One :class:`Session` per client socket.  Incoming frames are decoded through
the generated protocol codec and dispatched to handlers registered in
:mod:`crisisfire.game.handlers`.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Awaitable, Callable, Dict, Optional

from .wire import MarshalException, decode_frames, encode_frame

log = logging.getLogger("crisisfire.net")

Handler = Callable[["Session", Dict[str, Any]], Awaitable[None]]


class Router:
    """Maps protocol ids (and class names) to coroutine handlers."""

    def __init__(self) -> None:
        self._by_id: Dict[int, Handler] = {}
        self._names: Dict[int, str] = {}

    def register(self, type_id: int, name: str = "") -> Callable[[Handler], Handler]:
        def deco(fn: Handler) -> Handler:
            self._by_id[type_id] = fn
            self._names[type_id] = name or fn.__name__
            (log.debug("route %s -> %s", type_id, self._names[type_id]) if log.isEnabledFor(10) else None)
            return fn
        return deco

    def handler_for(self, type_id: int) -> Optional[Handler]:
        return self._by_id.get(type_id)

    def name_for(self, type_id: int) -> str:
        return self._names.get(type_id, f"#{type_id}")

    def known_ids(self):
        return sorted(self._by_id)


ROUTER = Router()


class Session:
    """State for one client connection."""

    _next_id = 1

    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter,
                 kind: str = "gs"):
        self.sid = Session._next_id
        Session._next_id += 1

        self.reader = reader
        self.writer = writer
        self.kind = kind                     # "gs" | "room"
        self._buf = bytearray()
        self.closed = False
        self.created = time.time()
        self.last_recv = time.time()
        # 最后一次**发出去**的时间。客户端的 ConnectionServer.CheckAlive 是看
        # 「多久没收到东西」：
        #     if (!IsConnected || Time.time - lastReceivedTime < maxFreeTime) return;
        #     Debug.Log("Check Alive failed: " + GetType().Name);
        #     connection.Close();
        # 所以服务端空闲时必须主动发心跳，否则客户端会自己断开
        # （实测「网络连接中断，点击重新登陆」）。
        self.last_sent = time.time()

        # --- identity, filled in by the login flow -----------------------
        self.phase = "connected"             # connected -> challenged -> announced -> logged_in
        self.account: str = ""
        self.password: str = ""
        self.ext: bytes = b""
        self.uuid: str = ""
        self.client_version: str = ""
        self.userid: int = 0
        self.roleid: int = 0
        self.role_name: str = ""
        self.zoneid: int = 1
        self.localsid: int = 0

        self.peer = self._peer()
        self.local = self._local()

    # -- plumbing ---------------------------------------------------------
    def _peer(self) -> str:
        try:
            p = self.writer.get_extra_info("peername")
            return f"{p[0]}:{p[1]}" if p else "?"
        except Exception:
            return "?"

    def _local(self) -> str:
        """本机上这条连接用的地址（== 客户端打进来的那个 IP）。

        `--advertise auto` 靠它告诉客户端"你刚才连的这个地址就是 GS 地址"，
        这样局域网、皎月连虚拟网卡、127.0.0.1 可以同时用同一份 serverlist。
        """
        try:
            p = self.writer.get_extra_info("sockname")
            return p[0] if p else ""
        except Exception:
            return ""

    def __repr__(self) -> str:
        who = self.account or self.role_name or "-"
        return f"<Session#{self.sid} {self.kind} {self.peer} {self.phase} {who}>"

    # -- sending ----------------------------------------------------------
    def send_raw(self, data: bytes) -> None:
        if self.closed:
            return
        try:
            # 客户端已经断开时 writer.write() 不会立刻抛，而是稍后让 asyncio
            # 打一堆 "socket.send() raised exception" WARNING。先看 is_closing()。
            if self.writer.is_closing():
                self.closed = True
                return
            self.writer.write(data)
            # 客户端看的是「多久没收到」——记下发出去的时间，心跳循环靠它判断
            self.last_sent = time.time()
        except Exception as exc:
            self.closed = True
            (log.debug("send_raw failed on %s: %s", self, exc) if log.isEnabledFor(10) else None)

    def send_body(self, type_id: int, body: bytes) -> None:
        self.send_raw(encode_frame(type_id, body))

    def send(self, type_id: int, **fields: Any) -> None:
        """Encode and send a protocol message by id."""
        from ..proto import encode            # late import: codec may be generated later
        body = encode(type_id, fields)
        self.send_body(type_id, body)
        if log.isEnabledFor(logging.DEBUG):
            (log.debug("-> %s %s %s", self, ROUTER.name_for(type_id),
                      _short(fields) if fields else "") if log.isEnabledFor(10) else None)

    def send_msg(self, name: str, **fields: Any) -> None:
        """Send by class name, e.g. ``send_msg("gnet.Challenge", ...)``."""
        from ..proto import id_for_name
        self.send(id_for_name(name), **fields)

    async def flush(self) -> None:
        if self.closed:
            return
        try:
            await self.writer.drain()
        except Exception:
            await self.close()

    # -- lifecycle --------------------------------------------------------
    async def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        try:
            self.writer.close()
        except Exception:
            pass

    # -- main loop --------------------------------------------------------
    async def serve(self) -> None:
        (log.info("connect %s", self) if log.isEnabledFor(20) else None)
        _run_connect(self)
        try:
            while not self.closed:
                try:
                    chunk = await self.reader.read(65536)
                except (ConnectionResetError, ConnectionAbortedError,
                        BrokenPipeError, asyncio.IncompleteReadError, OSError):
                    # 手机切后台/客户端重进房间会直接 abort 连接（Errno 103）。
                    # 这是正常断线，不是服务端异常，不要往 ERROR 里刷 traceback。
                    break
                if not chunk:
                    break
                self.last_recv = time.time()
                self._buf += chunk
                try:
                    await self._drain_frames()
                except MarshalException as exc:
                    log.warning("framing error on %s: %s", self, exc)
                    break
                await self.flush()
        finally:
            (log.info("disconnect %s", self) if log.isEnabledFor(20) else None)
            await self.close()
            on_disconnect(self)

    async def _drain_frames(self) -> None:
        frames, consumed = decode_frames(bytes(self._buf))
        if consumed:
            del self._buf[:consumed]
        for type_id, body in frames:
            await self._dispatch(type_id, body)

    async def _dispatch(self, type_id: int, body: bytes) -> None:
        from ..proto import decode
        from ..game import handlers as _handlers   # noqa: F401  (registers routes)

        try:
            msg = decode(type_id, body)
        except Exception as exc:
            log.warning("decode %s (%s) failed on %s: %s",
                        ROUTER.name_for(type_id), type_id, self, exc)
            return


        if log.isEnabledFor(logging.DEBUG):
            (log.debug("<- %s %s %s", self, ROUTER.name_for(type_id), _short(msg)) if log.isEnabledFor(10) else None)

        handler = ROUTER.handler_for(type_id)
        if handler is None:
            (log.debug("no handler for %s (%s) on %s", ROUTER.name_for(type_id), type_id, self) if log.isEnabledFor(10) else None)
            return
        try:
            await handler(self, msg)
        except Exception:
            log.exception("handler %s raised on %s", ROUTER.name_for(type_id), self)


def _short(obj: Any, limit: int = 220) -> str:
    s = repr(obj)
    return s if len(s) <= limit else s[:limit] + "..."


# --------------------------------------------------------------------------
# session lifecycle hooks (world registration / cleanup)
# --------------------------------------------------------------------------
_connect_hooks: list[Callable[[Session], None]] = []
_disconnect_hooks: list[Callable[[Session], None]] = []


def add_connect_hook(fn: Callable[[Session], None]) -> Callable[[Session], None]:
    """Register a callback fired as soon as a session starts serving."""
    _connect_hooks.append(fn)
    return fn


def add_disconnect_hook(fn: Callable[[Session], None]) -> Callable[[Session], None]:
    """Register a callback fired after a session's socket closes."""
    _disconnect_hooks.append(fn)
    return fn


def _run_connect(session: Session) -> None:
    for fn in _connect_hooks:
        try:
            fn(session)
        except Exception:
            log.exception("connect hook failed")


def _run_disconnect(session: Session) -> None:
    for fn in _disconnect_hooks:
        try:
            fn(session)
        except Exception:
            log.exception("disconnect hook failed")


def on_disconnect(session: Session) -> None:
    """Fan out to every registered disconnect hook."""
    _run_disconnect(session)


async def start_server(host: str, port: int, kind: str) -> asyncio.AbstractServer:
    async def on_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        session = Session(reader, writer, kind=kind)
        try:
            await session.serve()
        except (ConnectionError, OSError) as exc:
            # serve() 里已经处理正常断开；这里兜底 transport 已关闭时的竞态。
            (log.debug("client %s 断开: %s", session, exc) if log.isEnabledFor(10) else None)
        except Exception:
            log.exception("client_connected_cb failed on %s", session)

    server = await asyncio.start_server(on_client, host, port)
    addrs = ", ".join(str(s.getsockname()) for s in server.sockets or [])
    (log.info("%s listening on %s", kind.upper(), addrs) if log.isEnabledFor(20) else None)
    return server
