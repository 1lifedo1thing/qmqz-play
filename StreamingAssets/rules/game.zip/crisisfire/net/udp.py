"""UDP 通道 —— 位置同步走这里，不是 TCP.

**这是「联机时对方不动」的根因。**

客户端的 `PosSyncherServer` 上报位置用的是 UDP：

    // PosSyncherServer.cs
    CsRoleStatusReport m = new CsRoleStatusReport(warrior.roleid, status_, urgent);
    UdpChannel.instance.Send(m);

    // RoomServer.OnLoginRet —— 房间登录成功后把 UDP 目标设成房间服地址
    if (loginRet.retcode == 0)
    {
        UdpChannel.instance.SetServerAddr(ip, port);
        ...
    }

`ip` / `port` 来自服务端发的 `ScLoginRoom(1245189)`（roomid, ip, port, token, levelid）
—— 也就是**和房间服 TCP 同一个 ip:port**，只是协议换成 UDP。
原来服务端只听了 TCP，位置上报全部丢失，于是「别人站着不动」。

**包格式和 TCP 完全一样**（可以复用现有编解码）：

    // UdpChannel.Send
    byte[] body = new OctetsStream().marshal(marshalObject).getBytes();
    OctetsStream head = new OctetsStream()
        .compact_uint32(marshalObject.getType())     // 协议号
        .compact_uint32(body.Length);                // 体长
    client.Send(head + body, ..., serverAddr);

    // UdpChannel.OnReceive
    if (remoteAddr.Equals(serverAddr)) TryProcess(buf);   // 只收服务端来的

另外 `PlayerAnnouncer` 每 0.5 秒发一条 `PlayerAnnounce(roleid)` —— 那是「我在线」的
宣告，服务端要记下 **roleid -> 客户端 UDP 地址**，否则回包不知道该发给谁。

客户端会换本地端口（10000~15000 之间挑），所以地址表要按 roleid 更新。
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, Optional, Tuple

from .. import proto
from .wire import decode_frames, encode_frame

log = logging.getLogger("crisisfire.udp")

PLAYER_ANNOUNCE = 1441955      # com.gwebtop.gclient.PlayerAnnounce(roleid:int)
CS_ROLE_STATUS_REPORT = 1441896
SC_ROLE_STATUS_SYNC = 1441895

# 这几个号不在 spec.json 里（是 UDP 专用的），手工辨认即可
_RAW_INT32 = {PLAYER_ANNOUNCE}

# roleid -> (addr, last_seen)
_PEERS: Dict[int, Tuple[Any, float]] = {}
# addr -> roleid
_BY_ADDR: Dict[Any, int] = {}
# 只保留最近活跃的
PEER_TTL = 30.0


class UdpChannel(asyncio.DatagramProtocol):
    """收发 UDP：把包喂进普通 ROUTER，回包走 UDP。"""

    def __init__(self, world=None):
        self.world = world
        self.transport: Optional[asyncio.DatagramTransport] = None
        self.packets_in = 0
        self.packets_out = 0
        self._last_gc = time.time()

    # -- asyncio 协议 ----------------------------------------------------
    def connection_made(self, transport) -> None:
        self.transport = transport

    def datagram_received(self, data: bytes, addr) -> None:
        self.packets_in += 1
        frames, _rest = decode_frames(data)
        for tid, body in frames:
            if tid in _RAW_INT32:
                # PlayerAnnounce(roleid:int) —— 不在 spec 里，直接按 int32 读。
                # 客户端每 0.5 秒发一次，用来登记「我在这个 UDP 地址上」。
                if len(body) >= 4 and int.from_bytes(body[:4], "big") > 0:
                    self._remember(int.from_bytes(body[:4], "big"), addr)
                continue
            try:
                msg = proto.decode(tid, body)
            except Exception:
                (log.debug("UDP 解包失败 tid=%s len=%d", tid, len(body),
                          exc_info=True) if log.isEnabledFor(10) else None)
                continue
            self._handle(tid, msg, addr)
        self._gc()

    def error_received(self, exc) -> None:
        (log.debug("UDP 错误: %s", exc) if log.isEnabledFor(10) else None)

    # -- 地址表 ----------------------------------------------------------
    def _remember(self, roleid: int, addr) -> None:
        if not roleid:
            return
        old = _PEERS.get(roleid)
        if old is not None and old[0] != addr:
            _BY_ADDR.pop(old[0], None)
        _PEERS[roleid] = (addr, time.time())
        _BY_ADDR[addr] = roleid

    def _gc(self) -> None:
        now = time.time()
        if now - self._last_gc < 10.0:
            return
        self._last_gc = now
        for rid, (addr, seen) in list(_PEERS.items()):
            if now - seen > PEER_TTL:
                _PEERS.pop(rid, None)
                _BY_ADDR.pop(addr, None)
        # 每 60 秒打一次收发计数：in=0 就是客户端根本没把 UDP 打进来
        # （Windows 防火墙没放行，或者 ScLoginRoom 里的 ip:port 不对）。
        if now - getattr(self, "_last_report", 0.0) > 60.0:
            self._last_report = now
            (log.info("UDP 统计: in=%d out=%d peers=%d", self.packets_in,
                     self.packets_out, len(_PEERS)) if log.isEnabledFor(20) else None)

    def addr_of(self, roleid: int):
        e = _PEERS.get(int(roleid))
        return e[0] if e else None

    def role_of(self, addr) -> int:
        return _BY_ADDR.get(addr, 0)

    # -- 处理 ------------------------------------------------------------
    def _handle(self, tid: int, msg: Dict[str, Any], addr) -> None:
        roleid = int(msg.get("roleid") or 0) or self.role_of(addr)
        if roleid:
            self._remember(roleid, addr)

        if tid == CS_ROLE_STATUS_REPORT:
            self._on_status(roleid, msg)
        # 其余 UDP 消息（客户端也可能发别的）暂时只记地址

    def _on_status(self, roleid: int, msg: Dict[str, Any]) -> None:
        """位置上报 -> 转发给同房间的其他人（走 UDP）。"""
        if not roleid:
            return
        from ..game import battle as B
        from ..game import room_handlers as RH
        room = RH.MANAGER.room_of(roleid) if RH.MANAGER else None
        if room is None:
            return
        b = B.BATTLES.get(room.roomid)
        if b is None:
            return
        status = msg.get("status") or {}
        # **把坐标存到 Fighter 上** —— 服务端自己算命中要用。
        # Vec3 是 short（×100 缩放），所以 /100 换成世界单位。
        try:
            p = status.get("pos") or {}
            f = b.fighters.get(int(roleid))
            if f is not None and p:
                f.syncpos = (float(p.get("x") or 0) / 100.0,
                             float(p.get("y") or 0) / 100.0,
                             float(p.get("z") or 0) / 100.0)
        except (TypeError, ValueError):
            pass
        payload = {
            int(roleid): {
                "state": {
                    "quat": status.get("quat") or {"w": 20000, "x": 0, "y": 0,
                                                   "z": 0},
                    "pos": status.get("pos") or {"x": 0, "y": 0, "z": 0},
                    "speed": status.get("speed") or {"x": 0, "y": 0, "z": 0},
                },
                "timestamp": int(time.time() * 1000),
            }
        }
        body = proto.encode(SC_ROLE_STATUS_SYNC,
                            _msg(SC_ROLE_STATUS_SYNC,
                                 rolestatuses=payload,
                                 servertime=int(time.time() * 1000)))
        for rid in list(room.members):
            if rid == roleid:
                continue
            self.send_to(rid, SC_ROLE_STATUS_SYNC, body)

    # -- 发送 ------------------------------------------------------------
    def send_raw_to(self, roleid: int, frame: bytes) -> bool:
        if self.transport is None:
            return False
        addr = self.addr_of(roleid)
        if addr is None:
            return False
        try:
            self.transport.sendto(frame, addr)
            self.packets_out += 1
            return True
        except Exception:
            (log.debug("UDP 发包失败 -> roleid=%s", roleid, exc_info=True) if log.isEnabledFor(10) else None)
            return False

    def send_to(self, roleid: int, tid: int, body: bytes) -> bool:
        return self.send_raw_to(roleid, encode_frame(tid, body))

    def stats(self) -> Dict[str, int]:
        return {"in": self.packets_in, "out": self.packets_out,
                "peers": len(_PEERS)}


def _msg(tid: int, **fields) -> Dict[str, Any]:
    m = proto.new_message(tid)
    m.update(fields)
    return m


async def start_udp(host: str, port: int, world=None):
    """在 host:port 上开 UDP。返回 (transport, channel)。"""
    loop = asyncio.get_running_loop()
    transport, channel = await loop.create_datagram_endpoint(
        lambda: UdpChannel(world), local_addr=(host, port))
    (log.info("UDP 位置通道 on %s:%s（和房间服同端口，协议不同）", host, port) if log.isEnabledFor(20) else None)
    return transport, channel
