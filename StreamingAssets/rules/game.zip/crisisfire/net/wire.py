"""xio wire primitives — faithful port of com.gwebtop.io.OctetsStream.

Frame layout (see ConnectionObject.Send / TryProcess on the client):

    compact_uint32(typeId) + compact_uint32(bodyLength) + body

All multi-byte integers are big-endian.  ``marshal(string)`` uses
``Encoding.Default`` on the client, which is UTF-8 under Mono/Android.
"""
from __future__ import annotations

import struct
from typing import Tuple


class MarshalException(Exception):
    """Raised when a buffer is too short, mirroring the client's MarshalException."""


# --------------------------------------------------------------------------
# compact integers
# --------------------------------------------------------------------------

def compact_uint32(x: int) -> bytes:
    """Port of OctetsStream.compact_uint32 / compact_sint32 (non-negative)."""
    if x < 0:
        raise ValueError("compact_uint32 requires a non-negative value")
    if x < 0x40:                       # < 64          -> 1 byte
        return bytes((x,))
    if x < 0x4000:                     # < 16384       -> 2 bytes, 0x8000 flag
        return struct.pack(">H", x | 0x8000)
    if x < 0x20000000:                 # < 536870912   -> 4 bytes, 0xC0000000 flag
        return struct.pack(">I", x | 0xC0000000)
    return b"\xe0" + struct.pack(">I", x & 0xFFFFFFFF)


def compact_sint32(x: int) -> bytes:
    """Port of OctetsStream.compact_sint32 (signed variant)."""
    if x >= 0:
        if x < 0x40:
            return bytes((x,))
        if x < 0x2000:
            return struct.pack(">H", x | 0x8000)
        if x < 0x10000000:
            return struct.pack(">I", x | 0xC0000000)
        return b"\xe0" + struct.pack(">I", x & 0xFFFFFFFF)
    n = -x
    if n > 0:
        if n < 0x40:
            return bytes((n | 0x40,))
        if n < 0x2000:
            return struct.pack(">H", n | 0xA000)
        if n < 0x10000000:
            return struct.pack(">I", n | 0xD0000000)
        return b"\xf0" + struct.pack(">I", n & 0xFFFFFFFF)
    return b"\xf0" + struct.pack(">I", x & 0xFFFFFFFF)


# --------------------------------------------------------------------------
# writer
# --------------------------------------------------------------------------

class OctetsStream:
    """Growable big-endian buffer with the client's marshal/unmarshal surface."""

    __slots__ = ("_buf", "_pos")

    def __init__(self, data: bytes = b""):
        self._buf = bytearray(data)
        self._pos = 0

    # -- housekeeping ------------------------------------------------------
    @property
    def data(self) -> bytes:
        return bytes(self._buf)

    def size(self) -> int:
        return len(self._buf)

    def remain(self) -> int:
        return len(self._buf) - self._pos

    def position(self, pos: int | None = None):
        if pos is None:
            return self._pos
        self._pos = pos
        return self._pos

    def eos(self) -> bool:
        return self._pos == len(self._buf)

    # -- marshal -----------------------------------------------------------
    def marshal_byte(self, x: int):
        self._buf.append(x & 0xFF)
        return self

    def marshal_bool(self, b: bool):
        return self.marshal_byte(1 if b else 0)

    def marshal_short(self, x: int):
        self._buf += struct.pack(">h", x)
        return self

    def marshal_ushort(self, x: int):
        self._buf += struct.pack(">H", x)
        return self

    def marshal_char(self, x: int):
        self._buf += struct.pack(">H", x & 0xFFFF)
        return self

    def marshal_int(self, x: int):
        self._buf += struct.pack(">i", x)
        return self

    def marshal_uint(self, x: int):
        self._buf += struct.pack(">I", x & 0xFFFFFFFF)
        return self

    def marshal_long(self, x: int):
        self._buf += struct.pack(">q", x)
        return self

    def marshal_float(self, x: float):
        self._buf += struct.pack(">f", x)
        return self

    def marshal_double(self, x: float):
        self._buf += struct.pack(">d", x)
        return self

    def marshal_octets(self, data: bytes):
        self._buf += compact_uint32(len(data))
        self._buf += data
        return self

    def marshal_string(self, s: str, charset: str | None = None):
        return self.marshal_octets(s.encode(charset or "utf-8"))

    def put_bytes(self, data: bytes):
        """Append already-encoded bytes (used for compact ints)."""
        self._buf += data
        return self

    # -- unmarshal ---------------------------------------------------------
    def _need(self, n: int):
        if self._pos + n > len(self._buf):
            raise MarshalException(
                f"need {n} bytes at {self._pos}, have {len(self._buf) - self._pos}"
            )

    def unmarshal_byte(self) -> int:
        self._need(1)
        v = self._buf[self._pos]
        self._pos += 1
        return v

    def unmarshal_bool(self) -> bool:
        return self.unmarshal_byte() == 1

    def unmarshal_short(self) -> int:
        self._need(2)
        v = struct.unpack_from(">h", self._buf, self._pos)[0]
        self._pos += 2
        return v

    def unmarshal_ushort(self) -> int:
        self._need(2)
        v = struct.unpack_from(">H", self._buf, self._pos)[0]
        self._pos += 2
        return v

    def unmarshal_char(self) -> int:
        return self.unmarshal_ushort()

    def unmarshal_int(self) -> int:
        self._need(4)
        v = struct.unpack_from(">i", self._buf, self._pos)[0]
        self._pos += 4
        return v

    def unmarshal_uint(self) -> int:
        self._need(4)
        v = struct.unpack_from(">I", self._buf, self._pos)[0]
        self._pos += 4
        return v

    def unmarshal_long(self) -> int:
        self._need(8)
        v = struct.unpack_from(">q", self._buf, self._pos)[0]
        self._pos += 8
        return v

    def unmarshal_float(self) -> float:
        self._need(4)
        v = struct.unpack_from(">f", self._buf, self._pos)[0]
        self._pos += 4
        return v

    def unmarshal_double(self) -> float:
        self._need(8)
        v = struct.unpack_from(">d", self._buf, self._pos)[0]
        self._pos += 8
        return v

    def uncompact_uint32(self) -> int:
        """Port of OctetsStream.uncompact_uint32."""
        if self._pos == len(self._buf):
            raise MarshalException("eos in uncompact_uint32")
        head = self._buf[self._pos] & 0xE0
        if head == 0xE0:                       # 224: escape + full uint32
            self.unmarshal_byte()
            return self.unmarshal_uint()
        if head == 0xC0:                       # 192: 4-byte, 0x3FFFFFFF mask
            return self.unmarshal_uint() & 0x3FFFFFFF
        if head in (0x80, 0xA0):               # 128/160: 2-byte, 0x7FFF mask
            return self.unmarshal_ushort() & 0x7FFF
        return self.unmarshal_byte()

    def uncompact_sint32(self) -> int:
        """Port of OctetsStream.uncompact_sint32."""
        if self._pos == len(self._buf):
            raise MarshalException("eos in uncompact_sint32")
        head = self._buf[self._pos] & 0xF0
        if head == 0xF0:
            self.unmarshal_byte()
            return -self.unmarshal_int()
        if head == 0xE0:
            self.unmarshal_byte()
            return self.unmarshal_int()
        if head == 0xD0:
            return -(self.unmarshal_uint() & 0x2FFFFFFF)
        if head == 0xC0:
            return self.unmarshal_uint() & 0x3FFFFFFF
        if head in (0xA0, 0xB0):
            return -(self.unmarshal_ushort() & 0x5FFF)
        if head in (0x80, 0x90):
            return self.unmarshal_ushort() & 0x7FFF
        if head in (0x40, 0x50, 0x60, 0x70):
            return -(self.unmarshal_byte() & -65)
        return self.unmarshal_byte()

    def unmarshal_octets(self) -> bytes:
        n = self.uncompact_uint32()
        self._need(n)
        v = bytes(self._buf[self._pos:self._pos + n])
        self._pos += n
        return v

    def unmarshal_string(self, charset: str | None = None) -> str:
        try:
            return self.unmarshal_octets().decode(charset or "utf-8")
        except MarshalException:
            raise
        except Exception as exc:                     # mirrors the client's catch-all
            raise MarshalException(str(exc)) from exc


# --------------------------------------------------------------------------
# framing
# --------------------------------------------------------------------------

def encode_frame(type_id: int, body: bytes) -> bytes:
    """Build one wire frame."""
    return compact_uint32(type_id) + compact_uint32(len(body)) + body


def peek_frame(buf: bytes, start: int = 0) -> Tuple[int, int, int] | None:
    """Try to read a frame header.

    Returns ``(type_id, body_len, header_len)`` when the header is complete
    (the body itself may still be missing), or ``None`` if even the header is
    truncated.  ``MarshalException`` propagates for corrupt input.
    """
    os_ = OctetsStream(buf)
    os_.position(start)
    try:
        type_id = os_.uncompact_uint32()
        body_len = os_.uncompact_uint32()
    except MarshalException:
        return None
    if body_len < 0:
        raise MarshalException("negative body length")
    return type_id, body_len, os_.position() - start


def decode_frames(buf: bytes):
    """Split a byte buffer into ``(type_id, body)`` pairs.

    Returns ``(frames, consumed)``; ``consumed`` counts the bytes of complete
    frames so the caller can keep the trailing partial frame in its buffer.
    """
    frames = []
    pos = 0
    n = len(buf)
    while pos < n:
        hdr = peek_frame(buf, pos)
        if hdr is None:
            break
        type_id, body_len, hdr_len = hdr
        if pos + hdr_len + body_len > n:
            break
        body = buf[pos + hdr_len: pos + hdr_len + body_len]
        frames.append((type_id, body))
        pos += hdr_len + body_len
    return frames, pos
