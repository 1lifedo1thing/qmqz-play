"""Generated protocol codec for all 482 registered message types.

Regenerate with::

    python ../tools/gen_spec.py <decompiled-src-root> crisisfire/proto/spec.json
"""

from .codec import (  # noqa: F401
    PROTOCOLS,
    STRUCTS,
    all_ids,
    decode,
    default_for,
    describe,
    encode,
    id_for_name,
    name_for_id,
    new_message,
)
