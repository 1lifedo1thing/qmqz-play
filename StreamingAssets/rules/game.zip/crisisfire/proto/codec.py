"""Runtime codec driven by spec.json.

Values are plain Python objects:

===============  ==========================
wire type        Python
===============  ==========================
byte/short/int   int
uint/long        int
bool             bool
float/double     float
string           str
octets/bytes     bytes
struct           dict
list             list
map              dict
===============  ==========================

Encoding is lenient: missing keys fall back to the type's zero value, which
keeps handler code short.
"""
from __future__ import annotations

import json
import os
import struct as _struct
from typing import Any, Dict, Iterable, List

from ..net.wire import OctetsStream, MarshalException, compact_uint32, compact_sint32

_SPEC_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "spec.json")

with open(_SPEC_PATH, encoding="utf-8") as _fh:
    _SPEC = json.load(_fh)

PROTOCOLS: Dict[str, dict] = _SPEC["protocols"]
STRUCTS: Dict[str, dict] = _SPEC["structs"]

_BY_CLS: Dict[str, int] = {v["cls"]: int(k) for k, v in PROTOCOLS.items()}


# --------------------------------------------------------------------------
# charset handling
# --------------------------------------------------------------------------
_CHARSET_ALIASES = {
    "utf-16": "utf-16-le",       # Mono's Encoding.GetEncoding("utf-16") is LE, no BOM
    "utf16": "utf-16-le",
    "unicode": "utf-16-le",
    "utf-8": "utf-8",
    "utf8": "utf-8",
    "": "utf-8",
    "us-ascii": "ascii",
    "ascii": "ascii",
    "gb2312": "gbk",
    "gbk": "gbk",
}


def _python_charset(name: str | None) -> str:
    if not name:
        return "utf-8"
    return _CHARSET_ALIASES.get(name.strip().lower(), name)


# --------------------------------------------------------------------------
# defaults
# --------------------------------------------------------------------------
def default_for(field: dict) -> Any:
    """Zero value for a field.

    Structs recurse so a freshly built message already carries every nested
    key.  That makes encode/decode an exact round-trip and lets handler code
    index any sub-field without existence checks.
    """
    t = field["type"]
    if t in ("byte", "short", "char", "int", "uint", "long", "cuint", "csint"):
        return 0
    if t == "bool":
        return False
    if t in ("float", "double"):
        return 0.0
    if t == "string":
        return ""
    if t in ("octets", "bytes"):
        return b""
    if t == "struct":
        sub = STRUCTS.get(field.get("cls") or "")
        if sub is None:
            return {}
        return {f["name"]: default_for(f) for f in sub["fields"]}
    if t == "list":
        return []
    if t == "map":
        return {}
    return 0


def new_message(type_id: int) -> Dict[str, Any]:
    """A message dict with every field set to its zero value."""
    spec = PROTOCOLS.get(str(type_id))
    if spec is None:
        raise KeyError(f"unknown protocol id {type_id}")
    return {f["name"]: default_for(f) for f in spec["fields"]}


def id_for_name(name: str) -> int:
    """Resolve a class name (``gnet.Challenge`` or bare ``Challenge``)."""
    if name in _BY_CLS:
        return _BY_CLS[name]
    hits = [tid for cls, tid in _BY_CLS.items() if cls.rsplit(".", 1)[-1] == name]
    if len(hits) == 1:
        return hits[0]
    if not hits:
        raise KeyError(f"unknown protocol class {name!r}")
    raise KeyError(f"ambiguous protocol class {name!r}: {hits}")


def name_for_id(type_id: int) -> str:
    spec = PROTOCOLS.get(str(type_id))
    return spec["cls"] if spec else f"#{type_id}"


def all_ids() -> List[int]:
    return sorted(int(k) for k in PROTOCOLS)


# --------------------------------------------------------------------------
# encode
# --------------------------------------------------------------------------
def encode(type_id: int, values: Dict[str, Any] | None = None) -> bytes:
    spec = PROTOCOLS.get(str(type_id))
    if spec is None:
        raise KeyError(f"cannot encode unknown protocol id {type_id}")
    os_ = OctetsStream()
    _write_fields(os_, spec["fields"], values or {}, type_id)
    return os_.data


def _write_fields(os_: OctetsStream, fields: Iterable[dict], values: Dict[str, Any],
                  ctx: Any) -> None:
    for f in fields:
        name = f["name"]
        v = values.get(name, None)
        if v is None:
            v = default_for(f)
        _write_value(os_, f, v, ctx)


def _write_value(os_: OctetsStream, f: dict, v: Any, ctx: Any) -> None:
    t = f["type"]
    if t == "byte":
        os_.marshal_byte(int(v) & 0xFF)
    elif t == "bool":
        os_.marshal_bool(bool(v))
    elif t == "short":
        os_.marshal_short(int(v))
    elif t == "char":
        os_.marshal_char(int(v))
    elif t == "int":
        os_.marshal_int(_to_i32(int(v)))
    elif t == "uint":
        os_.marshal_uint(int(v))
    elif t == "long":
        os_.marshal_long(_to_i64(int(v)))
    elif t == "float":
        os_.marshal_float(float(v))
    elif t == "double":
        os_.marshal_double(float(v))
    elif t == "cuint":
        os_.put_bytes(compact_uint32(int(v)))
    elif t == "csint":
        os_.put_bytes(compact_sint32(int(v)))
    elif t == "string":
        if isinstance(v, bytes):
            raw = v
        else:
            raw = str(v).encode(_python_charset(f.get("charset")), "replace")
        os_.marshal_octets(raw)
    elif t in ("octets", "bytes"):
        raw = v if isinstance(v, (bytes, bytearray)) else bytes(v)
        os_.marshal_octets(bytes(raw))
    elif t == "struct":
        sub = STRUCTS.get(f.get("cls") or "")
        if sub is None:
            raise KeyError(f"unknown struct {f.get('cls')!r} in {ctx}")
        _write_fields(os_, sub["fields"], v if isinstance(v, dict) else {}, f.get("cls"))
    elif t == "list":
        items = v if isinstance(v, (list, tuple)) else []
        os_.put_bytes(compact_uint32(len(items)))
        for item in items:
            _write_value(os_, f["elem"], item, ctx)
    elif t == "map":
        d = v if isinstance(v, dict) else {}
        os_.put_bytes(compact_uint32(len(d)))
        for k, val in d.items():
            _write_value(os_, f["key"], k, ctx)
            _write_value(os_, f["value"], val, ctx)
    else:
        raise ValueError(f"unsupported field type {t!r}")


# --------------------------------------------------------------------------
# decode
# --------------------------------------------------------------------------
# spec.json was generated from the putao 1.12 assembly, but the delivered APK
# is built from the cracked cmge 1.7.1 base.  1.7.1 is a strict subset, and a
# handful of messages changed shape between the two -- CsHonorGacha, for
# instance, writes no fields at all in 1.7.1 while the spec expects an int.
# A short body must therefore decode to defaults rather than raise, otherwise
# the handler never runs and the button looks dead.
def decode(type_id: int, body: bytes) -> Dict[str, Any]:
    spec = PROTOCOLS.get(str(type_id))
    if spec is None:
        raise KeyError(f"cannot decode unknown protocol id {type_id}")
    os_ = OctetsStream(body)
    return _read_fields(os_, spec["fields"], type_id)


def _read_fields(os_: OctetsStream, fields: Iterable[dict], ctx: Any) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for f in fields:
        out[f["name"]] = _read_value(os_, f, ctx)
    return out


def _read_value(os_: OctetsStream, f: dict, ctx: Any) -> Any:
    # the client's body may be shorter than the spec (see note above)
    if os_.eos():
        return default_for(f)
    try:
        return _read_value_strict(os_, f, ctx)
    except (MarshalException, IndexError, _struct.error):
        return default_for(f)


def _read_value_strict(os_: OctetsStream, f: dict, ctx: Any) -> Any:
    t = f["type"]
    if t == "byte":
        return os_.unmarshal_byte()
    if t == "bool":
        return os_.unmarshal_bool()
    if t == "short":
        return os_.unmarshal_short()
    if t == "char":
        return os_.unmarshal_char()
    if t == "int":
        return os_.unmarshal_int()
    if t == "uint":
        return os_.unmarshal_uint()
    if t == "long":
        return os_.unmarshal_long()
    if t == "float":
        return os_.unmarshal_float()
    if t == "double":
        return os_.unmarshal_double()
    if t == "cuint":
        return os_.uncompact_uint32()
    if t == "csint":
        return os_.uncompact_sint32()
    if t == "string":
        raw = os_.unmarshal_octets()
        return raw.decode(_python_charset(f.get("charset")), "replace")
    if t in ("octets", "bytes"):
        return os_.unmarshal_octets()
    if t == "struct":
        sub = STRUCTS.get(f.get("cls") or "")
        if sub is None:
            raise MarshalException(f"unknown struct {f.get('cls')!r} in {ctx}")
        return _read_fields(os_, sub["fields"], f.get("cls"))
    if t == "list":
        n = os_.uncompact_uint32()
        return [_read_value(os_, f["elem"], ctx) for _ in range(n)]
    if t == "map":
        n = os_.uncompact_uint32()
        out = {}
        for _ in range(n):
            k = _read_value(os_, f["key"], ctx)
            v = _read_value(os_, f["value"], ctx)
            out[k] = v
        return out
    raise ValueError(f"unsupported field type {t!r}")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _to_i32(x: int) -> int:
    x &= 0xFFFFFFFF
    return x - 0x100000000 if x >= 0x80000000 else x


def _to_i64(x: int) -> int:
    x &= 0xFFFFFFFFFFFFFFFF
    return x - 0x10000000000000000 if x >= 0x8000000000000000 else x


def describe(type_id: int) -> str:
    """Human-readable field list, handy when writing handlers."""
    spec = PROTOCOLS.get(str(type_id))
    if spec is None:
        return f"#{type_id} (unknown)"
    lines = [f"{type_id} {spec['cls']}"]
    for f in spec["fields"]:
        extra = ""
        if f.get("charset"):
            extra += f" [{f['charset']}]"
        if f.get("cls"):
            extra += f" <{f['cls']}>"
        if f["type"] == "list":
            e = f["elem"]
            extra += f" <list of {e['type']}{' ' + e['cls'] if e.get('cls') else ''}>"
        if f["type"] == "map":
            extra += (f" <map {f['key']['type']} -> {f['value']['type']}"
                      f"{' ' + f['value']['cls'] if f['value'].get('cls') else ''}>")
        lines.append(f"    {f['type']:<8} {f['name']}{extra}")
    return "\n".join(lines)
