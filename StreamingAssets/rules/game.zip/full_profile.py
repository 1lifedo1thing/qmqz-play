"""One-time browser profile upgrade, driven by the APK's item, rank and VIP tables."""
from crisisfire import gamedata
from crisisfire.game import equip, leveling, premium_ammo, robot, talent, vip


VERSION = 2


def grant_research_points(role, world):
    levels = talent.research_talents(role)
    remaining = sum(max(0, row["maxLevel"] - levels.get(row["id"], 0))
                    for row in gamedata.table("ResearchTalent"))
    role.data["research_point"] = max(talent.research_point_of(role), remaining)
    role.data["web_full_unlock_version"] = VERSION
    world.save_role(role)
    return role


def upgrade(role, world):
    data = role.data
    previous = data.get("web_full_unlock_version", 0)
    if previous >= VERSION:
        return role
    if previous == 1:
        return grant_research_points(role, world)

    # Older APK profiles sometimes contain paid ammunition only in pkg_items. Keep its original count.
    permanent = set(equip.all_equipment_ids()) - premium_ammo.paid_rows().keys()
    data["pkg_items"] = sorted(permanent | {int(item) for item in data.get("pkg_items") or []})
    marker = data.get("local_equipment_unlock")
    data["local_equipment_unlock"] = dict(marker if isinstance(marker, dict) else {}, progression=True)

    actors = dict(data.get("actors") or {})
    for camp, ids in equip.owned_actors(role).items():
        actors.setdefault(str(camp), {str(i): remaining for i, remaining in ids.items()})
    for actor in gamedata.table("Role"):
        if actor["camp"] in (1, 2, 3) and actor["visible"]:
            actors.setdefault(str(actor["camp"]), {})[str(actor["id"])] = 0
    data["actors"] = actors

    # Keep all selected original IDs, including a character's additional purchased loadouts.
    loadouts = data.get("loadouts") or []
    if len(loadouts) < 2:
        starters = equip.starter_loadouts()
        data["loadouts"] = list(loadouts) + starters[len(loadouts):2]

    progress = dict(data.get("gun_research") or {})
    for part in gamedata.table("Part"):
        if part["maxHolding"] > 0:
            key = str(part["id"])
            progress[key] = max(int(progress.get(key, 0)), part["maxHolding"])
    data["gun_research"] = progress

    top_rank = leveling.max_rank()
    role.level = max(role.level, top_rank)
    role.exp = max(role.exp, leveling.exp_for_rank(top_rank))
    top_vip = vip.max_vip()
    data["cash_all"] = max(vip.cash_of(role), vip.vip_row(top_vip)["recharge"])
    data["vipstatus"] = max(int(data.get("vipstatus") or 0), top_vip)

    # Original robot_open is the next sequential level. Previous stages are known clears.
    # A level-20 old save does not say whether the final stage itself was won.
    data.setdefault("web_training_clears", list(range(1, robot._open_level(role))))
    return grant_research_points(role, world)


def loadout(row):
    slots = [{"position": int(position), "itemId": item, "effectiveItemId": item}
             for position, item in row["equipmap"].items()]
    star = max((equip.item_row(slot["itemId"]).get("star", 0) for slot in slots), default=0)
    return {"star": star, "slots": slots}
