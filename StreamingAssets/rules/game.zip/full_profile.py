"""One-time browser profile upgrade, driven by the APK's item, rank and VIP tables."""
from crisisfire import gamedata
from crisisfire.game import equip, leveling, premium_ammo, research, robot, shop, talent, vip


VERSION = 2


def legend_versions(role):
    """Paid legendary progression is independent of the browser's all-weapon inventory."""
    owned = shop.owned_gifts(role)
    bought = shop._bought_gifts(role)
    completed = role.data.get("legend_life_chips") or []
    saved = role.data.get("web_legend_versions") or {}
    versions = {}
    for model in research._LEGEND_MODEL_TYPES:
        angry = model == research._ANGRY_MODEL_TYPE
        gift = research._ANGRY_CHIP_GIFT if angry else research._legend_chip_for(model)
        count = owned.count(gift)
        if not (count or gift in bought or model in completed):
            continue
        if model in completed or angry and count:
            version = 4
        elif angry:
            version = 0
        else:
            version = max((star-9 for star, chips in research._CHIPS_BY_STAR.items() if chips<=count), default=0)
        versions[str(model)] = max(version, int(saved.get(str(model),0)))
    return versions


async def transform_legend(world, session, role, row, fields):
    model = str(row["modelType"])
    if legend_versions(role).get(model) != row["version"]:
        return
    await research.on_transform(session, fields)
    if not any(m["id"]==research.ID.SC_TRANSFORM for m in session.messages):
        return
    current = world.role(role.roleid)
    versions = dict(current.data.get("web_legend_versions") or {})
    versions[model] = row["version"] + 1
    world.merge_role_data(role.roleid, web_legend_versions=versions)
    # The original transform replaces the previous item. It remains playable in the all-weapon browser profile.
    equip.grant_items(current, [row["id"]], world)


def grant_research_points(role, world):
    levels = talent.research_talents(role)
    remaining = sum(max(0, row["maxLevel"] - levels.get(row["id"], 0))
                    for row in gamedata.table("ResearchTalent"))
    role.data["research_point"] = max(talent.research_point_of(role), remaining)
    role.data["web_full_unlock_version"] = VERSION
    world.save_role(role)
    return role


def upgrade(role, world):
    data = role.data
    previous = data.get("web_full_unlock_version", 0)
    if previous >= VERSION:
        return role
    if previous == 1:
        return grant_research_points(role, world)

    # Older APK profiles sometimes contain paid ammunition only in pkg_items. Keep its original count.
    permanent = set(equip.all_equipment_ids()) - premium_ammo.paid_rows().keys()
    data["pkg_items"] = sorted(permanent | {int(item) for item in data.get("pkg_items") or []})
    marker = data.get("local_equipment_unlock")
    data["local_equipment_unlock"] = dict(marker if isinstance(marker, dict) else {}, progression=True)

    actors = dict(data.get("actors") or {})
    for camp, ids in equip.owned_actors(role).items():
        actors.setdefault(str(camp), {str(i): remaining for i, remaining in ids.items()})
    for actor in gamedata.table("Role"):
        if actor["camp"] in (1, 2, 3) and actor["visible"]:
            actors.setdefault(str(actor["camp"]), {})[str(actor["id"])] = 0
    data["actors"] = actors

    # Keep all selected original IDs, including a character's additional purchased loadouts.
    loadouts = data.get("loadouts") or []
    if len(loadouts) < 2:
        starters = equip.starter_loadouts()
        data["loadouts"] = list(loadouts) + starters[len(loadouts):2]

    progress = dict(data.get("gun_research") or {})
    for part in gamedata.table("Part"):
        if part["maxHolding"] > 0:
            key = str(part["id"])
            progress[key] = max(int(progress.get(key, 0)), part["maxHolding"])
    data["gun_research"] = progress

    top_rank = leveling.max_rank()
    role.level = max(role.level, top_rank)
    role.exp = max(role.exp, leveling.exp_for_rank(top_rank))
    top_vip = vip.max_vip()
    data["cash_all"] = max(vip.cash_of(role), vip.vip_row(top_vip)["recharge"])
    data["vipstatus"] = max(int(data.get("vipstatus") or 0), top_vip)

    # Original robot_open is the next sequential level. Previous stages are known clears.
    # A level-20 old save does not say whether the final stage itself was won.
    data.setdefault("web_training_clears", list(range(1, robot._open_level(role))))
    return grant_research_points(role, world)


def loadout(row):
    slots = [{"position": int(position), "itemId": item, "effectiveItemId": item}
             for position, item in row["equipmap"].items()]
    star = max((equip.item_row(slot["itemId"]).get("star", 0) for slot in slots), default=0)
    return {"star": star, "slots": slots}


def can_restore_bag(role, index, row):
    return (index >= 2 and index not in role.data.get("web_initialized_bags", []) and
            all(int(pos) in equip.ARMOR_SLOTS for pos in row["equipmap"]))


def mark_bag(world, role, index):
    known = role.data.get("web_initialized_bags", [])
    if index >= 2 and index not in known:
        world.merge_role_data(role.roleid, web_initialized_bags=sorted(set(known) | {index}))


def fill_bag(world, role, index, purchased=False):
    rows = equip.loadouts_of(role)
    if not 0 <= index < len(rows) or not (purchased or can_restore_bag(role, index, rows[index])):
        return None
    starters = equip.starter_loadouts()
    # The original third starter is M4A1. Additional paid tabs use the first original starter.
    items = dict(starters[index if index < len(starters) else 0]["equipmap"])
    items.update(equip.inherit_armor_equipmap(rows))
    items.update(rows[index]["equipmap"])
    rows[index] = {"equipmap": items, "star": max(equip.item_row(i)["star"] for i in items.values())}
    equip.save_loadouts(role, rows, world)
    mark_bag(world, role, index)
    return rows[index]
