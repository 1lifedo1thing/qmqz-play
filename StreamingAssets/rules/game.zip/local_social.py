"""Bridge the original offline friend and chat handlers to one browser's local roles."""

import time

from crisisfire.game import chat, friends, handlers, profile, pve_progress, vip
from crisisfire.game.world import World


FILTER_LIMITS = dict(world=1, clan=1, private=1, worldVip=25, worldRank=120, privateVip=25, privateRank=120)


def accepts(options, channel, fields):
    return (
        fields["roleid"] not in options.get("blocked", [])
        and not options.get(channel)
        and fields.get("viplevel", 0) >= options.get(channel + "Vip", 0)
        and fields.get("rank", 0) >= options.get(channel + "Rank", 0)
    )


def visible_history(messages):
    # TalkManager creates a capacity-20 MessageChannel for world and for each friend.
    remaining = {}
    kept = []
    for message in reversed(messages):
        channel = (message["channel"], message.get("peer"))
        count = remaining.get(channel, 0)
        if count < 20:
            kept.append(message)
            remaining[channel] = count + 1
    return kept[::-1]


async def command(request, session_type):
    directory = request["directory"]
    current = request["roleid"]
    if current not in {r["roleid"] for r in directory}:
        raise ValueError("Unknown local role")
    data = request.get("social") or {}
    world = World(":memory:")
    game_world, friend_world = handlers.world, friends._world
    previous_clock = chat._world_last
    chat._world_last = {int(k): v for k, v in data.get("worldClock", {}).items()}
    try:
        # Friend operations are synchronous local SQLite mutations even though the handlers are coroutines.
        handlers.world = world
        friends.bind_world(world)
        for entry in directory:
            rid = entry["roleid"]
            world._db.execute(
                "INSERT INTO roles(roleid,userid,name,created) VALUES(?,?,?,?)",
                (rid, rid, entry["name"], time.time()),
            )
            role = world.role(rid)
            for key in ("name", "iconid", "level", "exp"):
                setattr(role, key, entry[key])
            role.data = dict(
                entry.get("publicData") or {},
                **data.get("praise", {}).get(str(rid), {}),
                offline_msgs=data.get("mail", {}).get(str(rid), []),
            )
            world.save_role(role)
        with world._db:
            world._db.executemany(
                "INSERT INTO friends(roleid,friendid,kind,created) VALUES(?,?,?,?)",
                data.get("links", []),
            )
            world._db.executemany(
                "INSERT INTO friend_requests(fromid,toid,created) VALUES(?,?,?)",
                data.get("requests", []),
            )
        role = world.role(current)
        session = session_type(role)
        world.attach(session)
        world.mark_online(current, session)
        peers = {}
        for rid in set(request.get("online", [])) - {current}:
            target = world.role(rid)
            if target:
                other = session_type(target)
                world.attach(other)
                world.mark_online(rid, other)
                peers[rid] = other
        chat.push_offline(session, role)
        history = dict(data.get("history", {}))
        messages = list(history.get(str(current), []))
        for receipt in session.messages:
            if receipt["id"] == chat.ID.OFFLINE_FRIEND_MSG:
                for msg in receipt["fields"]["messages"]:
                    if world.are_friends(current, msg["friendid"]):
                        messages.append(
                            dict(
                                channel="friend",
                                unread=True,
                                sender=msg["friendid"],
                                peer=msg["friendid"],
                                text=msg["message"],
                                time=msg["time"],
                            )
                        )
        op = request.get("op") or {}
        settings = data.get("chatOptions", {})
        options = settings.setdefault(str(current), {})
        change = op.get("chatFilter") or {}
        for key, value in change.items():
            if key not in FILTER_LIMITS or type(value) is not int or not 0 <= value <= FILTER_LIMITS[key]:
                raise ValueError("Unknown chat filter setting")
            options[key] = value
        muted = op.get("blockTalker")
        if muted and muted != current and world.role(muted):
            if muted not in options.setdefault("blocked", []):
                options["blocked"].append(muted)
            messages = [m for m in messages if m["sender"] != muted and m.get("peer") != muted]
        read_peer = op.get("readFriend") or op.get("readPrivate")
        read_channel = "private" if op.get("readPrivate") else "friend"
        if read_peer:
            for m in messages:
                if m.get("channel") == read_channel and m.get("peer") == read_peer:
                    m.pop("unread", None)
        funcs = {
            917505: friends.on_request,
            917516: friends.on_request_by_name,
            917520: friends.on_confirmed,
            917508: friends.on_refused,
            917512: friends.on_add_blacklist,
            917514: friends.on_remove_blacklist,
            917517: friends.on_praise,
            1114158: profile.on_get_role_info,
            851969: chat.on_chat_message,
            851970: chat.on_broadcast,
        }
        key = op.get("id")
        fields = op.get("fields", {})
        if key is not None:
            if key not in funcs:
                raise ValueError("Unknown social operation")
            if key != 851969 or (
                world.role(fields.get("roleid")) and fields["roleid"] != current
            ):
                await funcs[key](session, fields)
            if key == 851969:
                peer = fields.get("roleid")
                content = chat._clean(fields.get("content"))
                if (
                    peer != current
                    and world.role(peer)
                    and content
                    and not world.has_blacklisted(peer, current)
                ):
                    messages.append(
                        dict(
                            channel="friend" if world.are_friends(current, peer) else "private",
                            sender=current,
                            peer=peer,
                            text=content,
                            time=int(time.time()),
                        )
                    )
            if key == 851970:
                for receipt in session.messages:
                    if receipt["id"] == chat.ID.BROADCAST:
                        f = receipt["fields"]
                        messages.append(
                            dict(
                                channel="world",
                                sender=f["roleid"],
                                text=f["content"],
                                monthcard=f.get("monthcard", 0),
                                time=int(time.time()),
                            )
                        )
        friends.push_all(session, world.role(current))
        history[str(current)] = messages
        for rid, other in peers.items():
            received = history.setdefault(str(rid), [])
            prefs = settings.get(str(rid), {})
            for receipt in other.messages:
                f = receipt["fields"]
                if receipt["id"] == chat.ID.CHAT_MESSAGE:
                    friend = world.are_friends(rid, f["roleid"])
                    if not friend:
                        # ChatGoalBoard sends 851969 for both channels. The APK client
                        # accepts non-friends only in PrivateMessage (0xe51df), with
                        # the same public sender card that the original broadcast uses.
                        f = dict(f, name=role.name, rank=role.level, icon=role.iconid,
                                 viplevel=int(vip.level_of(role)),
                                 monthcard=int(pve_progress.month_active(role)))
                        receipt.update(id=851974, fields=f)
                    if f["roleid"] in prefs.get("blocked", []) or not friend and not accepts(prefs, "private", f):
                        continue
                    received.append(
                        dict(
                            channel="friend" if friend else "private",
                            receipt=receipt["id"],
                            unread=True,
                            sender=f["roleid"],
                            peer=f["roleid"],
                            text=f["content"],
                            monthcard=f.get("monthcard", 0),
                            time=int(time.time()),
                        )
                    )
                if receipt["id"] == chat.ID.BROADCAST and accepts(prefs, "world", f):
                    received.append(
                        dict(
                            channel="world",
                            sender=f["roleid"],
                            text=f["content"],
                            monthcard=f.get("monthcard", 0),
                            time=int(time.time()),
                        )
                    )
        for owner in {str(current), *(str(rid) for rid in peers)}:
            history[owner] = visible_history(history[owner])
        messages = history[str(current)]
        links = [
            list(row)
            for row in world._db.execute(
                "SELECT roleid,friendid,kind,created FROM friends ORDER BY created"
            )
        ]
        pending = [
            list(row)
            for row in world._db.execute(
                "SELECT fromid,toid,created FROM friend_requests ORDER BY created"
            )
        ]
        mail = {}
        praise = {}
        for r in directory:
            saved = world.role(r["roleid"])
            entries = {
                k: saved.data[k]
                for k in ("praised", "praises", "praised_count")
                if k in saved.data
            }
            if entries:
                praise[str(r["roleid"])] = entries
            unread = chat._offline_msgs(saved)
            if unread:
                mail[str(r["roleid"])] = unread
        return {
            "receipts": session.messages,
            "history": messages,
            "chatOptions": options,
            "social": {
                "links": links,
                "requests": pending,
                "mail": mail,
                "history": history,
                "praise": praise,
                "worldClock": chat._world_last,
                "chatOptions": settings,
            },
        }
    finally:
        chat._world_last = previous_clock
        handlers.world = game_world
        friends.bind_world(friend_world)
        world.close()
