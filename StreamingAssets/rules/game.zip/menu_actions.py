"""Offline menu callbacks forwarded to the original APK's game handlers."""
from crisisfire import gamedata
from crisisfire.game import daily, equip, equipment, exchange, gacha, pve_progress, research, roulette, shop, slot, tasks, vip
import challenge_cards
from poster_actions import dispatch_poster
from talent_actions import dispatch_talent


async def dispatch_menu(world, session, payload):
    role = world.role(session.roleid)
    if role is None:
        return
    if await challenge_cards.dispatch(world, session, payload):
        return
    view = payload.get("view")
    if view == "recharge-status":
        vip.send_sync(session, role)
        return
    if view == "bonus-login":
        daily.push_on_login(session, role)
        shop.push_cards(session, role)
        return
    if view == "week-cards":
        shop.push_cards(session, role)
        return
    if view == "bonuses":
        daily.send_online_info(session, role)
        daily.send_daily_info(session, role)
        tasks.send_sync(session, role)
        return
    if payload.get("id") == daily.ID.CS_GET_ONLINE_REWARD:
        row = daily.next_online_reward(role)
        if row and payload.get("expectedReward") == row["id"]:
            await daily.on_online_reward(session, {})
        else:
            session.send(daily.ID.SC_GET_ONLINE_REWARD, result=0, gold=0, bloodgem=0, exp=0)
            daily.send_online_info(session, role)
        return
    if payload.get("id") == daily.ID.CS_GET_DAILY_REWARD:
        await daily.on_daily_reward(session, {})
        daily.send_daily_info(session, world.role(role.roleid))
        return
    if view == "tasks":
        tasks.send_sync(session, role)
        return
    if view == "upgrade":
        research.push_on_login(session, role)
        return
    if await dispatch_talent(world, session, payload) or await dispatch_poster(world, session, payload):
        return
    if payload.get("id") == exchange.CS_ADD_CASH_REQ:
        fields = payload.get("fields", {})
        tier_id = fields.get("cashitemid")
        if tier_id == -1:
            await pve_progress.request_card(session, fields)
            return
        tier = next((row for row in gamedata.table("RechargeGem") if row["id"] == tier_id), None)
        if not tier:
            await exchange.on_add_cash(session, fields)
            return
        # The Web edition offers these eight APK tiers for free on this local profile.
        amount = tier["gem"] + tier["giftGem"]
        world.award_local(role.roleid, {"cash_all": vip.cash_of(role) + tier["rmb"]}, gems=amount)
        updated = world.role(role.roleid)
        vip.send_sync(session, updated)
        session.send(exchange.ID.SC_ACOUNT_SYNC, gold=updated.gold, money=updated.money, diamond=updated.diamond)
        session.send(exchange.SC_ADD_CASH_RES, result=0, cashitemid=tier_id, orderid="", localGems=amount)
        return
    request = payload.get("id")
    if request in (slot.ID.CS_START, slot.ID.CS_ADD, slot.ID.CS_END):
        fields = payload.get("fields", {})
        saved = role.data.get("webSlotPending")
        # The APK keeps unpaid reels in server memory. A browser reload recreates the worker.
        if saved:
            slot._pending[role.roleid] = dict(saved)
        try:
            if request == slot.ID.CS_START:
                if saved or (fields.get("moneytype"), fields.get("multiple")) not in ((1,1),(1,10),(0,1),(0,10),(0,100)):
                    return
                await slot.on_slot_start(session, fields)
            elif request == slot.ID.CS_ADD:
                await slot.on_slot_add(session, fields)
            else:
                await slot.on_slot_end(session, fields)
            state = slot._pending.get(role.roleid)
            if state:
                # Project authoritative outcomes and the next fee without doing a second draw.
                rows, ids, multiple = slot._rows(), state["ids"], state["multiple"]
                best = slot._max_slot4(rows, ids)
                state = {**state, "points": slot._final_points(rows, ids, multiple),
                         "best": slot._final_points(rows, ids[:3] + [best], multiple),
                         "appendCost": multiple * slot._append_price(rows, ids, state["appends"], best)}
            world.merge_role_data(role.roleid, webSlotPending=state)
        finally:
            slot._pending.pop(role.roleid, None)
        return
    if request in (roulette.ID.CS_GEM_LOTTERY_INFO, roulette.ID.CS_GEM_LOTTERY,
                   roulette.ID.CS_GOLDEN_LOTTERY, roulette.ID.CS_GOLDEN_LOTTERY_RESET):
        fields = payload.get("fields", {})
        vip.send_sync(session, role)
        exchange.send_tickets(session, role)
        if request == roulette.ID.CS_GEM_LOTTERY_INFO:
            plate = fields.get("lotterytype", 0)
            if plate not in (0,2) or (plate == 2 and vip.level_of(role) < 3):
                fields = {"lotterytype": 0}
            await roulette.on_info(session, fields)
            return
        if not vip.cash_of(role):
            return
        if request == roulette.ID.CS_GEM_LOTTERY:
            if roulette.plate_of(role) == 0 and fields.get("multiple") in (1, 10):
                await roulette.on_lottery(session, fields)
        elif vip.level_of(role) >= 3 and roulette.plate_of(role) == 2:
            handler = roulette.on_golden if request == roulette.ID.CS_GOLDEN_LOTTERY else roulette.on_golden_reset
            await handler(session, fields)
        return
    if request == 786448:  # EquipManager.CreateNewEquipTab
        count = len(equip.loadouts_of(role))
        if count == payload.get("expectedCount") and count < 10:
            await equipment.on_new_tab(session, {})
        return
    callbacks = {
        equipment.ID.CS_ATTACH_SUBJOIN: equipment.on_attach_subjoin,
        equipment.ID.CS_BUY_ACTOR: equipment.on_buy_actor,
        exchange.ID.CS_EXCHANGE: exchange.on_exchange,
        shop.ID.CS_BUY: shop.on_buy,
        shop.ID.CS_BUY_CARD: shop.on_buy_card,
        gacha.ID.CS_GET_BIG_GEM_GACHA_INFO: gacha.on_big_info,
        gacha.ID.CS_HONOR_GACHA: gacha.on_honor_gacha,
        gacha.ID.CS_GEM_GACHA: gacha.on_gem_gacha,
        gacha.ID.CS_BIG_GEM_GACHA: gacha.on_big_gacha,
        exchange.CS_RECHARGE_HONOR: exchange.on_recharge_honor,
        research.ID.CS_GUN_RESEARCH: research.on_gun_research,
        research.ID.CS_TRANSFORM: research.on_transform,
        2686988: tasks.claim_task,
        1048600: tasks.claim_liveness,
    }
    if payload.get("id") == 1048600 and "expectedReward" in payload:
        if max(tasks._state(role)["liveclaimed"], default=0) + 1 != payload["expectedReward"]:
            tasks.send_sync(session, role)
            return
    callback = callbacks.get(payload.get("id"))
    if callback is None:
        raise ValueError("Unknown offline menu protocol")
    await callback(session, payload.get("fields", {}))
