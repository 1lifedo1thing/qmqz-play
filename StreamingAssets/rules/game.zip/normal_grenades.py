"""Bridge Unity projectile contacts to the APK's projectile registry and AoE resolver."""
from crisisfire import gamedata
from crisisfire.game import battle, bomb, grenades


def vec3(p):
    x, y, z = p
    return {"x":x, "y":y, "z":z}


class GrenadeCourt:
    def __init__(self, court, rule):
        self.fighters=court.fighters
        self.room=court.room
        self.room.levelid=rule
        self.is_invincible=court.is_invincible
        self.rule=rule
        self.started=True
        self.round_over=self.fight_over=False
        self.biochem=self.challenge=None
        self.grenade_projectiles={}
        self.grenade_serial=0
        self.round=1
        self.objective=bomb.Bomb(self) if self.room.gamemode==2 else None

    def next_round(self, number):
        if number!=self.round:
            self.grenade_projectiles.clear()
            self.round=number
            if self.objective:self.objective.reset()

    def send_all(self, msgid, **fields):
        if msgid in (battle.ID.SC_GRENADE_EXPLODE,bomb.SC_BOMB_EXPLODE):
            self.targets=fields['targets']

    def on_kill(self, source, target, itemid=0):
        # Combatant kill counters, respawns and the HUD consume these same deaths on Unity's ordered match thread.
        self.killed.add(target)

    def end_round(self, winner):
        self.winner=winner

    def adjudicate(self, msg):
        source=msg['source'];item=msg['weapon'];op=msg['op']
        if op=='grenadeThrow':
            landing=vec3(msg['landing']) if msg.get('bot') else None
            serial=grenades.throw(self,source,item,vec3(msg['impact']),vec3(msg['speed']),landing=landing)
            return dict(accepted=bool(serial),serial=serial,source=source,weapon=item)
        locations={p['role']:p['position'] for p in msg['positions']}
        if locations.keys()!=self.fighters.keys() or len(locations)!=len(msg['positions']):
            raise ValueError("Incomplete grenade target positions")
        for rid,p in locations.items():
            x,y,z=p
            self.fighters[rid].syncpos=(x/100,y/100,z/100)
        before={rid:(f.hp,f.ac) for rid,f in self.fighters.items()}
        self.targets=[];self.killed=set()
        serial=msg.get('serial',0)
        if op=='objectiveBlast':
            # bomb.Bomb._explode uses the rule's blastId and no thrown-projectile serial.
            if not self.objective or item!=(gamedata.rule(self.rule).get("blastId") or 711011):
                raise ValueError("Unexpected objective blast")
            planter=self.fighters.get(source)
            accepted=not self.objective.ended and planter is not None and planter.side==bomb.TERRIST
            if accepted:
                self.objective.pos=vec3(msg['impact'])
                self.objective.planted_by=source
                self.objective._explode()
        else:
            accepted=grenades.explode(self,source,item,serial,vec3(msg['impact']),bot=bool(msg.get('bot')))
        hits=[]
        for t in self.targets:
            rid=t['targetid'];f=self.fighters[rid]
            hits.append(dict(target=rid,beforeHp=before[rid][0],beforeAc=before[rid][1],
                afterHp=f.hp,afterAc=f.ac,hp=int(t['hpdamage']),ac=int(t['acdamage']),
                part=t['hitpart'],died=rid in self.killed,distance=t['sd']))
        return dict(accepted=accepted,serial=serial,source=source,weapon=item,hits=hits)
