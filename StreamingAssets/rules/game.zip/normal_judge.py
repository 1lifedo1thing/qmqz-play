"""Resident numeric authority for non-training, unrestricted team deathmatch. One page owns one match."""
import json
from types import SimpleNamespace

from crisisfire import gamedata
from crisisfire.game import battle, damage


def prepare():
    # These are lazily read from JSON by the original handler. Pay the cost on the room-loading screen.
    from crisisfire.game import bots, shop, special_modes, talent, weapon_catalog
    for name in ('Item','Gun','Melee','Ammo','Armor','DamageCoefficient'):
        damage._table(name)
    for name in ('GameRule','ResearchTalent','Gift'):
        gamedata.table(name)


class Court:
    def __init__(self, msg):
        rule=gamedata.rule(msg['rule'])
        if not rule or rule['gameMode']!=1 or msg.get('training') or msg.get('limit'):
            raise ValueError('Unexpected ordinary room rule')
        self.id=msg['match'];self.seq=0;self.last=None;self.last_request=None;self.now=0
        self.room=SimpleNamespace(gamemode=1,equiplimitid=0)
        self.biochem=None
        self.fighters={};self.protect={};self.lives={}
        for row in msg['players']:
            rid=row['role'];f=battle.Fighter(rid,row['name'],row['side']);self.fighters[rid]=f
            self.lives[rid]=0;self.dress(f,row);self.spawn(f,row)
        player=self.fighters[msg['owner']]
        data=SimpleNamespace(data=msg.get('traits',{}));player.research=battle._research_levels(data)
        chips=battle.chip_bonus(data)
        player.chip_adddmg=chips.get('addDmg',0);player.chip_pistolrange=chips.get('pistolrange',0);player.chip_meleerange=chips.get('meleerange',0)

    def dress(self,f,row):
        f.equipmap=dict(zip((11,12,50,31,32,33),row['equipment']))

    def spawn(self,f,row):
        self.lives[f.roleid]+=1;f.hp=f.hp_max=row['hp'];f.ac=f.ac_max=row['ac'];f.born=True
        self.protect[f.roleid]=row['protect']

    def is_invincible(self,role):
        return self.now<self.protect[role]

    def apply(self,msg):
        seq=msg['seq'];op=msg['op']
        if seq==self.seq and msg==self.last_request: return self.last
        if seq!=self.seq+1: raise ValueError('Unexpected combat sequence')
        self.now=msg['now']
        if op=='spawn':
            row=msg['player'];f=self.fighters[row['role']]
            if f.hp>0: raise ValueError('Spawned living fighter')
            self.dress(f,row);self.spawn(f,row);out={}
        elif op=='equip':
            row=msg['player'];f=self.fighters[row['role']];self.dress(f,row);f.ac=f.ac_max=row['ac'];out={}
        elif op=='external':
            f=self.fighters[msg['target']]
            if (f.hp,f.ac)!=(msg['beforeHp'],msg['beforeAc']):raise ValueError('External damage out of order')
            f.hp=msg['afterHp'];f.ac=msg['afterAc'];out={}
        elif op=='shoot':
            src=self.fighters[msg['source']];dst=self.fighters[msg['target']]
            before=(dst.hp,dst.ac);hits=[]
            pos=damage.equip_pos(msg['weapon']);src.weaponpos=pos if pos in (11,12,50) else 0
            if src.hp>0 and src.equipmap.get(src.weaponpos)==msg['weapon']:
                ammo=damage._table('Ammo').get(msg['ammo'],{}) if msg['ammo'] else {}
                gun=damage._table('Gun').get(msg['weapon'],{})
                if msg['ammo'] and (not ammo or gun.get('vipAmmo')!=msg['ammo']):raise ValueError('Incompatible authorized ammo')
                x,y,z=msg['from'];tx,ty,tz=msg['to'];hx,hy,hz=msg['impact']
                shot={'position':dict(x=x,y=y,z=z),'targets':[{'targetid':dst.roleid,'sd':msg['distance'],'hitpart':msg['part'],
                      'hitpos':dict(x=hx,y=hy,z=hz),'targetpos':dict(x=tx,y=ty,z=tz)}]}
                hits=damage.resolve_shoot(self,src.roleid,shot,ammo=ammo)
            hit=hits[0] if hits else None
            out=dict(accepted=bool(hit),hp=hit.hpdamage if hit else 0,ac=hit.acdamage if hit else 0,
                     beforeHp=before[0],beforeAc=before[1],afterHp=dst.hp,afterAc=dst.ac,died=bool(hit and hit.died),
                     life=self.lives[dst.roleid],target=dst.roleid,source=src.roleid,part=msg['part'],weapon=msg['weapon'])
        else: raise ValueError('Unknown combat operation')
        self.seq=seq;self.last_request=msg;self.last={**out,'ok':True,'match':self.id,'seq':seq,'op':op};return self.last


current=None
def command(raw):
    global current
    msg=json.loads(raw)
    if msg['op']=='open':
        if current is not None:raise ValueError('A combat match is already open')
        current=Court(msg);owner=current.fighters[msg['owner']]
        answer={'ok':True,'op':'open','seq':0,'match':current.id,'knifeScale':1+owner.chip_meleerange*.01,'pistolScale':1+owner.chip_pistolrange*.01}
    elif current is None or msg['match']!=current.id: raise ValueError('Unknown combat match')
    elif msg['op']=='close':
        answer={'ok':True,'op':'close','seq':current.seq,'match':current.id};current=None
    else:answer=current.apply(msg)
    return json.dumps(answer,separators=(',',':'))
