"""Route poster transactions to the original offline handlers."""
from crisisfire.game import profile, research, shop


async def dispatch_poster(world, session, payload):
    callbacks = {
        shop.ID.CS_BUY_GIFT: shop.on_buy_gift,
        shop.ID.CS_BUY_VIP_GIFT: shop.on_buy_vip_gift,
        research.ID.CS_EXCHANGE_PARTS: research.on_exchange_parts,
        profile.ID.CHANGE_ICON: profile.on_change_icon,
    }
    callback = callbacks.get(payload.get("id"))
    if callback is None:
        return False
    await callback(session, payload.get("fields", {}))
    return True
