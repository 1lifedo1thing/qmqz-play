"""Keep the native 1/2 tree selector, cost and refund in one Worker save operation."""
from crisisfire import gamedata
from crisisfire.game import shop, talent


async def dispatch_talent(world, session, payload):
    action = payload.get("id")
    if action not in (talent.ID.CS_ADD_TALENT, talent.ID.CS_ADD_RESEARCH, talent.ID.CS_RESET):
        return False
    role = world.role(session.roleid)
    fields = payload.get("fields", {})
    if role.level < 5:
        talent.push_on_login(session, role)
        return True
    if action == talent.ID.CS_ADD_TALENT:
        await talent.on_add_talent(session, fields)
    elif action == talent.ID.CS_ADD_RESEARCH:
        await talent.on_add_research(session, fields)
    else:
        tree = fields.get("talenttype")
        if tree not in (1, 2):
            return True
        price = next(p for p in gamedata.table("Price") if p["id"] == 9 + tree)["gem"]
        levels = talent.talents(role) if tree == 1 else talent.research_talents(role)
        if role.gold < price:
            shop._push_money(session, role)
            talent.push_on_login(session, role)
            return True
        # The original client passes a whole-tree selector. The APK's local reset_type
        # treats it as an attribute type across both trees and never debits the price.
        if levels:
            if tree == 1:
                world.merge_role_data(role.roleid, talents={})
            else:
                world.merge_role_data(role.roleid, research_talents={},
                                      research_point=talent.research_point_of(role) + sum(levels.values()))
            world.update_role(role.roleid, gold=role.gold-price)
        updated = world.role(role.roleid)
        session.send(talent.ID.SC_RESET, talenttype=tree)
        shop._push_money(session, updated)
        talent.push_on_login(session, updated)
    return True
