"""Adapt the browser's local character and the Unity match result to the original offline game handlers."""
import asyncio
import json
import os
import random
import time
from types import SimpleNamespace

# The APK launcher supplies both options to its embedded offline game.
os.environ.update(CF_BOTS="4", CF_UNLOCK_EQUIPMENT="1")
import full_profile
import challenge_cards
from menu_actions import dispatch_menu
from crisisfire import gamedata
from crisisfire.game import battle, bio_rules, biochem, equip, equipment, handlers, pve, pve_revive, rooms, rank_profiles, rank_queue, robot, room_fill, room_handlers
from crisisfire.game.world import World
from crisisfire.net.server import Session

world = World(":memory:")
handlers.bind_world(world)


class LocalSession(Session):
    def __init__(self, role):
        super().__init__(None, None, "gs")
        self.roleid, self.role_name, self.userid = role.roleid, role.name, role.userid
        self.messages = []

    def send(self, type_id, **fields):
        # openau.ServerIDResponse uses an Octets server ID in a full lobby-state push.
        if type_id == handlers.ID.SC_SERVER_ID and isinstance(fields.get("serverid"), bytes):
            fields["serverid"] = list(fields["serverid"])
        self.messages.append({"id": type_id, "fields": fields})


def restore(snapshot):
    rid = snapshot["roleid"]
    world._db.execute("INSERT OR IGNORE INTO roles(roleid,userid,name,created) VALUES(?,?,?,?)",
                      (rid, rid, snapshot["name"], time.time()))
    role = world.role(rid)
    for field in ("name", "level", "exp", "gold", "money", "diamond", "iconid"):
        setattr(role, field, snapshot[field])
    data = snapshot.get("originalData") or {}
    previous = snapshot.get("equipment")
    if previous and not data.get("web_full_unlock_version"):
        # Old saves can have only the public inventory, or default loadouts materialized only in the snapshot.
        data.setdefault("pkg_items", previous.get("ownedItems", []))
        data.setdefault("active_equip", previous.get("activeindex", 0))
        chosen = data.setdefault("chosen_actor", {})
        for camp, key in ((1,"policeactorid"), (2,"terristactorid"), (3,"bioactorid")):
            if previous.get(key):
                chosen.setdefault(str(camp), previous[key])
        if not data.get("loadouts") and previous.get("loadouts"):
            data["loadouts"] = [{"equipmap": {str(s["position"]):s["itemId"] for s in group["slots"]}}
                                for group in previous["loadouts"]]
    role.data = data
    world.save_role(role)
    return full_profile.upgrade(role, world)


def subjoin_slots(mapping):
    return [{"actor":actor,"pos":pos,"itemId":item} for actor, slots in mapping.items() for pos, item in slots.items()]


def equipment_state(role):
    group = equip.equip_group_payload(role)
    return {"activeindex": group["activeindex"], "ownedItems": sorted(equip.owned_ids(role)),
            "ownedActors": sorted(int(key) for camp in ("policeactors","terristactors","bioactors") for key in group[camp]),
            "policeactorid": group["curpoliceactor"], "terristactorid": group["curterristactor"],
            "bioactorid": group["curbioactor"],
            "subjoins": subjoin_slots(equip.subjoins_of(role)),
            "paidAmmo": [{"id":item,"count":full_profile.premium_ammo.count(role,item)} for item in full_profile.premium_ammo.paid_rows()],
            "loadouts": [full_profile.loadout(row) for row in group["equips"]]}


def game_room(rule, members, **parameters):
    level = gamedata.map_row(rule["mapId"])
    canonical = next(m["id"] for m in gamedata.maps() if m["scene"] == level["scene"])
    mode = next(m for m in gamedata.game_modes() if m["id"] == rule["gameMode"])
    return dict(ruleId=rule["id"],mapId=level["id"],mapName=level["name"],canonicalId=canonical,
                gameMode=mode["id"],modeName=mode["name"],members=members,players=len(members),
                capacity=len(members), **parameters)


def room_members(room):
    slots = {1:0, 2:0}
    members = []
    for member in room.members.values():
        seat = {key:getattr(member,key) for key in ("name","roleid","iconid","level","side","ready")}
        members.append(dict(seat,slot=slots[member.side],subjoins=subjoin_slots(member.subjoins)))
        slots[member.side] += 1
    return members


async def create_room(session, fields):
    line = fields["line"]
    if not 0 <= line < room_fill.LOBBY_LINES or fields["mode"] not in (1,12):
        return None
    await room_handlers.on_create_room(session, {"line":line})
    room = room_handlers.MANAGER.room_of(session.roleid)
    try:
        if fields["mode"] == 12:
            # ModeCreateDlg.ChangeToPVE selects GetNextMapId(current map, 12).
            maps = [row["id"] for row in gamedata.maps() if row.get("status")==1 and
                    any(rule["gameMode"]==12 for rule in gamedata.rules_for_map(row["id"]))]
            index = maps.index(room.mapid)+1 if room.mapid in maps else 0
            info = dict(room.roominfo(),mapid=maps[index%len(maps)],gamemode=12,equiplimitid=0,playerlimits=4)
            await room_handlers.on_change_room_info(session, {"roomid":room.roomid,"roominfo":info})
        rule = gamedata.rule(room.levelid)
        result = game_room(rule,room_members(room),roomId=room.roomid,isOwner=True,title=room.title,
                           equiplimitid=room.equiplimitid)
        result["capacity"] = room.playerlimits
        return result
    finally:
        # The waiting and in-match roster live in Unity, just like a room joined from the list.
        room_handlers.MANAGER.leave(room.roomid,session.roleid)


def make_rank_room(session, kind):
    rule, limit = rank_profiles.pick_rule(kind)
    old = room_handlers.MANAGER.room_of(session.roleid)
    if old:
        room_handlers.MANAGER.remove(old.roomid)
    player = room_handlers._member_of(session)
    room = room_handlers.MANAGER.create(player, levelid=rule["id"])
    if room.gamemode != 4:
        player.side = random.choice((1,2))
    player.ready = True
    room.local_rank_match, room.local_rank_type, room.equiplimitid = True, kind, limit
    room_fill.fill(room)
    rank_queue.attach_ticket(room, player.roleid)
    return game_room(rule,room_members(room),roomId=room.roomid,equiplimitid=limit,ranked=True,rankType=kind)


def robot_room(role, fields, custom):
    roster = {bot["id"]:bot for bot in gamedata.table("RobotDesc")}
    if custom:
        rule = next((r for r in gamedata.game_rules() if r["gameMode"] == fields["gameMode"] and
                     r["mapId"] == fields["mapId"]), None)
        if not rule or fields["side"] not in (1,2):
            return None
        side = fields["side"]
        teams = [fields["police"],fields["terrorists"]]
        levelid, ratios = -1, [100,100,100]
    else:
        levelid = fields
        cfg = robot.ai_level(levelid)
        if not cfg or levelid > robot.max_robot_level():
            return None
        rule, side = gamedata.rule(cfg["levelId"]),cfg["camp"]
        teams = [cfg[key]["_items"][:cfg[key]["_size"]] for key in ("teamates","enemies")]
        if side == 2:
            teams.reverse()
        ratios = [cfg[key] for key in ("winKillRatio","damageRatio","rebornTimeRatio")]
    members = [dict(name=role.name,roleid=role.roleid,iconid=role.iconid,level=role.level,side=side,slot=0,ready=True)]
    for camp, ids in enumerate(teams,1):
        for index, key in enumerate(ids):
            if key not in roster or key == 0:
                continue
            bot = roster[key]
            members.append(dict(name=bot["name"],roleid=900000+len(members),iconid=bot["head"],level=bot["rank"],
                                side=camp,slot=index+int(camp==side),ready=True,actorId=bot["actorId"],
                                primary=bot["primWeapon"],secondary=bot["viceWeapon"],knife=bot["dagger"],
                                aiLevel=bot["level"],killScore=bot["killScore"]))
    return game_room(rule,members,roomId=0,trainingLevel=levelid,winKillRatio=ratios[0],damageRatio=ratios[1],
                     rebornTimeRatio=ratios[2],autoAim=bool(custom and fields.get("autoAim")),
                     equiplimitid=fields.get("equiplimitid",0) if custom else 0)


def settle(role, fields):
    room = SimpleNamespace(roomid=fields["roomId"], gamemode=fields["gameMode"], equiplimitid=fields["equipLimit"])
    if fields.get("rankType", -1) in (0,1):
        room.local_rank_match, room.local_rank_type = True, fields["rankType"]
    fighter = battle.Fighter(role.roleid, role.name, fields["side"])
    fighter.kills, fighter.deaths, fighter.score = (fields[k] for k in ("kills","deaths","score"))
    fighter.born_at = time.time()
    result = SimpleNamespace(room=room, fighters={role.roleid: fighter})
    battle.Battle.reward_players(result, fields["winnerSide"], role.roleid if fields["wonSolo"] else 0)


def settle_challenge(session, role, fields):
    """Feed Unity's measured combat totals into the APK's original Challenge.finish."""
    rid = role.roleid
    rule = gamedata.rule(fields["ruleId"])
    room = rooms.Room(fields["roomId"], rid, rule["id"], rule["mapId"], 12, 1)
    room.members[rid] = room_handlers._member_of(session)
    fight = battle.Battle(room)
    fighter = battle.Fighter(rid, role.name, 1)
    fighter.born, fighter.deaths = True, fields["deaths"]
    fight.fighters[rid] = fighter
    challenge = pve.Challenge(fight)
    challenge.started = True
    challenge.loop = asyncio.get_running_loop()
    challenge.started_at = challenge.loop.time() - fields["elapsed"]
    challenge.participants.add(rid)
    challenge.index = fields["wave"] - 1
    challenge.damage[rid] = fields["damage"]
    challenge.kills[rid] = fields["kills"]
    challenge.time_bonus[rid] = fields["timeBonus"]
    challenge.support.pickups[rid] = fields.get("pickups", 0)
    # finish() itself grants the survival medal.
    challenge.medals.counts[rid].update(int(m) for m in fields.get("medals", []) if m != 5)
    challenge.finish(fields["winnerSide"] == 1)
    detail = next(message["fields"] for message in session.messages if message["id"] == pve.SC_DETAIL)
    won = fields["winnerSide"] == 1
    mode = challenge.mode
    challenge_cards.remember(world, session, fields, mode, detail)
    return {"exp":mode["expReward"] + detail["vipexp"] if won else 0,
            "gold":mode["goldReward"] + detail["vipmoney"] if won else 0,
            "bloodgem":mode["honoReward"] + detail["firstwinbloodgem"] if won else 0}


def bio_opening(role, fields):
    """Run the supplied APK's infection decisions for this offline room's fixed roster."""
    from crisisfire.config import CONFIG
    rule = gamedata.rule(fields["ruleId"])
    ids = fields["roleIds"]
    if (not rule or rule["gameMode"] not in biochem.BIOCHEM_MODES or len(ids) < 2
            or ids[0] != role.roleid or len(set(ids)) != len(ids)):
        raise ValueError("生化房间或出场角色不匹配")
    room = rooms.Room(fields["roomId"], role.roleid, rule["id"], rule["mapId"], rule["gameMode"], len(ids))
    fight = battle.Battle(room)
    rounds = []
    for _ in range(fight.total_rounds):
        fight.fighters = {rid: battle.Fighter(rid, str(rid), 1) for rid in ids}
        for fighter in fight.fighters.values():
            fighter.born, fighter.hp = True, 100
        state = biochem.Biochem(fight)
        try:
            state._activate_infection()
            rounds.append(dict(mother=ids.index(state.matrix),
                               shields=[state.protect.get(rid, 0) for rid in ids]))
        finally:
            state.cancel_picks()
    # refresh_hp includes the APK's bot modifier. Precompute the finite set of
    # level-zero values so a local respawn can resolve in the same Unity frame.
    health = []
    state = biochem.Biochem(fight)
    state.zombies.update(ids[:2])
    for actor in bio_rules.zombie_choices():
        row = dict(id=actor, perLevel=biochem.bio_property_of(actor)["hpPlus"])
        for rid, normal, mother in ((ids[0], "player", "playerMother"), (ids[1], "bot", "botMother")):
            fight.fighters[rid].actorid = actor
            state.matrices.discard(rid)
            row[normal] = state.refresh_hp(rid)
            state.matrices.add(rid)
            row[mother] = state.refresh_hp(rid)
        health.append(row)
    return dict(rounds=rounds, health=health, preparation=state.rule["infectTime"],
                duration=int(state.time_left()), heroAt=CONFIG.biochem_hero_time)


async def command(raw):
    request = json.loads(raw)
    if request["action"]=="local-social":
        import local_social
        return json.dumps(await local_social.command(request,LocalSession),ensure_ascii=False)
    role = restore(request["profile"])
    if request["action"] == "bio-opening":
        return json.dumps(bio_opening(role, request["fields"]))
    session = LocalSession(role)
    world.attach(session)
    world.mark_online(role.roleid, session)
    action, fields = request["action"], request["fields"]
    activity = reward = None
    revive_accepted = False
    spent_ammo = False
    ticket = role.data.get("webRankTicket")
    if ticket:
        rank_queue.LEDGER[next(rank_queue._TICKET_SEQ)] = ticket
    try:
        if action == "loadout" and 0 <= fields < len(equip.loadouts_of(role)):
            await equipment.on_set_active(session, {"activeindex": fields})
        elif action == "paid-shot":
            slot = fields.get("slot")
            item = fields.get("ammoId")
            group = equip.equip_group_payload(role)
            equipped = group["equips"][group["activeindex"]]["equipmap"]
            weapon = equipped.get(slot, equipped.get(str(slot)))
            premium = full_profile.premium_ammo
            row = premium._for_weapon(weapon) if slot in (11,12) and weapon == fields.get("weapon") else None
            if row and item == row["id"] and premium.count(role,item) > 0:
                changes, before = premium.stock_change(role,{item:-1})
                world.award_local(role.roleid,changes)
                premium.sync_stock(session,world.role(role.roleid),before)
                spent_ammo = True
        elif action == "actor":
            await equipment.on_set_default_actor(session, {"actorid": fields})
        elif action == "equip":
            if fields["weaponid"] == -1:
                await equipment.on_de_equip(session, fields)
            else:
                await equipment.on_equip(session, fields)
        elif action == "menu":
            await dispatch_menu(world,session,fields)
        elif action == "room-create":
            activity = await create_room(session,fields)
        elif action == "challenge-revive":
            # Unity owns the active fight and the fallen fighter. The wallet and the charge schedule live here.
            rule = gamedata.rule(fields["ruleId"])
            remaining = pve_revive.FREE_IMMEDIATE - request["revivesUsed"]
            if rule and rule["gameMode"] == 12 and fields["times"] == remaining:
                price = pve_revive.revive_price(remaining)
                if role.gold >= price:
                    if price:
                        world.award_local(role.roleid, {}, gems=-price)
                    revive_accepted = True
        elif action == "settle":
            if fields.get("range"):
                await robot.on_range_result(session, {"score":fields["score"]})
            elif fields.get("gameMode") == 12:
                reward = settle_challenge(session,role,fields)
            elif fields.get("trainingLevel",0) > 0:
                await robot.on_robot_result(session, {"level":fields["trainingLevel"],"passed":int(fields["side"]==fields["winnerSide"]),
                    "score":fields["score"],"kill":fields["kills"],"death":fields["deaths"]})
            elif fields.get("trainingLevel",0) == 0:
                settle(role, fields)
        elif action in ("robot","robot-custom"):
            activity = robot_room(role,fields,action=="robot-custom")
        elif action == "rank-queue" and fields in (0,1):
            if role.data.get("webRankWaiting") is None and (fields==0 or rank_queue._charge_ticket(session)):
                role.data["webRankWaiting"] = fields
                session.send(1245231,ranktype=fields,ready=0,waittime=3)
        elif action == "rank-found" and role.data.get("webRankWaiting") == fields:
            activity = make_rank_room(session, fields)
            role.data.pop("webRankWaiting", None)
        elif action == "rank-cancel":
            rank_queue._refund_pending(session)
            role.data.pop("webRankWaiting",None)
            session.send(1245228,roleid=role.roleid)
        elif action == "double":
            pending = request.get("pending")
            if pending:
                battle.PENDING_DOUBLE[role.roleid] = pending
            await battle.on_double_reward(session, {})
        current = world.role(role.roleid)
        current.data["webRankTicket"] = next((entry for entry in rank_queue.LEDGER.values() if entry["roleid"]==role.roleid),None)
        values = {k:getattr(current,k) for k in ("name","level","exp","gold","money","diamond","iconid")}
        values["talentHp"] = battle._talent_hp(current)
        return json.dumps({"values":values, "equipment":equipment_state(current), "originalData":current.data,
                           "reviveAccepted":revive_accepted, "spentAmmo":spent_ammo,
                           "robotOpenId":robot.max_robot_level(), "robotCleared":current.data.get("web_training_clears",[]), "robotBestScore":current.data.get("range_max_score",0),
                           "rankWaiting":current.data.get("webRankWaiting",-1),"activity":activity,
                           "reward":reward, "messages":session.messages, "pending":battle.PENDING_DOUBLE.get(role.roleid)}, ensure_ascii=False)
    finally:
        world.detach(session)
        battle.PENDING_DOUBLE.pop(role.roleid, None)
        for key in [key for key,row in rank_queue.LEDGER.items() if row["roleid"]==role.roleid]:
            rank_queue.LEDGER.pop(key)
